
/**
 * 
 */

class AVerticalEvent extends AEvent
{
	constructor(acomp)
	{
		super(acomp);
	}

}
window.AVerticalEvent = AVerticalEvent;


