
function EXJisooChartDemo()
{
    BaseChartDemo.call(this);
    
	this.delegator = null;
	this.divisionVal = 1;
	
	this.preScale = 1;
	this.rateVal = 1;
	this.zoomState = 0;
    
    this.lastDist = 0;
    this.scollSX = 0;
    this.scollEX = 0;
    this.speed = 10;
    
    //-----------------------------------
    //이동시간을 구함
    this.mStartTime = 0;
    this.mOldTime = 0;
    //이동거리를 구함
    this.mStartX = 0;
    this.mEndX = 0;
    this.mScrollLR = false;
    this.timer = null;
    //----------------------------------------------
    
    this.offset = 0;
    this.startIdx = 0;
	this.startLineX = 0;
    this.endIdx = 0;
	this.BAR_CNT = 50;
	this.prdCls = 0;			//0:월, 1:주, 2:일, 5:분, 7틱
	//this.prdCls구분에 따른 datetime 표시
	this.dateformatFunc = 
	[
		afc.formatDate,
		afc.formatDate,
		afc.formatMonth,
		null,
		null,
		afc.formatDateTime,
		null,
		afc.formatTic
	];
	this.dateformat = this.dateformatFunc[this.prdCls];
    this.dashType = [1.5,4];
    
    this.TEXT_SIZE = '16px';            //텍스트 사이즈
    
   	this.colorObj = 
    {
    	BACK: StockColor.BACK, 
    	TEXT: StockColor.TEXT,
    	DOT: StockColor.DOT,
    	DIVLINE : StockColor.DIVLINE,
    	LINE: StockColor.LINE,
    	START: StockColor.START,
    	END: StockColor.END
    };
    
    this.touchEvent = null;
    this.isFirst = true;

    this.ROW_CNT = 14;          //금액 로우 간격 나누기 계산용 변수
    this.AM_R_WIDTH = 100;      //상단,하단 오른쪽 금액영역 너비
    this.AM_L_WIDTH = 0;      	//상단,하단 왼쪽 금액영역 너비
	this.MAX_BAR_W = 80;		//최대 봉 너비
    this.DEF_BAR_W = 8;       	//기본 봉 너비
    this.BAR_TERM = 0;          //봉차트간 간격
    
    this.upGrpMaxAm = 0;       	//상단 그래프 최대값
    this.upGrpMinAm = 0;       	//상단 그래프 최소값
    
    //포지션에 관련된 객체
    this.pos = 
    {     
        cavasW: 0,          //전체 캔버스 너비
        cavasH: 0,          //전체 캔버스 높이
        grpW: 0,            //상단,하단 그래프영역 너비
		grpEX: 0,           //상단,하단 그래프영역 끝 X좌표
        dtXs: [],           //상단,하단 그래프 세로구분 X좌표 배열 [1, 2, 3번째]
        amYs: [],           //상단 그래프 금액 구분선 Y좌표 배열[금액1, 금액2, 금액3, 금액4, 금액5]
        amPad: 0,           //금액 오른쪽 정렬시 마진
        txtY: 0,            //텍스트 세로 중간 정렬을 위한 Y위치  
        
        upGrpSY: 0,         //상단 그래프 시작 Y좌표
        upDtY: 0,           //상단 그래프 Date 영역 Y
        upGrpEY: 0,         //상단 그래프 끝 Y좌표
        upGrpH: 0,          //상단 그래프 그리는 영역 높이
        
        upRateH:  0,        //상단 높이 비율
        
        barW: this.DEF_BAR_W, //봉차트 너비
        
        barTot: 0           //봉차트 너비에 봉과 봉사이의 간격을 더한값(한봉이 그려지는 영역)
    };    
    
    this.compLeft = 0;  //엘리먼트의 Left 지점
    this.middleX = 0;   //엘리먼트의 중간X 지점
    
}
afc.extendsClass(EXJisooChartDemo, BaseChartDemo);

EXJisooChartDemo.prototype.init = function(context, evtListener)
{
    BaseChartDemo.prototype.init.call(this, context, evtListener);
    
    this.isFirst = true;
    
    this.title = this.element.children[1];
    
    this.infoDiv = this.element.children[2];
    this.longXdiv = this.element.children[3];
    this.longYdiv = this.element.children[4];
    
	this.zoomDiv = this.element.children[5];
	this.zoomInDiv = this.zoomDiv.children[0];
	this.zoomOutDiv = this.zoomDiv.children[1];
	
	//this.initEvent();
};

EXJisooChartDemo.prototype.initEvent = function()
{
	this.setTouchEvent();
    this.setZoomEvent();	
};

//그래프의 너비 및 높이를 업데이트
EXJisooChartDemo.prototype.updatePosition = function(pWidth, pHeight)
{
    BaseChartDemo.prototype.updatePosition.call(this, pWidth, pHeight);
    this.calcPosition(this.eleW, this.eleH);
    this.setData(jisoo_data);
};

EXJisooChartDemo.prototype.setZoomEvent = function()
{
	var thisObj = this;
	
	//zoomIn 버튼 클릭 리스너
	$(this.zoomInDiv).bind(afc.ACTION_UP, function(event){
		
		if(!thisObj.data || thisObj.data.length == 0) return;
		
		if(thisObj.zoomState != 1)
		{
			thisObj.rateVal = 1.0;
			thisObj.zoomState = 1;
		}
		thisObj.rateVal = parseFloat(thisObj.rateVal) + 0.01;
		thisObj.zoomInOut();
	});
	
	//zoomOut 버튼 클릭 리스너
	$(this.zoomOutDiv).bind(afc.ACTION_UP, function(event){
		
		if(!thisObj.data || thisObj.data.length == 0) return;
		
		if(thisObj.zoomState != 2)
		{
			thisObj.rateVal = 1.0;
			thisObj.zoomState = 2;
		}
		thisObj.rateVal = parseFloat(thisObj.rateVal) - 0.01;
		thisObj.zoomInOut();
	});	
};

//델리게이터를 셋팅(데이터를 더 필요로할때 이벤트를 날려줌)
EXJisooChartDemo.prototype.setDelegator = function(delegator)
{
    this.delegator = delegator;
};

EXJisooChartDemo.prototype.setDivisionVal = function(divisionVal)
{
    this.divisionVal = divisionVal;
};

EXJisooChartDemo.prototype.setColors = function(colors)
{
    for(var key in colors)
        if(colors.hasOwnProperty(key)) this['COLOR_'+key] = colors[key];
};

EXJisooChartDemo.prototype.setTitle = function(title)
{
    this.title.textContent = title;
};


//1.컴포넌트의 너비와 높이값을 이용하여 canvas에 들어갈 영역 x y 셋팅   
EXJisooChartDemo.prototype.calcPosition = function(elWidth, elHeight)
{
            
    this.pos.cavasW = elWidth;
    this.pos.cavasH = elHeight;
    
    this.pos.grpEX = elWidth - this.AM_R_WIDTH;
    this.pos.grpW = this.pos.grpEX - this.AM_L_WIDTH;
	
    this.pos.amPad = elWidth - 5; 
    
    this.pos.dtXs = [ this.AM_L_WIDTH + this.pos.grpW*0.25, this.AM_L_WIDTH + this.pos.grpW*0.5, this.AM_L_WIDTH + this.pos.grpW*0.75 ]; 
    
    this.pos.upGrpSY = elHeight/this.ROW_CNT;
    this.pos.txtY = (this.pos.upGrpSY/2);
    this.pos.upGrpEY = this.pos.upGrpSY*13;
    this.pos.upGrpH = this.pos.upGrpEY - this.pos.upGrpSY;  
    this.pos.upDtY = this.pos.upGrpEY + this.pos.txtY; 
    this.pos.amYs = [ this.pos.upGrpSY, this.pos.upGrpSY*4, this.pos.upGrpSY*7, this.pos.upGrpSY*10, this.pos.upGrpSY*13 ];
    
    //텍스트 사이즈 셋팅
    if(elWidth < elHeight) this.TEXT_SIZE = (this.pos.cavasW*0.03) + 'px';  
    else this.TEXT_SIZE = (this.pos.cavasH*0.03) + 'px';
	
    this.pos.barTot = this.pos.grpW/this.BAR_CNT;
    this.pos.barW = (this.pos.barTot - this.BAR_TERM);
    
    this.startLineX = this.pos.grpEX;
    
};

//데이터 입력
EXJisooChartDemo.prototype.setData = function(dataArr, keyArr)
{
	this.resetData();
	if(!keyArr)
	{
		var keyLength = dataArr[0].length;
		
		keyArr = new Array();
		for(var i = 0; i<keyLength; i++)
		{
			keyArr.push(i);
		}
	}
	
	var data = null;
	
	for(var i=0; i<dataArr.length; i++)
	{
		data = dataArr[i];
		
		this.data.push([
			data[keyArr[0]],
			data[keyArr[1]]/this.divisionVal,
			data[keyArr[2]]/this.divisionVal,
			data[keyArr[3]]/this.divisionVal,
			data[keyArr[4]]/this.divisionVal,
			data[keyArr[5]]/this.divisionVal,
			data[keyArr[6]]/this.divisionVal
		]);
	}
	
	this.updateGraph();
};

//맨처음 데이터를 불러오는지 여부 셋팅
EXJisooChartDemo.prototype.setIsFirst = function(isFirst)
{
    this.isFirst = isFirst;
};

//맨처음 데이터를 불러오는지 여부 가져오기
EXJisooChartDemo.prototype.getIsFirst = function()
{
    return this.isFirst;
};

//일자 또는 시간일 경우에 따른 표현 포멧 함수 셋팅
EXJisooChartDemo.prototype.setPrdCls = function(prdCls)
{
    this.prdCls = prdCls;
	this.dateformat = this.dateformatFunc[this.prdCls];
};

//차트 드로잉데이터를 리셋
EXJisooChartDemo.prototype.resetData = function()
{
	
	this.preScale = 1;
	this.rateVal = 1;
	this.zoomState = 0;
    
    this.lastDist = 0;
    this.scollSX = 0;
    this.scollEX = 0;
    this.speed = 0;
    
    //-----------------------------------
    //이동시간을 구함
    this.mStartTime = 0;
    this.mOldTime = 0;
    //이동거리를 구함
    this.mStartX = 0;
    this.mEndX = 0;
    this.mScrollLR = false;
    this.timer = null;
    //----------------------------------------------
    
    this.offset = 0;
    this.startIdx = 0;
    this.endIdx = 0;
	
	//주석처리 해봐야 할것 50일 넣으면 오른쪽으로 밀리는 현상 발견
	//this.BAR_CNT = 50;
	this.pos.barTot = this.pos.grpW/this.BAR_CNT;
    this.pos.barW = (this.pos.barTot - this.BAR_TERM);
    
    this.isFirst = true;
    
    this.upGrpMaxAm = 0;       //상단 그래프 최대값
    this.upGrpMinAm = 0;       //상단 그래프 최소값
    
	this.nextIqryDate = '';
    this.data = new Array();
	
	//백그라운드 클리어
    //this.ctx.fillStyle = this.colorObj.BACK;
    this.ctx.clearRect(0, 0, this.pos.cavasW, this.pos.cavasH);
	
	this.drawBackLine();
	
};

//상 하단 그래프 최대최소 구하기
EXJisooChartDemo.prototype.setMaxMin = function()
{
    this.upGrpMaxAm = 0;
    this.upGrpMinAm = Number.MAX_VALUE;
    var val = null;
    
    for(var i = this.startIdx; i < this.endIdx; i++)
    {
        val = this.data[i][4];
        if(val > this.upGrpMaxAm) this.upGrpMaxAm = val;
        if(val < this.upGrpMinAm) this.upGrpMinAm = val;    
    }
    this.pos.upRateH = (this.pos.upGrpEY - this.pos.upGrpSY)/(this.upGrpMaxAm - this.upGrpMinAm);
    
};

//차트 드로우 함수 모음
EXJisooChartDemo.prototype.draw = function()
{   
    //백그라운드 클리어
    //this.ctx.fillStyle = this.colorObj.BACK;
    this.ctx.clearRect(0, 0, this.pos.cavasW, this.pos.cavasH);
    
    //텍스트 기본 셋팅
    this.ctx.font = this.TEXT_SIZE +" '"+this.FONT_FAMILY+"'";
    this.ctx.textBaseline = 'middle';
    
    this.drawBackLine();
    this.drawGraph();
};

//백그라운드 기본 라인 그리기
EXJisooChartDemo.prototype.drawBackLine = function()
{

    //도트 그리기
    this.ctx.beginPath();
    this.ctx.lineWidth = 1.5;
    this.ctx.strokeStyle = this.colorObj.DOT;
    
    //가로선
    for(var i = 0; i<5; i++)
        this.drawDashedLine(this.AM_L_WIDTH + 0, this.pos.amYs[i], this.pos.grpEX, this.pos.amYs[i], this.dashType);
    
    //세로선
    for(var i = 0; i<3; i++)
        this.drawDashedLine(this.pos.dtXs[i]-1, 0, this.pos.dtXs[i], this.pos.upGrpEY, this.dashType);
    
    this.ctx.stroke();
    this.ctx.closePath();
    
    /*    
    //우측 금액 구분선 그리기
    this.ctx.beginPath();
    this.ctx.strokeStyle = this.colorObj.DIVLINE;
    this.ctx.moveTo(this.pos.grpEX, 0);
    this.ctx.lineTo(this.pos.grpEX, this.pos.cavasH);
    this.ctx.stroke();
    this.ctx.closePath();
    */
    
}; 

//그래프 그리기
EXJisooChartDemo.prototype.drawGraph = function()
{
	if(!this.data || this.data.length == 0) return;
	
    var lineX = this.pos.grpEX;
    var firstY = 0;
    var lineY = 0;
    
    //상하단 텍스트 그리기
    this.ctx.fillStyle = this.colorObj.TEXT;
    this.ctx.textAlign = 'center';
	
	var dtX1 = this.data[parseInt(this.BAR_CNT*0.75) + this.startIdx];
	var dtX2 = this.data[parseInt(this.BAR_CNT*0.5) + this.startIdx];
	var dtX3 = this.data[parseInt(this.BAR_CNT*0.25) + this.startIdx];
	
	if(dtX1) this.ctx.fillText(this.dateformat(dtX1[0]), this.pos.dtXs[0], this.pos.upDtY);
	if(dtX2) this.ctx.fillText(this.dateformat(dtX2[0]), this.pos.dtXs[1], this.pos.upDtY);
	if(dtX3) this.ctx.fillText(this.dateformat(dtX3[0]), this.pos.dtXs[2], this.pos.upDtY);
	
    this.ctx.textAlign = 'right';
    
    this.ctx.fillText(afc.addComma(this.upGrpMaxAm.toFixed(2)), this.pos.amPad, this.pos.amYs[0]);
    this.ctx.fillText(afc.addComma((this.upGrpMaxAm - (this.upGrpMaxAm-this.upGrpMinAm)*0.25).toFixed(2)), this.pos.amPad, this.pos.amYs[1]);
    this.ctx.fillText(afc.addComma((this.upGrpMaxAm - (this.upGrpMaxAm-this.upGrpMinAm)*0.5).toFixed(2)), this.pos.amPad, this.pos.amYs[2]);
    this.ctx.fillText(afc.addComma((this.upGrpMaxAm - (this.upGrpMaxAm-this.upGrpMinAm)*0.75).toFixed(2)), this.pos.amPad, this.pos.amYs[3]);
    this.ctx.fillText(afc.addComma(this.upGrpMinAm.toFixed(2)), this.pos.amPad, this.pos.amYs[4]);
    
    this.ctx.beginPath();
    
    this.ctx.lineJoin = 'bevel';
    this.ctx.lineCap = 'round';
    this.ctx.strokeStyle = this.colorObj.LINE;
	this.ctx.moveTo( lineX, this.pos.upGrpEY);
    this.ctx.lineTo( lineX, this.pos.upGrpSY + (this.upGrpMaxAm - this.data[this.startIdx][4])*this.pos.upRateH);
    
    this.ctx.stroke();
    
    for(var i = this.startIdx+1; i < this.endIdx; i++)
    {
        lineX -= this.pos.barW;
        this.ctx.lineTo( lineX , this.pos.upGrpSY + (this.upGrpMaxAm - this.data[i][4])*this.pos.upRateH );
    }
    
    this.ctx.stroke();
    
	this.ctx.lineTo(lineX, this.pos.upGrpEY);
    
    var grd = this.ctx.createLinearGradient(0, this.pos.upGrpSY, 0, this.pos.upGrpEY);
    grd.addColorStop(0, this.colorObj.START);
    grd.addColorStop(1, this.colorObj.END);
    this.ctx.fillStyle = grd;
    //this.ctx.globalAlpha = 0.5;
    this.ctx.fill();
    
    this.ctx.closePath();
    
     //우측 금액 구분선 그리기
    this.ctx.beginPath();
    
    this.ctx.lineWidth = 2;
    this.ctx.strokeStyle = this.colorObj.DIVLINE;
    this.ctx.moveTo(this.pos.grpEX, 0);
    this.ctx.lineTo(this.pos.grpEX, this.pos.cavasH);
    this.ctx.stroke();
    this.ctx.closePath();
        
};


//백그라운드 컬러 셋팅
EXJisooChartDemo.prototype.setBackLineColor = function(color, isRefresh)
{
    this.colorObj.DOT = color;
    if(isRefresh) this.updatePosition($(this.element).width(), $(this.element).height());
};

//텍스트 컬러 셋팅
EXJisooChartDemo.prototype.setTextColor = function(color, isRefresh)
{
    this.colorObj.TEXT = color;
    if(isRefresh) this.updatePosition($(this.element).width(), $(this.element).height());
};
       
//상승 컬러 셋팅 
EXJisooChartDemo.prototype.setUpColor = function(color, isRefresh)
{
    this.COLOR_PLUS = color;
    if(isRefresh) this.updatePosition($(this.element).width(), $(this.element).height());
};

//하락 컬러 셋팅        
EXJisooChartDemo.prototype.setDownColor = function(color, isRefresh)
{
    this.COLOR_MINUS = color;
    if(isRefresh) this.updatePosition($(this.element).width(), $(this.element).height());
};

//데이터가 더 필요한지를 체크
EXJisooChartDemo.prototype.isExistNextData = function()
{
	if((this.startIdx + this.BAR_CNT+1) > this.data.length) return false;
    else return true;	
};

//현재 그리는 데이터 오프셋 가져오기
EXJisooChartDemo.prototype.getOffset = function()
{       
	var tempInx = this.startIdx + this.BAR_CNT+1;
	if(tempInx > this.data.length) this.endIdx = this.data.length;
	else this.endIdx = tempInx;
};

//캔들의 너비를 바꿈
EXJisooChartDemo.prototype.barWidthChange = function()
{       
	this.pos.barTot = this.pos.barW + this.BAR_TERM;
    this.BAR_CNT = parseInt(this.pos.grpW/this.pos.barTot, 10);
	this.startLineX = this.pos.grpEX;
};

//왼쪽에서 오른쪽으로 스크롤 시킴
EXJisooChartDemo.prototype.scrollLToR = function(add)
{   
	
    if(!this.isExistNextData())
	{
		this.getOffset();
		return;
	}
	
	this.startIdx += add;
	this.updateGraph(); 
    
};

//오른쪽에서 왼쪽으로 스크롤 시킴
EXJisooChartDemo.prototype.scrollRToL = function(add)
{
	
	if(this.data.length < 1)
	{
		this.getOffset();
		return;
	}
	
    this.startIdx -= add;
    if(this.startIdx < 0) this.startIdx = 0;
    this.updateGraph();    
};

//그래프 업데이트
EXJisooChartDemo.prototype.updateGraph = function()
{
    if(this.isExistNextData() || !this.nextIqryDate)
	{
		this.getOffset();
		this.setMaxMin();
		this.draw();
	}
	else if(this.delegator) this.delegator.callNextData(this.nextIqryDate);
	
};

//줌 인아웃 
EXJisooChartDemo.prototype.zoomInOut = function()
{
	
	if(this.preScale == this.rateVal) return;
	
	this.preScale = this.rateVal;	
	this.pos.barW *= this.preScale;
	
	if(this.pos.barW < this.DEF_BAR_W)
	{
		this.pos.barW = this.DEF_BAR_W;
		return;
	}
	else if(this.pos.barW > this.MAX_BAR_W)
	{
		this.pos.barW = this.MAX_BAR_W;
		return;
	}
	this.barWidthChange();
	this.updateGraph();    

};

//롱탭시 안내선 보이기
EXJisooChartDemo.prototype.drawLongTabData = function(touchX)
{
    var oriX = touchX - this.compLeft;
    var offsetX = this.pos.grpEX - oriX;
    var curPos = parseInt(offsetX/this.pos.barTot);
    var curPer = offsetX%this.pos.barTot;
    
    if(curPer > this.pos.barTot) curPos += 1;
	
	var newOffset = this.startIdx + curPos;
	
	if(newOffset < this.startIdx ||  newOffset > this.endIdx) return;
        
    var detData = this.data[newOffset];
	if(detData)
	{
		this.infoDiv.innerHTML = '<span>'+this.dateformat(detData[0])+'</span></br><span>시가 : '+afc.addComma(detData[1])+
			                     '</span><span style="margin-left:20px;">고가 : '+afc.addComma(detData[2])+
			                     '</span></br><span>저가 : '+afc.addComma(detData[3])+
			                     '</span><span style="margin-left:20px;">종가 : '+afc.addComma(detData[4])+
			                     '</span></br><span>거래량 : '+afc.addComma(detData[5])+
			                     '</span></br><span>거래대금 : '+afc.addComma(detData[6])+'</span>';
			                     
		this.longXdiv.style.left = (this.startLineX - (curPos*this.pos.barTot)-1)+'px';
	
		//this.longXdiv.style.left = (this.startLineX - (curPos+1)*this.pos.barTot)+'px';
		this.longYdiv.style.top = (this.pos.upGrpSY + (this.upGrpMaxAm - detData[4])*this.pos.upRateH)+'px'; 
	}
};

// -----------------------  그래프 터치 이벤트  ----------------------- //
//자동스크를
EXJisooChartDemo.prototype.autoScroll = function(speed)
{
    var thisObj = this;
    
    if(speed>150 || !this.isExistNextData()) return;
    
    this.timer = setTimeout(function()
    {
		thisObj.timer = null;
		
        if(thisObj.mScrollLR) thisObj.scrollLToR(1);
        else thisObj.scrollRToL(1);
        thisObj.autoScroll(speed + speed/4);
    }, speed);
};

//터치이벤트 셋팅
EXJisooChartDemo.prototype.setTouchEvent = function()
{
    var thisObj = this;
    var touch1, touch2, pageX1, pageY1, pageX2, pageY2;
    
    this.canvas.addEventListener(afc.ACTION_DOWN, function(e) 
    {
		this.isDown = true;
		
		if(!thisObj.data || thisObj.data.length == 0) return;
		
        e.preventDefault();
        e.stopPropagation();
        
        if(afc.isPC) e.touches = [ { clientX:e.clientX, clientY:e.clientY, pageX:e.pageX, pageY:e.pageY } ];
        
        touch1 = e.touches[0];
        touch2 = e.touches[1];
        
        pageX1 = touch1.pageX;
        
        if(thisObj.timer)
        {
            clearTimeout(thisObj.timer);
            thisObj.timer = null;
        }
        
        thisObj.scollSX = pageX1;

        //------------------------      
        thisObj.mStartTime = new Date().getTime();
        thisObj.mOldTime = thisObj.mStartTime;
        thisObj.mStartX = pageX1;
        thisObj.mEndX = thisObj.mStartX;
        
        //-------------------------------------
        //롱탭을 눌렀을시
        //-------------------------------------
        if(!touch2)
        {
            this.longTime = setTimeout(function()
            {
                thisObj.mode = 1;
                
                thisObj.infoDiv.style.display = '';
                thisObj.longXdiv.style.display = '';
                thisObj.longYdiv.style.display = '';
                
                thisObj.moveX = pageX1;
                thisObj.drawLongTabLines();
                
            }, 500);
        }
        
    });
    
    function getDistance(p1, p2)
    {
        return Math.sqrt(Math.pow((p2.x - p1.x), 2) + Math.pow((p2.y - p1.y), 2));
    }
    
    this.canvas.addEventListener(afc.ACTION_MOVE, function(e) 
    {
        clearTimeout(this.longTime);
		
		if(!thisObj.data || thisObj.data.length == 0) return;
        
        e.preventDefault();
        e.stopPropagation();
        
        if(afc.isPC) 
        {
        	if(!this.isDown) return;
        	e.touches = [ { clientX:e.clientX, clientY:e.clientY, pageX:e.pageX, pageY:e.pageY } ];
        }
        
        touch1 = e.touches[0];
        touch2 = e.touches[1];
        
        pageX1 = touch1.pageX;
        pageY1 = touch1.pageY;
        
        //멀티터치
        if(touch2)
        {
            pageX2 = touch2.pageX;
            pageY2 = touch2.pageY;
            
            if(touch1 && touch2) {
                
                var dist = getDistance({
                    x: pageX1,
                    y: pageY1
                }, {
                    x: pageX2,
                    y: pageY2
                });
                if(!thisObj.lastDist) {
                    thisObj.lastDist = dist;
                }
				thisObj.rateVal = (dist/thisObj.lastDist).toFixed(2);
				thisObj.zoomState = 0;
                thisObj.zoomInOut();
                thisObj.lastDist = dist;
            }    
        }
        
        //일반 스크롤
        else
        {
            //--------------------------------------
            //롱탭 후 드래그 했을시
            if(thisObj.mode == 1)
            {
            	thisObj.moveX = pageX1;
            	thisObj.drawLongTabLines();
            }
            //일반 스크롤시
            else
            {
                //--------------------------------------
                var newTime = new Date().getTime();
                //멈춰있는 시간이 일정시간 이상이면 초기화
                if((newTime - thisObj.mOldTime)>100) 
                {
                    thisObj.mStartTime = newTime;
                    thisObj.mOldTime = newTime;
                    thisObj.mStartX = pageX1;
                    thisObj.mEndX = thisObj.mStartX;
                }
                
                else 
                {
                    thisObj.mOldTime = newTime;
                    thisObj.mEndX = pageX1;
                }
                
                //--------------------------------------
                var chkW = Math.abs(thisObj.scollSX - pageX1);
                if(chkW > thisObj.pos.barW)//+graph.distance
                {
                    if(thisObj.scollSX > pageX1)
                    {
                        thisObj.mScrollLR = false;
                        var count = parseInt((chkW/thisObj.pos.barW), 10);
                        thisObj.scrollRToL(count);
                    }
                    else
                    {
                        thisObj.mScrollLR = true;
                        var count = parseInt((chkW/thisObj.pos.barW), 10); 
                        thisObj.scrollLToR(count);
                    }
                    thisObj.scollSX = pageX1;
                }
            }
        }
        
    });

    this.canvas.addEventListener(afc.ACTION_UP, function(e) 
    {
    	this.isDown = false;
		if(!thisObj.data || thisObj.data.length == 0) return;
        clearTimeout(this.longTime);
        
        if(afc.isPC) e.touches = [ { clientX:e.clientX, clientY:e.clientY, pageX:e.pageX, pageY:e.pageY } ];
        
        thisObj.mode = 0;
        if(thisObj.infoDiv)
        {
            thisObj.infoDiv.style.display = 'none';
            thisObj.longXdiv.style.display = 'none';
            thisObj.longYdiv.style.display = 'none';
        } 
        
        e.preventDefault();
        e.stopPropagation();

        //------------------
        var interval = new Date().getTime() - thisObj.mStartTime;
        thisObj.speed = Math.abs(thisObj.mEndX - thisObj.mStartX)/interval;
        //속도값이 아주 작은 것은 무시한다.
        if(thisObj.speed > 0.5)
        {
            thisObj.autoScroll((4 - thisObj.speed)/2);
        }
        //----------------------------------
        
        thisObj.lastDist = null;
    });
};

EXJisooChartDemo.prototype.addNewData = function(dataArr, keyArr)
{
	
	if(!dataArr) return;
	
	this.startId--;
		
	if(!keyArr)
	{
		var keyLength = dataArr.length;
		
		keyArr = new Array();
		for(var i = 0; i<keyLength; i++)
		{
			keyArr.push(i);
		}
	}
	
	var newData = new Array();
	for(var i = 0; i<dataArr.length; i++)
		newData.push(dataArr[keyArr[i]]);
	
	this.data.unshift([
		dataArr[keyArr[0]],
		dataArr[keyArr[1]]/this.divisionVal,
		dataArr[keyArr[2]]/this.divisionVal,
		dataArr[keyArr[3]]/this.divisionVal,
		dataArr[keyArr[4]]/this.divisionVal,
		dataArr[keyArr[5]]/this.divisionVal,
		dataArr[keyArr[6]]/this.divisionVal
	]);
	
	this.updateGraph();
	
	//롱탭중일시에 정보 갱신
	if(this.mode == 1) this.drawLongTabLines();
	
};

//롱탭시 보여질 상세 데이터 표시
EXJisooChartDemo.prototype.drawLongTabLines = function()
{
	if(this.isShowLeft)
    {
        if(this.middleX > this.moveX)
        {
            this.infoDiv.style.left = '';
            this.infoDiv.style.right = '10px';
            this.isShowLeft = false;
        }
    }
    else
    {
        if(this.middleX < this.moveX)
        {
            this.infoDiv.style.right = '';
            this.infoDiv.style.left = '10px';
            this.isShowLeft = true;
        }
    }
    this.drawLongTabData(this.moveX);
};

EXJisooChartDemo.prototype.getQueryData = function(dataArr, keyArr)
{
	if(!keyArr) return;
};

EXJisooChartDemo.prototype.setQueryData = function(dataArr, keyArr, queryData)
{
	var data = null;
	
	for(var i=0; i<dataArr.length; i++)
	{
		data = dataArr[i];
		
		this.data.push([
			data[keyArr[0]],
			data[keyArr[1]]/this.divisionVal,
			data[keyArr[2]]/this.divisionVal,
			data[keyArr[3]]/this.divisionVal,
			data[keyArr[4]]/this.divisionVal,
			data[keyArr[5]]/this.divisionVal,
			data[keyArr[6]]/this.divisionVal
		]);
	}
	this.calcPosition();	
};