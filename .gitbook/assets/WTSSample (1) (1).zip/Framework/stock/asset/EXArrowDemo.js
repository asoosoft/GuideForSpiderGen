
function EXArrowDemo()
{
	this.svgEl = null;
    this.direction = 'top';
    this.stopTagArr = null;
    this.polygonTag = null;
    this.gradientTag = null;
    
}

EXArrowDemo.prototype.init = function(dom)
{
    this.svgEl = dom;
    this.stopTagArr = this.svgEl.getElementsByTagName('stop');
    this.polygonTag = this.svgEl.getElementsByTagName('polygon')[0];
    this.gradientTag = this.svgEl.getElementsByTagName('linearGradient')[0];
    
    this.setDirection($(dom).attr('data-direction'));
};   

EXArrowDemo.prototype.setDefsId = function()
{
    this.gradientTag.id = 'ARW_'+this.svgEl.id; 
    this.polygonTag.style.fill = "url(#"+this.gradientTag.id+")";
};

EXArrowDemo.prototype.setColors = function(sColor, eColor, sOpacity, eOpacity)
{
    if(!eColor)
    {
        this.polygonTag.style.fill = sColor;    
        alert(this.polygonTag.style.fill);
    }
    else
    {
        if(!sOpacity) sOpacity = 1.0;
        if(!eOpacity) sOpacity = 1.0;
        
        this.setDefsId();
        this.stopTagArr[0].setAttribute('stop-color', sColor);
        this.stopTagArr[0].setAttribute('stop-opacity', sOpacity);
        this.stopTagArr[1].setAttribute('stop-color', eColor);
        this.stopTagArr[1].setAttribute('stop-opacity', eOpacity);    
    }
};

EXArrowDemo.prototype.setStartColor = function(color)
{
    this.stopTagArr[0].setAttribute('stop-color', color);
};

EXArrowDemo.prototype.getStartColor = function()
{
    return this.stopTagArr[0].getAttribute('stop-color');
};

EXArrowDemo.prototype.setEndColor = function(color)
{
    this.stopTagArr[1].setAttribute('stop-color', color);
};

EXArrowDemo.prototype.getEndColor = function()
{
    return this.stopTagArr[1].getAttribute('stop-color');
};

EXArrowDemo.prototype.setStartOpacity = function(opacity)
{
    this.stopTagArr[0].setAttribute('stop-opacity', opacity);
};

EXArrowDemo.prototype.getStartOpacity = function()
{
    return this.stopTagArr[0].getAttribute('stop-opacity');
};

EXArrowDemo.prototype.setEndOpacity = function(opacity)
{
    this.stopTagArr[1].setAttribute('stop-opacity', opacity);    
};

EXArrowDemo.prototype.getEndOpacity = function()
{
    return this.stopTagArr[1].getAttribute('stop-opacity');    
};

EXArrowDemo.prototype.setDirection = function(direction)
{
    this.direction = direction;
    if(this.direction == 'left' || this.direction == 'right') this.setRotate(0);
    else this.setRotate(90);
    this.setPoints();
};

EXArrowDemo.prototype.setRotate = function(angle)
{
    this.gradientTag.setAttribute('gradientTransform', 'rotate('+angle+')');
};

EXArrowDemo.prototype.setPoints = function()
{
    var domW = this.svgEl.offsetWidth;
    var domH = this.svgEl.offsetHeight;
    var helfX = domW/2;
    var helfY = domH/2;
    var hhX = helfX/2; 
    var hhY = helfY/2; 
    
    if(this.direction == 'left')
    {
        this.polygonTag.setAttribute('points', '0 '+helfY+', '+helfX+' '+domH+', '+helfX+' '+(helfY+hhY)+', '+domW+' '+(helfY+hhY)+', '+domW+' '+hhY+', '+helfX+' '+hhY+', '+helfX+' 0, 0 '+helfY);  
    }
    else if(this.direction == 'top')
    {
        this.polygonTag.setAttribute('points', helfX+' 0, 0 '+helfY+', '+hhX+' '+helfY+', '+hhX+' '+domH+', '+(helfX+hhX)+' '+domH+', '+(helfX+hhX)+' '+helfY+', '+domW+' '+helfY);    
    }
    else if(this.direction == 'right')
    {
        this.polygonTag.setAttribute('points', domW+' '+helfY+', '+helfX+' 0, '+helfX+' '+hhY+', 0 '+hhY+', 0 '+(helfY+hhY)+', '+helfX+' '+(helfY+hhY)+', '+helfX+' '+domH+', '+domW+' '+helfY);
    }
    else if(this.direction == 'bottom')
    {
        this.polygonTag.setAttribute('points', helfX+' '+domH+', '+domW+' '+helfY+', '+(helfX+hhX)+' '+helfY+', '+(helfX+hhX)+' 0, '+hhX+' 0, '+hhX+' '+helfY+', 0 '+helfY+', '+helfX+' '+domH);        
    }
};