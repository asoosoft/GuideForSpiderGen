
function EXMiniChartDemo()
{
	BaseChartDemo.call(this);
	
	this.basePrice = 0;
	
	this.termMinute = 5;
  	this.maxCount = 360;
	
	this.termW = 0;
	
	this.maxAm = 0;
	this.minAm = Number.MAX_VALUE;
	
	this.bottomTextArr = [ '10', '12', '14' ];
	
     this.colorObj = {
		BACK : StockColor.BACK,
        DIVLINE: StockColor.DIVLINE,
        BASELINE: StockColor.BASELINE,
        TEXT: StockColor.TEXT,
        TIMELINE: StockColor.TIMELINE,
        UP: StockColor.UP_COLOR,
        DOWN: StockColor.DOWN_COLOR    
    };
    
    //포지션에 관련된 객체
    this.pos = 
    {  
    	grpSY : 0,
    	hourSY : 0,
    	hourY : 0,
    	grpEY : 0,
    	grpH : 0,
        baseY : 0,
        grpR : 0,  
        grpTp : null
    };
}

afc.extendsClass(EXMiniChartDemo, BaseChartDemo);

EXMiniChartDemo.prototype.init = function(context, evtListener)
{
	BaseChartDemo.prototype.init.call(this, context, evtListener);
	
};

EXMiniChartDemo.prototype.setBottomText = function(textArr)
{
  	this.bottomTextArr = textArr;
};

EXMiniChartDemo.prototype.setTermValue = function(termMinute, maxCount)
{
	this.termMinute = termMinute;
  	this.maxCount = maxCount;
};


EXMiniChartDemo.prototype.setColors = function(colors, isDraw)
{
    if(colors)
    {
        for(var key in colors)
            if(colors.hasOwnProperty(key)) this.colorOpt[key] = colors[key];
    }
    
    if(isDraw) this.draw();
};

EXMiniChartDemo.prototype.updatePosition = function(pWidth, pHeight)
{
	BaseChartDemo.prototype.updatePosition.call(this, pWidth, pHeight);
    this.termW = this.eleW/(this.maxCount/this.termMinute);
	this.calcPosition(this.eleW, this.eleH);
	this.setData(600, mini_data);
};

EXMiniChartDemo.prototype.setData = function(basePrice, data)
{
	this.basePrice = basePrice;
    this.data = data;
	this.maxAm = 0;
	this.minAm = Number.MAX_VALUE;
	this.updateGraph();
};

EXMiniChartDemo.prototype.addNewData = function(newData)
{
	if(this.data.length >= this.maxCount) return;
	
    this.data.push(newData);
	this.maxAm = 0;
	this.minAm = Number.MAX_VALUE;
	this.updateGraph();
};

//드로우 가능한 상태인지를 체크
EXMiniChartDemo.prototype.checkDrawPossible = function()
{
	if(this.data && this.eleW > 0 && this.eleH > 0) return true;
	else return false;
};

//1.컴포넌트의 너비와 높이값을 이용하여 canvas에 들어갈 영역 x y 셋팅   
EXMiniChartDemo.prototype.calcPosition = function(elWidth, elHeight)
{
    //그래프영역과 시간텍스트 영역 나누기
    this.pos.grpSY = this.eleH*0.05;
    this.pos.hourSY = this.eleH*0.8;
    this.pos.hourY = this.eleH - (this.eleH - this.pos.hourSY)/3;
    this.pos.grpEY = this.pos.hourSY - this.pos.grpSY;
    this.pos.grpH = this.pos.grpEY - this.pos.grpSY;
    
};

EXMiniChartDemo.prototype.setMaxMin = function()
{
	for(var i=0; i<this.data.length; i++)
    {
        var val = this.data[i];
        if(val > this.maxAm) this.maxAm = val;
        if(val < this.minAm) this.minAm = val;
    }
	
    if(this.minAm >= this.basePrice)
    {
        this.pos.baseY = this.pos.grpEY;
        this.pos.grpR = this.pos.grpH/(this.maxAm - this.basePrice);  
        this.pos.grpTp = 'up';
    }
    else
    {
        if(this.maxAm <= this.basePrice){
            this.pos.grpR = this.pos.grpH/(this.basePrice - this.minAm);
            this.pos.baseY = this.pos.grpSY;
            this.pos.grpTp = 'down';
        }   
        else{
            this.pos.grpR = this.pos.grpH/(this.maxAm - this.minAm);
            this.pos.baseY = this.pos.grpSY + (this.maxAm - this.basePrice)*this.pos.grpR;
            this.pos.grpTp = 'both';
        }
    }		
};

EXMiniChartDemo.prototype.updateGraph = function()
{
	this.setMaxMin();
	this.draw();
};

EXMiniChartDemo.prototype.draw = function()
{
    this.ctx.webkitImageSmoothingEnabled = true;
	
	this.canvas.width = this.eleW;
    this.canvas.height = this.eleH;

    //this.ctx.fillStyle = this.colorObj.BACK;
    this.ctx.clearRect(0,0, this.eleW, this.eleH);
    
    this.drawBack();
    
    if(this.pos.grpTp == 'both') this.drawBoth();
    else this.drawOnly();
    
    this.drawHourLine();
};

EXMiniChartDemo.prototype.drawBack = function()
{
    //그래프 영역과 시간 텍스트 영역 나누는 선 그리기
    this.ctx.beginPath();
    this.ctx.strokeStyle = this.colorObj.DIVLINE;
    this.ctx.lineWidth = '0.8';
    this.ctx.moveTo(0, this.pos.hourSY);
    this.ctx.lineTo(this.eleW, this.pos.hourSY);
    this.ctx.stroke();
    this.ctx.closePath();
    
    //시간영역 10 12 14 구분라인 그리기
    var hourDist = this.eleW/6;
    var hourLineX = hourDist;
    var startY = 0; endY = 0;
    
    if(this.pos.grpTp == 'up'){
        startY = 0;
        endY = this.pos.grpEY;
    } 
    else if(this.pos.grpTp == 'down'){
        startY = this.pos.grpSY;
        endY = this.pos.hourSY;
    }
    else
    {
        startY = 0;
        endY = this.pos.hourSY;
    }
    this.ctx.fillStyle = this.colorObj.TEXT;    
    this.ctx.textAlign = 'center';
	this.ctx.font = (parseInt(this.eleH/120*15, 10))+"px '"+this.FONT_FAMILY+"'";
    
    this.ctx.beginPath();
    this.ctx.strokeStyle = this.colorObj.TIMELINE;
    this.ctx.lineWidth = '0.8';
    this.ctx.moveTo(hourLineX, startY);
    this.ctx.lineTo(hourLineX, endY);
    this.ctx.stroke();
    this.ctx.closePath();
    
    this.ctx.fillText(this.bottomTextArr[0], hourLineX, this.pos.hourY);
    
    hourLineX = hourDist*3;
    this.ctx.beginPath();
    this.ctx.moveTo(hourLineX, startY);
    this.ctx.lineTo(hourLineX, endY);
    this.ctx.stroke();
    this.ctx.closePath();
    
    this.ctx.fillText(this.bottomTextArr[1], hourLineX, this.pos.hourY);
    
    hourLineX = hourDist*5;
    this.ctx.beginPath();
    this.ctx.moveTo(hourLineX, startY);
    this.ctx.lineTo(hourLineX, endY);
    this.ctx.stroke();
    this.ctx.closePath();
    
    this.ctx.fillText(this.bottomTextArr[2], hourLineX, this.pos.hourY);
    
    this.ctx.closePath();
        
};

//상한 또는 하한 한가지 경우
EXMiniChartDemo.prototype.drawOnly = function()
{
    this.ctx.lineJoin = 'bevel';
    this.ctx.lineCap = 'round';
    
    var maxVal, lineColor, gradColor, gradSY, gradEY, lastX = 0; 
    
    if(this.pos.grpTp == 'up'){
        lineColor = this.colorObj.UP;
        gradColor = this.colorObj.UP;
        gradSY = this.pos.grpSY;
        gradEY = this.pos.baseY;
        maxVal = this.maxAm;
    } 
    else if(this.pos.grpTp == 'down'){
        lineColor = this.colorObj.DOWN;
        gradColor = this.colorObj.DOWN;
        gradSY = this.pos.grpEY;
        gradEY = this.pos.baseY;
        maxVal = this.basePrice;
    } 

    this.ctx.beginPath();
    this.ctx.webkitImageSmoothingEnabled = true;
    this.ctx.moveTo(lastX, this.pos.grpSY + (maxVal - this.data[0])*this.pos.grpR);
    for(var i=1; i<this.data.length; i++)
    {
        lastX += this.termW;
        this.ctx.lineTo(lastX, this.pos.grpSY + (maxVal - this.data[i])*this.pos.grpR);
    }

    this.ctx.strokeStyle = lineColor;
    this.ctx.lineWidth = '0.8';
    this.ctx.stroke();
    this.ctx.lineTo(lastX, this.pos.baseY);
    this.ctx.lineTo(0, this.pos.baseY);
    this.ctx.lineTo(0, this.data[1]);
    this.drawGradient(gradSY, gradEY, gradColor);
    this.ctx.closePath();
};

//상한과 하한이 섞인경우
EXMiniChartDemo.prototype.drawBoth = function()
{
	
    var dataLength = this.data.length;
    var maxVal = this.maxAm;
    var preX = 0, preY = 0, firstVal = this.data[0], preUp, lineColor, gradColor;
    
    this.ctx.lineJoin = 'bevel';
    this.ctx.lineCap = 'round';
    
    this.ctx.beginPath();
	
	preY = this.pos.grpSY + (maxVal - firstVal)*this.pos.grpR;
	
	this.ctx.moveTo(-1, this.pos.baseY);
	this.ctx.lineTo(-1, preY);
	this.ctx.lineTo(preX, preY);
    
    if(firstVal >= this.basePrice)
    {
        preUp = true;
        this.ctx.strokeStyle = this.colorObj.UP;
        gradColor = '';
    }
    else
    {
        preUp = false;
        this.ctx.strokeStyle = this.colorObj.DOWN;
        gradColor = '';
    } 
	
	this.ctx.lineWidth = '0.8';
	
	
    var lastX = 0, nextVal = 0;
    for(var i=1; i<dataLength; i++)
    {
        lastX = this.termW*i;
        nextVal = this.data[i];
        if(preUp)
        {
            if(this.basePrice > nextVal)
            {
                var tempX = lastX - this.termW*( Math.abs(nextVal-this.basePrice) / Math.abs(nextVal-this.data[i-1]));
                //중간 앞영역 레드 그리기
                this.ctx.strokeStyle = this.colorObj.UP;
                this.ctx.lineTo(tempX, this.pos.baseY);
                this.ctx.stroke();
                
                this.ctx.lineTo(preX, this.pos.baseY);
                
                //레드 그라디언트 그리기
                this.drawGradient(this.pos.grpSY, this.pos.baseY, this.colorObj.UP);
                
                this.ctx.beginPath();
                this.ctx.moveTo(tempX, this.pos.baseY);
                
                this.ctx.strokeStyle = this.colorObj.DOWN;
                this.ctx.lineTo(lastX, this.pos.grpSY + (maxVal - nextVal)*this.pos.grpR);
                this.ctx.stroke();
                
                //블루 그라디언트 그리기
                this.drawGradient(this.pos.grpEY, this.pos.baseY, this.colorObj.DOWN);
                
                preUp = false;
            }
            else
            {
                this.ctx.lineTo(lastX, this.pos.grpSY + (maxVal - nextVal)*this.pos.grpR);
                this.ctx.strokeStyle = this.colorObj.UP;
                this.ctx.stroke();
            }
        }
        else
        {
            if(this.basePrice < nextVal)
            {
                //중간 앞영역 블루 그리기
                var tempX = lastX - this.termW*( Math.abs(nextVal-this.basePrice) / Math.abs(nextVal-this.data[i-1]));
                this.ctx.strokeStyle = this.colorObj.DOWN;
                this.ctx.lineTo(tempX, this.pos.baseY);
                this.ctx.stroke();
                
                //블루 그라디언트 그리기
                this.drawGradient(this.pos.grpEY, this.pos.baseY, this.colorObj.DOWN);
                
                this.ctx.beginPath();
                this.ctx.moveTo(tempX, this.pos.baseY);
                
                //중간 뒷영역 레드 그리기
                this.ctx.strokeStyle = this.colorObj.UP;
                this.ctx.lineTo(lastX, this.pos.grpSY + (maxVal - nextVal)*this.pos.grpR);
                this.ctx.stroke();
                
                //레드 그라디언트 그리기
                this.drawGradient(this.pos.grpSY, this.pos.baseY, this.colorObj.UP);
                
                preUp = true;
            }
            else
            {
                this.ctx.lineTo(lastX, this.pos.grpSY + (maxVal - nextVal)*this.pos.grpR);
                this.ctx.strokeStyle = this.colorObj.DOWN;
                this.ctx.stroke();      
            }
        }
    }
    
    this.ctx.lineTo(lastX, this.pos.baseY);
    
    if(preUp) this.drawGradient(this.pos.grpSY, this.pos.baseY, this.colorObj.UP);
    else this.drawGradient(this.pos.grpEY, this.pos.baseY, this.colorObj.DOWN);
    
    this.ctx.closePath();
    
};

EXMiniChartDemo.prototype.drawGradient = function(gradSY, gradEY, gradColor)
{
	var rgbaArr = [];
	if(gradColor.length > 26)
	{
		var rgba = gradColor.match(/^rgba?\((\d+),\s*(\d+),\s*(\d+),\s*(\d\.?\d+)\)$/);
		rgbaArr = [ rgba[1], rgba[2], rgba[3], rgba[4] ]; 
	}
	else if(gradColor.length > 15)
	{
		var rgb = gradColor.match(/^rgba?\((\d+),\s*(\d+),\s*(\d+)\)$/);
        rgbaArr = Util.RGBtoRGBA(rgb[1], rgb[2], rgb[3]);
	}
	else rgbaArr = Util.RGBtoRGBA(gradColor);
	
 	var grd = this.ctx.createLinearGradient(0, gradSY, 0, gradEY);
	grd.addColorStop(0, gradColor);
	grd.addColorStop(1, 'rgba('+rgbaArr[0]+', '+rgbaArr[1]+', '+rgbaArr[2]+', 0.0)');
	this.ctx.fillStyle = grd;
	this.ctx.globalAlpha = 0.5;
	this.ctx.fill();
};

EXMiniChartDemo.prototype.drawHourLine = function()
{
    //지수기준선 그리기
    this.ctx.beginPath();
    this.ctx.strokeStyle = this.colorObj.BASELINE;
    //this.ctx.setLineDash([4]);
    this.ctx.lineWidth = '0.8';
    this.ctx.moveTo(0, this.pos.baseY);
    this.ctx.lineTo(this.eleW, this.pos.baseY);
    this.ctx.stroke();
    this.ctx.closePath();
};

EXMiniChartDemo.prototype.getQueryData = function(dataArr, keyArr)
{
	if(!keyArr) return;
};

EXMiniChartDemo.prototype.setQueryData = function(dataArr, keyArr)
{
	if(!keyArr) return;
	
	var timeArr = new Array(), keyVal = keyArr[0];
	for(var i=dataArr.length-1; i>=0; i--)
	{
		timeArr.push(dataArr[i][keyVal]);
	}
	this.setData(this.basePrice, timeArr);
};
