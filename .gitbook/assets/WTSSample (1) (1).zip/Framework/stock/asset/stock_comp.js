
/************************************** 컴포넌트 프로퍼티 영역 **************************************/


//-------------------------------------------
//스톡라벨
COMP_MAP['EXStockLabel'] = 
{
	name: '스톡라벨', 
	attribute:
	{
	 	appearance:['text', 'color', 'background-color', 'font-family', 'font-size', 'font-weight', 'font-style', 'style', 'opacity', 'visibility', 'display'],
	 	data:['maskdata'],
	 	layout:['text-align', 'vertical-align', 'word-break'],//, 'line-breaks', 'ellipsis-line'],
	 	border:
	 	[
	 		'border-left-color', 'border-top-color', 'border-right-color', 'border-bottom-color',
	 		'border-left-width', 'border-top-width', 'border-right-width', 'border-bottom-width', 'border-radius'
	 	],
	 	padding: [ 'padding-left', 'padding-top', 'padding-right', 'padding-bottom' ]
	 	
	}
};

//-------------------------------------------
//	보안텍스트필드
COMP_MAP['EXSecureTextField'] = 
{
	name: '보안텍스트필드', 
	attribute:
	{
	 	appearance:
	 	[
	 		'input-value', 'input-type', 'input-placeholder', 'color', 'background-color', 
	 		'font-family', 'font-size', 'font-weight', 'font-style', 'style', 'opacity', 'readonly', 'disabled', 'visibility', 'display'
	 	],
	 	data:['padtitle', 'padtype', 'show-type', 'padmin', 'padmax'],
	 	layout:['text-align'],
	 	border:
	 	[
	 		'border-left-color', 'border-top-color', 'border-right-color', 'border-bottom-color',
	 		'border-left-width', 'border-top-width', 'border-right-width', 'border-bottom-width', 'border-radius'
	 	],
	 	padding: [ 'padding-left', 'padding-top', 'padding-right', 'padding-bottom' ]
	}
};

//-------------------------------------------
//	봉차트
COMP_MAP['EXStocksChart'] = 
{
	name: '봉차트', 
	attribute:
	{
	 	appearance:['background-color', 'style', 'opacity', 'visibility', 'display'],
	 	graph:['color-TEXT', 'color-DIVLINE', 'color-DOT', 'color-UP', 'color-DOWN'],
	 	border:
	 	[
	 		'border-left-color', 'border-top-color', 'border-right-color', 'border-bottom-color',
	 		'border-left-width', 'border-top-width', 'border-right-width', 'border-bottom-width', 'border-radius'
	 	]
	}
};

//-------------------------------------------
//  지수차트
COMP_MAP['EXJisooChart'] = 
{
    name: '지수차트', 
    attribute:
    {
        appearance:['background-color', 'style', 'opacity', 'visibility', 'display'],
        graph:['color-TEXT', 'color-DOT', 'color-DIVLINE', 'color-LINE', 'color-START', 'color-END'],
        border:
        [
            'border-left-color', 'border-top-color', 'border-right-color', 'border-bottom-color',
            'border-left-width', 'border-top-width', 'border-right-width', 'border-bottom-width', 'border-radius'
        ]
    }
};

//-------------------------------------------
//	미니차트
COMP_MAP['EXMiniChart'] = 
{
	name: '미니차트', 
	attribute:
	{
	 	appearance:['background-color', 'style', 'opacity', 'visibility', 'display'],
	 	graph:['color-TEXT', 'color-DIVLINE', 'color-BASELINE', 'color-TIMELINE', 'color-UP', 'color-DOWN'],
	 	border:
	 	[
	 		'border-left-color', 'border-top-color', 'border-right-color', 'border-bottom-color',
	 		'border-left-width', 'border-top-width', 'border-right-width', 'border-bottom-width', 'border-radius'
	 	]
	}
};

//-------------------------------------------
//	비교차트
COMP_MAP['EXCompareChart'] = 
{
	name: '비교차트', 
	attribute:
    {
        appearance:['background-color', 'style', 'opacity', 'visibility', 'display'],
	 	graph:['color-TEXT', 'color-DIVLINE', 'color-DOT', 'color-UP', 'color-DOWN'],
	 	border:
	 	[
	 		'border-left-color', 'border-top-color', 'border-right-color', 'border-bottom-color',
	 		'border-left-width', 'border-top-width', 'border-right-width', 'border-bottom-width', 'border-radius'
	 	]
    }
};

//-------------------------------------------
//	봉
COMP_MAP['EXBong'] = 
{
	name: '봉', 
	attribute:
	{
	 	appearance:['style', 'opacity', 'visibility', 'display'],
	 	bong:['color-bong-up', 'color-bong-down', 'direction-bong']
	}
};

//-------------------------------------------
//	삼각형
COMP_MAP['EXTriangle'] = 
{
	name: '삼각형', 
	attribute:
	{
	 	appearance:['style', 'opacity', 'visibility', 'display'],
	 	arrow:['color-arrow-up', 'color-arrow-down']
	}
};

//-------------------------------------------
//	화살표
COMP_MAP['EXArrow'] = 
{
	name: '화살표', 
	attribute:
	{
	 	appearance:['style', 'opacity', 'visibility', 'display'],
	 	arrow:['color-start', 'color-end', 'opacity-start', 'opacity-end', 'direction']
	}
};

//-------------------------------------------
//	종목박스
COMP_MAP['EXIscdBox'] = 
{
	name: '종목박스', 
	attribute:
    {
        appearance:
        [
            'input-value', 'input-type', 'input-placeholder', 'color', 'background-color', 
            'font-family', 'font-size', 'font-weight', 'font-style', 'style', 'opacity', 'readonly', 'visibility', 'display'
        ],
        layout:['text-align'],
        border:
        [
            'border-left-color', 'border-top-color', 'border-right-color', 'border-bottom-color',
            'border-left-width', 'border-top-width', 'border-right-width', 'border-bottom-width', 'border-radius'
        ]
    }
};

//-------------------------------------------
//	계좌박스
COMP_MAP['EXAccountBox'] = 
{
	name: '계좌박스', 
	attribute:
    {
        appearance:
        [
            'input-value', 'input-type', 'input-placeholder', 'color', 'background-color', 
            'font-family', 'font-size', 'font-weight', 'font-style', 'style', 'opacity', 'readonly', 'visibility', 'display'
        ],
        layout:['text-align'],
        border:
        [
            'border-left-color', 'border-top-color', 'border-right-color', 'border-bottom-color',
            'border-left-width', 'border-top-width', 'border-right-width', 'border-bottom-width', 'border-radius'
        ]
    }
};

//-------------------------------------------
//  피봇뷰
COMP_MAP['EXPivotView'] = 
{
	name: '피봇뷰', 
	attribute:
	{
	 	appearance:['background-color', 'background-image', 'background-option', 'style', 'opacity', 'visibility', 'display'],
	 	info:['load-url'],
	 	layout:['float', 'arrange-direction', 'overflow', 'view-type'],
	 	border:
	 	[
	 		'border-left-color', 'border-top-color', 'border-right-color', 'border-bottom-color',
	 		'border-left-width', 'border-top-width', 'border-right-width', 'border-bottom-width', 'border-radius'
	 	],
	 	padding: [ 'padding-left', 'padding-top', 'padding-right', 'padding-bottom' ]
	}
};

//-------------------------------------------
//  센터피봇뷰
COMP_MAP['EXCenterPivotView'] = 
{
	name: '센터피봇뷰', 
	attribute:
	{
	 	appearance:['background-color', 'background-image', 'background-option', 'style', 'opacity', 'visibility', 'display'],
	 	info:['load-url'],
	 	layout:['float', 'arrange-direction', 'overflow'],
	 	border:
	 	[
	 		'border-left-color', 'border-top-color', 'border-right-color', 'border-bottom-color',
	 		'border-left-width', 'border-top-width', 'border-right-width', 'border-bottom-width', 'border-radius'
	 	],
	 	padding: [ 'padding-left', 'padding-top', 'padding-right', 'padding-bottom' ]
	}
};

//-------------------------------------------
//  호가그리드
COMP_MAP['EXHogaGrid'] = 
{
	name: '호가그리드',
	attribute:
	{
	 	appearance:['background-color', 'font-family', 'font-size', 'font-weight', 'font-style', 'style', 'opacity', 'visibility', 'display'],
	 	option:['hide-header', 'single-select', 'fullrow-select', 'selectable', 'flexible-row'],
	 	defaultStyle:['border-color-def', 'hide-Wborder', 'hide-Hborder', 'color-def', 'background-color-def', 'background-image-def', 'style-def'],
	 	selectStyle: ['test-select', 'select-style', 'curprice-cell-style'],
	}
};

//-------------------------------------------
//  주문호가그리드
COMP_MAP['EXOrderHogaGrid'] = 
{
	name: '주문호가그리드',
	attribute:
	{
	 	appearance:['background-color', 'font-family', 'font-size', 'font-weight', 'font-style', 'style', 'opacity', 'visibility', 'display'],
	 	option:['hide-header', 'single-select', 'fullrow-select', 'selectable', 'flexible-row'],
	 	defaultStyle:['border-color-def', 'hide-Wborder', 'hide-Hborder', 'color-def', 'background-color-def', 'background-image-def', 'style-def'],
	 	selectStyle: ['test-select', 'select-style', 'curprice-cell-style'],
	}
};

//-------------------------------------------
//  5호가그리드
COMP_MAP['EXFiveHogaGrid'] = 
{
	name: '5호가그리드',
	attribute:
	{
	 	appearance:['background-color', 'font-family', 'font-size', 'font-weight', 'font-style', 'style', 'opacity', 'visibility', 'display'],
	 	option:['hide-header', 'single-select', 'fullrow-select', 'selectable', 'flexible-row'],
	 	defaultStyle:['border-color-def', 'hide-Wborder', 'hide-Hborder', 'color-def', 'background-color-def', 'background-image-def', 'style-def'],
	 	selectStyle: ['test-select', 'select-style', 'curprice-cell-style'],
	}
};
