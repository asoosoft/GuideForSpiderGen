
/**
Constructor
Do not call Function in Constructor.

this.data = 
[
	[ code, name, type ],
	...
]
*/

function HistoryInfo(key)
{
	this.data = [];
	this.key = key||'HISTORY';
}

if(window.cordova && window.AppManager)
{
	HistoryInfo.getPref = function(key, callback)
	{
		//향후 필요하게 되면 AAwait 로 바꿔서 코드 추가하기
		//CallbackDone.begin();
		AppManager.getPref(key, function(result)
		{
			if(result) result = JSON.parse(result);
			callback(result||[]);
			
			//CallbackDone.end();
		});
	}
	HistoryInfo.setPref = function(key, data)
	{
		AppManager.setPref(key, JSON.stringify(data));
	}
}
else
{
	HistoryInfo.getPref = function(key, callback)
	{
		var result = JSON.parse(localStorage.getItem(key));
		callback(result||[]);
	}
	HistoryInfo.setPref = function(key, data)
	{
		localStorage.setItem(key, JSON.stringify(data));	
	}
}

HistoryInfo.prototype.init = function(data)
{
	this.data = data;
};

//preference 정보 읽어오기
HistoryInfo.prototype.loadInfo = function()
{
	var thisObj = this;
	
	HistoryInfo.getPref(this.key, function(result)
	{
		thisObj.data = result;
	});
};

// preference 정보 저장하기
HistoryInfo.prototype.saveInfo = function()
{
	HistoryInfo.setPref(this.key, this.data);
};

// 전체 종목정보 가져오기
HistoryInfo.prototype.get = function(typeArr)
{
	if(typeArr)
	{
		if(typeof(typeArr) == 'string') typeArr = [typeArr];
		
		var newArr = [];
		for(i=0; i<this.data.length; i++)
		{
			if(typeArr.indexOf(this.data[i][2]) > -1)
			{
				newArr.push(this.data[i].slice());
			}
		}
		
		return newArr;
	}
	else return this.data;
};

// 전체 종목정보 가져오기
HistoryInfo.prototype.search = function(text, typeArr)
{
	var arr = [];
	if(typeArr)
	{
		if(typeof(typeArr) == 'string') typeArr = [typeArr];
		
		for(i=0; i<this.data.length; i++)
		{
			if(typeArr.indexOf(this.data[i][2]) > -1)
			{
				if(Search.compareText(text, this.data[i][0]) || Search.compareText(text, this.data[i][1]))
					arr.push(this.data[i].slice());
			}
		}
	}
	else
	{
		for(i=0; i<this.data.length; i++)
		{
			if(Search.compareText(text, this.data[i][0]) || Search.compareText(text, this.data[i][1]))
				arr.push(this.data[i].slice());
		}
	}
	
	return arr;
};

// 종목정보를 히스토리 배열에 추가하기(기존에 존재하는 경우 제거)
HistoryInfo.prototype.set = function(data, unshift)
{
	if(!data) return;

	for(var i=this.data.length-1; i>=0; i--)
	{
		if(this.data[i][0] == data[0] && this.data[i][2] == data[2])
		{
			this.data.splice(i, 1);
			break;
		}
	}
	
	if(unshift)
	{
		this.data.unshift(data);
		if(this.maxCount) this.data.length = Math.min(this.data.length, this.maxCount);
	}
	else
	{
		this.data.push(data);
		if(this.maxCount && (this.maxCount < this.data.length))
		{
			this.data.splice(0, this.data.length - this.maxCount);
		}
	}
};

//  최근에 조회한 종목정보를 찾는 함수(typeArr에 해당하는 종목, 없으면 전체에서 마지막)
HistoryInfo.prototype.getRecent = function(typeArr)
{
	if(!typeArr)
	{
		if(this.data.length > 0) return this.data[this.data.length-1];
		else return null;
	}
	else
	{
		if(typeof(typeArr) == 'string') typeArr = [typeArr];
		
		for(i=this.data.length-1; i>-1; i--)
		{
			if(typeArr.indexOf(this.data[i][2]) > -1)
			{
				return this.data[i];
			}
		}
		
		return null;
	}
};

// 히스토리 중 해당하는 종목정보 삭제
HistoryInfo.prototype.remove = function(data)
{
	for(var i=this.data.length-1; i>=0; i--)
	{
		if(this.data[i][0] == data[0] && this.data[i][2] == data[2])
		{
			this.data.splice(i, 1);
			break;
		}
	}
	this.saveInfo();
};

// 히스토리 모든 정보 삭제
HistoryInfo.prototype.removeAll = function()
{
	this.data = [];
	this.saveInfo();
};

//히스토리 최대 개수 지정
HistoryInfo.prototype.setMaxCount = function(cnt)
{
	this.maxCount = parseInt(cnt)||0;
};
