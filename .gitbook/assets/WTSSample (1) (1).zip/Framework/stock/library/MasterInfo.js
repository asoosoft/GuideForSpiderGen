

/*
this.itemObj = 
{
	type1:
	{
		'001':
		{

		},
		'002':
		{

		}
	}
	...
};

*/


function MasterInfo()
{
	// stock item info
	this.itemObj = {};
	
	// 아래의 키들은 아이템의 정보를 히스토리에 저장할 배열정보로 변경할 때 사용된다.
	// getInfoByItem 호출시 [ code, name, type ] 배열 리턴한다.
	// codeKey, nameKey 는 검색할 때도 사용된다.
	this.codeKey = 'code';
	this.nameKey = 'name';
	this.typeKey = 'type';
	
	this.queueList = [];
	
	this._checkEmptyMaster = this._checkNoMasterData;
	
	this.searchType = MasterInfo.searchType;
	this.caseSensitive = MasterInfo.caseSensitive;
}

MasterInfo.searchType = 0;
MasterInfo.caseSensitive = false;

MasterInfo.setSearchType = function(type) {
	MasterInfo.searchType = type;
};
MasterInfo.setSearchCaseInsensitive = function(caseSensitive) {
	MasterInfo.caseSensitive = caseSensitive;
};

MasterInfo.prototype.set = function(obj)
{
	this.itemObj = obj;
	
	if(!$.isEmptyObject(this.itemObj))
	{
		this._checkEmptyMaster = function(){};
		var item;
		while(this.queueList.length)
		{
			item = this.queueList.pop();
			item[0].apply(this, item[1]);
		}
	}
	else
	{
		this._checkEmptyMaster = this.checkNoMasterData;
	}
};

MasterInfo.prototype.get = function(callback)
{
	if(this._checkEmptyMaster(this.get, arguments)) return this.itemObj;
	
	if(callback) callback(this.itemObj);
	return this.itemObj;
};

MasterInfo.prototype.setCodeKey = function(key)
{
	this.codeKey = key;
};

MasterInfo.prototype.setNameKey = function(key)
{
	this.nameKey = key;
};

MasterInfo.prototype.setTypeKey = function(key)
{
	this.typeKey = key;
};

MasterInfo.prototype.getCodeKey = function()
{
	return this.codeKey;
};

MasterInfo.prototype.getNameKey = function()
{
	return this.nameKey;
};

MasterInfo.prototype.getTypeKey = function()
{
	return this.typeKey;
};

MasterInfo.prototype.getDefaultItem = function(typeArr, callback)
{
	if(this._checkEmptyMaster(this.getDefaultItem, arguments)) return;
	
	if(typeArr != undefined)
	{
		if(typeof(typeArr) == 'string') typeArr = [typeArr];
		
		for(var type in this.itemObj)
		{
			if(!typeArr.includes(type)) continue;
			
			for(var code in this.itemObj[type])
			{
				if(callback) callback(this.itemObj[type][code]);
				return this.itemObj[type][code];
			}
		}
		/*
		for(var code in this.itemObj[type])
		{
			return this.itemObj[type][code];
		}*/
	}
	else
	{
		for(var type in this.itemObj)
		{
			for(var code in this.itemObj[type])
			{
				if(callback) callback(this.itemObj[type][code]);
				return this.itemObj[type][code];
			}
		}
	}
};

MasterInfo.prototype.getDefaultItemInfo = function(typeArr, callback)
{
	if(this._checkEmptyMaster(this.getDefaultItemInfo, arguments)) return;
	
	var item = this.getDefaultItem(typeArr);
	
	if(item) item = this.getInfoByItem(item);
	
	if(callback) callback(item);
	return item;
};

MasterInfo.prototype.getItemsOfTypes = function(type, callback)
{
	var arr = [], items;
	
	if(this._checkEmptyMaster(this.getItemsOfTypes, arguments)) return arr;
	
	if(type)
	{
		if(typeof(type) == 'string') type = [type];
		for(var i=0; i<type.length; i++)
		{
			items = this.itemObj[type[i]];
			for(var code in items)
			{
				arr.push(items[code]);
			}
		}
	}
	else
	{
		for(var type in this.itemObj)
		{
			items = this.itemObj[type];
			for(var code in items)
			{
				arr.push(items[code]);
			}
		}
	}
	
	if(callback) callback(arr);
	return arr;
};

MasterInfo.prototype.getItem = function(itemCode, type, callback)
{
	if(this._checkEmptyMaster(this.getItem, arguments)) return;
	
	var ret = this.itemObj[type] ? this.itemObj[type][itemCode] : null;
	
	if(callback) callback(ret);
	return ret;
};

MasterInfo.prototype.getInfoByItem = function(item, callback)
{
	if(item) item = [item[this.codeKey], item[this.nameKey], item[this.typeKey]];
	if(callback) callback(item);
	return item;
};

MasterInfo.prototype.getItemByInfo = function(info, callback)
{
	if(this._checkEmptyMaster(this.getItemByInfo, arguments)) return;
	
	var ret = this.getItem(info[0], info[2]);
	if(callback) callback(ret);
	return ret;
};

MasterInfo.prototype.getItemValue = function(itemCode, type, valueKey, callback)
{
	if(this._checkEmptyMaster(this.getItemValue, arguments)) return;
	
	var ret;
	var item = this.getItem(itemCode, type);
	if(item) ret = item[valueKey];
	
	if(callback) callback(ret);
	return ret;
};

MasterInfo.prototype.searchItemInfo = function(srchTxt, type, except, callback)
{
	var result = [];
	
	if(this._checkEmptyMaster(this.searchItemInfo, arguments)) return result;
	
	var cmprTxt, obj = this.itemObj, info, itemInfo;
	
	srchTxt = srchTxt.toLowerCase();
	
	if(typeof(type) == 'string') type = [type];
	
	// key는 마켓 또는 분류값
	for(var key in obj)
	{
		// type 값이 있고 key와 다르면 continue
		if(type != undefined)
		{
			if(type.indexOf(key) < 0) continue;
		}
		
		// code 는 코드
		for(var code in obj[key])
		{
			item = obj[key][code];
			if(typeof item == 'string') continue;
			cmprTxt = item[this.nameKey];

			//종목명 비교
			if(!srchTxt || Search.compareText(srchTxt, cmprTxt.toLowerCase(), this.searchType, this.caseSensitive) || item[this.codeKey].toLowerCase().indexOf(srchTxt)>-1)
			{
				// except외 종목들은 보여지지 않게 처리함
				if(except && !code.match(except)) continue;

				itemInfo = this.getInfoByItem(item);

				//차후 특정 조건으로 정렬해야 할 경우 값을 셋팅한다.
				//arr.sortKey = info[''];

				result.push(itemInfo);
			}
		}
	}
	
	this.sortArr(result);
	if(callback) callback(result);
	return result;
	//return result;
};

MasterInfo.prototype.sortArr = function(sortArr)
{
	return sortArr;
	
	/*
	function compareFunc(a, b)
	{
		return a.sortKey-b.sortKey;
	}
	*/
	
	function compareFunc(a, b)
	{
		if(a.sortKey<b.sortKey) return -1;
		if(a.sortKey>b.sortKey) return 1;
		
		return 0;
	}
	
	
	return arr.sort(compareFunc);
};

//마스터가 세팅되기 전인 경우 return true를 반환한다.
MasterInfo.prototype._checkNoMasterData = function(func, param)
{
	if($.isEmptyObject(this.itemObj)) {
		this.queueList.unshift([func, param]);
		return true;
	}
};

MasterInfo.prototype.setSearchType = function(type)
{
	this.searchType = type;
};

MasterInfo.prototype.setSearchCaseInsensitive = function(caseSensitive)
{
	this.caseSensitive = caseSensitive;
};



