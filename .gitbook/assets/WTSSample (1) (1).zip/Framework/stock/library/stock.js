
var stock = 
{
};
//console.log('mdfc.js -> temp add lib');
//rMate css
//$('<link rel="stylesheet" type="text/css" href="lib/rMateGridH5/Assets/rMateH5.css"/>').appendTo('head');
//rMate license
//$('<script language="javascript" type="text/javascript" src="lib/LicenseKey/rMateGridH5License.js"></script>').appendTo('head');
//rMateGridH5 라이브러리  
//$('<script language="javascript" type="text/javascript" src="lib/rMateGridH5/JS/rMateGridH5.js"></script>').appendTo('head');

/*
mdfc.ClassName =
{
    RBARCHART:'RBarChart'
};


mdfc.COMP_CTX = {};
//버튼
mdfc.COMP_CTX[mdfc.ClassName.RBARCHART] = 
{
	
    //tag:'<span data-base="AButton" data-class="AButton" class="AButton-Style"><span>Button</span></span>',
    tag:'<div data-base="RBarChart" data-class="RBarChart" class="RBarChart-Style"></div>',

    defStyle: 
    {
    	width:'200px', height:'200px' 
    },
   
    events: []
};
*/
stock.compLabel = {
	"EXBong" : "EXBong",
	"EXMiniHoga" : "EXMiniHoga",
	"EXHogaGrid" : "EXHogaGrid",
	"EXHogaView" : "EXHogaView",
	"EXCenterPivotView" : "EXCenterPivotView",
	"EXSecureTextField" : "EXSecureTextField",
	"EXTriangle" : "EXTriangle",
	"ChartView" : "ChartView",
// 	"CompareChartView" : "CompareChartView",
// 	"MultiChartView" : "MultiChartView",
	"CandleChart" : "CandleChart",
	"CompareChart" : "CompareChart",
	"EXMiniChart" : "EXMiniChart",
	"EXJisooChart" : "EXJisooChart",
	"EXItemView" : "EXItemView",
	"EXSearchView" : "EXSearchView"
};

/*
stock.defaultLib = 
{
	"library":
	[
		"stock.js"
	],
	
	"component":
	[
	],
	
	"event":
	[
	],
	
	"style":
	[
		"comp.css",
		"theme.css"
	]
};
*/


var stk = { refData: {}};

  	 	 //0(보합),1(상한),2(상승),3(보합),4(하한),5(하락),6(기세상한),7(기세상승),8(기세하한),9(기세하락)
stk.StockTextArr = [ '', '▲', '▲', '', '▼', '▼', '▲', '▲', '▼', '▼' ];

/*
stk.StockColorArr = 
[
	[
		StockColor.STEADY_COLOR,
		StockColor.UP_COLOR,
		StockColor.UP_COLOR,
		StockColor.STEADY_COLOR,
		StockColor.DOWN_COLOR,
		StockColor.DOWN_COLOR,
		StockColor.UP_COLOR,
		StockColor.UP_COLOR,
		StockColor.DOWN_COLOR,
		StockColor.DOWN_COLOR
	],
	[
		StockColor.STEADY_COLOR_D,
		StockColor.UP_COLOR_D,
		StockColor.UP_COLOR_D,
		StockColor.STEADY_COLOR_D,
		StockColor.DOWN_COLOR_D,
		StockColor.DOWN_COLOR_D,
		StockColor.UP_COLOR_D,
		StockColor.UP_COLOR_D,
		StockColor.DOWN_COLOR_D,
		StockColor.DOWN_COLOR_D
	]
];
*/
/*
stk.StockBgColorArr = 
[
	[
		StockColor.STEADY_BG_COLOR,
		StockColor.UP_BG_COLOR,
		StockColor.UP_BG_COLOR,
		StockColor.STEADY_BG_COLOR,
		StockColor.DOWN_BG_COLOR,
		StockColor.DOWN_BG_COLOR,
		StockColor.UP_BG_COLOR,
		StockColor.UP_BG_COLOR,
		StockColor.DOWN_BG_COLOR,
		StockColor.DOWN_BG_COLOR
	]
];
*/

stk.StockColorClsName = 
[
	StockColor.STEADY_CLASS,
	StockColor.UP_CLASS,
	StockColor.UP_CLASS,
	StockColor.STEADY_CLASS,
	StockColor.DOWN_CLASS,
	StockColor.DOWN_CLASS,
	StockColor.UP_CLASS,
	StockColor.UP_CLASS,
	StockColor.DOWN_CLASS,
	StockColor.DOWN_CLASS
];

stk.StockColorClsName_D = 
[
	StockColor.STEADY_CLASS_D,
	StockColor.UP_CLASS_D,
	StockColor.UP_CLASS_D,
	StockColor.STEADY_CLASS_D,
	StockColor.DOWN_CLASS_D,
	StockColor.DOWN_CLASS_D,
	StockColor.UP_CLASS_D,
	StockColor.UP_CLASS_D,
	StockColor.DOWN_CLASS_D,
	StockColor.DOWN_CLASS_D
];

stk.StockTriangleTag = 
[
	'<div class="'+StockColor.STEADY_ARROW_CLASS+'"></div>',
	'<div class="'+StockColor.UP_ARROW_CLASS+'"></div>',
	'<div class="'+StockColor.UP_TRIANGLE_CLASS+'"></div>',
	'<div class="'+StockColor.STEADY_ARROW_CLASS+'"></div>',
	'<div class="'+StockColor.DOWN_ARROW_CLASS+'"></div>',
	'<div class="'+StockColor.DOWN_TRIANGLE_CLASS+'"></div>',
	'<div class="'+StockColor.UP_ARROW_CLASS+'"></div>',
	'<div class="'+StockColor.UP_TRIANGLE_CLASS+'"></div>',
	'<div class="'+StockColor.DOWN_ARROW_CLASS+'"></div>',
	'<div class="'+StockColor.DOWN_TRIANGLE_CLASS+'"></div>',
];

stk.StockTriangleTag_D = 
[
	'<div class="'+StockColor.STEADY_ARROW_CLASS_D+'"></div>',
	'<div class="'+StockColor.UP_ARROW_CLASS_D+'"></div>',
	'<div class="'+StockColor.UP_TRIANGLE_CLASS_D+'"></div>',
	'<div class="'+StockColor.STEADY_ARROW_CLASS_D+'"></div>',
	'<div class="'+StockColor.DOWN_ARROW_CLASS_D+'"></div>',
	'<div class="'+StockColor.DOWN_TRIANGLE_CLASS_D+'"></div>',
	'<div class="'+StockColor.UP_ARROW_CLASS_D+'"></div>',
	'<div class="'+StockColor.UP_TRIANGLE_CLASS_D+'"></div>',
	'<div class="'+StockColor.DOWN_ARROW_CLASS_D+'"></div>',
	'<div class="'+StockColor.DOWN_TRIANGLE_CLASS_D+'"></div>',
];

//-------------------------------------------------------------------------------------------------------------------------------------------
//	asoocool test
//-------------------------------------------------------------------------------------------------------------------------------------------

//삼각형 구현을 위한 css
stk.StockTriangleClass = 
[
	StockColor.STEADY_ARROW_CLASS,
	StockColor.UP_ARROW_CLASS,
	StockColor.UP_TRIANGLE_CLASS,
	StockColor.STEADY_ARROW_CLASS,
	StockColor.DOWN_ARROW_CLASS,
	StockColor.DOWN_TRIANGLE_CLASS,
	StockColor.UP_ARROW_CLASS,
	StockColor.UP_TRIANGLE_CLASS,
	StockColor.DOWN_ARROW_CLASS,
	StockColor.DOWN_TRIANGLE_CLASS
];

stk.StockTriangleClass_D = 
[
	StockColor.STEADY_ARROW_CLASS_D,
	StockColor.UP_ARROW_CLASS_D,
	StockColor.UP_TRIANGLE_CLASS_D,
	StockColor.STEADY_ARROW_CLASS_D,
	StockColor.DOWN_ARROW_CLASS_D,
	StockColor.DOWN_TRIANGLE_CLASS_D,
	StockColor.UP_ARROW_CLASS_D,
	StockColor.UP_TRIANGLE_CLASS_D,
	StockColor.DOWN_ARROW_CLASS_D,
	StockColor.DOWN_TRIANGLE_CLASS_D
];

/*
stk.StockColorArr = 
[
	StockColor.STEADY_COLOR,
	StockColor.UP_COLOR,
	StockColor.UP_COLOR,
	StockColor.STEADY_COLOR,
	StockColor.DOWN_COLOR,
	StockColor.DOWN_COLOR,
	StockColor.UP_COLOR,
	StockColor.UP_COLOR,
	StockColor.DOWN_COLOR,
	StockColor.DOWN_COLOR
];

stk.StockColorArr_D = 
[
	StockColor.STEADY_COLOR_D,
	StockColor.UP_COLOR_D,
	StockColor.UP_COLOR_D,
	StockColor.STEADY_COLOR_D,
	StockColor.DOWN_COLOR_D,
	StockColor.DOWN_COLOR_D,
	StockColor.UP_COLOR_D,
	StockColor.UP_COLOR_D,
	StockColor.DOWN_COLOR_D,
	StockColor.DOWN_COLOR_D
];

stk.StockBgColorArr = 
[
	StockColor.STEADY_BG_COLOR,
	StockColor.UP_BG_COLOR,
	StockColor.UP_BG_COLOR,
	StockColor.STEADY_BG_COLOR,
	StockColor.DOWN_BG_COLOR,
	StockColor.DOWN_BG_COLOR,
	StockColor.UP_BG_COLOR,
	StockColor.UP_BG_COLOR,
	StockColor.DOWN_BG_COLOR,
	StockColor.DOWN_BG_COLOR
];*/



//대비부호에 따른 색상 체크 함수 1(상한),2(상승),3(보합),4(하한),5(하락)
stk.getStockColor = function(state)
{
	return StockColor[StockColor._stateColorNameArr[state]];
};

stk.getStockColor_D = function(state)
{
	return StockColor[StockColor._stateColorNameArr_D[state]];
};

stk.getStockBgColor = function(state)
{
	return StockColor[StockColor._stateBgColorNameArr[state]];
}

//대비부호에 따른 상승하락 문자 리턴
stk.getStockText = function(state)
{
	return stk.StockTextArr[state];
};

//기준가에 따른 상승하락 대비부호 리턴
stk.getStockColorState = function(value, baseValue)
{
	//value = afc.removeComma(value);
	//if(value == '') value = 0;
	
	if(!value) value = 0;
	
	if(value < baseValue) return 5;
	else if(value > baseValue) return 1;
	else return 3;
};

//대비구분에 따른 삼각형 태그 리턴
stk.getStockTriangle = function(state, mask, data, ele)
{
	if(ele)
		ele.firstChild.className = stk.StockTriangleClass[state];
	else
		return stk.StockTriangleTag[state];
};

//대비구분에 따른 삼각형 태그 리턴
stk.getStockTriangle_D = function(state, mask, data, ele)
{
	if(ele)
		ele.firstChild.className = stk.StockTriangleClass_D[state];
	else
		return stk.StockTriangleTag_D[state];
};

//대비구분에 따른 라벨색 태그 리턴
stk.getStockColorTag = function(value, state, ele)
{
	var color = stk.getStockColor(state);
	if(ele)
	{
		ele.firstChild.textContent = value;
		ele.firstChild.style['color'] = color;
	}
	else return '<span style="color:'+color+'; ">'+value+'</span>'; 
};

//대비율에 따른 삼각형과 라벨 태그 리턴
stk.getTriAndColorTag = function(value, mask, data, ele)
{
	if(ele)
	{
		ele.lastChild.textContent = mask(value);
		
		if(value > 0)
		{
			ele.firstChild.className = StockColor.UP_TRIANGLE_CLASS;
			ele.lastChild.style['color'] = stk.getStockColor(1);
		} 
		
		else if(value < 0) 
		{
			ele.firstChild.className = StockColor.DOWN_TRIANGLE_CLASS;
			ele.lastChild.style['color'] = stk.getStockColor(5);
		}
		else 
		{
			ele.firstChild.className = '';
			ele.lastChild.style['color'] = stk.getStockColor(3);
		}
		
	}
	else
	{
		if(value > 0) return '<div class="'+StockColor.UP_TRIANGLE_CLASS+'"></div>'+'<span style="color:'+stk.getStockColor(1)+'; ">'+mask(value)+'</span>';
		else if(value < 0) return '<div class="'+StockColor.DOWN_TRIANGLE_CLASS+'"></div>'+'<span style="color:'+stk.getStockColor(5)+'; ">'+mask(value)+'</span>';
		else return '<div style="float:left"></div><span style="color:'+stk.getStockColor(3)+'; ">'+mask(value)+'</span>';
	}
};

//등락구분에 따른 삼각형과 라벨 태그 리턴
stk.getTriAndColorTagByState = function(value, mask, state, ele)
{
	if(ele)
	{
		ele.firstChild.textContent = '';
		ele.lastChild.textContent = mask(value);
		
		var colorVal = stk.getStockColor(state);
		if(colorVal)
		{
			ele.firstChild.className = stk.StockTriangleClass[state];
			ele.lastChild.style['color'] = colorVal;
		}
		else
		{
			if(state == '69') ele.firstChild.textContent = '예';
			else if(state == '70') ele.firstChild.textContent = '외';
			
			if(value > 0) 
			{
				ele.firstChild.className = stk.StockColorClsName[1];
				ele.lastChild.style['color'] = stk.getStockColor(1);
			}
			else if(value < 0) 
			{
				ele.firstChild.className = stk.StockColorClsName[5];
				ele.lastChild.style['color'] = stk.getStockColor(5);
			}
			else 
			{
				ele.firstChild.className = stk.StockColorClsName[3];
				ele.lastChild.style['color'] = stk.getStockColor(3);
			}
		}
		
	}
	else
	{
		if(stk.StockColorClsName[state])
			return stk.getStockTriangle(state)+'<span style="color:'+stk.getStockColor(state)+'; ">'+mask(value)+'</span>';
		else
		{
			var text;
			if(state == '69') text = '예';
			else if(state == '70') text = '외';
			
			if(value > 0) return '<div class = "'+StockColor.UP_CLASS+'" style = "margin-left: 5px; float:left">' + text + '</div>'+'<span style="color:'+stk.getStockColor(1)+'; ">'+mask(value)+'</span>';
			else if(value < 0) return '<div class = "'+StockColor.DOWN_CLASS+'" style = "margin-left: 5px; float:left">' + text + '</div>'+'<span style="color:'+stk.getStockColor(5)+'; ">'+mask(value)+'</span>';
			else return '<div class = "'+StockColor.STEADY_CLASS+'" style = "margin-left: 5px; float:left">' + text + '</div>'+'<span style="color:'+stk.getStockColor(3)+'; ">'+mask(value)+'</span>';
		}		
	}
};

//등락구분에 따른 삼각형과 라벨 태그 리턴
stk.getPrdtOvtmTextByState = function(value, mask, state, ele)
{
	if(ele)
	{
		ele.firstChild.textContent = '';
		
		if(!stk.StockColorClsName[state])
		{
			if(state == '69') ele.firstChild.textContent = '예';
			else if(state == '70') ele.firstChild.textContent = '외';
			
			if(value > 0) ele.firstChild.style['color'] = stk.getStockColor(1);
			else if(value < 0) ele.firstChild.style['color'] = stk.getStockColor(5);
			else ele.firstChild.style['color'] = stk.getStockColor(3);
		}
	}
	else
	{
		if(!stk.StockColorClsName[state])
		{
			var text;
			if(state == '69') text = '예';
			else if(state == '70') text = '외';
			
			if(value > 0) return '<div style="color:'+stk.getStockColor(1)+'; float:left;">'+text+'</div>';
			else if(value < 0) return '<div style="color:'+stk.getStockColor(5)+'; float:left;">'+text+'</div>';
			else return '<div style="color:'+stk.getStockColor(3)+'; float:left;">'+text+'</div>';
		}
		else return '<div style="float:left"></div>';
	}
};

//대비율에 따른 삼각형과 라벨 태그 리턴_어두움배경
stk.getTriAndColorTag_D = function(value, mask, data, ele)
{
	if(ele)
	{
		ele.lastChild.textContent = mask(value);
		
		if(value > 0)
		{
			ele.firstChild.className = StockColor.UP_TRIANGLE_CLASS_D;
			ele.lastChild.style['color'] = stk.getStockColor_D(1);
		} 
		
		else if(value < 0) 
		{
			ele.firstChild.className = StockColor.DOWN_TRIANGLE_CLASS_D;
			ele.lastChild.style['color'] = stk.getStockColor_D(5);
		}
		else 
		{
			ele.firstChild.className = '';
			ele.lastChild.style['color'] = stk.getStockColor_D(3);
		}
	}
	else
	{
		if(value > 0) return '<div class="'+StockColor.UP_TRIANGLE_CLASS_D+'"></div>'+'<span style="color:'+stk.getStockColor_D(1)+'; ">'+mask(value)+'</span>';
		else if(value < 0) return '<div class="'+StockColor.DOWN_TRIANGLE_CLASS_D+'"></div>'+'<span style="color:'+stk.getStockColor_D(5)+'; ">'+mask(value)+'</span>';
		else return '<div style="float:left"></div><span style="color:'+stk.getStockColor_D(3)+'; ">'+mask(value)+'</span>';
	}
};

//등락구분에 따른 삼각형과 라벨 태그 리턴_어두운 배경
stk.getTriAndColorTagByState_D = function(value, mask, state, ele)
{
	if(ele)
	{
		ele.firstChild.textContent = '';
		ele.lastChild.textContent = mask(value);
		
		var colorVal = stk.getStockColor_D(state); 
		if(colorVal)
		{
			ele.firstChild.className = stk.StockTriangleClass_D[state];
			ele.lastChild.style['color'] = colorVal;
		}
		else
		{
			if(state == '69') ele.firstChild.textContent = '예';
			else if(state == '70') ele.firstChild.textContent = '외';
			
			if(value > 0) 
			{
				ele.firstChild.className = stk.StockColorClsName_D[1];
				ele.lastChild.style['color'] = stk.getStockColor_D(1);
			}
			else if(value < 0) 
			{
				ele.firstChild.className = stk.StockColorClsName_D[5];
				ele.lastChild.style['color'] = stk.getStockColor_D(5);
			}
			else 
			{
				ele.firstChild.className = stk.StockColorClsName_D[3];
				ele.lastChild.style['color'] = stk.getStockColor_D(3);
			}
		}
		
	}
	else
	{
		if(stk.StockColorClsName[state])
			return stk.getStockTriangle_D(state)+'<span style="color:'+stk.getStockColor_D(state)+'; ">'+mask(value)+'</span>';
		else
		{
			var text;
			if(state == '69') text = '예';
			else if(state == '70') text = '외';
			
			if(value > 0) return '<div class = "'+StockColor.UP_CLASS_D+'" style = "float:left">' + text + '</div>'+'<span style="color:'+stk.getStockColor_D(1)+'; ">'+mask(value)+'</span>';
			else if(value < 0) return '<div class = "'+StockColor.DOWN_CLASS_D+'" style = "float:left">' + text + '</div>'+'<span style="color:'+stk.getStockColor_D(5)+'; ">'+mask(value)+'</span>';
			else return '<div class = "'+StockColor.STEADY_CLASS_D+'" style = "float:left">' + text + '</div>'+'<span style="color:'+stk.getStockColor_D(3)+'; ">'+mask(value)+'</span>';
		}		
	}
};

//기준가에 따른 태그 리턴
stk.makeStockTag = function(value, baseValue, newValue, ele)
{
	if(ele)
	{
		ele.firstChild.textContent = newValue;
		
		if(baseValue == undefined) ele.firstChild.style['color'] = stk.getStockColor(3);
		else if(value > baseValue) ele.firstChild.style['color'] = stk.getStockColor(1);
		else if(value < baseValue) ele.firstChild.style['color'] = stk.getStockColor(5);
		else ele.firstChild.style['color'] = stk.getStockColor(3);
	}
	else
	{
		if(baseValue == undefined) return '<span style="color:'+stk.getStockColor(3)+'; ">'+newValue+'</span>';
		else if(value > baseValue) return '<span style="color:'+stk.getStockColor(1)+'; ">'+newValue+'</span>';
		else if(value < baseValue) return '<span style="color:'+stk.getStockColor(5)+'; ">'+newValue+'</span>';
		else return '<span style="color:'+stk.getStockColor(3)+'; ">'+newValue+'</span>';
	}
};

//기준가에 따른 태그 리턴
stk.makeStockTag_D = function(value, baseValue, newValue, ele)
{
	if(ele)
	{
		ele.firstChild.textContent = newValue;
		
		if(baseValue == undefined) ele.firstChild.style['color'] = stk.getStockColor_D(3);
		else if(value > baseValue) ele.firstChild.style['color'] = stk.getStockColor_D(1);
		else if(value < baseValue) ele.firstChild.style['color'] = stk.getStockColor_D(5);
		else ele.firstChild.style['color'] = stk.getStockColor_D(3);
	}
	else
	{
		if(baseValue == undefined) return '<span style="color:'+stk.getStockColor_D(3)+'; ">'+newValue+'</span>';
		else if(value > baseValue) return '<span style="color:'+stk.getStockColor_D(1)+'; ">'+newValue+'</span>';
		else if(value < baseValue) return '<span style="color:'+stk.getStockColor_D(5)+'; ">'+newValue+'</span>';
		else return '<span style="color:'+stk.getStockColor_D(3)+'; ">'+newValue+'</span>';
	}
};

//마스크 정보로 리턴
stk.getAsMaskedIt = function(value, mask)
{
	return mask(value);
};

//------------------------------------------------------------------------------------------
//0과 비교하여 색상 태그 리턴(하락 / 상승 / 보합) 호가그리드에서 사용되는 등락율태그
//리얼에서 사용하지 않음.
stk.getCtrtRateTag = function(value, mask, baseValue)
{
	if(!baseValue) return '<span class = "B SZ22 '+StockColor.UP_CLASS+'" style="padding:0 0 0 10px;"> - </span>';

	value = afc.removeComma(value) - baseValue;
	var newValue = mask((value/baseValue)*100);
	/*
	if(value > 0) return '<span class = "B SZ22 '+StockColor.UP_CLASS+'" style="padding:0 0 0 10px;">'+newValue+'<font class="SZ15">%</font></span>';
	else if(value < 0) return '<span class = "B SZ22 '+StockColor.DOWN_CLASS+'" style=" padding:0 0 0 10px;">'+newValue+'<font class="SZ15">%</font></span>';
	else return '<span class = "B SZ22 '+StockColor.STEADY_CLASS+'" style="padding:0 0 0 10px;">'+newValue+'<font class="SZ15">%</font></span>';
	*/
	if(value > 0) return '<span class = "B SZ22 '+StockColor.UP_CLASS+'" style="padding:0 0 0 10px;">'+newValue+'%</span>';
	else if(value < 0) return '<span class = "B SZ22 '+StockColor.DOWN_CLASS+'" style=" padding:0 0 0 10px;">'+newValue+'%</span>';
	else return '<span class = "B SZ22 '+StockColor.STEADY_CLASS+'" style="padding:0 0 0 10px;">'+newValue+'%</span>';
};

//0과 비교하여 색상 태그 리턴(하락 / 상승 / 보합) 호가그리드에서 사용되는 등락율태그
stk.getCtrtTag = function(value, mask, baseValue, ele)
{
	if(value == '') value = 0;
	
	if(ele)
	{
		stk.getColorTagCfValue(value, mask, baseValue, ele);
		
		ele.lastChild.textContent = afc.toFixed2(((value-baseValue)/baseValue)*100) + '%'; 
		
		if(baseValue == undefined) ele.lastChild.style['color'] = stk.getStockColor(3);
		else if(value-baseValue > 0) ele.lastChild.style['color'] = stk.getStockColor(1);
		else if(value-baseValue < 0) ele.lastChild.style['color'] = stk.getStockColor(5);
		else ele.lastChild.style['color'] = stk.getStockColor(3);
	}
	else
	{
		var tag = stk.getColorTagCfValue(value, mask, baseValue, ele);
		
		var newValue = afc.toFixed2(((value-baseValue)/baseValue)*100);

		if(baseValue == undefined) tag += '<span class="B SZ22" style="color:'+stk.getStockColor(3)+'; padding:0 0 0 10px;">'+newValue+'%</span>';
		else if(value == 0) tag += '<span class="B SZ22" style="color:'+stk.getStockColor(1)+'; padding:0 0 0 10px;"></span>';
		else if(value-baseValue > 0) tag += '<span class="B SZ22" style="color:'+stk.getStockColor(1)+'; padding:0 0 0 10px;">'+newValue+'%</span>';
		else if(value-baseValue < 0) tag += '<span class="B SZ22" style="color:'+stk.getStockColor(5)+'; padding:0 0 0 10px;">'+newValue+'%</span>';
		else tag += '<span class="B SZ22" style="color:'+stk.getStockColor(3)+'; padding:0 0 0 10px;">'+newValue+'%</span>';

		/*		
		if(value-baseValue > 0) tag += '<span class="B SZ22" style="color:'+stk.getStockColor(1)+'; padding:0 0 0 10px;">'+newValue+'<font class="SZ15">%</font></span>';
		else if(value-baseValue < 0) tag += '<span class="B SZ22" style="color:'+stk.getStockColor(5)+'; padding:0 0 0 10px;">'+newValue+'<font class="SZ15">%</font></span>';
		else tag += '<span class="B SZ22" style="color:'+stk.getStockColor(3)+'; padding:0 0 0 10px;">'+newValue+'<font class="SZ15">%</font></span>';
		*/
		
		return tag;
	}
};
//------------------------------------------------------------------------------------------------


//0과 비교하여 색상 태그 리턴(하락 / 상승 / 보합)
stk.getColorTagCfZero = function(value, mask, data, ele)
{
	//value = afc.removeComma(value);
	//if(value == '') value = 0;

	if(!value) value = 0;
	
	return stk.makeStockTag(value, 0, mask(value), ele);	
};

//0과 비교하여 색상 태그 리턴(하락 / 상승 / 보합)
stk.getColorTagCfZero_D = function(value, mask, data, ele)
{
	//value = afc.removeComma(value);
	//if(value == '') value = 0;
	
	if(!value) value = 0;
	
	return stk.makeStockTag_D(value, 0, mask(value), ele);	
};

//값 비교에 따른 색상 태그 리턴(하락 / 상승 / 보합)
stk.getColorTagCfValue = function(value, mask, baseValue, ele)
{
	//value = afc.removeComma(value);
	//if(value == '') value = 0;
	
	if(!value) value = 0;
	
	return stk.makeStockTag(value, baseValue, mask(value), ele);	
};

//값 비교에 따른 색상 태그 리턴(하락 / 상승 / 보합)
stk.getColorTagCfValue_D = function(value, mask, baseValue, ele)
{
	//value = afc.removeComma(value);
	//if(value == '') value = 0;
	
	if(!value) value = 0;
	
	return stk.makeStockTag_D(value, baseValue, mask(value), ele);	
};

//구분값에 따른 색상 태그 리턴(하락 / 상승 / 보합)
stk.getColorTagCfState = function(value, mask, state, ele)
{
	//value = afc.removeComma(value);
	//if(value == '') value = 0;
	
	if(!value) value = 0;
	
	return stk.getStockColorTag(mask(value), state, ele);	
};

//baseValue와 0을 비교하여 색상 태그 리턴(하락 / 상승 / 보합)
stk.getBgColorTagCfZero = function(value, mask, data, ele)
{
	if(ele)
	{
		ele.firstChild.textContent = mask(value);
		
		if(value > 0) ele.firstChild.style['background-color'] = StockColor.UP_BG_COLOR;
		else if(value < 0) ele.firstChild.style['background-color'] = StockColor.DOWN_BG_COLOR;
		else ele.firstChild.style['background-color'] = StockColor.STEADY_BG_COLOR;
	}
	else
	{
		if(value > 0) return '<span style="width:95px; height:32px; line-height:32px; background-color:'+StockColor.UP_BG_COLOR+';" class = "'+StockColor.UP_SPAN_CLASS+'">'+mask(value)+'</span>';
		else if(value < 0) return '<span style="width:95px; height:32px; line-height:32px; background-color:'+StockColor.DOWN_BG_COLOR+';" class = "'+StockColor.DOWN_SPAN_CLASS+'">'+mask(value)+'</span>';
		else return '<span style="width:95px; height:32px; line-height:32px; background-color:'+StockColor.STEADY_BG_COLOR+';" class = "'+StockColor.STEADY_SPAN_CLASS+'">'+mask(value)+'</span>';
	}
};

stk.getBgColorTagCfZero125 = function(value, mask, data, ele)
{
	if(ele)
	{
		ele.firstChild.textContent = mask(value);
		
		if(value > 0) ele.firstChild.style['background-color'] = StockColor.UP_BG_COLOR;
		else if(value < 0) ele.firstChild.style['background-color'] = StockColor.DOWN_BG_COLOR;
		else ele.firstChild.style['background-color'] = StockColor.STEADY_BG_COLOR;
	}
	else
	{
		if(value > 0) return '<span style="width:125px; height:40px; line-height:40px; background-color:'+StockColor.UP_BG_COLOR+';" class = "'+StockColor.UP_SPAN_CLASS+'">'+mask(value)+'</span>';
		else if(value < 0) return '<span style="width:125px; height:40px; line-height:40px; background-color:'+StockColor.DOWN_BG_COLOR+';" class = "'+StockColor.DOWN_SPAN_CLASS+'">'+mask(value)+'</span>';
		else return '<span style="width:125px; height:40px; line-height:40px; background-color:'+StockColor.STEADY_BG_COLOR+';" class = "'+StockColor.STEADY_SPAN_CLASS+'">'+mask(value)+'</span>';
	}
};

//baseValue와 0을 비교하여 색상 태그 리턴(하락 / 상승 / 보합)
stk.getColorTagValueCfZero = function(value, mask, baseValue, ele)
{
	//baseValue = afc.removeComma(baseValue);
	//if(baseValue == '') baseValue = 0;
	
	if(!baseValue) baseValue = 0;
	
	return stk.makeStockTag(baseValue, 0, mask(value), ele);	
};

//baseValue의 값(1: 매도 2: 매수)에 따라 색상 태그 리턴 
stk.getColorTagCfOrderType = function(value, mask, baseValue, ele)
{
	return stk.makeStockTag(baseValue, 1.5, mask(value), ele);	
};

//baseValue의 값(1: 매도 2: 매수)에 따라 색상 태그 리턴 
stk.getColorTagCfOrderText = function(value, mask, baseValue, ele)
{
	if(baseValue == '매도') baseValue = 1;
	else if(baseValue == '매수') baseValue = 2;
	//else baseValue = 2;
	 
	return stk.makeStockTag(baseValue, 1.5, mask(value), ele);	
};

//매수 상승색
stk.getUpColorTag = function(value, mask, data, ele)
{
	return stk.getStockColorTag(mask(value), 1, ele);
};

//매도 하락색
stk.getDownColorTag = function(value, mask, data, ele)
{
	return stk.getStockColorTag(mask(value), 5, ele);
};

//0과 비교하여 색상 리턴
stk.getColorCfZero = function(value)
{
	//value = afc.removeComma(value);
	//if(value == '') value = 0;
	
	if(!value) value = 0;
	
	if(value > 0) return StockColor.UP_COLOR;
	else if(value < 0) return StockColor.DOWN_COLOR;
	else return StockColor.STEADY_COLOR;
};

//0과 비교하여 색상 리턴
stk.getBgColorCfZero = function(value)
{
	//value = afc.removeComma(value);
	//if(value == '') value = 0;
	
	if(!value) value = 0;
	
	if(value > 0) return StockColor.UP_BG_COLOR;
	else if(value < 0) return StockColor.DOWN_BG_COLOR;
	else return StockColor.STEADY_BG_COLOR;
};

//0과 비교하여 색상 리턴(어두운 배경)
stk.getColorCfZero_D = function(value)
{
	//value = afc.removeComma(value);
	//if(value == '') value = 0;
	
	if(!value) value = 0;
	
	if(value > 0) return StockColor.UP_COLOR_D;
	else if(value < 0) return StockColor.DOWN_COLOR_D;
	else return StockColor.STEADY_COLOR_D;
};

//기준가에 따른 색상체크 함수 (하락 / 상승 / 보합)
stk.getColorCfValue = function(value, baseValue)
{
	//value = afc.removeComma(value);
	//if(value == '') value = 0;
	
	if(!value) value = 0;
	
	if(value > baseValue) return StockColor.UP_COLOR;
	else if(value < baseValue) return StockColor.DOWN_COLOR;
	else return StockColor.STEADY_COLOR;
};

//기준가에 따른 색상체크 함수 (하락 / 상승 / 보합)
stk.getBgColorCfValue = function(value, baseValue)
{
	//value = afc.removeComma(value);
	//if(value == '') value = 0;
	
	if(!value) value = 0;
	
	if(value > baseValue) return StockColor.UP_BG_COLOR;
	else if(value < baseValue) return StockColor.DOWN_BG_COLOR;
	else return StockColor.STEADY_BG_COLOR;
};

//기준가에 따른 색상체크 함수 (하락 / 상승 / 보합)
stk.getColorCfValue_D = function(value, baseValue)
{
	//value = afc.removeComma(value);
	//if(value == '') value = 0;
	
	if(!value) value = 0;
	
	if(value > baseValue) return StockColor.UP_COLOR_D;
	else if(value < baseValue) return StockColor.DOWN_COLOR_D;
	else return StockColor.STEADY_COLOR_D;
};

//deprecated, use stk.getStockColor 
stk.getColorCfState = function(value, state)
{
	return stk.getStockColor(state);
};

//deprecated, use stk.getStockBgColor;
stk.getBgColorCfState = function(value, state)
{
	return stk.getStockBgColor(state);
};

//deprecated, use stk.getStockColor_D
stk.getColorCfState_D = function(value, state)
{
	return stk.getStockColor_D(state);
};

stk.getColorValueCfZero = function(value, baseValue)
{
	//baseValue = afc.removeComma(baseValue);
	//if(baseValue == '') baseValue = 0;
	
	if(!baseValue) baseValue = 0;
	
	if(baseValue > 0) return StockColor.UP_COLOR;
	else if(baseValue < 0) return StockColor.DOWN_COLOR;
	else return StockColor.STEADY_COLOR;
};

stk.getBgColorValueCfZero = function(value, baseValue)
{
	//baseValue = afc.removeComma(baseValue);
	//if(baseValue == '') baseValue = 0;
	
	if(!baseValue) baseValue = 0;
	
	if(baseValue > 0) return StockColor.UP_BG_COLOR;
	else if(baseValue < 0) return StockColor.DOWN_BG_COLOR;
	else return StockColor.STEADY_BG_COLOR;
};

stk.getColorValueCfZero_D = function(value, baseValue)
{
	//baseValue = afc.removeComma(baseValue);
	//if(baseValue == '') baseValue = 0;
	
	if(!baseValue) baseValue = 0;
	
	if(baseValue > 0) return StockColor.UP_COLOR_D;
	else if(baseValue < 0) return StockColor.DOWN_COLOR_D;
	else return StockColor.STEADY_COLOR_D;
};

//기준가에 따른 색상체크 함수 (하락 / 상승 / 보합)
stk.getStockColorCompare = function(value, baseValue, ele)
{
	//value = afc.removeComma(value);
	//if(value == '') value = 0;
	
	if(!value) value = 0;
	
	return stk.makeStockTag(value, baseValue, afc.addComma(value), ele);	
};

//기준가에 따른 색상체크 함수 (하락 / 상승 / 보합)
stk.getStockColorCompareFO = function(value, baseValue, valueType, ele)
{
	if(!value) value = 0;
	
	return stk.makeStockTag(value, baseValue, afc.addComma(value.toFixed(valueType)), ele);
};

//기준값에 따른 색상체크 함수 소수점 pos이하 버림
stk.getStockColorCompareFloor = function(value, baseValue, pos, ele)
{
	if(!value) value = 0;
	
	return stk.makeStockTag(value, baseValue, afc.addComma(afc.floor(value, pos)), ele);
};

//기준값에 따른 색상체크 함수 소수점 pos이하 버림
stk.getStockColorCompareFloorPer = function(value, baseValue, pos, ele)
{
	if(!value) value = 0;
	
	return stk.makeStockTag(value, baseValue, afc.addComma(afc.floor(value, pos)), ele);
};

//기준가에 따른 색상체크 함수 (하락 / 상승 / 보합)
stk.getStockClassName = function(value, baseValue)
{
	value *= 1;
	baseValue *= 1;
	if(value > baseValue) return StockColor.UP_CLASS;
	else if(value < baseValue) return StockColor.DOWN_CLASS;
	else return StockColor.STEADY_CLASS;
};

stk.setRefData = function(key, data)
{
	stk.refData[key] = data;
};

stk.getRefData = function(key)
{
	return stk.refData[key];
};

stk.RGBtoRGBA = function(r, g, b)
{
	if((g == void 0) && (typeof r == "string"))
	{
		if(r.indexOf('rgb') > -1)
		{
			r = r.replace(/rgb|\(|\)/g, '').split(',');
			g = parseInt(r[1]);
			b = parseInt(r[2]);
			r = parseInt(r[0]);
		}
		else
		{
			r = r.replace(/^\s*#|\s*&/g, "");
			if(r.length == 3) r = r.replace(/(.)/g, "$1$1");
			g = parseInt(r.substr(2, 2), 16);
			b = parseInt(r.substr(4, 2), 16);
			r = parseInt(r.substr(0, 2), 16);
		}
	}
	r = Math.min(r, 255);
	g = Math.min(g, 255);
	b = Math.min(b, 255);
	var min, d = (255 - (min = Math.min(r, g, b)) ) / 255;
	return [
		r = 0 | (r - min) / d,
		g = 0 | (g - min) / d,
		b = 0 | (b - min) / d,
		d = (0 | 1000 * d) / 1000
	];
};

