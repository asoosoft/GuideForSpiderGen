
/**
Constructor
Do not call Function in Constructor.
*/
function Search()
{
}

//-------------------------------------------------------------------------------------------------------


//초성검색 관련
Search._chosung = [ 'ㄱ', 'ㄲ', 'ㄴ', 'ㄷ', 'ㄸ', 'ㄹ', 'ㅁ', 'ㅂ', 'ㅃ', 'ㅅ', 'ㅆ', 'ㅇ', 'ㅈ', 'ㅉ', 'ㅊ', 'ㅋ', 'ㅌ', 'ㅍ', 'ㅎ' ];
Search._choHash = null;

Search._getChosung = function(code)
{
	code -= 44032;
	if(code>-1 && code<11172) return Search._chosung[Math.floor(code/588)].charCodeAt(0);
};

Search._makeHash = function()
{
    var hash = {'0': 0}, arr = Search._chosung;
	
    for (var i = 0; i<arr.length; i++) 
	{
		if(arr[i]) hash[arr[i].charCodeAt(0)] = i;
    }
	
	Search._choHash = hash;
};

Search._makeHash();

//---------------------------------------------------------------------------------------------------------
// type
// 0: 검색어로 시작하는 경우만(초성검색 포함)
// 1: 검색어가 있는 모든 경우(초성검색 포함)
// isCaseSensitive : 대소문자 구분 여부
Search.compareText = function(srchTxt, cmprTxt, type, isCaseSensitive)
{
	// 검색어가 단어의 길이보다 긴 경우 비교하지 않음
	if(srchTxt.length > cmprTxt.length) return false;
	
	//대소문자 구분처리하기
	if(!isCaseSensitive) {
		srchTxt = srchTxt.toLowerCase();
		cmprTxt = cmprTxt.toLowerCase();
	}
	
	if(!type)
	{
		var code, code2;
		for(var i=0; i<srchTxt.length; i++)
		{
			if(i>=cmprTxt.length) return false;
			else
			{
				code = srchTxt.charCodeAt(i);
				code2 = cmprTxt.charCodeAt(i);

				if(Search._choHash[code]!=undefined)
				{
					if(code!=Search._getChosung(code2)) return false;
				}
				else if(code!=code2) return false;
			}
		}

		return cmprTxt.substring(0, srchTxt.length);
	}
	else if(type == 1)
	{
		if(cmprTxt.indexOf(srchTxt) > -1) return srchTxt;

		var srchCode, cmprCode, i=0, j=0, startIdx, endIdx;
		for(; i<cmprTxt.length; i++)
		{
			cmprCode = cmprTxt.charCodeAt(i);
			for(; j<srchTxt.length; j++)
			{
				srchCode = srchTxt.charCodeAt(j);

				if(srchCode == cmprCode)
				{
					if(startIdx == null) startIdx = endIdx = i;
					else endIdx = i;
					j++;
					break;
				}

				if(srchCode!=Search._getChosung(cmprCode))
				{
					i=i-j;
					j=0;
					startIdx = null;
					break;
				}
				else
				{
					if(startIdx == null) startIdx = endIdx = i;
					else endIdx = i;
					j++;
					break;
				}
			}

			if(srchTxt.length == j) return cmprTxt.substring(startIdx, endIdx+1);
		}

		return false;
	}
};
