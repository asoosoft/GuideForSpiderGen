(async function() {

await afc.import('Framework/afc/library/ADataMask.js');

ADataMask.Stock = 
{
	moneyNo0:
	{
		title: '값이 0인 경우 공백문자를 반환하고 그 외에는 정수 3자리마다 콤마를 넣는다.',
		func: function moneyNo0(value, param, ele)
		{
			if(!value || Number(value) == 0) value = '　';
			else value = ADataMask.Number.money.func(value);

			return value;
		}
	},
	
	cfValue:
	{
		title: '특정 필드값과 값을 비교하여 상승,하락,보합색으로 변경한다.(StockColor.UP_COLOR, DOWN_COLOR, STEADY_COLOR)',
		param: ['비교필드명'],
		func: function cfValue(value, param, ele, dataObj)
		{
			var data = ADataMask.getQueryData()[0];
			var cfVal = 0;
			if(data && data[param[0]]) cfVal = data[param[0]];

			const styleObj = (dataObj && dataObj.style) || ele.style;
			if(value > cfVal) styleObj.color = StockColor.UP_COLOR;
			else if(value < cfVal) styleObj.color = StockColor.DOWN_COLOR;
			else styleObj.color = StockColor.STEADY_COLOR;
			return value;
		}
	},
	
	ValueCfZero:
	{
		title: '특정 필드값과 0을 비교하여 상승,하락,보합색으로 변경한다.(StockColor.UP_COLOR, DOWN_COLOR, STEADY_COLOR)',
		param: ['비교필드명'],
		func: function ValueCfZero(value, param, ele, dataObj)
		{
			var data = ADataMask.getQueryData()[0];
			var cfVal = 0;
			if(data && data[param[0]]) cfVal = data[param[0]];

			const styleObj = (dataObj && dataObj.style) || ele.style;
			if(cfVal > 0) styleObj.color = StockColor.UP_COLOR;
			else if(cfVal < 0) styleObj.color = StockColor.DOWN_COLOR;
			else styleObj.color = StockColor.STEADY_COLOR;
			return value;
		}
	},
	
	ColorByState:
	{
		title: '등락구분 필드값에 따라 글자색을 상승,하락,보합색으로 변경한다.(StockColor.UP_COLOR, DOWN_COLOR, STEADY_COLOR)',
		param: ['등락구분 필드명'],
		func: function ColorByState(value, param, ele, dataObj)
		{
			var data = ADataMask.getQueryData()[0];
			var cfVal = 3;
			if(data && data[param[0]]) cfVal = data[param[0]];
			
            let styleObj = (dataObj && dataObj.style) || ele.style;
			var color = stk.getStockColor(cfVal)||StockColor.STEADY_COLOR;
			if(color) styleObj.color = color;
			
			return value;
		}
	},
	
	cfStkRefValue:
	{
		title: 'stk.setRefData 로 저장된 비교값과 값을 비교하여 상승,하락,보합색으로 변경한다.(StockColor.UP_COLOR, DOWN_COLOR, STEADY_COLOR)',
		param: ['비교키명'],
		func: function cfStkRefValue(value, param, ele, dataObj)
		{
			var cfVal = stk.getRefData(param[0]);
			if(cfVal == undefined) cfVal = 0;
			
			const styleObj = (dataObj && dataObj.style) || ele.style;
			if(value > cfVal) styleObj.color = StockColor.UP_COLOR;
			else if(value < cfVal) styleObj.color = StockColor.DOWN_COLOR;
			else styleObj.color = StockColor.STEADY_COLOR;
			return value;
		}
	},
	
	addBong:
	{
		title: '그리드의 셀에 봉을 표현한다. 셀의 넓이, 높이값 세팅필요(다른 컴포넌트에서는 적용되지 않음)',
		param: ['시가 필드명', '고가 필드명', '저가 필드명', '종가 필드명', '봉 넓이(15px)', '봉 높이(60px)'],
		func: function addBong(value, param, ele)
		{
			// 매핑을 Dummy Field로 해야한다.
			var data = ADataMask.getQueryData()[0];
			
			if(ele.exbong)
			{
				ele.exbong.setData([ data[param[0]], data[param[1]], data[param[2]], data[param[3]] ]);
				
				return;
			}
			else
			{
				var bong = new EXBong();
				bong.init();
				bong.$ele.css({
					'position': 'relative',
					'float': 'left',
					'width': param[4]?param[4]:'15px',
					'height': param[5]?param[5]:'60px',
				});
				bong.setData([ data[param[0]], data[param[1]], data[param[2]], data[param[3]] ]);
				ele.exbong = bong;
				
				return bong;
			}
		}
	},
	
	addTriangle:
	{
		title: '그리드의 셀에 등락구분 값으로 삼각형을 표현한다. (StockColor.UP_COLOR, DOWN_COLOR, STEADY_COLOR)',
		param: ['등락구분 필드명', '넓이(16px)', '높이(14px)'],
		func: function addTriangle(value, param, ele)
		{
			var data = ADataMask.getQueryData()[0];
			var cfVal = value;
			if(data && data[param[0]]) cfVal = data[param[0]];
			
			if(ele.extriangle)
			{
				ele.extriangle.setDirection(cfVal);
				
				return;
			}
			else
			{
				var tri = new EXTriangle();
				tri.init();
				tri.$ele.css({
					'position': 'static',
					//'float': 'left',
					'width': param[1]?param[1]:'16px',
					'height': param[2]?param[2]:'14px',
				});
				tri.initPos();
				tri.setDirection(cfVal);
				ele.extriangle = tri;
				
				return tri;
			}
		}
	},
	
	cfValueTriangle:
	{
		title: '그리드의 셀에 특정 필드값과 값을 비교하여 삼각형을 표현한다. (StockColor.UP_COLOR, DOWN_COLOR, STEADY_COLOR)',
		param: ['비교필드명', '넓이(16px)', '높이(14px)'],
		func: function cfValueTriangle(value, param, ele)
		{
			var data = ADataMask.getQueryData()[0],
				cfVal = 0;
			if(data && data[param[0]]) cfVal = data[param[0]];
			
			if(value > cfVal) cfVal = 2;
			else if(value < cfVal) cfVal = 5;
			else cfVal = 3;
			
			value = null;
			if(ele.extriangle)
			{
				ele.extriangle.setDirection(cfVal);	// ele.data === ele.extriangle
				
				return;
			}
			else
			{
				var tri = new EXTriangle();
				tri.init();
				tri.$ele.css({
					'position': 'relative',
					'float': 'left',
					'width': param[1]?param[1]:'16px',
					'height': param[2]?param[2]:'14px',
				});
				tri.initPos();
				tri.setDirection(cfVal);
				ele.extriangle = tri;
				
				return tri;
			}
		}
	},
};

})();