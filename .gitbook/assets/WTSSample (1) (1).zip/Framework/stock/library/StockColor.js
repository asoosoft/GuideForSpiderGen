var StockColor = {
	/*UP_COLOR : '#ff5353', //상승색
	DOWN_COLOR : '#418dff', //하락색*/
	
	_stateColorNameArr:
	[
		'STEADY_COLOR',
		'UP_COLOR',
		'UP_COLOR',
		'STEADY_COLOR',
		'DOWN_COLOR',
		'DOWN_COLOR',
		'UP_COLOR',
		'UP_COLOR',
		'DOWN_COLOR',
		'DOWN_COLOR'
	],
	
	_stateColorNameArr_D:
	[
		'STEADY_COLOR_D',
		'UP_COLOR_D',
		'UP_COLOR_D',
		'STEADY_COLOR_D',
		'DOWN_COLOR_D',
		'DOWN_COLOR_D',
		'UP_COLOR_D',
		'UP_COLOR_D',
		'DOWN_COLOR_D',
		'DOWN_COLOR_D'
	],
	
	_stateBgColorNameArr:
	[
		'STEADY_BG_COLOR',
		'UP_BG_COLOR',
		'UP_BG_COLOR',
		'STEADY_BG_COLOR',
		'DOWN_BG_COLOR',
		'DOWN_BG_COLOR',
		'UP_BG_COLOR',
		'UP_BG_COLOR',
		'DOWN_BG_COLOR',
		'DOWN_BG_COLOR'
	],
	
	UP_COLOR : '#ff0000', //상승색
	DOWN_COLOR : '#0070ff', //하락색
	STEADY_COLOR : '#000000', //보합색

	UP_COLOR_D : '#ff4f62', //상승색
	DOWN_COLOR_D : '#008bff', //하락색
	STEADY_COLOR_D : '#e4e5ec', //보합색

	UP_BG_COLOR : '#ff5353', //상승배경색
	DOWN_BG_COLOR : '#418dff', //하락배경색
	STEADY_BG_COLOR : 'rgba(255,255,255,0.5)', //보합배경색

	UP_CLASS : 'CR_RED', //상승 클래스
	DOWN_CLASS : 'CR_BLUE', //하락 클래스
	STEADY_CLASS : 'CR_W50', //보합 클래스

	UP_CLASS_D : 'CR_003_D', //상승 클래스
	DOWN_CLASS_D : 'CR_004_D', //하락 클래스
	STEADY_CLASS_D : 'CR_006_D', //보합 클래스

	UP_SPAN_CLASS : 'BG_RED', //상승 배경색 span 클래스
	DOWN_SPAN_CLASS : 'BG_BLUE', //하락 배경색 span 클래스
	STEADY_SPAN_CLASS : 'BG_W50', //보합 배경색 span 클래스

	UP_ARROW_CLASS : 'up_arrow', //상한 화살표
	UP_TRIANGLE_CLASS : 'up_triangle', //상승 삼각형
	DOWN_ARROW_CLASS : 'down_arrow', //하한 화살표
	DOWN_TRIANGLE_CLASS : 'down_triangle', //하락 삼각형
	STEADY_ARROW_CLASS : 'steady_arrow', //보합 삼각형

	UP_ARROW_CLASS_D : 'up_arrow', //상한 화살표
	UP_TRIANGLE_CLASS_D : 'up_triangle', //상승 삼각형
	DOWN_ARROW_CLASS_D : 'down_arrow', //하한 화살표
	DOWN_TRIANGLE_CLASS_D : 'down_triangle', //하락 삼각형
	STEADY_ARROW_CLASS_D : 'steady_arrow', //보합 삼각형

	// -----------------------------  미니차트 부분 시작 ----------------------------- //
	//미니차트 어두운 컬러 정의
	TEXT_D : '#e4e5ec', //차트 전체 텍스트 색
	TEXT_BASE_D : '#e4e5ec', //기준가 금액 텍스트 색
	TEXT_LEFT_D : '#e4e5ec', //미니 차트 왼쪽 텍스트 컬러
	TEXT_TIME_D : '#6f7790', //미니 차트 하단 텍스트 컬러
	BACK_D : '#000000', //차트 전체 배경 색
	BACKLINE_D : '#ffffff', //차트 전체 영역 구분선 색
	DOT_D : '#ffffff', //차트 전체 도트 색

	CONT_BACK_D : '#2c304a', //컨텐츠 배경색
	CONT_ROUND_D : 'transparent', //컨텐츠 배경색

	DIVLINE_D : '#393e60', //구분선 색
	BASELINE_D : '#586094', //기준가 선 색
	TIMELINE_D : '#ffffff', //타임영역 구분선 색

	//미니차트 밝은 컬러 정의
	TEXT : '#000000', //차트 전체 텍스트 색
	TEXT_CURR : '#000000', //차트 현재가 텍스트 색
	TEXT_BASE : '#ffffff', //기준가 금액 텍스트 색
	TEXT_LEFT : '#5e637d', //미니 차트 왼쪽 텍스트 컬러
	TEXT_TIME : '#5e637d', //미니 차트 하단 텍스트 컬러
	BACK : '#000000', //차트 전체 배경 색
	BACKLINE : '#ffffff', //차트 전체 영역 구분선 색
	DOT : '#d9dbe5', //차트 전체 도트 색

	CONT_BACK : '#ffffff', //컨텐츠 배경색
	CONT_ROUND : '#d9dbe5', //컨텐츠 배경색

	DIVLINE : '#d9dbe5', //구분선 색
	BASELINE : '#7a7c8b', //기준가 선 색
	TIMELINE : '#ffffff', //타임영역 구분선 색

	// -----------------------------  미니차트 부분 끝 ----------------------------- //

	LAST :
	[
		'#07a3a3',	//마지막 현재가 배경 보합색
		'#a91505',	//마지막 현재가 배경 상승색
		'#07a3a3'	//마지막 현재가 배경 하락색
	],

	SUB_COLORS : [['#F82008', '#C98607', '#177E37'], //이평(5,20,60) 색
	['#FD651A'], //OBV색
	['#FD651A', '#177E37'], //MACD(12,26)', 'Signal(9)' 색
	['#FD651A', '#177E37'], //'Slow%K(5,3)', 'Slow%D(3)' 색
	['#FD651A', '#177E37'], //'Fast K(5)', 'Fast D(3)' 색
	['#FD651A'], //'이격도(10)' 색
	['#FD651A', '#DC00DC']	//'RSI(12)', 'Signal'색
	],

	COMPARE_COLORS : ['Aqua', 'Bisque', 'Brown', 'Aquamarine', 'Chartreuse', 'Coral', 'DarkOrange', 'DarkTurquoise', 'DeepPink', 'Gold', 'Ivory', 'MediumSpringGreen', 'OrangeRed', 'PaleTurquoise', 'Yellow'],

	LINE : '#ffffff', //라인차트 선 색
	START : '#00ff00', //라인차트 그라데이션 시작 색
	END : 'rgba(0,255,0,0.0)',	//라인차트 그라데이션 끝 색

	// CandleChart
	VOLUME : '#00ff00',         // 하단 거래량 색상 추가
    CANDLE_LINE : '#ff00ff',    // LineMode 선 색상
};
