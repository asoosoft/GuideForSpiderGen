
/**
Constructor
Do not call Function in Constructor.
*/
CompareChartAttrProp = class CompareChartAttrProp extends BaseProp
{
    constructor()
    {
        super()
		
	
		//this.attrPath = 'Framework/stock/attribute/CompareChart/';
	
	

    }
}



CompareChartAttrProp.prototype.init = function(context, evtListener)
{
	BaseProp.prototype.init.call(this, context, evtListener);
	
	//this.acc.insertItem('Color', this.attrPath+'Color.lay');

    this.makeAttrItem('stock', 'CompareChart')

};

//	●●●●● 이 함수에서는 값을 꺼내는 방식을 지정한다. ●●●●●
//
//	dataKey 는 valueComp 의 아이디이고 css 의 프로퍼티(키값)가 된다.
//	selComp 의 정보를 얻어 value 값을 리턴한다.
CompareChartAttrProp.prototype.getUpdateValue = function(selComp, dataKey, groupName)
{
	var value;
	if(groupName=='ATTR_VALUE')
	{
		if(dataKey.indexOf('data-color-') > -1)
		{
			var key = dataKey.replace('data-color-', '').toUpperCase();
			value = selComp.colorObj[key];
		}
	}
	
	if(value) return value;
	else return BaseProp.prototype.getUpdateValue.call(this, selComp, dataKey, groupName);
};

CompareChartAttrProp.prototype.applyValueToSelComp = function(selComp, dataKey, valGroup, value)
{
	if(valGroup=='ATTR_VALUE')
	{
		if(dataKey.indexOf('data-color-') > -1)
		{
			var prevVal = selComp.$ele.attr(dataKey);
			if(value) selComp.$ele.attr(dataKey, value);
			else selComp.$ele.removeAttr(dataKey);

			selComp.extractColorObj(); 
			selComp.updatePosition(selComp.getWidth(), selComp.getHeight());
			return prevVal;
		}
	}
	
	return BaseProp.prototype.applyValueToSelComp.call(this, selComp, dataKey, valGroup, value);
};