
/**
Constructor
Do not call Function in Constructor.
*/
EXItemViewAttrProp = class EXItemViewAttrProp extends BaseProp
{
    constructor()
    {
        super()
		
		
		//this.attrPath = 'Framework/stock/attribute/EXItemView/';
	
	

    }
}



EXItemViewAttrProp.prototype.init = function(context, evtListener)
{
	BaseProp.prototype.init.call(this, context, evtListener);
	
    /*
	this.acc.insertItem('Info', this.attrPath+'Info.lay');
    */

	this.makeAttrItem('stock', 'EXItemView')
	
};








