/**
 * @author asoocool
 */

EXArrowAttrProp = class EXArrowAttrProp extends BaseProp
{
    constructor()
    {
        super()
		
		
		//TODO:edit here
		//this.attrPath = 'Framework/stock/attribute/EXArrow/';
		
	

    }
}



EXArrowAttrProp.prototype.init = function(context, evtListener)
{
	BaseProp.prototype.init.call(this, context, evtListener);
	
    /*
	this.acc.insertItem('Data', this.attrPath+'Data.lay');
    */

    this.makeAttrItem('stock', 'EXArrow')

	
};

EXArrowAttrProp.prototype.getUpdateValue = function(selComp, dataKey, groupName)
{
	var value = '';
		
	//단일 선택인 경우만 값을 읽어와 셋팅한다. 다중 선택인 경우는 값을 클리어 해준다.
	if(this.selCompArr.length==1)
	{
		//groupName 에 따라 얻어오는 방법 분기, selComp 는 AComponent 이다.
		switch(groupName)
		{
			case 'ATTR_VALUE':
				if(dataKey == 'color-start')
				{
					return this.selCompArr[0].getStartColor();
				}
				else if(dataKey == 'color-end')
				{
					return this.selCompArr[0].getEndColor();
				}
			break;
		}
	}
	
	return BaseProp.prototype.getUpdateValue.call(this, selComp, dataKey, groupName);
};

EXArrowAttrProp.prototype.onColorPickerClick = function(comp, info)
{
	var wnd = new AWindow_('ColorPicker'),
		ofs = comp.get$ele().offset(),
		w = 190, compH = comp.getHeight(), compId = comp.getComponentId();
		
	wnd.valueComp = comp;
	wnd.opts = {
		mode: 0,
		color: comp.$ele.css('background-color'),
		noGradient: true
	};
	
	
	//컬러피커의 그라데이션 모드인 경우
	if(compId=='background-image')
	{
		wnd.opts.mode = 1;
		wnd.opts.noGradient = false;
		wnd.opts.color = null;
	}
	
	//wnd.setResultListener(this);
	wnd.setWindowOption(
	{
		isModal: true,
		isFocusLostClose: true,
		modalBgOption: 'none',
	});
	
	if(ofs.left+190 > $(window).width()) ofs.left = $(window).width() - w;

	wnd.open('Source/popup/ColorPicker.lay', null, ofs.left, ofs.top+compH, w, 'auto');
	var thisObj = this;
	wnd.setResultCallback(function(result)
	{
		// '' 이 리턴될 수도 있으므로 !result 로 비교하면 안됨
		if(result==undefined) return;
		
		//-------------------------------------------
		//	valueComp 자신에게 적용하는 부분
		
		//컬러피커의 그라데이션 셋팅인 경우
		if(compId=='background-image') comp.$ele.css('background-image', result);
		else
		{
			if(compId == 'color-start')
				for(var i=0; i<thisObj.selCompArr.length; i++)
				{
					thisObj.selCompArr[i].setStartColor(result);
				}
			else if(compId == 'color-end')
				for(var i=0; i<thisObj.selCompArr.length; i++)
				{
					thisObj.selCompArr[i].setEndColor(result);
				}
		
			//color, border-color ...
			comp.$ele.css('background-color', result);
		}
		
		//selComp 에 적용하는 부분
		thisObj.applyValue(comp, result);
	});
};
