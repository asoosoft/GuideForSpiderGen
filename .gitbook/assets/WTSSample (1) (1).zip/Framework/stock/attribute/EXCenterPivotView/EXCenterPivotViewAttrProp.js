/**
 * @author asoocool
 */

EXCenterPivotViewAttrProp = class EXCenterPivotViewAttrProp extends BaseProp
{
    constructor()
    {
        super()
		
		
		//TODO:edit here
		//this.attrPath = 'Framework/stock/attribute/EXCenterPivotView/';
		
	

    }
}



EXCenterPivotViewAttrProp.prototype.init = function(context, evtListener)
{
	BaseProp.prototype.init.call(this, context, evtListener);
	
    this.makeAttrItem('stock', 'EXCenterPivotView')
	
};
