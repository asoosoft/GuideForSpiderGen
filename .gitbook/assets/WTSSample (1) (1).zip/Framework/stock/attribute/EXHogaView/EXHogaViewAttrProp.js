
/**
Constructor
Do not call Function in Constructor.
*/
EXHogaViewAttrProp = class EXHogaViewAttrProp extends BaseProp
{
    constructor()
    {
        super()
		
		
		//this.attrPath = 'Framework/stock/attribute/EXHogaView/';
	
	

    }
}



EXHogaViewAttrProp.prototype.init = function(context, evtListener)
{
	BaseProp.prototype.init.call(this, context, evtListener);
	
    /*
	this.acc.insertItem('Info', this.attrPath+'Info.lay');
    */

    this.makeAttrItem('stock', 'EXHogaView')
    
};

EXHogaViewAttrProp.prototype.updateASelectBox = function(dataKey, valueComp, value, selComp)
{
	if(dataKey == 'data-show-count')
	{
		valueComp.removeAll();
		var isFlexible = selComp.hogaGrid.option.isFlexibleRow;
		
		if(isFlexible)
		{
			valueComp.enable(true);
			valueComp.setStyle('opacity', '1');
			
			// 아무런 동작을 하지 않을 경우
			valueComp.addItem('', '0');
		
			// 모든 로우를 보여주는 것은 현재 호가그리드의 호가개수에 상관없게 값을 11로 지정한다.
			valueComp.addItem('Full', 11);

			// 호가그리드가 뷰에서 보여지는 호가 개수를 지정한다.
			for(var i=1; i<=selComp.hogaGrid.getQuoteCount(); i++)
				valueComp.addItem(i+' Units', i);
		}
		else
		{
			valueComp.enable(false);
			valueComp.setStyle('opacity', '0.3');
		}
	}

	BaseProp.prototype.updateASelectBox.call(this, dataKey, valueComp, value, selComp);
};

EXHogaViewAttrProp.prototype.applyValueToSelComp = function(selComp, dataKey, valGroup, value)
{
	var prevVal;
	if(valGroup=='ATTR_VALUE')
	{
		switch(dataKey)
		{
			case 'data-arrange':
			{
				prevVal = selComp.$ele.attr(dataKey);
				
				if(value=='none') 
				{
					selComp.$ele.children().css({'position':'absolute', 'float':'none', 'margin':''});
					selComp.$ele.removeAttr('data-arrange');
					selComp.$ele.css('padding', '');
				}

				//float left, right 
				else 
				{
					//무조건 아래 설정을 유지해야 함. 다른 옵션은 안됨.
					selComp.$ele.children().css({'position':'relative', left:'0px', top:'0px', 'float':value});
					selComp.$ele.attr(dataKey, value);
				}
			}
			return prevVal;
			
			case 'data-load-url':
			{
				this.testLoadView(selComp.$ele, value);
			}
			break;
			
			case 'data-auto-resize':
			{
				selComp.setAutoResizeChildren(value);
			}
			break;
		}
	}
	
	return BaseProp.prototype.applyValueToSelComp.call(this, selComp, dataKey, valGroup, value);
};

EXHogaViewAttrProp.prototype.testLoadView = function($ele, url)
{
	var prjView = theApp.getProjectView(),
		item = prjView.findProjectItemByTreePath(url);
		
	$ele.find('.test-view').remove();

	if(item)
	{
		url = prjView.getFullPath(item);
		
		if(url)
		{
			if(AUtil.extractExtName(url) != 'lay') return;

			var html = afc.getFileSrc(url);
			if(html)
			{
				$ele.append('<div class="test-view">' + html + '</div>');

				var child = $ele.children();
				child.find('.RGrid-Style').removeAttr('id').css('border', '1px solid blue').text('rMate Grid').css('text-align','center');
				child.find('.RChart-Style').removeAttr('id').css('border', '1px solid yellow').text('rMate Chart').css('text-align','center');
				child.css({
					position: 'relative',
					width: '100%',
					height: '100%'
				});
			}
		}
	}
};








