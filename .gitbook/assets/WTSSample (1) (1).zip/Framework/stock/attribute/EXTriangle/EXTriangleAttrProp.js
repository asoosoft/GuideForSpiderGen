/**
 * @author asoocool
 */

EXTriangleAttrProp = class EXTriangleAttrProp extends BaseProp
{
    constructor()
    {
        super()
		
		
		//TODO:edit here
		//this.attrPath = 'Framework/stock/attribute/EXTriangle/';
		
	

    }
}



EXTriangleAttrProp.prototype.init = function(context, evtListener)
{
	BaseProp.prototype.init.call(this, context, evtListener);
	
    /*
	this.acc.insertItem('Data', this.attrPath+'Data.lay');
    */

    this.makeAttrItem('stock', 'EXTriangle')

};

EXTriangleAttrProp.prototype.applyValueToSelComp = function(selComp, dataKey, valGroup, value)
{
	var ret = BaseProp.prototype.applyValueToSelComp.call(this, selComp, dataKey, valGroup, value);
	
// 	if(valGroup=='ATTR_VALUE')
// 	{
		if(dataKey == 'data-color-up' ||
		   dataKey == 'data-color-down' ||
		   dataKey == 'data-use-stockcolor')
		{
			if(selComp.getAttr('data-use-stockcolor'))
			{
				selComp.setUpDownColor(iWin.StockColor.UP_COLOR, iWin.StockColor.DOWN_COLOR);
			}
			else selComp.setUpDownColor();
		}
		else if(dataKey == 'data-direction')
		{
			selComp.setDirection(value);	
		}
// 	}
	
	return ret;
};

/*
EXTriangleAttrProp.prototype.onCheckBtnClick = function(comp, info)
{
	BaseProp.prototype.onCheckBtnClick.call(this, comp, info);
	
	if(comp.getComponentId() == 'data-use-stockcolor')
	{
		var nextComp = comp;
		for(var i=0; i<4; i++)
		{
			nextComp = nextComp.getNextComp();
			if(comp.getCheck()) nextComp.setStyle('opacity', '0.6');
			else nextComp.setStyle('opacity', '1');
		}
	}
};
*/

/*
EXTriangleAttrProp.prototype.updateACheckBox = function(dataKey, valueComp, value, selComp)
{
	BaseProp.prototype.updateACheckBox.call(this, dataKey, valueComp, value, selComp);
	
	if(dataKey == 'data-use-stockcolor')
	{
		// var nextComp = valueComp;
		// for(var i=0; i<4; i++)
		// {
		// 	nextComp = nextComp.getNextComp();
		// 	if(value) nextComp.setStyle('opacity', '0.6');
		// 	else nextComp.setStyle('opacity', '1');
		// }

        let view = this.findCompById('upColorView')
        if(value) view.setStyle('opacity', '0.6');
		else view.setStyle('opacity', '1');

	}
};
*/