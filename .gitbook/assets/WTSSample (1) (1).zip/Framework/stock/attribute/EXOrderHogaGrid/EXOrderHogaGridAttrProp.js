
/**
Constructor
Do not call Function in Constructor.
*/
EXOrderHogaGridAttrProp = class EXOrderHogaGridAttrProp extends BaseProp
{
    constructor()
    {
        super()
		
	
		//this.attrPath = 'Framework/stock/attribute/EXOrderHogaGrid/';
	

    }
}



EXOrderHogaGridAttrProp.prototype.init = function(context, evtListener)
{
	BaseProp.prototype.init.call(this, context, evtListener);
	
    /*
	this.acc.insertItem('Option', this.attrPath+'Option.lay');
	//this.acc.insertItem('Style', this.attrPath+'Style.lay');
    */

	this.makeAttrItem('stock', 'EXOrderHogaGrid')
};
/*
function EXOrderHogaGridAttrProp*getUpdateValue(selComp, dataKey, groupName)
{
	//단일 선택인 경우만 값을 읽어와 셋팅한다. 다중 선택인 경우는 값을 클리어 해준다.
	if(this.selCompArr.length==1)
	{
		if(groupName=='ATTR_VALUE')
		{
			switch(dataKey)
			{
				case 'data-style-header': 
					return selComp.showThead.attr(dataKey);
					
				case 'data-style-body': 
					return selComp.tBody.attr(dataKey);
					
				//data-hide-header
			}
		}
	}

	return super.getUpdateValue(selComp, dataKey, groupName);	
};*/

EXOrderHogaGridAttrProp.prototype.applyValueToSelComp = function(selComp, dataKey, valGroup, value)
{
	var prevVal;
	if(valGroup=='ATTR_VALUE')
	{
		switch(dataKey)
		{/*
			case 'data-style-header':
			{
				prevVal = selComp.showThead.attr(dataKey);
				this.applyStyleValue(dataKey, value, selComp.showThead);
			}
			return prevVal;
			
			case 'data-style-body':
			{
				prevVal = selComp.tBody.attr(dataKey);
				this.applyStyleValue(dataKey, value, selComp.tBody);
			}
			return prevVal;
			*/
			case 'data-hide-header':
			{
				if(value) selComp.hideHeader();
				else selComp.showHeader();
			}
			break;
			//return !value;
			
		}
	}
	
	return BaseProp.prototype.applyValueToSelComp.call(this, selComp, dataKey, valGroup, value);
};

EXOrderHogaGridAttrProp.prototype.onStyleFocus = function(comp, info)
{
	var selStyle = comp.getText().trim(), selComp;

	this.saveSelArr = [];

	if(!selStyle) selStyle = 'agrid_select';
	
	for(var i=0; i<this.selCompArr.length; i++)
	{
		selComp = this.selCompArr[i];
		
		selComp.selectStyleName = selStyle;
		selComp.selectCell(selComp.getRow(0));
		
		this.saveSelArr[i] = selComp;
	}
};

EXOrderHogaGridAttrProp.prototype.onStyleBlur = function(comp, info)
{
	for(var i=0; i<this.saveSelArr.length; i++)
	{
		this.saveSelArr[i].clearSelected();
	}
};

