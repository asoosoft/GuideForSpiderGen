/**
 * @author asoocool
 */

EXAccountBoxAttrProp = class EXAccountBoxAttrProp extends BaseProp
{
    constructor()
    {
        super()
		
		
		//TODO:edit here
		//this.attrPath = 'Framework/stock/attribute/EXAccountBox/';
		
	

    }
}



EXAccountBoxAttrProp.prototype.init = function(context, evtListener)
{
	BaseProp.prototype.init.call(this, context, evtListener);
	
    /*
	this.acc.insertItem('Data', this.attrPath+'Data.lay');
    */

	this.makeAttrItem('stock', 'EXAccountBox')
};

EXAccountBoxAttrProp.prototype.getUpdateValue = function(selComp, dataKey, groupName)
{
	//단일 선택인 경우만 값을 읽어와 셋팅한다. 다중 선택인 경우는 값을 클리어 해준다.
	if(this.selCompArr.length==1)
	{
		if(groupName=='ATTR_VALUE')
		{
			if(dataKey=='placeholder' || dataKey =='readonly')
			{
				return $(selComp.accNoField[0]).attr(dataKey);
			}
		}
		else if(groupName=='CSS_VALUE')
		{
			if(dataKey=='text-align')
			{
				return $(selComp.accNoField[0]).css(dataKey);
			}
		}
	}

	return BaseProp.prototype.getUpdateValue.call(this, selComp, dataKey, groupName);	
};

EXAccountBoxAttrProp.prototype.applyValueToSelComp = function(selComp, dataKey, valGroup, value)
{
	var prevVal;
	var $selCompTxtField = $(selComp.accNoField[0]);
		
	if(valGroup=='ATTR_VALUE')
	{
		if(dataKey=='placeholder' || dataKey=='readonly')
		{
			
			prevVal = $selCompTxtField.attr(dataKey);
			
			if(value) $selCompTxtField.attr(dataKey, value);
			else $selCompTxtField.removeAttr(dataKey);
			
			return prevVal;
		}
		
	}
	
	else if(valGroup=='CSS_VALUE')
	{
		if(dataKey=='text-align')
		{			
			prevVal = $selCompTxtField.css(dataKey);
			$selCompTxtField.css(dataKey, value);
			return prevVal;
		}
	}

	
	return BaseProp.prototype.applyValueToSelComp.call(this, selComp, dataKey, valGroup, value);
};


