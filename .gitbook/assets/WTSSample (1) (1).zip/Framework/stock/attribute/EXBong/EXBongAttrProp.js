/**
 * @author asoocool
 */

EXBongAttrProp = class EXBongAttrProp extends BaseProp
{
    constructor()
    {
        super()
		
		
		//TODO:edit here
		//this.attrPath = 'Framework/stock/attribute/EXBong/';
		
	

    }
}



EXBongAttrProp.prototype.init = function(context, evtListener)
{
	BaseProp.prototype.init.call(this, context, evtListener);
	
	/*this.acc.insertItem('Data', this.attrPath+'Data.lay');*/

    this.makeAttrItem('stock', 'EXBong')
	
};

EXBongAttrProp.prototype.onCheckBtnClick = function(comp, info)
{
	var checked = comp.getCheck(),
		compId = comp.getComponentId();
		
	if(compId=='direction-bong')
	{
		for(var i=0; i<this.selCompArr.length; i++)
		{
			var bong = this.selCompArr[i];
			var value;
			if(checked) value = 'port';
			else value = 'land';
			/*
			var bong = this.selCompArr[i];
			var value = 'port';
			var lineEl = bong.lineEl;
			var bongEl = bong.bongEl;
			//landscape 일때 자식 스타일 바꾸기
			if(!checked)
			{
				value = 'land';
				lineObj.css('right', '0px');
				lineObj.css('top', '50%');
				lineObj.css('width', '100%');
				lineObj.css('height', '1px');

				bongObj.css('right', '25%');
				bongObj.css('top', '0px');
				bongObj.css('width', '50%');
				bongObj.css('height', '100%');
			}
			//portrait 일때 자식 스타일 바꾸기
			else
			{
				value = 'port';
				lineObj.css('right', '50%');
				lineObj.css('top', '0px');
				lineObj.css('width', '1px');
				lineObj.css('height', '100%');
				
				bongObj.css('right', '0px');
				bongObj.css('top', '25%');
				bongObj.css('width', '100%');
				bongObj.css('height', '50%');
			}*/
			
			this.applyValue(comp, value);
			
			bong.init(bong.element);
		}
		return;
	}
		
	BaseProp.prototype.onCheckChange.call(this, comp, info);
};

EXBongAttrProp.prototype.updateACheckBox = function(dataKey, valueComp, value, selComp)
{
	if(dataKey=='direction-bong') 
	{
		value = (value=='port');
	}

	BaseProp.prototype.updateACheckBox.call(this, dataKey, valueComp, value, selComp);
};