
/**
Constructor
Do not call Function in Constructor.
*/
EXStockLabelAttrProp = class EXStockLabelAttrProp extends BaseProp
{
    constructor()
    {
        super()
		
	
		//this.attrPath = 'Framework/stock/attribute/EXStockLabel/';
	
	

    }
}



EXStockLabelAttrProp.prototype.init = function(context, evtListener)
{
	BaseProp.prototype.init.call(this, context, evtListener);
	
    /*
	this.acc.insertItem('Data', this.attrPath+'Data.lay');
    */

	this.makeAttrItem('stock', 'EXStockLabel')
	
};

EXStockLabelAttrProp.prototype.onTextValueChange = function(comp, info)
{
	var compId = comp.getComponentId();
	var view = theApp.getLayoutView();
	
	if(compId=='Text')
	{
		this.applyValue(comp, info);
		if(view)
		{
			for(var i=0; i<this.selCompArr.length; i++)
			{
				var selComp = this.selCompArr[i];
				var id = selComp.getComponentId();
				view.getDocument().treeRename(selComp, id!=''?id:(selComp.getAttr(afc.ATTR_CLASS) + ' "' + selComp.getText() + '"'));
			}
		}

		return;
	}
	
	BaseProp.prototype.onTextValueChange.call(this, comp, info);
};
