
/**
Constructor
Do not call Function in Constructor.
*/
EXHogaGridAttrProp = class EXHogaGridAttrProp extends BaseProp
{
    constructor()
    {
        super()
		
	
		//this.attrPath = 'Framework/stock/attribute/EXHogaGrid/';
	

    }
}



EXHogaGridAttrProp.prototype.init = function(context, evtListener)
{
	BaseProp.prototype.init.call(this, context, evtListener);
	
    /*
	this.acc.insertItem('Data', this.attrPath+'Data.lay');
	this.acc.insertItem('Price Color', this.attrPath+'PriceColor.lay');
	this.acc.insertItem('Bar Style', this.attrPath+'BarStyle.lay');
	this.acc.insertItem('Option', this.attrPath+'Option.lay');
	
	//스타일 공통처리를 위해 주석처리
	//this.acc.insertItem('Current Price Select Style', this.attrPath+'CurrentStyle.lay');
	//this.acc.insertItem('Style', this.attrPath+'Style.lay');
    */

	this.makeAttrItem('stock', 'EXHogaGrid')
};
/*
function EXHogaGridAttrProp*getUpdateValue(selComp, dataKey, groupName)
{
	//단일 선택인 경우만 값을 읽어와 셋팅한다. 다중 선택인 경우는 값을 클리어 해준다.
	if(this.selCompArr.length==1)
	{
		if(groupName=='ATTR_VALUE')
		{
			switch(dataKey)
			{
				case 'data-style-header': 
					return selComp.showThead.attr(dataKey);
					
				case 'data-style-body': 
					return selComp.tBody.attr(dataKey);
					
				//data-hide-header
			}
		}
	}

	return super.getUpdateValue(selComp, dataKey, groupName);	
};*/

EXHogaGridAttrProp.prototype.applyValueToSelComp = function(selComp, dataKey, valGroup, value)
{
	var prevVal;
	if(valGroup=='ATTR_VALUE')
	{
		switch(dataKey)
		{/*
			case 'data-style-header':
			{
				prevVal = selComp.showThead.attr(dataKey);
				this.applyStyleValue(dataKey, value, selComp.showThead);
				this.applyStyleValue(dataKey, value, selComp.hideThead);
			}
			return prevVal;
			
			case 'data-style-body':
			{
				prevVal = selComp.tBody.attr(dataKey);
				this.applyStyleValue(dataKey, value, selComp.tBody);
			}
			return prevVal;
			*/
			case 'data-hide-header':
			{
				if(value) selComp.hideHeader();
				else selComp.showHeader();
			}
			break;
			//return !value;

			case 'data-flexible-row':
			{
				selComp.setFlexibleRow(value);
			}
			break;

			case 'data-up-color':
			{
				selComp.setUpColor(value);
			}
			break;

			case 'data-down-color':
			{
				selComp.setDownColor(value);
			}
			break;

			case 'data-steady-color':
			{
				selComp.setSteadyColor(value);
			}
			break;

			case 'data-bottom-count':
			{
				selComp.setBottomRowCount(value);
			}
			break;
			
			case 'data-bar-size':
			{
				selComp.setBarSize(value);
			}
			break;
		}
	}
	
	return BaseProp.prototype.applyValueToSelComp.call(this, selComp, dataKey, valGroup, value);
};

EXHogaGridAttrProp.prototype.onStyleFocus = function(comp, info)
{
	var selStyle = comp.getText().trim(), selComp;

	this.saveSelArr = [];

	if(!selStyle) selStyle = 'agrid_select';
	
	for(var i=0; i<this.selCompArr.length; i++)
	{
		selComp = this.selCompArr[i];
		
		selComp.selectStyleName = selStyle;
		selComp.selectCell(selComp.getRow(0));
		
		this.saveSelArr[i] = selComp;
	}
};

EXHogaGridAttrProp.prototype.onStyleBlur = function(comp, info)
{
	for(var i=0; i<this.saveSelArr.length; i++)
	{
		this.saveSelArr[i].clearSelected();
	}
};

EXHogaGridAttrProp.prototype.updateATextField = function(dataKey, valueComp, value, selComp)
{
	if(dataKey.indexOf('BarBgImg') > -1)
	{
		valueComp.setStyle('background-image', value);
	}
	else BaseProp.prototype.updateATextField.call(this, dataKey, valueComp, value);
};
/*
function EXHogaGridAttrProp*onColorPickerClick(comp, info)
{
	var wnd = new AWindow_('ColorPicker')
		ofs = comp.get$ele().offset(),
		w = 190, compH = comp.getHeight(), compId = comp.getComponentId();
		
	var color = comp.$ele.css('background-color').replace(/ /gi,'')
	if(color == 'rgba(0,0,0,0)') 
		color = 'rgba(1,1,1,1)';
		
	wnd.valueComp = comp;
	wnd.opts = {
		mode: 0,
		color: color,
		noGradient: true
	};
	
	
	//컬러피커의 그라데이션 모드인 경우
	if(compId=='background-image' || compId.indexOf('BarBgImg') > -1)
	{
		wnd.opts.mode = 1;
		wnd.opts.noGradient = false;
		wnd.opts.color = null;
	}
	
	//wnd.setResultListener(this);
	wnd.setWindowOption(
	{
		isModal: true,
		isFocusLostClose: true,
		modalBgOption: 'none',
	});
	
	if(ofs.left+190 > $(window).width()) ofs.left = $(window).width() - w - 5;

	wnd.open('Source/popup/ColorPicker.lay', null, ofs.left, ofs.top+compH, w, 'auto');
	var thisObj = this;
	wnd.setResultCallback(function(result)
	{
		// '' 이 리턴될 수도 있으므로 !result 로 비교하면 안됨
		if(result==undefined) return;
		
		//-------------------------------------------
		//	valueComp 자신에게 적용하는 부분
		if(compId.indexOf('BarBgImg') > -1)
		{
			comp.$ele.css('background-image', result);
		}
		//컬러피커의 그라데이션 셋팅인 경우
		else if(compId=='background-image')
		{
			comp.$ele.css('background-image', result);
			
			// 이미지 경로 제거, 이미지 선택 버튼 show.
			comp.setText('');
			comp.getNextComp().show();
		}
		
		//color, border-color ...
		else comp.$ele.css('background-color', result);
		
		//selComp 에 적용하는 부분
		thisObj.applyValue(comp, result);
	});
};*/

EXHogaGridAttrProp.prototype.updateAImage = function(dataKey, valueComp, value, selComp)
{
	switch(dataKey)
	{
		case 'data-up-color':
			value = selComp.getUpColor();
		break;
		case 'data-down-color':
			value = selComp.getDownColor();
		break;
		case 'data-steady-color':
			value = selComp.getSteadyColor();
		break;
	}
	
	BaseProp.prototype.updateAImage.call(this, dataKey, valueComp, value, selComp);
};

