
/**
Constructor
Do not call Function in Constructor.
*/
MultiChartViewAttrProp = class MultiChartViewAttrProp extends BaseProp
{
    constructor()
    {
        super()
		
	
		//this.attrPath = 'Framework/stock/attribute/MultiChartView/';
	
	

    }
}



MultiChartViewAttrProp.prototype.init = function(context, evtListener)
{
	BaseProp.prototype.init.call(this, context, evtListener);
	
    /*
	//this.acc.insertItem('Layout', this.attrPath+'Layout.lay');
    */

    this.makeAttrItem('stock', 'MultiChartView')

};