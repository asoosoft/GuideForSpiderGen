
/**
Constructor
Do not call Function in Constructor.
*/
EXSearchViewAttrProp = class EXSearchViewAttrProp extends BaseProp
{
    constructor()
    {
        super()
		
		
		//this.attrPath = 'Framework/stock/attribute/EXSearchView/';
	
	

    }
}



EXSearchViewAttrProp.prototype.init = function(context, evtListener)
{
	BaseProp.prototype.init.call(this, context, evtListener);
	
    /*
	this.acc.insertItem('Info', this.attrPath+'Info.lay');
    */

    this.makeAttrItem('stock', 'EXSearchView')

};

