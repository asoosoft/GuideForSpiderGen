
/**
Constructor
Do not call Function in Constructor.
*/
EXSecureTextFieldAttrProp = class EXSecureTextFieldAttrProp extends BaseProp
{
    constructor()
    {
        super()
		
	
		//this.attrPath = 'Framework/stock/attribute/EXSecureTextField/';
	
	

    }
}



EXSecureTextFieldAttrProp.prototype.init = function(context, evtListener)
{
	BaseProp.prototype.init.call(this, context, evtListener);
	
    /*
	this.acc.insertItem('Data', this.attrPath+'Data.lay');
    */

    this.makeAttrItem('stock', 'EXSecureTextField')
};

EXSecureTextFieldAttrProp.prototype.getUpdateValue = function(selComp, dataKey, groupName)
{
	//단일 선택인 경우만 값을 읽어와 셋팅한다. 다중 선택인 경우는 값을 클리어 해준다.
	if(this.selCompArr.length==1)
	{
		var attrVal = selComp.$ele.attr(dataKey);
		if(dataKey=='padtype' || dataKey=='showtype')
		{
			if(!attrVal) attrVal = '0';
			return attrVal;
		}
		else if(dataKey=='padmin')
		{
			if(!attrVal) attrVal = 4;
			return attrVal;
		}
		else if(dataKey=='padmax')
		{
			if(!attrVal) attrVal = 20;
			return attrVal;
		}
	}

	return BaseProp.prototype.getUpdateValue.call(this, selComp, dataKey, groupName);	
};


EXSecureTextFieldAttrProp.prototype.applyValueToSelComp = function(selComp, dataKey, valGroup, value)
{
	var prevVal;
	var $selComp = selComp.$ele;
		
	if(valGroup=='ATTR_VALUE')
	{
		if(dataKey=='padmin')
		{
			
			prevVal = $selComp.attr(dataKey);
			compVal = $selComp.attr('padmax');
			if(!compVal) compVal = 20;
			else compVal = parseInt(compVal, 10);

			if(value=='') $selComp.removeAttr(dataKey);
			else
			{
				if(value<0) $selComp.attr(dataKey, 0);
				else
				{
					if(compVal>=value) $selComp.attr(dataKey, value);
					else eventObj.val(compVal);
				}
			}
			if(value) $selComp.attr(dataKey, value);
			else $selComp.removeAttr(dataKey);
			
			return prevVal;
		}
		else if(dataKey=='padmax')
		{
			
			prevVal = $selComp.attr(dataKey);
			
			if(value) $selComp.attr(dataKey, value);
			else $selComp.removeAttr(dataKey);
			
			return prevVal;
		}
		
	}
	
	return BaseProp.prototype.applyValueToSelComp.call(this, selComp, dataKey, valGroup, value);
};

EXSecureTextFieldAttrProp.prototype.onNumberValueChange = function(comp, info)
{
	var compId = comp.getComponentId();
	
	if(compId=='padmin')
	{
		for(var i=0; i<this.selCompArr.length; i++)
		{
			var selComp = this.selCompArr[i];
			var $selComp = selComp.$ele;
			
			var padmax = $selComp.attr('padmax');
			if(!padmax) padmax = 20;
			else padmax = parseInt(padmax, 10);

			if(!isNaN(info) && info!='')
			{
				if(info<0) info = 0;
				else
				{
					if(padmax<info) info = padmax;
				}
			}
			comp.setText(info);
		}
		
		this.applyValue(comp, info);
		return;
	}
	else if(compId=='padmax')
	{
		for(var i=0; i<this.selCompArr.length; i++)
		{
			var selComp = this.selCompArr[i];
			var $selComp = selComp.$ele;
			
			var padmin = $selComp.attr('padmin');
			if(!padmin) padmin = 4;
			else padmin = parseInt(padmin, 10);

			if(!isNaN(info) && info!='')
			{
				if(info<0) info = 0;
				else
				{
					if(padmin>info) info = padmin;
				}
			}
			comp.setText(info);
		}
		
		this.applyValue(comp, info);
		return;
	}
	
	BaseProp.prototype.onNumberValueChange.call(this, comp, info);
};
