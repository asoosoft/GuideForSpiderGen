
/**
Constructor
Do not call Function in Constructor.
*/
CompareChartViewAttrProp = class CompareChartViewAttrProp extends BaseProp
{
    constructor()
    {
        super()
		
	
		//this.attrPath = 'Framework/stock/attribute/CompareChartView/';
	
	

    }
}



CompareChartViewAttrProp.prototype.init = function(context, evtListener)
{
	BaseProp.prototype.init.call(this, context, evtListener);
	
	//this.acc.insertItem('Layout', this.attrPath+'Layout.lay'); - 원래 주석, 사용 안 하는 듯

    this.makeAttrItem('stock', 'CompareChartView')

};