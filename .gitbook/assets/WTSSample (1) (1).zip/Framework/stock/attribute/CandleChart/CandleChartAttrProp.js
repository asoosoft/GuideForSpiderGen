
/**
Constructor
Do not call Function in Constructor.
*/
CandleChartAttrProp = class CandleChartAttrProp extends BaseProp
{
    constructor()
    {
        super()
		
	
		//this.attrPath = 'Framework/stock/attribute/CandleChart/';
	
	

    }
}



CandleChartAttrProp.prototype.init = function(context, evtListener)
{
	BaseProp.prototype.init.call(this, context, evtListener);
/*	
    this.acc.insertItem('Data', this.attrPath+'Data.lay');
	this.acc.insertItem('Color', this.attrPath+'Color.lay');
	this.acc.insertItem('Current Price Color', this.attrPath+'CurrentPriceColor.lay');
	this.acc.insertItem('Option', this.attrPath+'Option.lay');
*/

    this.makeAttrItem('stock', 'CandleChart')

};

//	●●●●● 이 함수에서는 값을 꺼내는 방식을 지정한다. ●●●●●
//
//	dataKey 는 valueComp 의 아이디이고 css 의 프로퍼티(키값)가 된다.
//	selComp 의 정보를 얻어 value 값을 리턴한다.
CandleChartAttrProp.prototype.getUpdateValue = function(selComp, dataKey, groupName)
{
	var value;
	if(groupName=='ATTR_VALUE')
	{
		if(dataKey.indexOf('data-color-') > -1)
		{
			var key = dataKey.replace('data-color-', '').toUpperCase();
			value = selComp.colorObj[key];
		}
	}

    if(dataKey == 'Intervals')
    {
        this.updateRefValByIntervals(selComp['get'+dataKey]());
    }
	
	if(value) return value;
	else return BaseProp.prototype.getUpdateValue.call(this, selComp, dataKey, groupName);
};

CandleChartAttrProp.prototype.applyValueToSelComp = function(selComp, dataKey, valGroup, value)
{
	if(valGroup=='ATTR_VALUE')
	{
		if(dataKey.indexOf('data-color-') > -1)
		{
			var prevVal = selComp.$ele.attr(dataKey);
			if(value) selComp.$ele.attr(dataKey, value);
			else selComp.$ele.removeAttr(dataKey);

			selComp.extractColorObj(); 
			selComp.updatePosition(selComp.getWidth(), selComp.getHeight());
			return prevVal;
		}
	}
	
	return BaseProp.prototype.applyValueToSelComp.call(this, selComp, dataKey, valGroup, value);
};

CandleChartAttrProp.prototype.updateACheckBox = function(dataKey, valueComp, value, selComp)
{
	if(dataKey=='data-touch-event') 
	{
		value = (value!='false');
	}
	
	BaseProp.prototype.updateACheckBox.call(this, dataKey, valueComp, value, selComp);
};

//property 의 _ACheckButton 이 클릭된 경우
CandleChartAttrProp.prototype.onCheckBtnClick = function(comp, info, e)
{
	var checked = comp.getCheck(),
		compId = comp.getComponentId();
	
	if(compId=='data-touch-event') 
	{
		if(checked) checked = '';
		else checked = 'false';
		this.applyValue(comp, checked);
	}
	else BaseProp.prototype.onCheckBtnClick.call(this, comp, info, e);
};

CandleChartAttrProp.prototype.onSelectValueChange = function(comp, info, e)
{
	var compId = comp.getComponentId();
	
	if(compId=='Intervals') 
	{
        this.updateRefValByIntervals(info);
	}
	
    BaseProp.prototype.onSelectValueChange.call(this, comp, info, e);
};

CandleChartAttrProp.prototype.updateRefValByIntervals = function(intevals)
{
    let placeHolder;
    if(intevals == iWin.CandleChart.INTERVALS_MINUTE)
    {
        placeHolder = 'update time(1s: 1000)';
    }
    else if(intevals == iWin.CandleChart.INTERVALS_TICK)
    {
        placeHolder = 'tick count';
    }

    let urvLblTxf = this.findCompById('urvLblTxf')

    if(placeHolder)
    {
        urvLblTxf.show();
        this.findCompById('data-updaterefvalue').setPlaceholder(placeHolder);
    }
    else
    {
        urvLblTxf.hide();
    }
};