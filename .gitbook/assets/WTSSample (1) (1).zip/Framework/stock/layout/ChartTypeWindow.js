
/**
Constructor
Do not call Function in Constructor.
*/
ChartTypeWindow = class ChartTypeWindow extends AView
{
    constructor()
    {
        super()
		
	
		//TODO:edit here
		this.listData = null;
	
	

    }
}



ChartTypeWindow.prototype.onInitDone = function()
{

	//TODO:edit here
	//this.setData();

};

ChartTypeWindow.prototype.setData = function()
{

	//TODO:edit here
	for(var i = 0; i<this.listData.length; i++)
	{
		var rowValueArr = this.listData[i].split(':');
		if(rowValueArr.length > 1)
		{
			if(rowValueArr[0] == '1')
			{
				this.listGrid.addRowWithData([rowValueArr[1]]);
			}
		}
		else this.listGrid.addRowWithData([rowValueArr[0]]);
	}

};

ChartTypeWindow.prototype.onListGridSelect = function(comp, info)
{

	//TODO:edit here
	this.getContainer().close(info.text());

};
