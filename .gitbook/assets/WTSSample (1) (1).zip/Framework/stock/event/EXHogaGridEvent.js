(async function(){

await afc.import('Framework/afc/event/AGridEvent.js');



/**
 * @author asoocool
 */

EXHogaGridEvent = class EXHogaGridEvent extends AGridEvent
{
    constructor(acomp)
    {
        super(acomp);
    }
}
                    
//window.EXHogaGridEvent = EXHogaGridEvent;
                    
})();