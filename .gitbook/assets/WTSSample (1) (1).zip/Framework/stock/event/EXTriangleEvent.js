            
/**
 * @author 
 */

class EXTriangleEvent extends AEvent
{
	constructor(acomp)
	{
		super(acomp);
	}
}
window.EXTriangleEvent = EXTriangleEvent;
