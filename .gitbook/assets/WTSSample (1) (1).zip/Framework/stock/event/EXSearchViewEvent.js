               
/**
 * @author 
 */

class EXSearchViewEvent extends AViewEvent
{
	constructor(acomp)
	{
		super(acomp);
	}
}
window.EXSearchViewEvent = EXSearchViewEvent;
