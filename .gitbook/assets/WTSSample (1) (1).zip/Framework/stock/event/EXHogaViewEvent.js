
/**
 * @author 
 */

class EXHogaViewEvent extends AViewEvent
{
	constructor(acomp)
	{
		super(acomp);
	}
}
window.EXHogaViewEvent = EXHogaViewEvent;



//events: ['swipe']

//---------------------------------------------------------------------------------------------------
//	Component Event Functions

