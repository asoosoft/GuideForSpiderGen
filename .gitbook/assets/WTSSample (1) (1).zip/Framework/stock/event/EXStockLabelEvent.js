(async function(){

await afc.import("Framework/afc/event/ALabelEvent.js");



/**
 * @author 
 */

EXStockLabelEvent = class EXStockLabelEvent extends ALabelEvent
{
    constructor(acomp)
    {
        super(acomp);
    }
}

//window.EXStockLabelEvent = EXStockLabelEvent;
                    
})();