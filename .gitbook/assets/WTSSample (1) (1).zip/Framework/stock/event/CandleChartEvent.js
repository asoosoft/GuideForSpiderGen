                 
/**
 * @author asoocool
 */

class CandleChartEvent extends AEvent
{
	constructor(acomp)
	{
		super(acomp);
	}
}
window.CandleChartEvent = CandleChartEvent;


CandleChartEvent.prototype.change = function()
{
	//this._change();
};/*

EXItemViewEvent.prototype._change = function()
{
	this.acomp.reportEvent('change', this.acomp.getItemInfo());
};
*/
