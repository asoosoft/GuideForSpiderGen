(async function(){

await afc.import("Framework/afc/event/AGridEvent.js");



/**
 * @author asoocool
 */

EXFiveHogaGridEvent = class EXFiveHogaGridEvent extends AGridEvent
{
    constructor(acomp)
    {
        super(acomp);
    }
}
                    
//window.EXFiveHogaGridEvent = EXFiveHogaGridEvent;
                    
})();