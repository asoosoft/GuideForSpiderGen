                 
/**
 * @author asoocool
 */

class EXMiniChartEvent extends AEvent
{
	constructor(acomp)
	{
		super(acomp);
	}
}
window.EXMiniChartEvent = EXMiniChartEvent;


EXMiniChartEvent.prototype.change = function()
{
	//this._change();
};

/*

EXItemViewEvent.prototype._change = function()
{
	this.acomp.reportEvent('change', this.acomp.getItemInfo());
};
*/
