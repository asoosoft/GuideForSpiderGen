

class EXItemViewEvent extends AViewEvent
{
    constructor(acomp)
    {
        super(acomp);
    }
	
}

window.EXItemViewEvent = EXItemViewEvent;

EXItemViewEvent.prototype.change = function()
{
	//this._change();
};/*

EXItemViewEvent.prototype._change = function()
{
	this.acomp.reportEvent('change', this.acomp.getItemInfo());
};
*/

