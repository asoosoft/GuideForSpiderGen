

class EXJisooChartEvent extends AEvent
{
	constructor(acomp)
	{
		super(acomp);
	}
}
window.EXJisooChartEvent = EXJisooChartEvent;

