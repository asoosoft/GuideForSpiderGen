
/**
 * @author 
 */

class EXPivotViewEvent extends AViewEvent
{
	constructor(acomp)
	{
		super(acomp);
	}
}
window.EXPivotViewEvent = EXPivotViewEvent;



//events: ['swipe']

//---------------------------------------------------------------------------------------------------
//	Component Event Functions

EXPivotViewEvent.prototype.swipe = function()
{
	this._swipe();
};

