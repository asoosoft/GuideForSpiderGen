                 
/**
 * @author 
 */

class EXBongEvent extends AEvent
{
	constructor(acomp)
	{
		super(acomp);
	}
}
window.EXBongEvent = EXBongEvent;
