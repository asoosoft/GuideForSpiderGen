               
/**
 * @author 
 */

class EXCenterPivotViewEvent extends AViewEvent
{
	constructor(acomp)
	{
		super(acomp);
	}
}
window.EXCenterPivotViewEvent = EXCenterPivotViewEvent;
