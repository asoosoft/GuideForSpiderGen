(async function(){

await afc.import("Framework/afc/event/AGridEvent.js");



/**
 * @author asoocool
 */

EXMiniHogaEvent = class EXMiniHogaEvent extends AGridEvent
{
    constructor(acomp)
    {
        super(acomp);
    }
	
}

//window.EXMiniHogaEvent = EXMiniHogaEvent;

})();