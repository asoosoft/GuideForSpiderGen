
/**
 * @author 
 */

class ChartViewEvent extends AViewEvent
{
	constructor(acomp)
	{
		super(acomp);
	}
}
window.ChartViewEvent = ChartViewEvent;


//---------------------------------------------------------------------------------------------------
//	Component Event Functions

