(async function(){

/**
 * @author asoocool
 */
await afc.import("Framework/afc/event/ATextFieldEvent.js");


EXSecureTextFieldEvent = class EXSecureTextFieldEvent extends ATextFieldEvent
{
    constructor(acomp)
    {
        super(acomp);
    }
}

//window.EXSecureTextFieldEvent = EXSecureTextFieldEvent;

EXSecureTextFieldEvent.prototype.defaultAction = function()
{
	var atextfield = this.acomp;
	
	//상위로 이벤트를 전달할 필요가 없다.
    this.acomp.bindEvent(AEvent.ACTION_DOWN, function(e)
    {
    	if(!atextfield.isEnable || afc.isSimulator) return;

		if(afc.isMobile) 
		{
			//네이티브 하이브리드인 경우
			if(afc.isHybrid) e.preventDefault();
			//스마트폰 웹인 경우
			else e.stopPropagation();
		}
		
    });

	atextfield.bindEvent(AEvent.ACTION_UP, function(e)
    {
    	if(!atextfield.isEnable) return;
    	
		//SecurePadManager.isEnable 이 true 이거나
		//기존 isAndorid isIos, isHybrid 인 경우 처리
		if((window.SecurePadManager && SecurePadManager.isEnable) ||
		  ((afc.isAndroid || afc.isIos) && afc.isHybrid))
		{
			atextfield.openPad();
		}
    });
    
    this._focus();
	this._blur();
};

//---------------------------------------------------------------------------------------------------
//	Component Event Functions
//	events: ['change']

//---------------------------------------------------------------------------------------------------

EXSecureTextFieldEvent.prototype._focus = function()
{
	var atextfield = this.acomp;

	//SecurePadManager.isEnable 이 true 이거나
	//기존 isAndorid isIos, isHybrid 인 경우 처리
	if((window.SecurePadManager && SecurePadManager.isEnable) ||
	   ((afc.isAndroid || afc.isIos) && afc.isHybrid))
	{
		atextfield.$ele.focus(function(e) {
			atextfield.$ele.blur();
			atextfield.reportEvent('focus', null,  e);
			atextfield.openPad();
		});
	}
	else
	{
		ATextFieldEvent.prototype._focus.call(this);
	}
};

EXSecureTextFieldEvent.prototype._blur = function()
{
	var atextfield = this.acomp;
	var thisObj = this;
	atextfield.$ele.blur(function(e){
		if(thisObj.chkInterval) 
		{
			clearInterval(thisObj.chkInterval);
			thisObj.chkInterval = null;
		}
		if(window.StringUtil && StringUtil.encrypt)
		{
			atextfield.cipherData = StringUtil.encrypt(atextfield.getText());
		}
		atextfield.reportEvent('blur', e);
	});
};

EXSecureTextFieldEvent.prototype._change = function()
{
	if(this.isChangeBind) return;
	this.isChangeBind = true;

	var acomp = this.acomp;
	acomp.$ele.on('keyup', function(e) 
	{
		if(!acomp.keyPropagation) e.stopPropagation();
		if(e.which == afc.KEY_ENTER) {
			acomp.reportEvent('change', acomp.getCipherData(), e);
		}
	});
};


                    
})();