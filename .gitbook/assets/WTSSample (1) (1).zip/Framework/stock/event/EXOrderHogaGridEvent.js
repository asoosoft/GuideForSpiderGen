(async function(){

await afc.import("Framework/afc/event/AGridEvent.js");



/**
 * @author asoocool
 */

EXOrderHogaGridEvent = class EXOrderHogaGridEvent extends AGridEvent
{
    constructor(acomp)
    {
        super(acomp);
    }
}
                    
//window.EXOrderHogaGridEvent = EXOrderHogaGridEvent;
                    
})();