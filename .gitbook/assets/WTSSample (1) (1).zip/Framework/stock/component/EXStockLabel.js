
(async function(){

await afc.import("Framework/afc/component/ALabel.js");



/**
 * @author asoocool
 */


EXStockLabel = class EXStockLabel extends ALabel
{

	constructor()
    {
		this.frwName = 'stock';
	
		this.value = undefined;
		this.colorState = undefined;
		this.compareKey = 'diff';
	// 	this.compareValue = undefined;
	// 	this.compareType = undefined;

	}
	
	
}


EXStockLabel.CONTEXT = 
{
    tag:'<span data-base="EXStockLabel" data-class="EXStockLabel" class="ALabel-Style"><span>Label</span></span>',

    defStyle: 
    {
        width:'100px', height:'25px'
    },

    events: []
};
/*
// 비교할 값 세팅
EXStockLabel.prototype.setCompareValue = function(value)
{
	this.compareValue = value;
};

// 0: 매핑값1과 비교값을 비교, 1: 비교값과 0을 비교 // 아직 미처리 2: 비교값의 구분에 따라 표현
EXStockLabel.prototype.setCompareType = function(type)
{
	this.compareType = type;
};
*/
// 매핑값1은 표현값, 매핑값2는 비교값
EXStockLabel.prototype.getMappingCount = function()
{
	return ['text', 'cmpr'];
};

// 수신된 데이터에서 비교할 키가 매핑이 되지 않았을 때 자동으로 비교되는 키
EXStockLabel.prototype.setCompareKey = function(key)
{
	this.compareKey = key;
};

// 매핑값1은 표현값, 매핑값2는 비교값
EXStockLabel.prototype.getCompareKey = function()
{
	return this.compareKey;
};

EXStockLabel.prototype.setQueryData = function(dataArr, keyArr)
{
	if(!keyArr) return;
	
	var value = dataArr[0][keyArr[0]];
	if(value!=undefined) this.value = value;
	this.setText(this.value);
	
	var colorState = 0, compareValue;
	
	if(keyArr[1]) compareValue = dataArr[0][keyArr[1]];
	else compareValue = dataArr[0][this.compareKey];

	if(compareValue>0) colorState	= 2;
	else if(compareValue<0) colorState	= 4;
	
	this.colorState = colorState;
	
	this.setStyle('color', stk.getStockColor(this.colorState));
// 	this.setTextColor(stk.getStockColor(this.colorState));

	/*
	if(this.compareValue != undefined) compareValue = this.compareValue;
	else if(keyArr[1]) compareValue = data[keyArr[1]];
	else compareValue = 0;

	if(this.compareType == 0)
	{
		if(value > compareValue) colorState = 2;
		else if(value < compareValue) colorState = 4;
	}
	else if(this.compareType == 1)
	{
		if(compareValue > 0) colorState = 2;
		else if(compareValue < 0) colorState = 4;
	}
	else if(this.compareType == 2)
	{
		if(compareValue == 1) colorState = 2;
		else if(compareValue == 5) colorState = 4;
	}*/
};

//window['EXStockLabel'] = EXStockLabel;
                    
//window.EXStockLabel = EXStockLabel;
                    
})();