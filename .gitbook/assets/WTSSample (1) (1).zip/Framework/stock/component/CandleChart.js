(async function(){

await afc.import("Framework/stock/component/BaseChart.js");


CandleChart = class CandleChart extends BaseChart
{
    //mode : 모드 표시
    static MODE_CANDLE  = 0;
    static MODE_LINE    = 1;

    //intervals : 시간 표시
    static INTERVALS_MONTH = 0;
    static INTERVALS_WEEK = 1;
    static INTERVALS_DAY = 2;
    static INTERVALS_MINUTE = 5;
    static INTERVALS_TICK = 7;

    //indicator : 지표
    static INDICATOR_VOLUME = 0;
    static INDICATOR_OBV = 1;
    static INDICATOR_MACD = 2;
    static INDICATOR_SLOW = 3;
    static INDICATOR_FAST = 4;
    static INDICATOR_DISPARITY = 5;
    static INDICATOR_RSI = 6;
    static INDICATOR_EMPTY = 7;

    //데이터의 각 위치에 해당하는 값
    static INDEX_OPEN = 1;      //시가 인덱스
    static INDEX_HIGH = 2;		//고가 인덱스
    static INDEX_LOW = 3;		//저가 인덱스
    static INDEX_CLOSE = 4;	    //종가 인덱스
    static INDEX_QTY = 5;	    //체결량 인덱스

    constructor()
    {
        super();
            
        this.frwName = 'stock';

        this.delegator = null;

        this.preScale = 1;
        this.rateVal = 1;
        this.zoomState = 0;

        this.lastDist = 0;
        this.scollSX = 0;
        this.scollEX = 0;
        this.speed = 10;

        this.upEndDegree = 13;
        this.dotDegree = [1, 4, 7, 10];
        //-----------------------------------
        //이동시간을 구함
        this.mStartTime = 0;
        this.mOldTime = 0;
        //이동거리를 구함
        this.mStartX = 0;
        this.mEndX = 0;
        this.mScrollLR = false;
        this.timer = null;
        //----------------------------------------------

        this.offset = 0;
        this.startIdx = 0;
        this.startLineX = 0;
        this.endIdx = 0;
        this.BAR_CNT = 50;
        this.subType = 0;       //deprecated, use indicator
        this.indicator = 0;     //서브 그래프 타입 0~6까지
        this.prdCls = 0;        //deprecated, use intervals
        this.intervals = CandleChart.INTERVALS_MONTH;     //시간 간격
        //0:월, 1:주, 2:일, 5:분, 7틱

        //this.intervals구분에 따른 datetime 표시
        // this.dateformatFunc = [afc.formatDate, afc.formatDate, afc.formatMonth, null, null, afc.formatDateTime, null, afc.formatTime];
        this.dateformatFunc = [afc.formatMonth, afc.formatDate, afc.formatDate, null, null, afc.formatTime, null, afc.formatTime];
        this.dateformat = this.dateformatFunc[this.intervals];
        this.dashType = [1.5, 4];
        this.TEXT_SIZE = '16px';
        this.MIN_TEXT_SIZE = 16;

        this.defColorObj = {
            BACK : StockColor.BACK,
            TEXT : StockColor.TEXT,			//일반 폰트색
            DOT : StockColor.DOT,			//도트색
            DIVLINE : StockColor.DIVLINE,	//상단 하단 그래프 구분선색
            UP : StockColor.UP_COLOR,		//현재가 봉상승색
            DOWN : StockColor.DOWN_COLOR,	//현재가 봉하락색
            UPBG : StockColor.LAST[1],		//현재가 글자배경 상승색
            DOWNBG : StockColor.LAST[2],	//현재가 글자배경 하락색
            UPTEXT : StockColor.TEXT_CURR,	//현재가 글자 상승색
            DOWNTEXT : StockColor.TEXT_CURR,//현재가 글자 하락색
            VOLUME : StockColor.VOLUME,		//거래량 막대그래프 색상
            LINE : StockColor.CANDLE_LINE,//거래량 막대그래프 색상
        };
        
        this.colorObj = {
            BACK : StockColor.BACK,
            TEXT : StockColor.TEXT, 		//일반 폰트색
            DOT : StockColor.DOT, 			//도트색
            DIVLINE : StockColor.DIVLINE, 	//상단 하단 그래프 구분선색
            UP : StockColor.UP_COLOR,		//현재가 상승색
            DOWN : StockColor.DOWN_COLOR,	//현재가 하락색
            UPBG : StockColor.LAST[1],		//현재가 글자배경 상승색
            DOWNBG : StockColor.LAST[2],	//현재가 글자배경 하락색
            UPTEXT : StockColor.TEXT_CURR,	//현재가 글자 상승색
            DOWNTEXT : StockColor.TEXT_CURR,//현재가 글자 하락색
            VOLUME : StockColor.VOLUME,		//거래량 막대그래프 색상
            LINE : StockColor.CANDLE_LINE,//거래량 막대그래프 색상
        };

        this.maKeyArr = new Array(5, 20, 60);
        this.maKeyLen = 3;

        //상승하락 색상
        this.COLOR_ARR = [this.colorObj.DOWN, this.colorObj.UP, this.colorObj.DOWN];

        //마지막 종가 배경 색상
        this.CURRENT_BGCOLOR_ARR = [this.colorObj.DOWNBG, this.colorObj.UPBG, this.colorObj.DOWNBG]; //StockColor.LAST;

        //마지막 종가 글자 색상
        this.CURRENT_COLOR_ARR = [this.colorObj.DOWNTEXT, this.colorObj.UPTEXT, this.colorObj.DOWNTEXT];

        this.TEXT_SET = ['MA5', 'MA20', 'MA60'];
        //텍스트 묶음
        this.COLOR_SET = StockColor.SUB_COLORS[0];

        this.SUB_TEXT_SET =
        [
            ['MA5', 'MA20', 'MA60'],
            ['OBV'],
            ['MACD(12,26)', 'Signal(9)'],
            ['Slow%K(5,3)', 'Slow%D(3)'],
            ['Fast K(5)', 'Fast D(3)'],
            ['이격도(10)'],
            ['RSI(12)', 'Signal']
        ];

        this.SUB_COLOR_SET = StockColor.SUB_COLORS;

        this.touchEvent = null;
        this.isFirst = true;

        this.ROW_CNT = 20;		//금액 로우 간격 나누기 계산용 변수
        this.AM_R_WIDTH = 100;	//상단,하단 오른쪽 금액영역 너비
        this.AM_L_WIDTH = 0;	//상단,하단 왼쪽 금액영역 너비
        this.MAX_BAR_W = 80;	//최대 봉 너비
        this.DEF_BAR_W = 8;		//기본 봉 너비
        this.MIN_BAR_W = 8;		//최소 봉 너비
        this.BAR_TERM = 1;		//봉차트간 간격

        this.upGrpMaxAm = 0;	//상단 그래프 최대값
        this.upGrpMinAm = 0;	//상단 그래프 최소값

        this.dwGrpMaxAm = 0;	//하단 그래프 최대값
        this.dwGrpMinAm = 0;	//하단 그래프 최소값

        //포지션에 관련된 객체
        this.pos =
        {
            cavasW : 0,		//전체 캔버스 너비
            cavasH : 0,		//전체 캔버스 높이
            grpW : 0,		//상단,하단 그래프영역 너비
            grpEX : 0,		//상단,하단 그래프영역 끝 X좌표
            dtXs : [],		//상단,하단 그래프 세로구분 X좌표 배열 [1, 2, 3번째]
            amYs : [],		//상단 그래프 금액 구분선 Y좌표 배열[금액1, 금액2, 금액3, 금액4, 금액5]
            amPad : 0,		//금액 오른쪽 정렬시 마진
            txtY : 0,		//텍스트 세로 중간 정렬을 위한 Y위치

            upGrpSY : 0,	//상단 그래프 시작 Y좌표
            upDtY : 0,		//상단 그래프 Date 영역 Y
            upGrpEY : 0,	//상단 그래프 끝 Y좌표
            upGrpH : 0,		//상단 그래프 그리는 영역 높이
            kbnY : 0,		//상단,하단 그래프 구분Y
            dwGrpSY : 0,	//하단 그래프 시작 Y좌표
            dwDtY : 0,		//하단 그래프 Date 영역 Y
            dwGrpEY : 0,	//하단 그래프 끝 Y좌표
            dwGrpH : 0,		//하단 그래프 그리는 영역 높이

            dw80Y : 0,		//하단 80퍼센트 높이
            dw20Y : 0,		//하단 20퍼센트 높이

            upRateH : 0,	//상단 높이 비율
            dwRateH : 0,	//하단 높이 비율

            barW : this.DEF_BAR_W, //봉차트 너비

            barTot : 0		//봉차트 너비에 봉과 봉사이의 간격을 더한값(한봉이 그려지는 영역)
        };

        this.drawBackType = null;
        this.drawTextType = null;
        this.drawChartType = null;

        this.drawSubGrpFuncs = [
            [this.drawBackType0, this.drawTextType0, this.drawMaxMinType0, this.drawChartType0, this.calcMaxMinChartType0], 
            [this.drawBackType1, this.drawTextType1, this.drawMaxMinType1, this.drawChartType1, this.calcMaxMinChartType1], 
            [this.drawBackType2, this.drawTextType2, this.drawMaxMinType2, this.drawChartType2, this.calcMaxMinChartType2], 
            [this.drawBackType3, this.drawTextType3, this.drawMaxMinType3, this.drawChartType3, this.calcMaxMinChartType3], 
            [this.drawBackType4, this.drawTextType4, this.drawMaxMinType4, this.drawChartType4, this.calcMaxMinChartType4], 
            [this.drawBackType5, this.drawTextType5, this.drawMaxMinType5, this.drawChartType5, this.calcMaxMinChartType5], 
            [this.drawBackType6, this.drawTextType6, this.drawMaxMinType6, this.drawChartType6, this.calcMaxMinChartType6], 
            [this.drawBackType7, this.drawTextType7, this.drawMaxMinType7, this.drawChartType7, this.calcMaxMinChartType7]
        ];
        
        this.drawBackType = this.drawSubGrpFuncs[this.indicator][0];		//하단 7개 그래프 백그라운드 그리는 함수 저장 변수
        this.drawTextType = this.drawSubGrpFuncs[this.indicator][1];		//하단 7개 그래프 금액 그리는 함수 저장 변수
        this.drawMaxMinType = this.drawSubGrpFuncs[this.indicator][2];	//하단 7개 그래프 그리는 함수 저장 변수
        this.drawChartType = this.drawSubGrpFuncs[this.indicator][3];
        this.calcMaxMinChartType = this.drawSubGrpFuncs[this.indicator][4];

        this.compLeft = 0;	//엘리먼트의 Left 지점
        this.middleX = 0;	//엘리먼트의 중간X 지점

        this.currentTickCount = 0; // 틱인 경우 리얼 수신시 개수 체크하는 변수
    }
}

window.CandleChart = CandleChart;

CandleChart.CONTEXT = 
{
    tag:'<div data-base="CandleChart" data-class="CandleChart" class="CandleChart-Style" >\
            <canvas width="640px" height="400px"></canvas>\
	        <div class="chart-vline" style="display: none;"></div>\
			<div class="chart-hline" style="display: none;"></div>\
			<div class="chart-zoomLay"><div class="chart-zoomIn" >+</div><div class="chart-zoomOut">-</div></div>\
			<div class="chart-info" style="display: none;"></div>\
		</div>',

    defStyle: 
    {
        width:'640px', height:'400px'
    },

    events: [ 'scrollleft' ]
};

CandleChart.prototype.init = function(context, evtListener) {
    BaseChart.prototype.init.call(this, context, evtListener);

    this.isFirst = true;
	
    this.longXdiv = this.element.children[1];
    this.longYdiv = this.element.children[2];

    this.zoomDiv = this.element.children[3];
    this.zoomInDiv = this.zoomDiv.children[0];
    this.zoomOutDiv = this.zoomDiv.children[1];
	
    this.infoDiv = this.element.children[4];
	
	this.setOption(
	{
		touchEvent: this.getAttr('data-touch-event')!='false'?true:false	// 차트 터치이벤트, 확대 축소 제거. 롱탭이벤트는 유지
	}, true);

    this.setMode(this.getAttr('data-mode') || 0);
    this.setIntervals(this.getAttr('data-intervals') || CandleChart.INTERVALS_MONTH);
    this.setIndicator(this.getAttr('data-indicator') || CandleChart.INDICATOR_VOLUME);
    this.setUpdateRefVal(this.getAttr('data-updaterefvalue'));

    //$(this.zoomDiv).hide();
    this.initEvent();
//	this.updatePosition();
};

//차트 색상정보를 추출
CandleChart.prototype.extractColorObj = function()
{
    BaseChart.prototype.extractColorObj.call(this);
	
    this.COLOR_ARR = [this.colorObj.DOWN, this.colorObj.UP, this.colorObj.DOWN];
    this.CURRENT_BGCOLOR_ARR = [this.colorObj.DOWNBG, this.colorObj.UPBG, this.colorObj.DOWNBG];
	this.CURRENT_COLOR_ARR = [this.colorObj.DOWNTEXT, this.colorObj.UPTEXT, this.colorObj.DOWNTEXT];
};

CandleChart.prototype.initEvent = function()
{
	// 추후 setTouchEvent에서 touchEvent option에 따라서 이벤트 처리하게 수정
	// 현재 로직이 더 좋다면 수정하지 않아도 됨
	if(this.option.touchEvent)
	{
		this.setTouchEvent();
		this.setZoomEvent();	
	}
	else
	{
		this.zoomDiv.style.display = 'none';
		this.setLongTabEvent();
	}
};

CandleChart.prototype.changeBtnStyle = function(inStyle, outStyle) {
    if (inStyle) {
        $(this.zoomInDiv).removeClass('chart-zoomIn');
        $(this.zoomInDiv).addClass(inStyle);
    }
    if (outStyle) {
        $(this.zoomOutDiv).removeClass('chart-zoomOut');
        $(this.zoomOutDiv).addClass(outStyle);
    }
};

//그래프의 너비 및 높이를 업데이트
CandleChart.prototype.updatePosition = function(pWidth, pHeight) {
	if(!this.isShow()) return;
    BaseChart.prototype.updatePosition.call(this, pWidth, pHeight);
    this.calcPosition(this.eleW, this.eleH);
	if(this.data) this.updateGraph();
};

CandleChart.prototype.setZoomEvent = function(inComp, outComp) {
    var thisObj = this;
    var inDiv = this.zoomInDiv;
    var outDiv = this.zoomOutDiv;
    if (inComp)
        inDiv = inComp.element;
    if (outComp)
        outDiv = outComp.element;

    //zoomIn 버튼 클릭 리스너
    $(inDiv).bind(AEvent.ACTION_UP, function(event) {

        if (!thisObj.data || thisObj.data.length == 0)
            return;

        if (thisObj.zoomState != 1) {
            thisObj.rateVal = 1.0;
            thisObj.zoomState = 1;
        }
        thisObj.rateVal = parseFloat(thisObj.rateVal) + 0.01;
        thisObj.zoomInOut();
    });

    //zoomOut 버튼 클릭 리스너
    $(outDiv).bind(AEvent.ACTION_UP, function(event) {

        if (!thisObj.data || thisObj.data.length == 0)
            return;

        if (thisObj.zoomState != 2) {
            thisObj.rateVal = 1.0;
            thisObj.zoomState = 2;
        }
        thisObj.rateVal = parseFloat(thisObj.rateVal) - 0.01;
        thisObj.zoomInOut();
    });

};

//델리게이터를 셋팅(데이터를 더 필요로할때 이벤트를 날려줌)
CandleChart.prototype.setDelegator = function(delegator) {
    this.delegator = delegator;
};

//이동평균선 정보를 셋팅
CandleChart.prototype.setMAInfo = function(keyArr, colorArr) {
    this.maKeyArr = keyArr;
    this.maKeyLen = this.maKeyArr.length;

    this.TEXT_SET = new Array(this.maKeyLen);
    this.SUB_TEXT_SET[0] = new Array(this.maKeyLen);

    for (var i = 0; i < keyArr.length; i++) {
        this.TEXT_SET[i] = 'MA' + this.maKeyArr[i];
        this.SUB_TEXT_SET[0][i] = 'MA' + this.maKeyArr[i];
    }

    if (colorArr) {
        this.COLOR_SET = colorArr;
        this.SUB_COLOR_SET[0] = colorArr;
    } else {
        this.COLOR_SET = new Array(this.maKeyLen);
        var randomColor = null;
        for (var i = 0; i < keyArr.length; i++) {
            randomColor = afc.getRandomColor();
            this.COLOR_SET[i] = randomColor;
            this.SUB_COLOR_SET[0][i] = randomColor;
        }
    }
};

//1.컴포넌트의 너비와 높이값을 이용하여 canvas에 들어갈 영역 x y 셋팅
CandleChart.prototype.calcPosition = function(elWidth, elHeight)
{
    this.pos.cavasW = elWidth;
    this.pos.cavasH = elHeight;

    this.pos.grpEX = elWidth - this.AM_R_WIDTH;
    this.pos.grpW = this.pos.grpEX - this.AM_L_WIDTH;

    this.pos.amPad = elWidth - 5;

    this.pos.dtXs = [this.AM_L_WIDTH + this.pos.grpW * 0.25, this.AM_L_WIDTH + this.pos.grpW * 0.5, this.AM_L_WIDTH + this.pos.grpW * 0.75];

    this.pos.upGrpSY = elHeight / this.ROW_CNT;
    this.pos.txtY = (this.pos.upGrpSY / 2);
    //this.pos.upGrpEY = this.pos.upGrpSY*19;
    this.pos.upGrpEY = this.pos.upGrpSY * this.upEndDegree;
    this.pos.upGrpH = this.pos.upGrpEY - this.pos.upGrpSY;
    this.pos.upDtY = this.pos.upGrpEY + this.pos.txtY;
    this.pos.amYs = [this.pos.upGrpSY * this.dotDegree[0], this.pos.upGrpSY * this.dotDegree[1], this.pos.upGrpSY * this.dotDegree[2], this.pos.upGrpSY * this.dotDegree[3], this.pos.upGrpEY];
    //this.pos.amYs = [ this.pos.upGrpSY, this.pos.upGrpSY*4, this.pos.upGrpSY*7, this.pos.upGrpSY*10, this.pos.upGrpEY ];

    this.pos.kbnY = this.pos.upGrpSY * 14;	// * 19 로 되어있는 부분을 Demo에 * 14 로 되어있어 수정 -김민수
    //s:start, e: end
    this.pos.dwGrpSY = this.pos.upGrpSY * 15;
    this.pos.dwGrpEY = this.pos.upGrpSY * 19;
    this.pos.dwDtY = this.pos.dwGrpEY + this.pos.txtY;

    this.pos.dwGrpH = this.pos.dwGrpEY - this.pos.dwGrpSY;
    this.pos.dw80Y = this.pos.dwGrpSY + this.pos.dwGrpH * 0.2;
    this.pos.dw20Y = this.pos.dwGrpSY + this.pos.dwGrpH * 0.8;

    //텍스트 사이즈 셋팅
    if(elWidth < elHeight) this.TEXT_SIZE = (this.pos.cavasW * 0.03);
    else this.TEXT_SIZE = (this.pos.cavasH * 0.03);
	
	// 최소 폰트 사이즈 16px 되도록 처리
	if(this.TEXT_SIZE < this.MIN_TEXT_SIZE) this.TEXT_SIZE = this.MIN_TEXT_SIZE;
	this.TEXT_SIZE += 'px';
        
    this.reCalcWidth();
	/*
    this.pos.barTot = this.pos.grpW / this.BAR_CNT;
    this.pos.barW = (this.pos.barTot - this.BAR_TERM);
    */
    this.startLineX = this.pos.grpEX + this.pos.barW / 2;
    //this.DEF_BAR_W = this.pos.barW;

    //서브타입을 기준으로 서브 차트를 그리기위한 함수 셋팅
    this.settingDrawIndicator();

};

//캔들개수로 캔들넓이를 구하는 함수 
CandleChart.prototype.reCalcWidth = function(cnt) {
	if(cnt) this.BAR_CNT = cnt;
	this.pos.barTot = this.pos.grpW / this.BAR_CNT;
    this.pos.barW = (this.pos.barTot - this.BAR_TERM);
};

//데이터 입력
CandleChart.prototype.setData = function(dataArr, keyArr)
{
    this.resetData();
	
	if(dataArr.length == 0)
	{
        AToast.show('데이터가 존재하지 않습니다.');
        return;
    }
	
    if (!keyArr)
	{
		var data = dataArr[0];
		if(Object.prototype.toString.call(data) == '[object Array]')
		{
			keyArr = [];
       		data.forEach(function(v, i)
			{
				keyArr.push(i);
			});
		}
		else keyArr = Object.keys(data);
    }
    this.makeChartCanvasData(dataArr, keyArr);
    this.updateGraph();
};

//맨처음 데이터를 불러오는지 여부 셋팅
CandleChart.prototype.setIsFirst = function(isFirst) {
    this.isFirst = isFirst;
};

//맨처음 데이터를 불러오는지 여부 가져오기
CandleChart.prototype.getIsFirst = function() {
    return this.isFirst;
};

/**
 * `일자 또는 시간일 경우에 따른 표현 포멧 함수 셋팅`
 * @param {Number} prdCls `0(월), 1(주), 2(일), 5(분), 7(틱)`
 * @deprecated use setIntervals
 */
CandleChart.prototype.setPrdCls = function(prdCls) {
    this.setIntervals(prdCls);
};

CandleChart.prototype.getIntervals = function() {
    return this.intervals;
};

/**
 * `일자 또는 시간일 경우에 따른 표현 포멧 함수 셋팅`
 * @param {Number} intervals `시간 간격 값`
 * @param {boolean} noUpdate `차트 미갱신 여부`
 */
CandleChart.prototype.setIntervals = function(intervals, noUpdate) {
    this.intervals = intervals;

    let dateformat = this.dateformatFunc[this.intervals];
    if(typeof dateformat == 'string') {
        this.dateformat = ADataMask.getFunc('format');
        this.dateParam = dateformat;
    } else {
        this.dateformat = dateformat;
        this.dateParam = null;
    }

    if(!noUpdate) this.updateGraph();

    this.setAttr('data-intervals', intervals);
};

CandleChart.prototype.setUpdateRefVal = function(updateRefVal) {
    if(updateRefVal != undefined) this.updateRefVal = updateRefVal;
}

CandleChart.prototype.setDateformatFunc = function(intervals, dateFormatFunc) {
    this.dateformatFunc[intervals] = dateFormatFunc;
    this.setIntervals(this.intervals);
};

//하단의 서브 그래프 타입을 호출
CandleChart.prototype.getIndicator = function() {
    return this.indicator;
};

//하단의 서브 그래프 타입을 호출
CandleChart.prototype.setIndicator = function(indicator, noUpdate) {
    this.indicator = indicator;
    this.settingDrawIndicator();

    if (indicator == 7) {
        this.upEndDegree = 19;
        this.dotDegree = [1, 6, 12, 18];
    } else {
        this.dotDegree = [1, 4, 7, 10];
        this.upEndDegree = 13;
    }

    this.calcPosition(this.eleW, this.eleH);

    if(!noUpdate) this.updateGraph();

    this.setAttr('data-indicator', indicator);
};

//deprecated, use setIndicator
//하단의 서브 그래프 타입을 호출
CandleChart.prototype.setSubGrpType = function(index, isRefresh) {
    this.setIndicator(index, !isRefresh);
};

//서브타입을 기준으로 서브 차트를 그리기위한 함수 셋팅
CandleChart.prototype.settingDrawSubGrp = function() {
    this.settingDrawIndicator();
};

//서브타입을 기준으로 서브 차트를 그리기위한 함수 셋팅
CandleChart.prototype.settingDrawIndicator = function() {
    var subFuncArr = this.drawSubGrpFuncs[this.indicator];
    this.drawBackType = subFuncArr[0];
    this.drawTextType = subFuncArr[1];
    this.drawMaxMinType = subFuncArr[2];
    this.drawChartType = subFuncArr[3];
    this.calcMaxMinChartType = subFuncArr[4];
};

CandleChart.prototype.getData = function() {
    return this.data;
    /*
     var resultData = [];
     var dataRow = null;
     for(var i = 0; i<this.data.length; i++)
     {
     dataRow = this.data[i];
     resultData.push(dataRow[0],dataRow[1], dataRow[2], dataRow[3], dataRow[4], dataRow[5]);
     }

     return resultData;
     */

};

//차트 드로잉데이터를 리셋
CandleChart.prototype.resetData = function() {

    this.preScale = 1;
    this.rateVal = 1;
    this.zoomState = 0;

    this.lastDist = 0;
    this.scollSX = 0;
    this.scollEX = 0;
    this.speed = 0;

    //-----------------------------------
    //이동시간을 구함
    this.mStartTime = 0;
    this.mOldTime = 0;
    //이동거리를 구함
    this.mStartX = 0;
    this.mEndX = 0;
    this.mScrollLR = false;
    this.timer = null;
    //----------------------------------------------

    this.offset = 0;
    this.startIdx = 0;
    this.endIdx = 0;

    //주석처리 해봐야 할것 50일 넣으면 오른쪽으로 밀리는 현상 발견
    //this.BAR_CNT = 50;
    
    this.reCalcWidth();
    /*
    this.pos.barTot = this.pos.grpW / this.BAR_CNT;
    this.pos.barW = (this.pos.barTot - this.BAR_TERM);
    */

    this.isFirst = true;

    this.upGrpMaxAm = 0;
    //상단 그래프 최대값
    this.upGrpMinAm = 0;
    //상단 그래프 최소값

    this.dwGrpMaxAm = 0;
    //하단 그래프 최대값
    this.dwGrpMinAm = 0;
    //하단 그래프 최소값

    this.nextIqryDate = '';
    this.prevNextIqryDate = '';
    this.data = [];

    this.upDownArr = [];
    this.macdDataArr = [];
    this.dptDataArr = [];
    this.obvDataArr = [];
    this.rsiDataArr = [];  // Relative Strength Index - 가격의 상승압력과 하락압력 간의 상대적인 강도를 나타낸다.
    this.stkDataArr = [];
    this.rsiUp = [];
    this.rsiDw = [];

    this.topMaTotalArr = new Array(this.maKeyLen);
    this.topMaxMinArr = [];
    this.btmMaxMinArr = [];
    this.bottomMaTotalArr = new Array(this.maKeyLen);
    for (var j = 0; j < this.maKeyLen; j++) {
        this.topMaTotalArr[j] = 0;
        this.bottomMaTotalArr[j] = 0;
    }
    this.rsiTotalUp = 0;
    this.rsiTotalDw = 0;
    this.dispTotal = 0;

    this.topMaArr = [];
    this.bottomMaArr = [];

    for (var j = 0; j < this.maKeyLen; j++) {
        this.topMaArr[j] = [];
        this.bottomMaArr[j] = [];
    }

    //백그라운드 클리어
    //this.ctx.fillStyle = this.colorObj.BACK;
    this.ctx.clearRect(0, 0, this.pos.cavasW, this.pos.cavasH);

    this.drawBackLine();

};

//차트 드로우 함수 모음
CandleChart.prototype.draw = function() {
    //백그라운드 클리어
    //this.ctx.fillStyle = this.colorObj.BACK;
    this.ctx.clearRect(0, 0, this.pos.cavasW, this.pos.cavasH);

    //텍스트 기본 셋팅
    this.ctx.font = this.TEXT_SIZE + " '" + this.FONT_FAMILY + "'";
    this.ctx.textBaseline = 'middle';

    this.drawBackLine();
    this.drawBackText();
    this.drawGraph();
};

//백그라운드 기본 라인 그리기
CandleChart.prototype.drawBackLine = function() {

    //도트 그리기
    this.ctx.beginPath();
    this.ctx.lineWidth = 1.5;
    this.ctx.strokeStyle = this.colorObj.DOT;

    //가로선
    for (var i = 0; i < 5; i++)
        this.drawDashedLine(this.AM_L_WIDTH + 0, this.pos.amYs[i], this.pos.grpEX, this.pos.amYs[i], this.dashType);

    //세로선
    for (var i = 0; i < 3; i++)
        this.drawDashedLine(this.pos.dtXs[i] - 1, 0, this.pos.dtXs[i], this.pos.dwGrpEY, this.dashType);

    //하단 그래프 도트선
    this.drawBackType();

    this.ctx.stroke();
    this.ctx.closePath();

    if(this.indicator != 7)
    {
        //상단 하단 그래프 구분선 그리기
        this.ctx.beginPath();
        this.ctx.lineWidth = 1;
        this.ctx.strokeStyle = this.colorObj.DIVLINE;
        this.ctx.moveTo(0, this.pos.kbnY);
        this.ctx.lineTo(this.pos.cavasW, this.pos.kbnY);

        this.ctx.stroke();
        this.ctx.closePath();
    }

    //우측 금액 구분선 그리기
    this.ctx.beginPath();
    this.ctx.moveTo(this.pos.grpEX, 0);
    this.ctx.lineTo(this.pos.grpEX, this.pos.cavasH);
    this.ctx.stroke();
    this.ctx.closePath();

};

//상태에 따른 백그라운드 고정 텍스트 그리기
CandleChart.prototype.drawBackText = function() {
    /*var txt = '',
        nextX = this.AM_L_WIDTH,
        termX = 10;

    this.ctx.textAlign = 'left';

    for (var i = 0; i < this.TEXT_SET.length; i++) {
        nextX += this.ctx.measureText(txt).width + termX;
        txt = this.TEXT_SET[i];
        this.ctx.fillStyle = this.COLOR_SET[i];
        this.ctx.fillText(txt, nextX, this.pos.txtY);
    }*/
	
	this._drawLegend(this.AM_L_WIDTH, 10, this.pos.txtY, this.TEXT_SET, this.COLOR_SET);

    //서브타입에 따라서 서브타입 고정 텍스트 그리기
    this.drawTextType();
};

//상 하단 그래프 최대최소 구하기
CandleChart.prototype.setMaxMin = function() {
    this.upGrpMaxAm = 0;
    this.upGrpMinAm = Number.MAX_VALUE;

    this.dwGrpMaxAm = 0;
    this.dwGrpMinAm = Number.MAX_VALUE;

    var maxmin = null;

    for (var i = this.startIdx; i < this.endIdx; i++) {

        maxmin = this.topMaxMinArr[i];

        this.upGrpMaxAm = Math.max(this.upGrpMaxAm, maxmin[0]);
        this.upGrpMinAm = Math.min(this.upGrpMinAm, maxmin[1]);

        this.calcMaxMinChartType(i);

    }

    // 윗부분 최대값과 최소값이 같은 경우 중간에 표현되도록 최소값을 0으로 변경한다.
    if(this.upGrpMaxAm == this.upGrpMinAm) this.upGrpMinAm = 0;

    // 아래부분 최대값과 최소값이 같은 경우 중간에 표현되도록 최소값을 0으로 변경한다.
    if(this.dwGrpMaxAm == this.dwGrpMinAm) this.dwGrpMinAm = 0;

    this.pos.upRateH = (this.pos.upGrpEY - this.pos.upGrpSY) / (this.upGrpMaxAm - this.upGrpMinAm);
    this.pos.dwRateH = (this.pos.dwGrpEY - this.pos.dwGrpSY) / (this.dwGrpMaxAm - this.dwGrpMinAm);
};

//그래프 그리기
CandleChart.prototype.drawGraph = function() {
    if (!this.data || this.data.length == 0)
        return;
    var data = this.data;
    var dataOne = null;

    var lineX = this.startLineX;
    var firstY = 0;
    var lineY = 0;
    var lineY1 = 0;

    var maDataOne = null;

    var preUpArr = [];
    var preDwArr = [];
    
    if(this.mode == CandleChart.MODE_LINE)
    {
    	preUpArr.push({
            x : null,
            y : null
        });
        
        for (var i = 0; i < this.maKeyLen; i++) {
	        preDwArr.push({
	            x : null,
	            y : null
	        });
	    }
    }
    else
    {
    	for (var i = 0; i < this.maKeyLen; i++) {
	        preUpArr.push({
	            x : null,
	            y : null
	        });
	        preDwArr.push({
	            x : null,
	            y : null
	        });
	    }	
    }

    //상하단 텍스트 그리기
    this.ctx.fillStyle = this.colorObj.TEXT;
    this.ctx.textAlign = 'center';

    var dtX1 = data[parseInt(this.BAR_CNT * 0.75) + this.startIdx];
    var dtX2 = data[parseInt(this.BAR_CNT * 0.5) + this.startIdx];
    var dtX3 = data[parseInt(this.BAR_CNT * 0.25) + this.startIdx];

    if (dtX1)
        this.ctx.fillText(this.dateformat(dtX1[0], this.dateParam), this.pos.dtXs[0], this.pos.dwDtY);
    if (dtX2)
        this.ctx.fillText(this.dateformat(dtX2[0], this.dateParam), this.pos.dtXs[1], this.pos.dwDtY);
    if (dtX3)
        this.ctx.fillText(this.dateformat(dtX3[0], this.dateParam), this.pos.dtXs[2], this.pos.dwDtY);

    /*
     this.ctx.fillText(this.dateformat(data[parseInt((this.endIdx - this.startIdx)*0.75) + this.startIdx][0], this.dateParam), this.pos.dtXs[0], this.pos.dwDtY);
     this.ctx.fillText(this.dateformat(data[parseInt((this.endIdx - this.startIdx)*0.5) + this.startIdx][0], this.dateParam), this.pos.dtXs[1], this.pos.dwDtY);
     this.ctx.fillText(this.dateformat(data[parseInt((this.endIdx - this.startIdx)*0.25) + this.startIdx][0], this.dateParam), this.pos.dtXs[2], this.pos.dwDtY);
     */

    this.ctx.textAlign = 'right';
    
    // this.ctx.fillText(afc.addComma(parseInt(this.upGrpMaxAm)), this.pos.amPad, this.pos.amYs[0]);
    // this.ctx.fillText(afc.addComma(parseInt(this.upGrpMaxAm - ((this.upGrpMaxAm - this.upGrpMinAm) * 0.25))), this.pos.amPad, this.pos.amYs[1]);
    // this.ctx.fillText(afc.addComma(parseInt(this.upGrpMaxAm - ((this.upGrpMaxAm - this.upGrpMinAm) * 0.5))), this.pos.amPad, this.pos.amYs[2]);
    // this.ctx.fillText(afc.addComma(parseInt(this.upGrpMaxAm - ((this.upGrpMaxAm - this.upGrpMinAm) * 0.75))), this.pos.amPad, this.pos.amYs[3]);
    // this.ctx.fillText(afc.addComma(parseInt(this.upGrpMinAm)), this.pos.amPad, this.pos.amYs[4]);
    this.ctx.fillText(this._getDecimalValue(this.upGrpMaxAm), this.pos.amPad, this.pos.amYs[0]);
    this.ctx.fillText(this._getDecimalValue(this.upGrpMaxAm - ((this.upGrpMaxAm - this.upGrpMinAm) * 0.25)), this.pos.amPad, this.pos.amYs[1]);
    this.ctx.fillText(this._getDecimalValue(this.upGrpMaxAm - ((this.upGrpMaxAm - this.upGrpMinAm) * 0.5)), this.pos.amPad, this.pos.amYs[2]);
    this.ctx.fillText(this._getDecimalValue(this.upGrpMaxAm - ((this.upGrpMaxAm - this.upGrpMinAm) * 0.75)), this.pos.amPad, this.pos.amYs[3]);
    this.ctx.fillText(this._getDecimalValue(this.upGrpMinAm), this.pos.amPad, this.pos.amYs[4]);

    this.drawMaxMinType();
    
    for (var i = this.startIdx; i < this.endIdx; i++) {
        dataOne = data[i];

        lineX -= this.pos.barTot;
        
        if(this.mode == CandleChart.MODE_LINE)
        {
        	this.drawAvgLine(this.colorObj.LINE, preUpArr[0], lineX, this.pos.upGrpSY + (this.upGrpMaxAm - dataOne[CandleChart.INDEX_CLOSE]) * this.pos.upRateH);
        }
        else
        {
        	lineY = this.pos.upGrpSY + Math.abs((this.upGrpMaxAm - dataOne[CandleChart.INDEX_HIGH])) * this.pos.upRateH;
        
	        this.ctx.beginPath();
	        this.ctx.lineWidth = this.pos.barW;
	
	        //상승과 하락을 결정하여 색상을 셋팅
	        this.ctx.strokeStyle = this.COLOR_ARR[this.upDownArr[i][0]];
	
	        this.ctx.moveTo(lineX, this.pos.upGrpSY + (this.upGrpMaxAm - dataOne[CandleChart.INDEX_OPEN]) * this.pos.upRateH);
	
	        lineY1 = this.pos.upGrpSY + (this.upGrpMaxAm - dataOne[CandleChart.INDEX_CLOSE]) * this.pos.upRateH;
	        this.ctx.lineTo(lineX, lineY1 + this.upDownArr[i][1]);
	
	        this.ctx.stroke();
	        this.ctx.closePath();
	
	        //고가 저가 선 그리기
	        this.ctx.beginPath();
	        this.ctx.lineWidth = "1.5";
	        this.ctx.moveTo(lineX, lineY);
	        this.ctx.lineTo(lineX, lineY + Math.abs(dataOne[CandleChart.INDEX_HIGH] - dataOne[CandleChart.INDEX_LOW]) * this.pos.upRateH);
	        this.ctx.stroke();
	        this.ctx.closePath();
	        for (var j = 0; j < this.maKeyLen; j++) {
	            maDataOne = this.topMaArr[j][i];
	            this.drawAvgLine(maDataOne[0], preUpArr[j], lineX, this.pos.upGrpSY + (this.upGrpMaxAm - maDataOne[1]) * this.pos.upRateH);
	        }
        }
        
        //6개 타입에 따른 하단 그래프 그리기
        this.drawChartType(i, preDwArr, lineX);
	}
	
    this.ctx.strokeStyle = this.CURRENT_BGCOLOR_ARR[this.upDownArr[this.startIdx][0]];
    firstY = this.pos.upGrpSY + (this.upGrpMaxAm - data[this.startIdx][CandleChart.INDEX_CLOSE]) * this.pos.upRateH;

    this.ctx.beginPath();
    this.ctx.lineWidth = this.pos.upGrpSY;
    this.ctx.moveTo(this.pos.grpEX + 1, firstY);
    this.ctx.lineTo(this.pos.cavasW, firstY);
    this.ctx.stroke();
    this.ctx.closePath();

    this.ctx.textAlign = 'right';
    this.ctx.fillStyle = this.CURRENT_COLOR_ARR[this.upDownArr[this.startIdx][0]]; //this.colorObj.TEXT;
    //this.ctx.fillText(afc.addComma(data[this.startIdx][CandleChart.INDEX_CLOSE]), this.pos.amPad, firstY);
    this.ctx.fillText(this._getDecimalValue(data[this.startIdx][CandleChart.INDEX_CLOSE]), this.pos.amPad, firstY);

};

//이동평균선 그리기
CandleChart.prototype.drawAvgLine = function(color, preLine, x, y) {
    this.ctx.beginPath();
    this.ctx.strokeStyle = color;
    if (preLine.x == null) {
        preLine.x = x;
        preLine.y = y;
    }
    this.ctx.moveTo(preLine.x, preLine.y);
    this.ctx.lineTo(x, y);
    preLine.x = x;
    preLine.y = y;
    this.ctx.stroke();
    this.ctx.closePath();

};

//하단 그래프 라인 그리기
CandleChart.prototype.drawSubLine = function(color, preLine, x, y) {
    this.ctx.beginPath();
    this.ctx.strokeStyle = color;
    if (preLine.x == null) {
        preLine.x = x;
        preLine.y = y;
    }
    this.ctx.moveTo(preLine.x, preLine.y);
    this.ctx.lineTo(x, y);
    preLine.x = x;
    preLine.y = y;
    this.ctx.stroke();
    this.ctx.closePath();
};

//백그라운드 컬러 셋팅
CandleChart.prototype.setBackLineColor = function(color, isRefresh) {
    this.colorObj.DOT = color;
    if (isRefresh)
        this.updatePosition($(this.element).width(), $(this.element).height());
};

//텍스트 컬러 셋팅
CandleChart.prototype.setTextColor = function(color, isRefresh) {
    this.colorObj.TEXT = color;
    if (isRefresh)
        this.updatePosition($(this.element).width(), $(this.element).height());
};

//상승 컬러 셋팅
CandleChart.prototype.setUpColor = function(color, isRefresh) {
    this.colorObj.UP = color;
    if (isRefresh)
        this.updatePosition($(this.element).width(), $(this.element).height());
};

//하락 컬러 셋팅
CandleChart.prototype.setDownColor = function(color, isRefresh) {
    this.colorObj.DOWN = color;
    if (isRefresh)
        this.updatePosition($(this.element).width(), $(this.element).height());
};

CandleChart.prototype._drawLegend = function(startX, termX, textY, txtArr, colorArr) {
    var txt = '';
	var nextX = startX;
	this.ctx.textAlign = 'left';
    for (var i = 0; i < txtArr.length; i++) {
        nextX += this.ctx.measureText(txt).width + termX;
        txt = txtArr[i];
        this.ctx.fillStyle = colorArr[i];
        this.ctx.fillText(txt, nextX, textY);
    }
};
/*******************************************************
 거래량 그래프
 *******************************************************/
//도트선
CandleChart.prototype.drawBackType0 = function() {
    this.drawDashedLine(this.AM_L_WIDTH + 0, this.pos.dwGrpSY, this.pos.grpEX, this.pos.dwGrpSY, this.dashType);
    this.drawDashedLine(this.AM_L_WIDTH + 0, this.pos.dwGrpEY, this.pos.grpEX, this.pos.dwGrpEY, this.dashType);
};
//배경텍스트
CandleChart.prototype.drawTextType0 = function() {
    /*var txt = '',
        nextX = this.AM_L_WIDTH,
        termX = 10;
    textY = this.pos.kbnY + this.pos.txtY;
    for (var i = 0; i < this.maKeyLen; i++) {
        nextX += this.ctx.measureText(txt).width + termX;
        txt = this.TEXT_SET[i];
        this.ctx.fillStyle = this.COLOR_SET[i];
        this.ctx.fillText(txt, nextX, textY);
    }*/
	
	this._drawLegend(this.AM_L_WIDTH, 10, this.pos.kbnY + this.pos.txtY, this.TEXT_SET, this.COLOR_SET);
};
//최대최소텍스트
CandleChart.prototype.drawMaxMinType0 = function() {
    this.ctx.fillText(afc.addComma(parseInt(this.dwGrpMaxAm)), this.pos.amPad, this.pos.dwGrpSY);
    this.ctx.fillText(afc.addComma(parseInt(this.dwGrpMinAm)), this.pos.amPad, this.pos.dwGrpEY);
};
//거래량 그래프
CandleChart.prototype.drawChartType0 = function(i, preDw, lineX) {
    this.ctx.strokeStyle = this.colorObj.VOLUME;

    this.ctx.beginPath();
    this.ctx.lineWidth = this.pos.barW;
    this.ctx.moveTo(lineX, this.pos.dwGrpSY + (this.dwGrpMaxAm - this.data[i][CandleChart.INDEX_QTY]) * this.pos.dwRateH);
    this.ctx.lineTo(lineX, this.pos.dwGrpEY);

    this.ctx.stroke();
    this.ctx.closePath();

    //하단 5선, 10선, 20선, 60선, 120선 그리기
    this.ctx.lineWidth = '1.5';

    var btmOneArr = null;
    for (var j = 0; j < this.maKeyLen; j++) {
        btmOneArr = this.bottomMaArr[j][i];
        this.drawSubLine(btmOneArr[0], preDw[j], lineX, this.pos.dwGrpSY + (this.dwGrpMaxAm - btmOneArr[1]) * this.pos.dwRateH);
    }
};
//거래량 MAX / MIN 구하기
CandleChart.prototype.calcMaxMinChartType0 = function(i) {
    this.dwGrpMaxAm = Math.max(this.dwGrpMaxAm, this.btmMaxMinArr[i][0]);
    this.dwGrpMinAm = Math.min(this.dwGrpMinAm, this.btmMaxMinArr[i][1]);
};

/*******************************************************
 OBV 그래프
 *******************************************************/
//도트선
CandleChart.prototype.drawBackType1 = function() {
};
//배경텍스트
CandleChart.prototype.drawTextType1 = function() {
// 	this.ctx.fillStyle = this.SUB_COLOR_SET[this.indicator][0];
// 	this.ctx.fillText(this.SUB_TEXT_SET[this.indicator][0], this.AM_L_WIDTH + 10, this.pos.kbnY + this.pos.txtY);
	
	this._drawLegend(this.AM_L_WIDTH, 10, this.pos.kbnY + this.pos.txtY, this.SUB_TEXT_SET[this.indicator], this.SUB_COLOR_SET[this.indicator]);
};
//최대최소텍스트
CandleChart.prototype.drawMaxMinType1 = function() {
    this.ctx.fillText(afc.addComma(parseInt(this.dwGrpMaxAm)), this.pos.amPad, this.pos.dwGrpSY);
    this.ctx.fillText(afc.addComma(parseInt(this.dwGrpMinAm)), this.pos.amPad, this.pos.dwGrpEY);
};
//OBV 그래프
CandleChart.prototype.drawChartType1 = function(i, preDw, lineX) {
    this.drawSubLine(this.SUB_COLOR_SET[this.indicator][0], preDw[0], lineX, this.pos.dwGrpSY + (this.dwGrpMaxAm - this.obvDataArr[i]) * this.pos.dwRateH);
};
//OBV MAX / MIN 구하기
CandleChart.prototype.calcMaxMinChartType1 = function(i) {
    this.dwGrpMaxAm = Math.max(this.dwGrpMaxAm, this.obvDataArr[i]);
    this.dwGrpMinAm = Math.min(this.dwGrpMinAm, this.obvDataArr[i]);
};

/*******************************************************
 MACD 그래프
 *******************************************************/
//도트선
CandleChart.prototype.drawBackType2 = function() {
    this.drawDashedLine(this.AM_L_WIDTH + 0, this.pos.dwGrpSY, this.pos.grpEX, this.pos.dwGrpSY, this.dashType);
    this.drawDashedLine(this.AM_L_WIDTH + 0, this.pos.dwGrpEY, this.pos.grpEX, this.pos.dwGrpEY, this.dashType);
};
//배경텍스트
CandleChart.prototype.drawTextType2 = function() {
    /*var txt = '',
        nextX = this.AM_L_WIDTH + 0,
        termX = 10;
    textY = this.pos.kbnY + this.pos.txtY;
    for (var i = 0; i < 2; i++) {
        nextX += this.ctx.measureText(txt).width + termX;
        txt = this.SUB_TEXT_SET[this.indicator][i];
        this.ctx.fillStyle = this.SUB_COLOR_SET[this.indicator][i];
        this.ctx.fillText(txt, nextX, textY);
    }*/
	this._drawLegend(this.AM_L_WIDTH, 10, this.pos.kbnY + this.pos.txtY, this.SUB_TEXT_SET[this.indicator], this.SUB_COLOR_SET[this.indicator]);
};
//최대최소텍스트
CandleChart.prototype.drawMaxMinType2 = function() {
    this.ctx.fillText(afc.addComma(parseInt(this.dwGrpMaxAm)), this.pos.amPad, this.pos.dwGrpSY);
    this.ctx.fillText(afc.addComma(parseInt(this.dwGrpMinAm)), this.pos.amPad, this.pos.dwGrpEY);
};
//MACD 그래프
CandleChart.prototype.drawChartType2 = function(i, preDw, lineX) {
    this.drawSubLine(this.SUB_COLOR_SET[this.indicator][0], preDw[0], lineX, this.pos.dwGrpSY + (this.dwGrpMaxAm - this.macdDataArr[i][0]) * this.pos.dwRateH);
    this.drawSubLine(this.SUB_COLOR_SET[this.indicator][1], preDw[1], lineX, this.pos.dwGrpSY + (this.dwGrpMaxAm - this.macdDataArr[i][1]) * this.pos.dwRateH);
    /*
     if(this.data[i][this.MACD] < 0)
     {
     this.ctx.fillStyle = this.colorObj.DOWN;
     this.ctx.fillRect((this.pos.grpEX-this.distance)-(i-start)*this.distance,  this.dwMadcMid, this.barW, (this.pos.dwGrpEY+(this.dwMadcMin-(this.data[i][this.MACD]))*this.dwRateH)-this.dwMadcMid);
     }
     else
     {
     this.ctx.fillStyle = this.colorObj.UP;
     var startY = this.pos.dwGrpSY + (this.dwMadcMax-this.data[i][this.MACD])*this.dwRateH;
     this.ctx.fillRect((this.pos.grpEX-this.distance)-(i-start)*this.distance,  startY, this.barW, this.dwMadcMid-startY);
     }
     this.drawSubLine(2, 0, preDw[0], lineX, this.pos.dwGrpSY + (this.dwMaxAm-this.data[i][12])*this.dwRateH);
     this.drawSubLine(2, 1, preDw[1], lineX, this.pos.dwGrpSY + (this.dwMaxAm-this.data[i][14])*this.dwRateH);
     */
};
//MACD MAX / MIN 구하기
CandleChart.prototype.calcMaxMinChartType2 = function(i) {
    var macdOneData = this.macdDataArr[i][0];
    var macdOneData1 = this.macdDataArr[i][1];

    this.dwGrpMaxAm = Math.max(this.dwGrpMaxAm, macdOneData, macdOneData1);
    this.dwGrpMinAm = Math.min(this.dwGrpMinAm, macdOneData, macdOneData1);

    /*
     this.dwMaxAm = 0;
     this.dwMinAm = Number.MAX_VALUE;

     this.dwMadcMax = 0; this.dwMadcMid = 0; this.dwMadcMin = 0;

     var data = this.data;
     for(var i=this.startIdx; i<this.endIdx; i++)
     {
     this.maxAm = Math.max(this.maxAm, data[i][this.HIGH], data[i][7], data[i][9], data[i][10]  );
     this.minAm = Math.min(this.minAm, data[i][this.LOW], data[i][7], data[i][9], data[i][10]);
     this.dwMaxAm = Math.max(this.dwMaxAm, data[i][12], data[i][14] );
     this.dwMinAm = Math.min(this.dwMinAm, data[i][12], data[i][14] );
     this.dwMadcMax = Math.max(this.dwMadcMax, data[i][this.MACD] );
     this.dwMadcMin = Math.min(this.dwMadcMin, data[i][this.MACD] );
     }

     this.topRateH = (this.pos.upGrpEY-this.pos.upGrpSY)/(this.maxAm-this.minAm);
     this.dwRateH = (this.pos.dwGrpEY-this.pos.dwGrpSY)/this.dwMaxAm;

     this.dwMadcMid = this.pos.dwGrpSY+(this.dwMadcMax/(Math.abs(this.dwMadcMax) + Math.abs(this.dwMadcMin)))*(this.pos.dwGrpEY-this.pos.dwGrpSY);
     */

};

/*******************************************************
 Slow 그래프
 *******************************************************/

//도트선
CandleChart.prototype.drawBackType3 = function() {
    this.drawDashedLine(0, this.pos.dw80Y, this.pos.grpEX, this.pos.dw80Y, this.dashType);
    this.drawDashedLine(0, this.pos.dw20Y, this.pos.grpEX, this.pos.dw20Y, this.dashType);
};
//배경텍스트
CandleChart.prototype.drawTextType3 = function() {
    /*var txt = '',
        nextX = this.AM_L_WIDTH + 0,
        termX = 10;
    textY = this.pos.kbnY + this.pos.txtY;
    for (var i = 0; i < 2; i++) {
        nextX += this.ctx.measureText(txt).width + termX;
        txt = this.SUB_TEXT_SET[this.indicator][i];
        this.ctx.fillStyle = this.SUB_COLOR_SET[this.indicator][i];
        this.ctx.fillText(txt, nextX, textY);
    }*/
	this._drawLegend(this.AM_L_WIDTH, 10, this.pos.kbnY + this.pos.txtY, this.SUB_TEXT_SET[this.indicator], this.SUB_COLOR_SET[this.indicator]);
};
//최대최소텍스트
CandleChart.prototype.drawMaxMinType3 = function() {
    this.ctx.fillText('80%', this.pos.amPad, this.pos.dw80Y);
    this.ctx.fillText('20%', this.pos.amPad, this.pos.dw20Y);
};
//Slow 그래프
CandleChart.prototype.drawChartType3 = function(i, preDw, lineX) {
    this.drawSubLine(this.SUB_COLOR_SET[this.indicator][0], preDw[0], lineX, this.pos.dwGrpSY + (100 - this.stkDataArr[i][1]) / 100 * this.pos.dwRateH);
    this.drawSubLine(this.SUB_COLOR_SET[this.indicator][1], preDw[1], lineX, this.pos.dwGrpSY + (100 - this.stkDataArr[i][2]) / 100 * this.pos.dwRateH);
};

//Slow MAX / MIN 구하기
CandleChart.prototype.calcMaxMinChartType3 = function() {
    this.dwGrpMaxAm = 2;
    this.dwGrpMinAm = 1;
};

//deprecated, use setMode
CandleChart.prototype.setChartMode = function(mode, isRefresh) {
	this.setIntervals(7);
    this.setMode(mode, !isRefresh);
};

CandleChart.prototype.getMode = function() {
    return this.mode;
};

CandleChart.prototype.setMode = function(mode, noUpdate) {
    this.mode = mode;
    if(!noUpdate) this.updateGraph();

    this.setAttr('data-mode', mode);
};
/*******************************************************
 Fast 그래프
 *******************************************************/

//도트선
CandleChart.prototype.drawBackType4 = function() {
    this.drawDashedLine(0, this.pos.dw80Y, this.pos.grpEX, this.pos.dw80Y, this.dashType);
    this.drawDashedLine(0, this.pos.dw20Y, this.pos.grpEX, this.pos.dw20Y, this.dashType);
};
//배경텍스트
CandleChart.prototype.drawTextType4 = function() {
    /*var txt = '',
        nextX = this.AM_L_WIDTH + 0,
        termX = 10;
    textY = this.pos.kbnY + this.pos.txtY;
    for (var i = 0; i < 2; i++) {
        nextX += this.ctx.measureText(txt).width + termX;
        txt = this.SUB_TEXT_SET[this.indicator][i];
        this.ctx.fillStyle = this.SUB_COLOR_SET[this.indicator][i];
        this.ctx.fillText(txt, nextX, textY);
    }*/
	this._drawLegend(this.AM_L_WIDTH, 10, this.pos.kbnY + this.pos.txtY, this.SUB_TEXT_SET[this.indicator], this.SUB_COLOR_SET[this.indicator]);
};
//최대최소텍스트
CandleChart.prototype.drawMaxMinType4 = function() {
    this.ctx.fillText('80%', this.pos.amPad, this.pos.dw80Y);
    this.ctx.fillText('20%', this.pos.amPad, this.pos.dw20Y);
};
//Fast 그래프
CandleChart.prototype.drawChartType4 = function(i, preDw, lineX) {
    this.drawSubLine(this.SUB_COLOR_SET[this.indicator][0], preDw[0], lineX, this.pos.dwGrpSY + (100 - this.stkDataArr[i][0]) / 100 * this.pos.dwRateH);
    this.drawSubLine(this.SUB_COLOR_SET[this.indicator][1], preDw[1], lineX, this.pos.dwGrpSY + (100 - this.stkDataArr[i][1]) / 100 * this.pos.dwRateH);
};

//Fast MAX / MIN 구하기
CandleChart.prototype.calcMaxMinChartType4 = function() {
    this.dwGrpMaxAm = 2;
    this.dwGrpMinAm = 1;
};

/*******************************************************
 이격도 그래프 disparity
 *******************************************************/
//도트선
CandleChart.prototype.drawBackType5 = function() {
};
//배경텍스트
CandleChart.prototype.drawTextType5 = function() {
// 	this.ctx.fillStyle = this.SUB_COLOR_SET[this.indicator][0];
// 	this.ctx.fillText(this.SUB_TEXT_SET[this.indicator][0], this.AM_L_WIDTH + 10, this.pos.kbnY + this.pos.txtY);
	this._drawLegend(this.AM_L_WIDTH, 10, this.pos.kbnY + this.pos.txtY, this.SUB_TEXT_SET[this.indicator], this.SUB_COLOR_SET[this.indicator]);
};
//최대최소텍스트
CandleChart.prototype.drawMaxMinType5 = function() {
    this.ctx.fillText(afc.addComma(parseInt(this.dwGrpMaxAm)), this.pos.amPad, this.pos.dwGrpSY);
    this.ctx.fillText(afc.addComma(parseInt(this.dwGrpMinAm)), this.pos.amPad, this.pos.dwGrpEY);
};
//이격도 그래프
CandleChart.prototype.drawChartType5 = function(i, preDw, lineX) {
    this.drawSubLine(this.dptDataArr[i][0], preDw[0], lineX, this.pos.dwGrpSY + (this.dwGrpMaxAm - this.dptDataArr[i][1]) * this.pos.dwRateH);
};
//이격도 MAX / MIN 구하기
CandleChart.prototype.calcMaxMinChartType5 = function(i) {
    var dispOneData = this.dptDataArr[i][1];
    this.dwGrpMaxAm = Math.max(this.dwGrpMaxAm, dispOneData);
    this.dwGrpMinAm = Math.min(this.dwGrpMinAm, dispOneData);

};

/*******************************************************
 RSI 그래프
 *******************************************************/
//도트선
CandleChart.prototype.drawBackType6 = function() {
    this.drawDashedLine(0, this.pos.dw80Y, this.pos.grpEX, this.pos.dw80Y, this.dashType);
    this.drawDashedLine(0, this.pos.dw20Y, this.pos.grpEX, this.pos.dw20Y, this.dashType);
};
//배경텍스트
CandleChart.prototype.drawTextType6 = function() {
    /*var txt = '',
        nextX = this.AM_L_WIDTH + 0,
        termX = 10;
    textY = this.pos.kbnY + this.pos.txtY;
    for (var i = 0; i < 2; i++) {
        nextX += this.ctx.measureText(txt).width + termX;
        txt = this.SUB_TEXT_SET[this.indicator][i];
        this.ctx.fillStyle = this.SUB_COLOR_SET[this.indicator][i];
        this.ctx.fillText(txt, nextX, textY);
    }*/
	this._drawLegend(this.AM_L_WIDTH, 10, this.pos.kbnY + this.pos.txtY, this.SUB_TEXT_SET[this.indicator], this.SUB_COLOR_SET[this.indicator]);
};
//최대최소텍스트
CandleChart.prototype.drawMaxMinType6 = function() {
    this.ctx.fillText('80%', this.pos.amPad, this.pos.dw80Y);
    this.ctx.fillText('20%', this.pos.amPad, this.pos.dw20Y);
};
//RSI 그래프
CandleChart.prototype.drawChartType6 = function(i, preDw, lineX) {
    this.drawSubLine(this.SUB_COLOR_SET[this.indicator][0], preDw[0], lineX, this.pos.dwGrpSY + (100 - this.rsiDataArr[i][0]) / 100 * this.pos.dwRateH);
    this.drawSubLine(this.SUB_COLOR_SET[this.indicator][1], preDw[1], lineX, this.pos.dwGrpSY + (100 - this.rsiDataArr[i][1]) / 100 * this.pos.dwRateH);
};

//RSI MAX / MIN 구하기
CandleChart.prototype.calcMaxMinChartType6 = function() {
    this.dwGrpMaxAm = 2;
    this.dwGrpMinAm = 1;
};

/*******************************************************
 EMPTY 그래프
 *******************************************************/
//도트선
CandleChart.prototype.drawBackType7 = function() {
};
//배경텍스트
CandleChart.prototype.drawTextType7 = function() {

};
//최대최소텍스트
CandleChart.prototype.drawMaxMinType7 = function() {
};
//RSI 그래프
CandleChart.prototype.drawChartType7 = function(i, preDw, lineX) {
};

//RSI MAX / MIN 구하기
CandleChart.prototype.calcMaxMinChartType7 = function() {
};

//데이터가 더 필요한지를 체크
CandleChart.prototype.isExistNextData = function() {
    if ((this.startIdx + this.BAR_CNT) > this.data.length)
        return false;
    else
        return true;
};

//현재 그리는 데이터 오프셋 가져오기
CandleChart.prototype.getOffset = function() {
    var tempInx = this.startIdx + this.BAR_CNT;
    if (tempInx > this.data.length)
        this.endIdx = this.data.length;
    else
        this.endIdx = tempInx;
};

//캔들의 너비와 캔들 간의 공백넓이로 캔들 개수를 바꿈
CandleChart.prototype.barWidthChange = function() {
    this.pos.barTot = this.pos.barW + this.BAR_TERM;
    this.BAR_CNT = parseInt(this.pos.grpW / this.pos.barTot, 10);
    this.startLineX = this.pos.grpEX + this.pos.barW / 2;
};

//왼쪽에서 오른쪽으로 스크롤 시킴
CandleChart.prototype.scrollLToR = function(add) {

    if (!this.isExistNextData()) {
        this.getOffset();
		
		if(!this.isReportedScrollLeft)
		{
			this.reportEvent('scrollleft');
			this.isReportedScrollLeft = true;
		}
        return;
    }

    this.startIdx += add;
    this.updateGraph();

};

//오른쪽에서 왼쪽으로 스크롤 시킴
CandleChart.prototype.scrollRToL = function(add) {

    if (this.data.length < 1) {
        this.getOffset();
        return;
    }
	
	this.isReportedScrollLeft = false;

    this.startIdx -= add;
    if (this.startIdx < 0) this.startIdx = 0;
    
    this.updateGraph();
};

//그래프 업데이트
CandleChart.prototype.updateGraph = function() {
    if (this.isExistNextData() || !this.nextIqryDate) {
        this.getOffset();
        this.setMaxMin();
        this.draw();
    } else if (this.delegator) {
        if(this.prevNextIqryDate !== this.nextIqryDate) {
            this.delegator.callNextData(this.nextIqryDate);
            this.prevNextIqryDate = this.nextIqryDate;
        }
    }
};

CandleChart.prototype.resetZoom = function(isDraw) {
	this.rateVal = 1;
	this.pos.barW = this.DEF_BAR_W;
	this.barWidthChange();
	if(isDraw) this.updateGraph();
};

CandleChart.prototype.zoomIn = function()
{
	this.zoomInDiv.dispatchEvent(new Event(AEvent.ACTION_UP));
};

CandleChart.prototype.zoomOut = function()
{
	this.zoomOutDiv.dispatchEvent(new Event(AEvent.ACTION_UP));
};

//줌 인아웃
CandleChart.prototype.zoomInOut = function()
{
    if (this.preScale != this.rateVal) {
	
		this.preScale = this.rateVal;
		this.pos.barW *= this.preScale;

		if (this.pos.barW < this.MIN_BAR_W) this.pos.barW = this.MIN_BAR_W;
		else if (this.pos.barW > this.MAX_BAR_W) this.pos.barW = this.MAX_BAR_W;
		
	}
   
    this.barWidthChange();
    this.updateGraph();
};

//롱탭시 안내선 보이기
CandleChart.prototype.drawLongTabData = function(touchX) {
    var oriX = touchX - this._getCompLeft();
    var offsetX = this.pos.grpEX - oriX;
    var curPos = parseInt(offsetX / this.pos.barTot);
    var curPer = offsetX % this.pos.barTot;

    if (curPer > this.pos.barTot)
        curPos += 1;

    var newOffset = this.startIdx + curPos;

    if (newOffset < this.startIdx || newOffset > this.endIdx)
        return;

    var detData = this.data[newOffset];
    if (detData) {
    	if(this.mode == CandleChart.MODE_LINE) this.infoDiv.innerHTML = '<span>' + this.dateformat(detData[0], this.dateParam) + '</span></br><span>종가 : ' + afc.addComma(detData[4]) + '</span>';
        else
		{
			var tagStr = '<span>' + this.dateformat(detData[0], this.dateParam) + '</span></br><span>시가 : ' 
						+ afc.addComma(detData[1]) + '</span><span style="margin-left:20px;">고가 : ' 
						+ afc.addComma(detData[2]) + '</span></br><span>저가 : ' 
						+ afc.addComma(detData[3]) + '</span><span style="margin-left:20px;">종가 : ' 
						+ afc.addComma(detData[4]) + '</span></br><span>거래량 : ' 
						+ afc.addComma(detData[5]) + '</span>';
			
			if(detData[6] != undefined) tagStr += '</br><span>거래대금 : ' + afc.addComma(detData[6]) + '</span>';
			
			this.infoDiv.innerHTML = tagStr;
		}

        this.longXdiv.style.left = (this.startLineX - (curPos + 1) * this.pos.barTot) + 'px';
        this.longYdiv.style.top = (this.pos.upGrpSY + (this.upGrpMaxAm - detData[4]) * this.pos.upRateH) + 'px';
    }
};

// -----------------------  그래프 터치 이벤트  ----------------------- //
//자동스크를
CandleChart.prototype.autoScroll = function(speed) {
    var thisObj = this;

    if (speed > 150) return;
	else if(!this.isExistNextData())
	{
		this.isReportedScrollLeft = true;
		this.reportEvent('scrollleft');
	    return;
	}
    

    this.timer = setTimeout(function() {
        thisObj.timer = null;

        if (thisObj.mScrollLR)
            thisObj.scrollLToR(1);
        else
            thisObj.scrollRToL(1);
        thisObj.autoScroll(speed + speed / 4);
    }, speed);
};

//터치이벤트 셋팅
CandleChart.prototype.setTouchEvent = function()
{
    var thisObj = this;
    var touch1,
        touch2,
        pageX1,
        pageY1,
        pageX2,
        pageY2,
        isDown = false;
	var isXMove = false,
		isYMove = false;

    AEvent.bindEvent(this.canvas, AEvent.ACTION_DOWN, function(e) {
        isDown = true;
		isXMove = false;
		isYMove = false;
        if (!thisObj.data || thisObj.data.length == 0)
            return;

        //e.preventDefault();
        //e.stopPropagation();

        touch1 = e.targetTouches[0];
        touch2 = e.targetTouches[1];
		
		if(touch2) {
			e.preventDefault();
			e.stopPropagation();
		}

        pageX1 = touch1.pageX;
        pageY1 = touch1.pageY;

        if (thisObj.timer) {
            clearTimeout(thisObj.timer);
            thisObj.timer = null;
        }

        thisObj.scollSX = pageX1;

        //------------------------
        thisObj.mStartTime = new Date().getTime();
        thisObj.mOldTime = thisObj.mStartTime;
        thisObj.mStartX = pageX1;
		thisObj.mStartY = pageY1;
        thisObj.mEndX = thisObj.mStartX;

        //-------------------------------------
        //롱탭을 눌렀을시
        //-------------------------------------

        this.longTime = setTimeout(function() {
            if (touch2)
                return;

            thisObj.touchMode = 1;

            thisObj.infoDiv.style.display = '';
            thisObj.longXdiv.style.display = '';
            thisObj.longYdiv.style.display = '';

            thisObj.moveX = pageX1;
            thisObj.drawLongTabLines();

        }, 500);
    });

    function getDistance(p1, p2) {
        return Math.sqrt(Math.pow((p2.x - p1.x), 2) + Math.pow((p2.y - p1.y), 2));
    }


    AEvent.bindEvent(this.canvas, AEvent.ACTION_MOVE, function(e) {
        clearTimeout(this.longTime);

        if (!isDown || e.buttons == 0) {
            isDown = false;
            return;
        }
        if (!thisObj.data || thisObj.data.length == 0)
            return;

        //e.preventDefault();
        //e.stopPropagation();

        touch1 = e.targetTouches[0];
        touch2 = e.targetTouches[1];

        pageX1 = touch1.pageX;
        pageY1 = touch1.pageY;

        //멀티터치
        if (touch2) {
			e.preventDefault();
			e.stopPropagation();
            pageX2 = touch2.pageX;
            pageY2 = touch2.pageY;

            if (touch1 && touch2) {

                var dist = getDistance({
                    x : pageX1,
                    y : pageY1
                }, {
                    x : pageX2,
                    y : pageY2
                });
                if (!thisObj.lastDist) {
                    thisObj.lastDist = dist;
                }
                thisObj.rateVal = (dist / thisObj.lastDist).toFixed(2);
                thisObj.zoomState = 0;
                thisObj.zoomInOut();
                thisObj.lastDist = dist;
            }
        }

        //일반 스크롤
        else {
            //--------------------------------------
            //롱탭 후 드래그 했을시
            if (thisObj.touchMode == 1) {
                thisObj.moveX = pageX1;
                thisObj.drawLongTabLines();

                //스크롤 안되게 처리
                e.preventDefault();
            }
            //일반 스크롤시
            else {
				if (!isXMove && !isYMove ) {
					if( Math.abs(thisObj.mStartX-pageX1) > 10 ) {
						isXMove = true;
					} else if( Math.abs(thisObj.mStartY-pageY1) > 10 ) {
						isYMove = true;
					}
				}
				
				if (isXMove) e.stopPropagation();
				if (isYMove) return;
                //--------------------------------------
                var newTime = new Date().getTime();
                //멈춰있는 시간이 일정시간 이상이면 초기화
                if ((newTime - thisObj.mOldTime) > 100) {
                    thisObj.mStartTime = newTime;
                    thisObj.mOldTime = newTime;
                    thisObj.mStartX = pageX1;
                    thisObj.mEndX = thisObj.mStartX;
                } else {
                    thisObj.mOldTime = newTime;
                    thisObj.mEndX = pageX1;
                }

                //--------------------------------------
                var chkW = Math.abs(thisObj.scollSX - pageX1);
                if (chkW > thisObj.pos.barW)//+graph.distance
                {
                    if (thisObj.scollSX > pageX1) {
                        thisObj.mScrollLR = false;
                        var count = parseInt((chkW / thisObj.pos.barW), 10);
                        thisObj.scrollRToL(count);
                    } else {
                        thisObj.mScrollLR = true;
                        var count = parseInt((chkW / thisObj.pos.barW), 10);
                        thisObj.scrollLToR(count);
                    }
                    thisObj.scollSX = pageX1;
                }
            }
        }

    });

    AEvent.bindEvent(this.canvas, AEvent.ACTION_UP, function(e) {
        isDown = false;
        if (!thisObj.data || thisObj.data.length == 0)
            return;

        clearTimeout(this.longTime);

        thisObj.touchMode = 0;
        if (thisObj.infoDiv) {
            thisObj.infoDiv.style.display = 'none';
            thisObj.longXdiv.style.display = 'none';
            thisObj.longYdiv.style.display = 'none';
        }

        //e.preventDefault();
		if (isXMove) {
			e.preventDefault();
			e.stopPropagation();
		}
		if (isYMove) return;

        //------------------
        var interval = new Date().getTime() - thisObj.mStartTime;
        thisObj.speed = Math.abs(thisObj.mEndX - thisObj.mStartX) / interval;
        //속도값이 아주 작은 것은 무시한다.
        if (thisObj.speed > 0.5) {
            thisObj.autoScroll((4 - thisObj.speed) / 2);
        }
        //----------------------------------

        thisObj.lastDist = null;
    });
};

//터치이벤트 셋팅
CandleChart.prototype.setLongTabEvent = function()
{
    var thisObj = this;
    var touch1,
        touch2,
        pageX1,
        pageY1,
        pageX2,
        pageY2,
        isDown = false;

    AEvent.bindEvent(this.canvas, AEvent.ACTION_DOWN, function(e) {
        isDown = true;
        if (!thisObj.data || thisObj.data.length == 0)
            return;

        e.preventDefault();
        e.stopPropagation();

        touch1 = e.targetTouches[0];
        touch2 = e.targetTouches[1];

        pageX1 = touch1.pageX;

        if (thisObj.timer) {
            clearTimeout(thisObj.timer);
            thisObj.timer = null;
        }

        thisObj.scollSX = pageX1;

        //------------------------
        thisObj.mStartTime = new Date().getTime();
        thisObj.mOldTime = thisObj.mStartTime;
        thisObj.mStartX = pageX1;
        thisObj.mEndX = thisObj.mStartX;

        //-------------------------------------
        //롱탭을 눌렀을시
        //-------------------------------------

        this.longTime = setTimeout(function() {
            if (touch2)
                return;

            thisObj.touchMode = 1;

            thisObj.infoDiv.style.display = '';
            thisObj.longXdiv.style.display = '';
            thisObj.longYdiv.style.display = '';

            thisObj.moveX = pageX1;
            thisObj.drawLongTabLines();

        }, 500);
    });

    function getDistance(p1, p2) {
        return Math.sqrt(Math.pow((p2.x - p1.x), 2) + Math.pow((p2.y - p1.y), 2));
    }


    AEvent.bindEvent(this.canvas, AEvent.ACTION_MOVE, function(e) {
        clearTimeout(this.longTime);

        if (!isDown || e.buttons == 0) {
            isDown = false;
            return;
        }
        if (!thisObj.data || thisObj.data.length == 0)
            return;

        e.preventDefault();
        e.stopPropagation();

        touch1 = e.targetTouches[0];
        touch2 = e.targetTouches[1];

        pageX1 = touch1.pageX;
        pageY1 = touch1.pageY;

        //멀티터치
        if (touch2) {
            pageX2 = touch2.pageX;
            pageY2 = touch2.pageY;

            if (touch1 && touch2) {

                var dist = getDistance({
                    x : pageX1,
                    y : pageY1
                }, {
                    x : pageX2,
                    y : pageY2
                });
                if (!thisObj.lastDist) {
                    thisObj.lastDist = dist;
                }
                thisObj.rateVal = (dist / thisObj.lastDist).toFixed(2);
                thisObj.zoomState = 0;
                thisObj.zoomInOut();
                thisObj.lastDist = dist;
            }
        }

        //일반 스크롤
        else {
            //--------------------------------------
            //롱탭 후 드래그 했을시
            if (thisObj.touchMode == 1) {
                thisObj.moveX = pageX1;
                thisObj.drawLongTabLines();
            }
            //일반 스크롤시
            else {
                //--------------------------------------
                var newTime = new Date().getTime();
                //멈춰있는 시간이 일정시간 이상이면 초기화
                if ((newTime - thisObj.mOldTime) > 100) {
                    thisObj.mStartTime = newTime;
                    thisObj.mOldTime = newTime;
                    thisObj.mStartX = pageX1;
                    thisObj.mEndX = thisObj.mStartX;
                } else {
                    thisObj.mOldTime = newTime;
                    thisObj.mEndX = pageX1;
                }

                //--------------------------------------
                var chkW = Math.abs(thisObj.scollSX - pageX1);
                if (chkW > thisObj.pos.barW)//+graph.distance
                {
                    if (thisObj.scollSX > pageX1) {
                        thisObj.mScrollLR = false;
                        var count = parseInt((chkW / thisObj.pos.barW), 10);
                        thisObj.scrollRToL(count);
                    } else {
                        thisObj.mScrollLR = true;
                        var count = parseInt((chkW / thisObj.pos.barW), 10);
                        thisObj.scrollLToR(count);
                    }
                    thisObj.scollSX = pageX1;
                }
            }
        }

    });

    AEvent.bindEvent(this.canvas, AEvent.ACTION_UP, function(e) {
        isDown = false;
        if (!thisObj.data || thisObj.data.length == 0)
            return;

        clearTimeout(this.longTime);

        thisObj.touchMode = 0;
        if (thisObj.infoDiv) {
            thisObj.infoDiv.style.display = 'none';
            thisObj.longXdiv.style.display = 'none';
            thisObj.longYdiv.style.display = 'none';
        }

        e.preventDefault();
        e.stopPropagation();

        //------------------
        var interval = new Date().getTime() - thisObj.mStartTime;
        thisObj.speed = Math.abs(thisObj.mEndX - thisObj.mStartX) / interval;
        //속도값이 아주 작은 것은 무시한다.
        if (thisObj.speed > 0.5) {
            thisObj.autoScroll((4 - thisObj.speed) / 2);
        }
        //----------------------------------

        thisObj.lastDist = null;
    });
};

CandleChart.prototype.addNewData = function(dataArr, keyArr) {

    if (!dataArr)
        return;

    this.startId--;

    if (!keyArr) {
        var keyLength = dataArr.length;

        keyArr = [];
        for (var i = 0; i < keyLength; i++) {
            keyArr.push(i);
        }
    }
    this.upDownArr.unshift([]);
    this.macdDataArr.unshift([]);
    this.dptDataArr.unshift([]);
    this.obvDataArr.unshift([]);
    this.rsiDataArr.unshift([]);
    this.rsiUp.unshift([]);
    this.rsiDw.unshift([]);
    this.topMaxMinArr.unshift([]);
    this.btmMaxMinArr.unshift([]);
    this.stkDataArr.unshift([]);

    for (var j = 0; j < this.maKeyLen; j++) {
        this.topMaArr[j].unshift([]);
        this.bottomMaArr[j].unshift([]);
    }

    // 01.봉차트를 그리기 위한 순수배열 데이터
    //   0       1      2      3       4       5         6
    //['일시', '시가', '고가', '저가', '종가', '거래량', '거래대금' ]

    this.OPENVAL = dataArr[keyArr[1]];
    this.HIGHVAL = dataArr[keyArr[2]];
    this.LOWVAL = dataArr[keyArr[3]];
    this.CLOSEVAL = dataArr[keyArr[4]];
    this.QTYVAL = dataArr[keyArr[5]];

	var arr = [dataArr[keyArr[0]], this.OPENVAL, this.HIGHVAL, this.LOWVAL, this.CLOSEVAL, this.QTYVAL];
	if(keyArr[6]) arr.push(dataArr[keyArr[6]]);
    this.data.unshift(arr);

    //02.상승하락 구분 배열 데이터
    //      0                1            2          3
    //['상하색상구분', '보합일경우 높이', '상승한값', '하락한값']

    this.curOffset = 0;

    //02.상승하락 구분 배열 데이터
    this.makeUpDownData();

    //03.단순이동평균 배열 데이터
    this.makeMoveAvgData();

    //04.이격도 데이터
    this.makeDptData();

    //05.MACD 지수이동평균 / OBV 배열 데이터
    this.makeMacdObvData();

    //07.RSI 데이터
    this.makeRSIData();

    //08.Stoch-Fast ~ Stoch-Slow
    this.makeStochasticData();

    this.updateGraph();

    //롱탭중일시에 정보 갱신
    if (this.touchMode == 1) this.drawLongTabLines();
};

CandleChart.prototype.addRealData = function(dataArr, keyArr) {

    if (!dataArr)
        return;

    this.startIdx--;
    if (this.startIdx < 0) this.startIdx = 0;

    if (!keyArr) {
        var keyLength = dataArr.length;

        keyArr = [];
        for (var i = 0; i < keyLength; i++) {
            keyArr.push(i);
        }
    }
    
    this.upDownArr.unshift([]);
    this.macdDataArr.unshift([]);
    this.dptDataArr.unshift([]);
    this.obvDataArr.unshift([]);
    this.rsiDataArr.unshift([]);
    this.rsiUp.unshift([]);
    this.rsiDw.unshift([]);
    this.topMaxMinArr.unshift([]);
    this.btmMaxMinArr.unshift([]);
    this.stkDataArr.unshift([]);

    for (var j = 0; j < this.maKeyLen; j++) {
        //this.topMaTotalArr[j] = 0;
        //this.bottomMaTotalArr[j] = 0;
        this.topMaArr[j].unshift([]);
        this.bottomMaArr[j].unshift([]);
    }
	
	var arr = [
        dataArr[keyArr[0]],		+dataArr[keyArr[1]], +dataArr[keyArr[2]],
		+dataArr[keyArr[3]],	+dataArr[keyArr[4]], +dataArr[keyArr[5]]
	];
	if(keyArr[6]) arr.push(+dataArr[keyArr[6]]);
    this.data.unshift(arr);
    
    this.curOffset = 0;
    this.preUpDown = this.upDownArr[this.curOffset + 1] ? this.upDownArr[this.curOffset + 1][0] : 2;

    this.OPENVAL = this.data[0][1];
    this.HIGHVAL = this.data[0][2];
    this.LOWVAL = this.data[0][3];
    this.CLOSEVAL = this.data[0][4];
    this.QTYVAL = this.data[0][5];

    //02.상승하락 구분 배열 데이터
    this.makeUpDownData();

    //03.단순이동평균 배열 데이터
    this.makeMoveAvgData();

    //04.이격도 데이터
    this.makeDptData();

    //05.MACD 지수이동평균 / OBV 배열 데이터
    this.makeMacdObvData();

    //07.RSI 데이터
    this.makeRSIData();

    //08.Stoch-Fast ~ Stoch-Slow
    this.makeStochasticData();

    this.updateGraph();

    //롱탭중일시에 정보 갱신
    if (this.touchMode == 1) this.drawLongTabLines();
};

CandleChart.prototype.updateRealData = function(data, keyArr)
{
    if (!data)
        return;

    // this.startIdx--;
    // if (this.startIdx < 0) this.startIdx = 0;

    if (!keyArr) keyArr = Object.keys(data);

    if(this.data.length == 0)
    {
        this.setData([data], keyArr);
        return;
    }
    
	//Number Type으로 변경
	data[keyArr[4]] = +data[keyArr[4]];
	
    data[keyArr[0]] = this.data[0][0];
    data[keyArr[1]] = this.data[0][1];
    data[keyArr[2]] = Math.max(this.data[0][2], data[keyArr[4]]);
    data[keyArr[3]] = Math.min(this.data[0][3], data[keyArr[4]]);
    
    this.curOffset = 0;

    // makeMoveAvgData 이전 상태로 돌려놓기
    var termCnt, preTermIdx;
    for (var j = 0; j < this.maKeyLen; j++) {
        termCnt = this.maKeyArr[j];
        preTermIdx = this.curOffset + termCnt;

        if(this.data[preTermIdx]) {
            this.topMaTotalArr[j] += this.data[preTermIdx][CandleChart.INDEX_CLOSE];
            this.bottomMaTotalArr[j] += this.data[preTermIdx][5];
        }
        this.topMaTotalArr[j] -= this.data[0][CandleChart.INDEX_CLOSE];
        this.bottomMaTotalArr[j] -= this.data[0][5];
    }
    
    // makeDptData 이전 상태로 돌려놓기
    termCnt = 10;
    preTermIdx = this.curOffset + termCnt;
    this.dispTotal -= this.CLOSEVAL;       // 이전 종가 뺴기
    if (this.data[preTermIdx]) this.dispTotal += this.data[preTermIdx][4]; //다시 뺄테니 더해주기

    // makeMacdObvData 이전 상태로 돌려놓기
    var DISTJONG;
    //06.OBV 데이터
    if (this.PRECLOSE) {
        DISTJONG = this.CLOSEVAL - this.PRECLOSE;
        if (DISTJONG > 0) {
            this.PREOBV -= this.QTYVAL;
            this.UPVAL = DISTJONG;
            this.DWVAL = 0;
        } else if (DISTJONG < 0) {
            this.PREOBV += this.QTYVAL;
            this.UPVAL = 0;
            this.DWVAL = DISTJONG * -1;
        }
        this.rsiUp[this.curOffset] = this.UPVAL;
        this.rsiDw[this.curOffset] = this.DWVAL;
    } else {
        this.rsiUp[this.curOffset] = this.rsiDw[this.curOffset] = 0;
    }

    this.rsiTotalUp -= this.UPVAL;
    this.rsiTotalDw -= this.DWVAL;

    this.PRECLOSE = this.CLOSEVAL;
    this.obvDataArr[this.curOffset] = this.PREOBV;
    
    // makeRSIData 이전 상태로 돌려놓기
    termCnt = 12;
    preTermIdx = this.curOffset + termCnt;
    if (this.data[preTermIdx]) {
        this.rsiTotalUp += this.rsiUp[preTermIdx];
        this.rsiTotalDw += this.rsiDw[preTermIdx];
    }

    // makeStochasticData 이전 상태로 돌려놓기
    // 아무런 작업도 안해도됨

	var arr = [
        this.data[0][0],
        data[keyArr[1]],
        data[keyArr[2]],
        data[keyArr[3]],
        data[keyArr[4]],
        this.data[0][5] + (+data[keyArr[5]])
	];
	if(keyArr[6]) arr.push(+data[keyArr[6]]);
    this.data[0] = arr;

    this.EMA1 = this.EMA2 = this.data[0][CandleChart.INDEX_CLOSE];
    this.preUpDown = this.upDownArr[this.curOffset + 1] ? this.upDownArr[this.curOffset + 1][0] : 2;

    this.OPENVAL = this.data[0][1];
    this.HIGHVAL = this.data[0][2];
    this.LOWVAL = this.data[0][3];
    this.CLOSEVAL = this.data[0][4];
    this.QTYVAL = this.data[0][5];

    //02.상승하락 구분 배열 데이터
    this.makeUpDownData();

    //03.단순이동평균 배열 데이터
    this.makeMoveAvgData();

    //04.이격도 데이터
    this.makeDptData();

    //05.MACD 지수이동평균 / OBV 배열 데이터
    this.makeMacdObvData();

    //07.RSI 데이터
    this.makeRSIData();

    //08.Stoch-Fast ~ Stoch-Slow
    this.makeStochasticData();

    this.updateGraph();

    //롱탭중일시에 정보 갱신
    if (this.touchMode == 1) this.drawLongTabLines();
};

//롱탭시 보여질 상세 데이터 표시
CandleChart.prototype.drawLongTabLines = function()
{
	var middleX = this._getMiddleX();
	
    if (this.isShowLeft)
	{
        if (middleX > this.moveX)
		{
            this.infoDiv.style.left = '';
            this.infoDiv.style.right = '10px';
            this.isShowLeft = false;
        }
    }
	else
	{
        if (middleX < this.moveX)
		{
            this.infoDiv.style.right = '';
            this.infoDiv.style.left = '10px';
            this.isShowLeft = true;
        }
    }
    this.drawLongTabData(this.moveX);
};

//차트를 그릴 원시데이터 가공
CandleChart.prototype.makeChartCanvasData = function(dataArr, keyArr) {

    var len = dataArr.length;

    if (len < 1)
        return;
        
    //기존에 데이터가 없었던 경우에만 개수에 맞게 계산한다.
    if((!this.data || !this.data.length) && this.BAR_CNT>len)
    {
    	this.reCalcWidth(len);
    }

    var preDataLen = this.data.length;
    this.data.length += len;

    /*
     var curDataLen = this.data.length;
     //일자 3자리가 셋팅되는 버그가 생김
     //if(curDataLen < this.BAR_CNT) this.BAR_CNT = curDataLen;
     */

    this.curOffset = 0;

    this.upDownArr.length += len;
    this.macdDataArr.length += len;
    this.dptDataArr.length += len;
    this.obvDataArr.length += len;
    this.rsiDataArr.length += len;
    this.rsiUp.length += len;
    this.rsiDw.length += len;
    this.topMaxMinArr.length += len;
    this.btmMaxMinArr.length += len;
    this.stkDataArr.length += len;

    for (var j = 0; j < this.maKeyLen; j++) {
        this.topMaTotalArr[j] = 0;
        this.bottomMaTotalArr[j] = 0;
        this.topMaArr[j].length += len;
        this.bottomMaArr[j].length += len;
    }

    this.rsiTotalUp = 0;
    this.rsiTotalDw = 0;

    this.OPENVAL = 0;
    this.HIGHVAL = 0;
    this.LOWVAL = 0;
    this.CLOSEVAL = 0;
    this.QTYVAL = 0;
    this.DISTVAL = 0;

    this.TOPMAX = 0;
    this.TOPMIN = 999999999999;
    this.BTMMAX = 0;
    this.BTMMIN = 999999999999;
    this.TOPAVG = 0;
    this.BTMAVG = 0;

    this.EMA1;
    this.EMA2;
    this.MACD = 0;
    this.SIGNAL = 0;
    this.RSI = 0;
    this.RSISIGNAL = 0;
    this.DISTJONG = 0;
    this.UPVAL = 0;
    this.DWVAL = 0;
    this.STCMAX = 0;
    this.STCMIN = 999999999999;
    this.STC_K = 0;
    this.STC_FASTD = 0;
    this.STC_SLOWD = 0;
    this.PRECLOSE = null;
    this.PREOBV = 0;

    this.preUpDown = 2;
    var servRow = null;
    var dateVal = '';
    var convRow = [];
    
    var dateKey = keyArr[0],	//일시키
        openKey = keyArr[1],	//시가키
        highKey = keyArr[2],	//고가키
        lowKey = keyArr[3],     //저가키
        closeKey = keyArr[4],	//종가키
        qtyKey = keyArr[5],		//거래량키
        prcKey = keyArr[6];		//거래대금키

    var OPEN = 0,	//시가
        HIGH = 0,	//고가
        LOW = 0,	//저가
        CLOSE = 0,	//종가
        QTY = 0;	//거래량

    this.EMA1 = this.EMA2 = +dataArr[0][closeKey];

    // 들어온 데이터를 뒷부분에 추가하고 각종 정보를 세팅한다.
    for (var i = len - 1; i > -1; i--) {
        // 01.봉차트를 그리기 위한 순수배열 데이터
        //   0       1      2      3       4       5         6
        //['일시', '시가', '고가', '저가', '종가', '거래량', '거래대금' ]

        servRow = dataArr[i];
        convRow = [];
		
		//Number Type으로 변경
		servRow[openKey] = +servRow[openKey];
		servRow[highKey] = +servRow[highKey];
		servRow[lowKey] = +servRow[lowKey];
		servRow[closeKey] = +servRow[closeKey];
		
        dateVal = servRow[dateKey].toString();
        if(dateVal.length == 7) dateVal = '0'+dateVal;
        
        convRow.push(dateVal);
        this.OPENVAL = OPEN = (openKey) ? servRow[openKey] : servRow[closeKey];
        this.HIGHVAL = HIGH = (highKey) ? servRow[highKey] : servRow[closeKey];
        this.LOWVAL = LOW = (lowKey) ? servRow[lowKey] : servRow[closeKey];
        this.CLOSEVAL = CLOSE = servRow[closeKey];
        this.QTYVAL = QTY = (qtyKey) ? +servRow[qtyKey] : 0;
        convRow.push(OPEN);
        convRow.push(HIGH);
        convRow.push(LOW);
        convRow.push(CLOSE);
        convRow.push(QTY);
		if(prcKey) convRow.push(+servRow[prcKey]);

        this.curOffset = preDataLen + i;

        this.data[this.curOffset] = convRow;

        //02.상승하락 구분 배열 데이터
        this.makeUpDownData();

        //03.단순이동평균 배열 데이터
        this.makeMoveAvgData();

        //04.이격도 데이터
        this.makeDptData();

        //05.MACD 지수이동평균 / OBV 배열 데이터
        this.makeMacdObvData();

        //07.RSI 데이터
        this.makeRSIData();

        //08.Stoch-Fast ~ Stoch-Slow
        this.makeStochasticData();

    }

    // 기존 데이터의 각종 정보들을 다시 갱신한다.
    for (var i = this.curOffset - 1; i > -1; i--) {

        servRow = this.data[i];

        this.OPENVAL = servRow[1];
        this.HIGHVAL = servRow[2];
        this.LOWVAL = servRow[3];
        this.CLOSEVAL = servRow[4];
        this.QTYVAL = servRow[5];

        this.curOffset = i;

        //03.단순이동평균 배열 데이터
        this.makeMoveAvgData();

        //04.이격도 데이터
        this.makeDptData();

        //05.MACD 지수이동평균 / OBV 배열 데이터
        this.makeMacdObvData();

        //07.RSI 데이터
        this.makeRSIData();

        //08.Stoch-Fast ~ Stoch-Slow
        this.makeStochasticData();
    }

};

//02.상승하락 구분 배열 데이터
CandleChart.prototype.makeUpDownData = function() {
    //      0                1            2          3
    //['상하색상구분', '보합일경우 높이', '상승한값', '하락한값']
    this.DISTVAL = this.CLOSEVAL - this.OPENVAL;

    if (this.DISTVAL > 0) {
        this.preUpDown = 1;
        this.upDownArr[this.curOffset] = [this.preUpDown, 0, this.DISTVAL, 0];
    } else if (this.DISTVAL < 0) {
        this.preUpDown = 2;
        this.upDownArr[this.curOffset] = [this.preUpDown, 0, 0, this.DISTVAL * -1];
    } else {
        // 종가가 시가와 같은 경우 이전 종가와 비교하여 색상적용
        if(this.data[this.curOffset+1])
        {
            if(this.CLOSEVAL > this.data[this.curOffset+1][CandleChart.INDEX_CLOSE]) this.preUpDown = 1;
            else if(this.CLOSEVAL < this.data[this.curOffset+1][CandleChart.INDEX_CLOSE]) this.preUpDown = 2;
        }

        this.upDownArr[this.curOffset] = [this.preUpDown, 2, 0, 0];
    }
};

//03.단순이동평균 배열 데이터
CandleChart.prototype.makeMoveAvgData = function() {

    this.TOPMAX = this.HIGHVAL;
    this.TOPMIN = this.LOWVAL;
    this.BTMMAX = this.BTMMIN = this.QTYVAL;

    var termCnt, preTermIdx;
    //03.단순이동평균 배열 데이터
    //  0     1     2     3
    //['5', '10', '20', '60']
    for (var j = 0; j < this.maKeyLen; j++) {
        termCnt = this.maKeyArr[j];
        preTermIdx = this.curOffset + termCnt;

        this.topMaTotalArr[j] += this.CLOSEVAL;
        this.bottomMaTotalArr[j] += this.QTYVAL;

        if (this.data[preTermIdx]) {
            this.topMaTotalArr[j] -= this.data[preTermIdx][4];
            this.TOPAVG = this.topMaTotalArr[j] / termCnt;
            this.topMaArr[j][this.curOffset] = [this.COLOR_SET[j], this.TOPAVG];
            this.TOPMAX = Math.max(this.TOPMAX, this.TOPAVG);
            this.TOPMIN = Math.min(this.TOPMIN, this.TOPAVG);

            this.bottomMaTotalArr[j] -= this.data[preTermIdx][5];
            this.BTMAVG = this.bottomMaTotalArr[j] / termCnt;
            this.bottomMaArr[j][this.curOffset] = [this.COLOR_SET[j], this.BTMAVG];
            this.BTMMAX = Math.max(this.BTMMAX, this.BTMAVG);
            this.BTMMIN = Math.min(this.BTMMIN, this.BTMAVG);
        } else {
            this.topMaArr[j][this.curOffset] = ['transparent', this.CLOSEVAL];
            this.bottomMaArr[j][this.curOffset] = ['transparent', this.QTYVAL];
        }
    }
	
	this.topMaxMinArr[this.curOffset] = [this.TOPMAX, this.TOPMIN];
	this.btmMaxMinArr[this.curOffset] = [this.BTMMAX, this.BTMMIN];
};

//04.이격도 데이터 만들기
CandleChart.prototype.makeDptData = function() {

    var termCnt = 10;
    var preTermIdx = this.curOffset + termCnt;

    this.dispTotal += this.CLOSEVAL;

    if (this.data[preTermIdx]) {
        this.dispTotal -= this.data[preTermIdx][4];
        this.dptDataArr[this.curOffset] = [this.SUB_COLOR_SET[5][0], this.CLOSEVAL / (this.dispTotal / termCnt) * 100];
    } else {
        this.dptDataArr[this.curOffset] = ['transparent', this.CLOSEVAL / (this.CLOSEVAL / termCnt) * 100];
    }
};

//05.MACD 지수이동평균 배열 데이터
CandleChart.prototype.makeMacdObvData = function() {
    //05.MACD 지수이동평균 배열 데이터
    //    0        1           2
    //['MACD', 'SIGNAL', 'MACD - SIGNAL']

    this.EMA1 = 2.0 / 13 * (this.CLOSEVAL - this.EMA1) + this.EMA1;
    this.EMA2 = 2.0 / 27 * (this.CLOSEVAL - this.EMA2) + this.EMA2;

    this.MACD = this.EMA1 - this.EMA2;
    this.SIGNAL = 2.0 / 10 * (this.MACD - this.SIGNAL) + this.SIGNAL;

    this.macdDataArr[this.curOffset] = [this.MACD, this.SIGNAL, this.MACD - this.SIGNAL];

    var DISTJONG;
    //06.OBV 데이터
    if (this.PRECLOSE) {
        DISTJONG = this.CLOSEVAL - this.PRECLOSE;
        if (DISTJONG > 0) {
            this.PREOBV += this.QTYVAL;
            this.UPVAL = DISTJONG;
            this.DWVAL = 0;
        } else if (DISTJONG < 0) {
            this.PREOBV -= this.QTYVAL;
            this.UPVAL = 0;
            this.DWVAL = DISTJONG * -1;

        }
        this.rsiUp[this.curOffset] = this.UPVAL;
        this.rsiDw[this.curOffset] = this.DWVAL;
    } else {
        this.rsiUp[this.curOffset] = 0;
        this.rsiDw[this.curOffset] = 0;
    }

    this.rsiTotalUp += this.UPVAL;
    this.rsiTotalDw += this.DWVAL;

    this.PRECLOSE = this.CLOSEVAL;
    this.obvDataArr[this.curOffset] = this.PREOBV;

};

//07.RSI 데이터
CandleChart.prototype.makeRSIData = function() {

    var termCnt = 12;
    var preTermIdx = this.curOffset + termCnt;

    if (this.data[preTermIdx]) {
        this.rsiTotalUp -= this.rsiUp[preTermIdx];
        this.rsiTotalDw -= this.rsiDw[preTermIdx];
    }

    if (this.rsiTotalUp > 0 && this.rsiTotalDw > 0) {
        this.RSI = (this.rsiTotalUp / (this.rsiTotalUp + this.rsiTotalDw)) * 100;
    } else
        this.RSI = 0;

    if (!this.RSISIGNAL)
        this.RSISIGNAL = this.RSI;
    this.RSISIGNAL = 2.0 / 10 * (this.RSI - this.RSISIGNAL) + this.RSISIGNAL;

    this.rsiDataArr[this.curOffset] = [this.RSI, this.RSISIGNAL];

};

//08.Stoch-Fast ~ Stoch-Slow
CandleChart.prototype.makeStochasticData = function() {
    var termCnt = 5;
    var preTermIdx = this.curOffset + termCnt - 1;

    if (this.data[preTermIdx]) {
        this.STCMAX = Math.max(this.data[preTermIdx - 4][2], this.data[preTermIdx - 3][2], this.data[preTermIdx - 2][2], this.data[preTermIdx - 1][2], this.data[preTermIdx][2]);
        this.STCMIN = Math.min(this.data[preTermIdx - 4][3], this.data[preTermIdx - 3][3], this.data[preTermIdx - 2][3], this.data[preTermIdx - 1][3], this.data[preTermIdx][3]);
    } else {
        this.STCMAX = Math.max(this.STCMAX, this.HIGHVAL);
        this.STCMIN = Math.min(this.STCMIN, this.LOWVAL);
    }

    this.STC_K = (this.CLOSEVAL - this.STCMIN) / (this.STCMAX - this.STCMIN) * 100;

    if (!this.STC_FASTD)
        this.STC_FASTD = this.STC_K;
    this.STC_FASTD = 2.0 / 4 * (this.STC_K - this.STC_FASTD) + this.STC_FASTD;

    if (!this.STC_SLOWD)
        this.STC_SLOWD = this.STC_FASTD;
    this.STC_SLOWD = 2.0 / 4 * (this.STC_FASTD - this.STC_SLOWD) + this.STC_SLOWD;

    this.stkDataArr[this.curOffset] = [this.STC_K, this.STC_FASTD, this.STC_SLOWD];
};

CandleChart.prototype.setLongtabLineColor = function(color)
{
    this.longXdiv.style.background = color;
    this.longYdiv.style.background = color;
};

CandleChart.prototype.getLongtabLineColor = function(color)
{
    return this.longXdiv.style.background;
};

// 매핑가능한 개수를 리턴한다.
CandleChart.prototype.getMappingCount = function()
{
	return ['Date', 'Start Price', 'High Price', 'Low Price', 'End Price', 'Trade Qty', 'Trade Price'];
	//return 7;
};

CandleChart.prototype.getQueryData = function(dataArr, keyArr, queryData)
{

};

CandleChart.prototype.setQueryData = function(dataArr, keyArr, queryData)
{
    if (!keyArr)
        return;

    if (dataArr.length == 0) {
        AToast.show('데이터가 존재하지 않습니다.');
        return;
    }

    // 실시간 처리
    if(queryData.isReal)
    {
        let updateRefVal;

        //0:월, 1:주, 2:일, 5:분, 7틱

        // 틱인 경우 개수를 체크하여 그 이후에 추가를 한다.
        // 틱과 분인 경우에는 고가, 저가를 실시간으로 들어온 데이터로 처리하지 않고 종가를 가지고 비교하여 처리한다.
        if(this.intervals == CandleChart.INTERVALS_TICK)
        {
            updateRefVal = this.tickCount || this.updateRefVal;

            ++this.currentTickCount;
            if(this.currentTickCount == 1)
            {
                dataArr[0][keyArr[1]] = dataArr[0][keyArr[4]];                
                dataArr[0][keyArr[2]] = dataArr[0][keyArr[4]];
                dataArr[0][keyArr[3]] = dataArr[0][keyArr[4]];
                // 새로운 데이터를 추가한다. 시고저종의 값은 모두 종가로 세팅한다.
                this.addRealData(dataArr[0], keyArr); // 틱데이터 추가 종:현재가
                
                if(this.currentTickCount >= updateRefVal) this.currentTickCount = 0;
            }
            else
            {
                // 0번째 위치의 데이터를 갱신한다. 고저의 값은 종가와 비교하여 세팅한다.
                this.updateRealData(dataArr[0], keyArr); // 틱데이터 갱신 종:현재가

                if(this.currentTickCount >= updateRefVal) this.currentTickCount = 0;
            }
        }
        else if(this.intervals == CandleChart.INTERVALS_MINUTE)
        {
            updateRefVal = this.updateTime || this.updateRefVal;

			// 차트데이터가 없을때 리얼이 들어오는 경우 이전 시간이 없으므로 0으로 기본값 세팅
            var prevTime = this.data[0]?String(this.data[0][0]):'000000';
            var time = String(dataArr[0][keyArr[0]]);
            time = time.substring(0,2)*3600 + time.substring(2,4)*60 + time.substring(4,6)*1;
            prevTime = prevTime.substring(0,2)*3600 + prevTime.substring(2,4)*60 + prevTime.substring(4,6)*1;

            // 09시 이전에 데이터를 조회하면 이전데이터가 09:01분으로 세팅되어있음
            // 09시 이전인 경우 실시간을 수신하면 09:01분봉에 시가도 세팅하여 보여줘야 하는지 확인 필요
            //if(prevTime >= 16*3600) prevTime = 8*3600; // 8시로 수정

            //          ~ 09:00:00 를 09:00 분봉으로 친다.
            // 09:00:01 ~ 09:01:00 를 09:01 분봉으로 친다.
            // 09:01:01 ~ 09:02:00 를 09:02 분봉으로 친다.
            if(prevTime >= time) //142200 >= 142159
            {
                // 0번째 위치의 데이터를 갱신한다.
                // 고저의 값은 updateRealData 내부에서 종가와 비교하여 세팅한다.
                this.updateRealData(dataArr[0], keyArr);
            }
            else
            {
                // 142200 142200 - (14-14)*3600 + (22-22)*60 + (00-00) -> 0
                // 142200 142359 - (14-14)*3600 + (23-22)*60 + (59-00) -> 119
                // 142200 142500 - (14-14)*3600 + (25-22)*60 + (00-00) -> 180
                // 현재는 빈봉을 추가하지는 않고 넘어온 데이터만 분봉으로 그린다.
                time = parseInt((time - prevTime)/updateRefVal);
                prevTime += (time + 1) * updateRefVal;
                var h, m, s;
                h = parseInt(prevTime/3600);
                prevTime = prevTime%3600;
                m = parseInt(prevTime/60);
                prevTime = prevTime%60;
                s = prevTime;
                dataArr[0][keyArr[0]] = [h<10?'0'+h:h, m<10?'0'+m:m, s<10?'0'+s:s].join('');
                dataArr[0][keyArr[1]] = dataArr[0][keyArr[2]] = dataArr[0][keyArr[3]] = dataArr[0][keyArr[4]];
                // 새로운 데이터를 추가한다. 시고저종의 값은 모두 종가로 세팅한다.
                this.addRealData(dataArr[0], keyArr);
            }
        }
        else
        {
            // 월, 주, 일인 경우 0번째 데이터만 가공한다.
            // 고저의 값은 updateRealData 내부에서 종가와 비교하여 세팅한다.
            this.updateRealData(dataArr[0], keyArr);
        }
    }
    // 일반 조회 처리
    else
    {
        this.makeChartCanvasData(dataArr, keyArr);
        this.updateGraph();
    }
};

//window.CandleChart = CandleChart;


})();