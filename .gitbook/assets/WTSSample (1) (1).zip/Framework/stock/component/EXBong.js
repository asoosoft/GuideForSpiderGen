              
class EXBong extends AComponent
{
	constructor()
    {
        super();

        this.frwName = 'stock';
        
        this.lineEl = null;
        this.bongEl = null;
        this.upColor = '#da2c03';
        this.downColor = '#75b02c';
        this.steadColor = '#dee0e9';
        this.isUp = false;
        this.isPort = true;
        this.defColor = 'transparent';
        
        this.si = null;
        this.go = null;
        this.je = null;
        this.jo = null;
        this.prdyvrss = null;
    }
}

window.EXBong = EXBong;

EXBong.CONTEXT = 
{
    tag: '<div data-base="EXBong" data-class="EXBong" class="EXBong-Style" color-bong-up="'+StockColor.UP_COLOR+'" color-bong-down="'+StockColor.DOWN_COLOR+'" direction-bong="port">'+
                '<span style="right:50%; width:1px; height:100%;"></span>'+
                '<span style="top:25%; width:100%; height:50%;"></span></div>',
    defStyle: 
    {
        width:'10px', height:'60px'
    },

    events: []
};


EXBong.prototype.init = function(context, evtListener)
{
	AComponent.prototype.init.call(this, context, evtListener);
	
	this.lineEl = this.element.children[0];
	this.bongEl = this.element.children[1];
	
	this.lineEl.style.backgroundColor = this.defColor;
	this.bongEl.style.backgroundColor = this.defColor;
	
	var jObj = this.$ele;
	var upCol = jObj.attr('color-bong-up');  
	var downCol = jObj.attr('color-bong-down');  
	var direction = jObj.attr('direction-bong');
	
	if(direction == 'port') this.isPort = true;
	else this.isPort = false;
	
	if(upCol) this.setUpColor(upCol);
	else this.setUpColor(StockColor.UP_COLOR);
	
	if(downCol) this.setDownColor(downCol);
	else this.setDownColor(StockColor.DOWN_COLOR);
	
	/*
	this.setUpColor(StockColor.UP_COLOR);
	this.setDownColor(StockColor.DOWN_COLOR);
	*/
	this.setSteadyColor(StockColor.STEADY_COLOR);
	
	this.initPos();

	// 개발시점에 봉을 표현하기 위해 수정
	if(this.isDev()) this.setData([25, 100, 0, 75]);
};

EXBong.prototype.initPos = function()
{
	if(this.isPort)
	{
		$(this.lineEl).css({
			'right': '50%',
			'top': '0px',
			'width': '1px',
			'height': '100%'
		});
		
		$(this.bongEl).css({
			'right': '0px',
			'top': '25%',
			'width': '100%',
			'height': '50%'
		});
	}
	else
	{
		
		$(this.lineEl).css({
			'right': '0px',
			'top': '50%',
			'width': '100%',
			'height': '1px'
		});
		
		$(this.bongEl).css({
			'right': '25%',
			'top': '0px',
			'width': '50%',
			'height': '100%'
		});
	}
};



EXBong.prototype.setUpColor = function(color)
{
	this.upColor = color;
};

EXBong.prototype.setDirection = function(isPort)
{
	this.isPort = isPort;
};

EXBong.prototype.setDownColor = function(color)
{
	this.downColor = color;
};

EXBong.prototype.setSteadyColor = function(color)
{
	this.steadColor = color;
};

EXBong.prototype.setColor = function(color)
{
	this.lineEl.style.backgroundColor = color;
	this.bongEl.style.backgroundColor = color;
};

EXBong.prototype.resetData = function()
{
	this.lineEl.style.backgroundColor = 'transparent';
	this.bongEl.style.backgroundColor = 'transparent';
	
	if(this.isPort)
	{
		this.lineEl.style.height = '0px';
		this.bongEl.style.top = '50%';
		this.bongEl.style.height = '1px';
	}
	else
	{
		this.lineEl.style.width = '0px';
		this.bongEl.style.right = '50%';
		this.bongEl.style.width = '1px';
	}
};

// valueArr = [시, 고, 저, 종, 최대값, 최소값]
// prdyvrss 대비
EXBong.prototype.setData = function(valueArr, prdyvrss)
{
	if(valueArr[0] != undefined) this.si = afc.removeComma(valueArr[0]);
	if(valueArr[1] != undefined) this.go = afc.removeComma(valueArr[1]);
	if(valueArr[2] != undefined) this.je = afc.removeComma(valueArr[2]);
	if(valueArr[3] != undefined) this.jo = afc.removeComma(valueArr[3]);
	if(prdyvrss != undefined) this.prdyvrss = prdyvrss;
	
    var maxV = 0; 
    var minV = 0;
	
	var maxRate = 0;
    if(valueArr.length == 4 )
    {
        maxV = this.go;
        minV = this.je;
    }
    else
    {
        maxV = valueArr[4];
        minV = valueArr[5];
    }
    
    maxRate = maxV - minV;
	var disAm = this.si - this.jo;
	var color, topVal;
	var barH =  Math.abs(disAm);
	var lineH =  Math.abs(this.go-this.je);
	
	if(this.si == 0 || this.go == 0 || lineH == 0)
	{
		if(this.prdyvrss) color = stk.getStockColor(this.prdyvrss);
		else color = this.upColor;	//this.steadColor;
		
		topVal = this.go?this.go:this.je;
		
		// maxRate 의 값이 0 인 경우에는 계산이 되지 않음
		var tmp = (maxV-topVal)/maxRate*100;
		if(isNaN(tmp)) tmp = 50;
		if(this.isPort)
		{
			this.lineEl.style.top = tmp+'%';
			this.lineEl.style.height = '0px';
			this.bongEl.style.top = tmp+'%'; //this.bongEl.style.top = '50%';
			this.bongEl.style.height = '1px';
		}
		else
		{
			this.lineEl.style.right = tmp+'%';
			this.lineEl.style.width = '0px';
			this.bongEl.style.right = tmp+'%'; //this.bongEl.style.right = '50%';
			this.bongEl.style.width = '1px';
		}
	}
	else
	{
		if(disAm > 0)
		{
			color = this.downColor;
			topVal = this.si;
			this.isUp = false;
		}
		else if(disAm < 0)
		{
			color = this.upColor;
			topVal = this.jo;
			this.isUp = true;
		}	
		else
		{
			topVal = this.jo;
			if(this.prdyvrss) color = stk.getStockColor(this.prdyvrss);
			else color = this.upColor;	//this.downColor;
		}
		
		var barHeight = barH/maxRate*100;
		if(barHeight == 0) barHeight = '1px';
		else barHeight+='%';
		
		if(this.isPort)
		{
			this.lineEl.style.top = (maxV-this.go)/maxRate*100+'%';
			this.lineEl.style.height = 'calc(' + lineH/maxRate*100+ '% - 1px)';
			
			if((maxV-topVal)/maxRate*100) this.bongEl.style.top = 'calc(' + (maxV-topVal)/maxRate*100 + '% - 1px)';
			else this.bongEl.style.top = (maxV-topVal)/maxRate*100 + '%';
			this.bongEl.style.height = barHeight;
		}
		else
		{
			this.lineEl.style.right = (maxV-this.go)/maxRate*100+'%';
			this.lineEl.style.width = 'calc(' + lineH/maxRate*100+ '% - 1px)';
			
			if((maxV-topVal)/maxRate*100) this.bongEl.style.right = 'calc(' + (maxV-topVal)/maxRate*100 + '% - 1px)';
			else this.bongEl.style.right = (maxV-topVal)/maxRate*100 + '%';
			
			this.bongEl.style.width = barHeight;
		}
	}
	
	this.lineEl.style.backgroundColor = color;
	this.bongEl.style.backgroundColor = color;
};

EXBong.prototype.setQueryData = function(dataArr, keyArr, queryData)
{
	if(!keyArr) return;
	var data = dataArr[0];
	var colorVrss = null;
	if(keyArr[4]) colorVrss = data[keyArr[4]];
	this.setData([ data[keyArr[0]], data[keyArr[1]], data[keyArr[2]], data[keyArr[3]] ], colorVrss );
};

EXBong.prototype.getQueryData = function(dataArr, keyArr)
{
	if(!keyArr) return;
	
};

EXBong.prototype.getMappingCount = function()
{
	return ['Open', 'High', 'Low', 'Close', 'Color'];
};
                    
