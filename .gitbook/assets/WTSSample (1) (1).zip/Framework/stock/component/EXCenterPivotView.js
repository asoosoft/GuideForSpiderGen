
//afc.import("Framework/afc/component/AGrid.js");

/**
 * @author asoocool
 */
class EXCenterPivotView extends AView
{
	constructor()
    {
        super();

        this.frwName = 'stock';
        
        this.leftGrid = null;
        this.pivotGrid = null;
        this.rightGrid = null; 
    }
}

window.EXCenterPivotView = EXCenterPivotView;

EXCenterPivotView.CONTEXT = 
{
    tag: '<div data-base="EXCenterPivotView" data-class="EXCenterPivotView" class="AView-Style">\
	         <div data-base="AView" data-class="AView" class="AView-Style" style="right:60%; top:0px; width:40%; height:100%;">\
	    		<div data-base="AGrid" data-class="AGrid" data-fullrow-select="true" data-selectable="true" data-clear-rowtmpl="true" class="AGrid-Style"\
					style="width:225%; height:100%">\
					<table class="grid-header-table" align="center" style="width:100%; border-collapse:collapse; table-layout: fixed;">\
						<colgroup><col><col><col></colgroup>\
						<thead align="center" class="head-prop">\
							<tr height="22px"><td>col1</td><td>col2</td><td>col3</td></tr>\
						</thead>\
					</table>\
					<div style="height:100%; overflow-y:auto; overflow-x:hidden; -webkit-overflow-scrolling:touch;">\
						<table class="grid-body-table" align="center" style="width:100%; border-collapse:collapse; table-layout: fixed;">\
							<colgroup><col><col><col></colgroup>\
							<thead align="center" class="head-prop">\
								<tr height="22px"><td>col1</td><td>col2</td><td>col3</td></tr>\
							</thead>\
							<tbody align="center" class="body-prop">\
								<tr height="22px"><td>data 1,1</td><td>data 1,2</td><td>data 1,3</td></tr>\
							</tbody>\
						</table>\
					</div>\
				</div>\
	         </div>\
    		<div data-base="AGrid" data-class="AGrid" data-fullrow-select="true" data-selectable="true" data-clear-rowtmpl="true" class="AGrid-Style"\
				style="left:40%; width:20%; height:100%">\
				<table class="grid-header-table" align="center" style="width:100%; border-collapse:collapse; table-layout: fixed;">\
					<colgroup><col></colgroup>\
					<thead align="center" class="head-prop">\
						<tr height="22px"><td>col1</td></tr>\
					</thead>\
				</table>\
				<div style="height:100%; overflow-y:auto; overflow-x:hidden; -webkit-overflow-scrolling:touch;">\
					<table class="grid-body-table" align="center" style="width:100%; border-collapse:collapse; table-layout: fixed;">\
						<colgroup><col></colgroup>\
						<thead align="center" class="head-prop">\
							<tr height="22px"><td>col1</td></tr>\
						</thead>\
						<tbody align="center" class="body-prop">\
							<tr height="22px"><td>data 1,1</td></tr>\
						</tbody>\
					</table>\
				</div>\
			</div>\
	        <div data-base="AView" data-class="AView" class="AView-Style" style="left:60%; top:0px; width:40%; height:100%;">\
	    		<div data-base="AGrid" data-class="AGrid" data-fullrow-select="true" data-selectable="true" data-clear-rowtmpl="true" class="AGrid-Style"\
					style="width:225%; height:100%">\
					<table class="grid-header-table" align="center" style="width:100%; border-collapse:collapse; table-layout: fixed;">\
						<colgroup><col><col><col></colgroup>\
						<thead align="center" class="head-prop">\
							<tr height="22px"><td>col1</td><td>col2</td><td>col3</td></tr>\
						</thead>\
					</table>\
					<div style="height:100%; overflow-y:auto; overflow-x:hidden; -webkit-overflow-scrolling:touch;">\
						<table class="grid-body-table" align="center" style="width:100%; border-collapse:collapse; table-layout: fixed;">\
							<colgroup><col><col><col></colgroup>\
							<thead align="center" class="head-prop">\
								<tr height="22px"><td>col1</td><td>col2</td><td>col3</td></tr>\
							</thead>\
							<tbody align="center" class="body-prop">\
								<tr height="22px"><td>data 1,1</td><td>data 1,2</td><td>data 1,3</td></tr>\
							</tbody>\
						</table>\
					</div>\
				</div>\
	         </div>\
         </div>',

    defStyle: 
    {
        width:'400px', height:'300px'
    },

    //events: ['swipe', 'longtab', 'scroll', 'scrollleft', 'scrollright', 'scrolltop', 'scrollbottom', 'drop', 'dragStart', 'dragEnd' ]
    events: [ 'swipe', 'longtab', 'scroll', 'scrollleft', 'scrollright', 'scrolltop', 'scrollbottom' ]
};

EXCenterPivotView.prototype.init = function(context, evtListener)
{
    AView.prototype.init.call(this, context, evtListener);
    
    var thisObj = this, children = this.getChildren();
    
    this.leftView = children[0];
    this.rightView = children[2];
    
    this.leftGrid = this.leftView.getChildren()[0];
    this.pivotGrid = children[1];
    this.rightGrid = this.rightView.getChildren()[0];
    
    this.leftGrid.isStoppagation = false;
    this.rightGrid.isStoppagation = false;
    
    this.pivotGrid.element.style.zIndex = 2;
    
    this.leftGrid.enableScrlManager(this.pivotGrid.scrollArea[0], this.rightGrid.scrollArea[0]);
    this.pivotGrid.enableScrlManager(this.leftGrid.scrollArea[0], this.rightGrid.scrollArea[0]);
    this.rightGrid.enableScrlManager(this.leftGrid.scrollArea[0], this.pivotGrid.scrollArea[0]);
    
    this.scrollSyncSet( this.leftGrid, this.leftView );
    this.scrollSyncSet( this.rightGrid, this.rightView );
	/*
	this.leftGrid.isCheckScrl = false;
	this.pivotGrid.isCheckScrl = false;
	this.rightGrid.isCheckScrl = false;
	this.leftGrid.scrollArea.css('overflow', 'hidden');
	this.pivotGrid.scrollArea.css('overflow', 'hidden');
	this.rightGrid.scrollArea.css('overflow', 'hidden');
	this.leftView.setStyle('overflow', 'hidden');
	this.rightView.setStyle('overflow', 'hidden');
	*/
    
	//두 개의 그리드의 selectCell 함수 변경
	if(this.leftGrid.option.isFullRowSelect || this.pivotGrid.option.isFullRowSelect || this.rightGrid.option.isFullRowSelect)
	{
		this.leftGrid.option.isFullRowSelect = true;
		this.pivotGrid.option.isFullRowSelect = true;
		this.rightGrid.option.isFullRowSelect = true;
	}
	
	this.setAllGridSelect();
	
	//4.0 이하 피봇 그리드 구현
	if(afc.andVer<4.1)
	{
		//scrollArea 를 감싸고 있는 div 에 overflow auto(scrollTop disable) 를 셋팅하면
		//상위의 view 가 좌우 스크롤이 발생된다.
		this.leftGrid.$ele.css('overflow', 'auto');
		this.rightGrid.$ele.css('overflow', 'auto');
	}
  
  	var thisObj = this;
	if(!this.isDev()) setTimeout(function(){ thisObj.scrollViewLeft(); });
};

//스크롤 싱크 셋팅
EXCenterPivotView.prototype.scrollSyncSet = function(scrollGrid, scrollView)
{
    scrollView.enableScrlManagerX();
    
    scrollView.scrlManagerX.addDisableManager(scrollGrid.scrlManager);
    scrollGrid.scrlManager.addDisableManager(scrollView.scrlManagerX);
};

EXCenterPivotView.prototype.scrollViewLeft = function()
{
	this.leftView.element.scrollLeft = this.leftGrid.getWidth();
};

//하나의 row 를 추가한다.
EXCenterPivotView.prototype.addRow = function(leftData, pivotData, rightData)
{
	var ret = new Array(3);
	/*
    ret[0] = this.addHelper(this.leftGrid, leftData);
    ret[1] = this.pivotGrid.addRow(pivotData);
    ret[2] = this.addHelper(this.rightGrid, rightData);
    */
    ret[0] = this.leftGrid.addRow(leftData);
    ret[1] = this.pivotGrid.addRow(pivotData);
    ret[2] = this.rightGrid.addRow(rightData);
    return ret;
};

EXCenterPivotView.prototype.prependRow = function(leftData, pivotData, rightData)
{
	var ret = new Array(3);
	/*
    ret[0] = this.addHelper(this.leftGrid, leftData, true);
    ret[1] = this.pivotGrid.prependRow(pivotData);
    ret[2] = this.addHelper(this.rightGrid, rightData, true);
    */
    ret[0] = this.leftGrid.prependRow(leftData);
    ret[1] = this.pivotGrid.prependRow(pivotData);
    ret[2] = this.rightGrid.prependRow(rightData);
    return ret;
};

EXCenterPivotView.prototype.addHelper = function(grid, data, isPrepend)
{
	var addData = ['○','○','○','○','○','○','○','○','○','○','○'], i;
	
	for(i=0; i<addData.length; i++)
	{
		if(data[i]=='') addData[i] = '';
	}
	
    //var row = grid.addRow(addData);
    var row;
    if(isPrepend) row = grid.prependRow(addData);
    else row = grid.addRow(addData);
    
	for(i=0; i<addData.length; i++)
	{
		//월물의 해당하는 행사가에 대한 데이터가 없는 경우 X css를 넣어준다.
		if(addData[i] == '') $(grid.getCell(row, i)).addClass('BT103_K00072');
		grid.setCellData(row, i, data[i]);
	}
		
	return row;
};

EXCenterPivotView.prototype.removeRow = function(rowIdx)
{
    this.leftGrid.removeRow(rowIdx);
    this.pivotGrid.removeRow(rowIdx);
    this.rightGrid.removeRow(rowIdx);
};

EXCenterPivotView.prototype.removeAll = function()
{   
    this.leftGrid.removeAll();
    this.pivotGrid.removeAll();
    this.rightGrid.removeAll();
};

EXCenterPivotView.prototype.setAllGridSelect = function()
{
	var thisPivot = this;
	this.leftGrid.selectCell = this.pivotGrid.selectCell = this.rightGrid.selectCell = function(cell)
	{
		if(!this.option.isSelectable) return;
		
		thisPivot.leftGrid.clearSelected();
		thisPivot.pivotGrid.clearSelected();
		thisPivot.rightGrid.clearSelected();
		
		//새롭게 선택된 셀을 추가하고 배경 색을 바꾼다.
		this.selectedCells.push(cell);
		
		if(this.option.isFullRowSelect)
		{
			var leftRow = $(thisPivot.leftGrid.getRow(cell[0].rowIndex-1));
			var pivotRow = $(thisPivot.pivotGrid.getRow(cell[0].rowIndex-1));
			var rightRow = $(thisPivot.rightGrid.getRow(cell[0].rowIndex-1));
			
			thisPivot.leftGrid.selectedCells.push(leftRow);
			thisPivot.pivotGrid.selectedCells.push(pivotRow);
			thisPivot.rightGrid.selectedCells.push(rightRow);
			
			leftRow.children().each(function()
			{
				$(this).addClass(thisPivot.leftGrid.selectStyleName);
			});
			
			pivotRow.children().each(function()
			{
				$(this).addClass(thisPivot.pivotGrid.selectStyleName);
			});
			
			rightRow.children().each(function()
			{
				$(this).addClass(thisPivot.rightGrid.selectStyleName);
			});
		}
		else $(cell).addClass(this.selectStyleName);
	};
	
};


//-----------------------------------------------------
//	about scroll
EXCenterPivotView.prototype.scrollTo = function(pos)
{
    this.leftGrid.scrollTo(pos);
    this.pivotGrid.scrollTo(pos);
    this.rightGrid.scrollTo(pos);
};

EXCenterPivotView.prototype.scrollOffset = function(offset)
{
    this.leftGrid.scrollOffset(offset);
    this.pivotGrid.scrollOffset(offset);
    this.rightGrid.scrollOffset(offset);
};

//row or rowIndex
EXCenterPivotView.prototype.scrollIntoArea = function(row, isAlignTop)
{
    this.leftGrid.scrollIntoArea(row, isAlignTop);
    this.pivotGrid.scrollIntoArea(row, isAlignTop);
    this.rightGrid.scrollIntoArea(row, isAlignTop);
};

EXCenterPivotView.prototype.scrollToTop = function()
{
    this.leftGrid.scrollToTop();
    this.pivotGrid.scrollToTop();
    this.rightGrid.scrollToTop();
};

EXCenterPivotView.prototype.scrollToBottom = function()
{
    this.leftGrid.scrollToBottom();
    this.pivotGrid.scrollToBottom();
    this.rightGrid.scrollToBottom();
};

EXCenterPivotView.prototype.scrollToCenter = function()
{
    this.leftGrid.scrollToCenter();
    this.pivotGrid.scrollToCenter();
    this.rightGrid.scrollToCenter();
};
//------------------------------------------------

EXCenterPivotView.prototype.setData = function(dataArr){};
EXCenterPivotView.prototype.setQueryData = function(dataArr, keyArr, queryData)
{
    
    
};

EXCenterPivotView.prototype.getQueryData = function(dataArr, keyArr, queryData)
{
    
    
};
                    
                    
