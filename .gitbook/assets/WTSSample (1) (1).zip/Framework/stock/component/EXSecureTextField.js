
(async function(){

await afc.import("Framework/afc/component/ATextField.js");



EXSecureTextField = class EXSecureTextField extends ATextField
{
	constructor()
    {
		super();
		
		this.frwName = 'stock';
		
		this.useSecure = false;
		this.cipherData = null;
		this.pwLength = 0;
		this.padOption =
		{
			title: '비밀번호 입력',
			padType: 'char', 
			returnType: "1",
			maxLength: 20,
			minLength: 4
		};
		
		this.isTabable = true;
	}	
}

//window.EXSecureTextField = EXSecureTextField;

EXSecureTextField.CONTEXT =
{
    tag: '<input data-base="EXSecureTextField" data-class="EXSecureTextField" type="password" value="Text" class="ATextField-Style"/>',
        
    defStyle: 
    {
        width:'100px', height:'25px'  
    },

    events: ['change','focus','blur']
};

EXSecureTextField.prototype.init = function(context, evtListener)
{
	//context.preventEvent = true;
	
    ATextField.prototype.init.call(this, context, evtListener);
    
	if(this.$ele.attr('padtitle')) this.padOption.title = this.$ele.attr('padtitle');
	if(this.$ele.attr('padType')) this.padOption.padType = this.$ele.attr('padType');
	if(this.$ele.attr('returnType')) this.padOption.returnType = this.$ele.attr('returnType');
	if(this.$ele.attr('padmax')) this.padOption.maxLength = this.$ele.attr('padmax');
	if(this.$ele.attr('padmin')) this.padOption.minLength = this.$ele.attr('padmin');
};

EXSecureTextField.prototype.setCipherData = function(cipherData)
{
	this.cipherData = cipherData;
};

EXSecureTextField.prototype.getCipherData = function()
{
	if(this.cipherData) return this.cipherData;
	else return this.getText();
};

EXSecureTextField.prototype.setPwLength = function(len)
{
	this.pwLength = len;
};

EXSecureTextField.prototype.getPwLength = function()
{
	return this.pwLength;
};

//deprecated
EXSecureTextField.prototype.clear = function()
{
	this.reset();
};

EXSecureTextField.prototype.reset = function()
{
	this.setText('');
	this.cipherData = null;
	this.pwLength = 0;
};

EXSecureTextField.prototype.openPad = function()
{
	if(window.SecurePadManager && SecurePadManager.isEnable)
	{
		var thisObj = this;
		SecurePadManager.openPad(this.padOption, function(isBlur, data, len){
			if(isBlur) thisObj.reportEvent('blur');
			thisObj.cipherData = data;
			thisObj.pwLength = len;
			thisObj.setText(afc.makeDummyString(len));
			//if(len > 0) thisObj.reportEvent('change');
			//### len이 0인 경우도 전달해준다. 변경값을 받아서 다른 처리를 하는 경우가 있음.
			thisObj.reportEvent('change', data);

		}, this); //웹키패드에서는 컴포넌트(엘리먼트)가 필요한 경우가 있어 추가
	}
};

EXSecureTextField.prototype.openWebPad = function()
{
	this.reset();
	this.enable(false);
	var thisObj = this;
	SecureWebPadManager.openPad(this.padOption, function(res, data, len){
		thisObj.enable(true);
		if(!res) return;
		thisObj.cipherData = data;
		thisObj.pwLength = len;
		thisObj.setText(afc.makeDummyString(len));
	});
};

EXSecureTextField.prototype.getQueryData = function(dataArr, keyArr, queryData)
{
	if(!keyArr) return;
	if(!dataArr || dataArr.length==0) return;
	
	//생성되어져 있는 객체에 셋팅하는 구조
	var data = dataArr[0];
	data[keyArr[0]] = this.getCipherData();
};
                    

                    
})();