
/**
 * @author
 */
/*
data :
1. item - data[type][code]
{ 
	'001':
	{
		'005930':{code: '005930', name:'삼성전자', market: '001'},
		'005930':{code: '005930', name:'삼성전자', market: '001'},
		...
	},
	'002':
	{
		...
	}
}

2. item - data[type][0], data[type][1]
{ 
	'001':
	[
		{code: '005930', name:'삼성전자', market: '001'},
		{code: '005930', name:'삼성전자', market: '001'},
		...
	],
	'002':
	[
		...
	]
}

3. item - data[0][0], data[1][1]
[
	[
		{code: '', name: '', type: '' },
		{code: '', name: '', type: '' },
		...
	],
	[
		{code: '', name: '', type: '' },
		{code: '', name: '', type: '' },
		...
	]
]
*/

class EXSearchView extends AView
{
    constructor(){

		super();

		this.frwName = 'stock';
		this.searchKeyArr = ['name'];
		this.depth = 1;

	}

	
}

EXSearchView.prototype.init = function(context, evtListener)
{
    AView.prototype.init.call(this, context, evtListener);
	
	var keys = this.getAttr('data-search-keys');
	if(keys)
	{
		keys = keys.split(',');
		keys.forEach(function(t, i, a){ a[i] = t.trim(); });
		this.setSearchKeyArr(keys);
	}
};

EXSearchView.CONTEXT = 
{
    tag:'<div data-base="EXSearchView" data-class="EXSearchView" class="AView-Style">\
			<div data-base="AView" data-class="AView" class="AView-Style" style="width: calc((100% - 10px) - 10px); height: 60px; left: 10px; top: 10px;" data-sgap-width="1" data-stretch-width="true">\
				<input data-base="ATextField" data-class="ATextField" type="text" class="ATextField-Style" autocomplete="off" style="width: calc((100% - 0px) - 70px); height: 100%; left: 0px; top: 0px;" data-sgap-width="1" data-stretch-width="true">\
				<button data-base="AButton" data-class="AButton" class="AButton-Style" style="width: 60px; height: 100%; top: 0px; right: 0px; border-width: 1px;"></button>\
			</div>\
			<div data-base="AGrid" data-class="AGrid" data-selectable="true" data-clear-rowtmpl="true" class="AGrid-Style" style="width: calc((100% - 10px) - 10px); height: calc((100% - 75px) - 10px); left: 10px; top: 75px;" data-sgap-width="1" data-stretch-width="true" data-sgap-height="1" data-stretch-height="true" data-hide-header="true" data-fullrow-select="true">\
				<table class="grid-header-table" align="center" style="width: calc(100% - 0px); border-collapse: collapse; table-layout: fixed;">\
					<colgroup><col></colgroup>\
					<thead align="center" class="head-prop" style="display: none;">\
						<tr height="22"><td>col1</td></tr>\
					</thead>\
				</table>\
			<div style="height: 100%; overflow-y: auto; overflow-x: hidden;">\
				<table class="grid-body-table" align="center" style="width:100%; border-collapse:collapse; table-layout: fixed;">\
					<colgroup><col></colgroup>\
					<thead align="center" class="head-prop" style="display: none;">\
						<tr height="22"><td>col1</td></tr>\
					</thead>\
						<tbody align="center" class="body-prop">\
							<tr height="60"><td class="" style="text-align: left; padding: 0px 0px 0px 10px;">data 1,1</td></tr>\
						</tbody>\
					</table>\
				</div>\
			</div>\
		</div>',

    defStyle: 
    {
        width:'400px', height:'400px'
    },

    //events: ['swipe', 'longtab', 'scroll', 'scrollleft', 'scrollright', 'scrolltop', 'scrollbottom', 'drop', 'dragStart', 'dragEnd' ]
    events: [ 'change', 'select' ]
};

// 검색할 모든 데이터를 지정한다. 
EXSearchView.prototype.setData = function(data)
{
	this.data = data;
	
	// 데이터를 판단하여 depth를 구한다.
	this.depth = this._checkDepth(data);
};

// 지정한 데이터를 반환한다.
EXSearchView.prototype.getData = function()
{
	return this.data;
};

EXSearchView.prototype._checkDepth = function(data)
{
	for(var key in data)
	{
		if(typeof(data[key]) != 'object') return 0;
		else return 1+this._checkDepth(data[key]);
	}
	return 0;
};

// 데이터에서 검색할 키 목록을 저장한다.
EXSearchView.prototype.setSearchKeyArr = function(arr)
{
	this.searchKeyArr = arr;
};

// 데이터에서 검색할 키 목록을 반환한다.
EXSearchView.prototype.getSearchKeyArr = function()
{
	return this.searchKeyArr;
};
/*
// 데이터 구조에 맞는 depth 를 지정한다. 검색할 때 사용된다.
EXSearchView.prototype.setDepth = function(depth)
{
	this.depth = depth;
};

// 데이터의 depth 를 반환한다. 검색할 때 사용된다.
EXSearchView.prototype.getDepth = function()
{
	return this.depth;
};*/

// 모든 데이터에서 검색내용이 들어있는 데이터를 찾아 배열로 리턴한다.
EXSearchView.prototype.searchData = function(srchTxt, type, except)
{
	var cmprTxt, obj = this.data, item, result = [];
	
	if(srchTxt) srchTxt = srchTxt.toLowerCase();
	
	if(typeof(type) == 'string') type = [type];
	if(typeof(except) == 'string') except = [except];
	
	this._searchData(result, this.depth, obj, srchTxt, type, except);
	/*
	// key는 마켓 또는 분류값
	for(var key in obj)
	{
		// type 값이 있고 key와 다르면 continue
		if(type != undefined)
		{
			if(type.indexOf(key) < 0) continue;
		}
	
		// code 는 코드
		for(var code in obj[key])
		{
			item = obj[key][code];
			if(typeof item == 'string') continue;
			
			// except외 종목들은 보여지지 않게 처리함
			if(except && !code.match(except)) continue;
			
			if(!srchTxt) result.push(item);
			else
			{
				for(var i=0; i<this.searchKeyArr.length; i++)
				{
					cmprTxt = item[this.searchKeyArr[i]];

					//종목명 비교
					if(cmprTxt && Search.compareText(srchTxt, cmprTxt.toLowerCase()))
					{
						//arr = [code, cmprTxt];
						//차후 특정 조건으로 정렬해야 할 경우 값을 셋팅한다.
						//arr.sortKey = item[''];

						result.push(item);
						break;
					}
				}
			}
		}
	}*/
	
	return result;
};
// 모든 데이터에서 검색내용이 들어있는 데이터를 찾아 배열로 리턴한다.
EXSearchView.prototype._searchData = function(resultArr, depth, data, srchTxt, typeArr, except)
{
	var item, cmprTxt, isExcept;
	for(var key in data)
	{
		// 데이터 전체의 뎁스와 현재 뎁스 즉 data가 최상의 데이터인 경우 타입을 비교한다.
		if(this.depth == depth)
		{
			// type 값이 있고 key와 다르면 continue
			if(typeArr != undefined)
			{
				if(typeArr.indexOf(key) < 0) continue;
			}
		}
	
		if(depth <= 1)
		{
			item = data[key];
			if(typeof item == 'string') continue;
			
			// except 종목들은 보여지지 않게 처리함
			if(except != undefined)
			{
				isExcept = false;
				for(var i=0; i<except.length; i++)
				{
					if(key.match(except[i]))
					{
						isExcept = true;
						break;
					}
				}
				if(isExcept) continue;
			}
			
			if(!srchTxt) resultArr.push(item);
			else
			{
				for(var i=0; i<this.searchKeyArr.length; i++)
				{
					cmprTxt = item[this.searchKeyArr[i]];

					//종목명 비교
					if(cmprTxt && Search.compareText(srchTxt, cmprTxt.toLowerCase()))
					{
						//arr = [code, cmprTxt];
						//차후 특정 조건으로 정렬해야 할 경우 값을 셋팅한다.
						//arr.sortKey = item[''];

						resultArr.push(item);
						break;
					}
				}
			}
		}
		else this._searchData(resultArr, depth-1, data[key], srchTxt, typeArr, except);
	}
};


window['EXSearchView'] = EXSearchView;