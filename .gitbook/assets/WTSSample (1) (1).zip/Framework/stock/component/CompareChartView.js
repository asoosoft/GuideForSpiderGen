
(async function(){


await afc.import('Framework/stock/component/ChartView.js');

//--------------------------------------------------------------
//	난독화 될 경우 클래스 생성자가 축약되므로 
//	function CompareChartView() 와 같이 하면 안됨

CompareChartView = class CompareChartView extends ChartView
{
    constructor()
    {
        super();
	
        this.frwName = 'stock';
        
        this.delegator = null;
        this.noReal = true;
        
        this.compareArray = null;
        this.compareChecks = null;
        this.isInit = false;
        
        this.sendIdx = 0;
    }
}
//window.CompareChartView = CompareChartView;

CompareChartView.CONTEXT = 
{
    tag: '<div data-base="CompareChartView" data-class="CompareChartView" class="AView-Style"></div>',

    defStyle: 
    {
        width:'400px', height:'200px'
    },

    //events: ['swipe', 'longtab', 'scroll', 'scrollleft', 'scrollright', 'scrolltop', 'scrollbottom', 'drop', 'dragStart', 'dragEnd' ]
    events: ['swipe', 'longtab', 'scroll', 'scrollleft', 'scrollright', 'scrolltop', 'scrollbottom', 'drop', 'dragstart', 'dragend' ]
};

//네이티브 차트가 준비간 된 시점에 날라오는 이벤트
CompareChartView.prototype.onChartInit = function()
{
	this.isInit = true;
	this.loadData();
	if(this.delegator) this.delegator.onChartInit();
	
};
CompareChartView.prototype.loadData = function()
{
	var item = localStorage.getItem(this.getElementId());
	if(item)
	{
		item = JSON.parse(item);
		this.compareArray = item[0];
		this.compareChecks = item[1];
	}
	else
	{
        this.compareArray = ['^KR001BTC__KRW__^BTC^001'];
		this.compareChecks = [1];
	}
	
	return [this.compareArray, this.compareChecks];
};

CompareChartView.prototype.saveData = function()
{
	var saveArr = [this.compareArray, this.compareChecks];
	localStorage.setItem(this.getElementId(), JSON.stringify(saveArr));
};

//비교할 종목 한개를 셋팅하는 함수
CompareChartView.prototype.setCompareData = function(item)
{
	ChartManager.setCompareData([this.getElementId(), item]);
};

//setCompareData 함수 호출 이후 네이티브가 리턴해주는 함수
CompareChartView.prototype.onCompareDataRequest = function(compareArray, compareChecks)
{
    
//    alert(compareArray);
    
	this.compareArray = compareArray;
	this.compareChecks = compareChecks;
	
	this.saveData();
	
	this.sendIdx = 0;
	this.sendArrayDataProcess();
    
    
};

//팝업에 올릴 값을 가져오는 함수
CompareChartView.prototype.getComparePopupData = function()
{
	ChartManager.getComparePopupData(this.getElementId());
};

//팝업의 값을 네이티브에 저장하는 함수
CompareChartView.prototype.setCompareArrayFromPopup = function(sendCompareArray, sendCompareChecks)
{
//    alert("CompareChartView.js_setCompareArrayFromPopup");
	ChartManager.setCompareArrayFromPopup(this.getElementId(), sendCompareArray, sendCompareChecks);
};

//setCompareArrayFromPopup 함수 호출 이후 네이티브가 리턴해주는 함수
CompareChartView.prototype.onComparePopupData = function(compareArray, compareChecks)
{
	if(this.delegator) this.delegator.onComparePopupData(compareArray, compareChecks)
};

//네이티브에 index에 있는 단일 아이템의 체크여부를 저장하는함수
CompareChartView.prototype.setCheckCompareItem = function(nIndex, isChecked)
{
	ChartManager.setCheckCompareItem(this.getElementId(), nIndex, isChecked);
};

//네이티브에 index에 있는 단일 아이템을 지우는 함수
CompareChartView.prototype.setRemoveCompareItem = function(nIndex)
{
	ChartManager.setRemoveCompareItem(this.getElementId(), nIndex);
};

//비교할 종목들을 조회하는 함수
CompareChartView.prototype.sendArrayDataProcess = function()
{
    var arrJongmokData = this.compareArray[0];
//    alert("CompareChartView_data:"+arrJongmokData);
    var arrJongmokRowData = arrJongmokData.split("^");
	
    var type = 1, term = 2;
//    if(this.searchType == 1)
//    {
//        type = 6;
//        if(this.clickBtn) term = this.clickBtn.getText();
//    }
//    else if(this.searchType == 2)
//    {
//        type = 7;
//        if(this.clickBtn) term = this.clickBtn.getText();
//    }
//    else if(this.searchType == 0)
//    {
//        if(this.termBtn.getText() == '일')
//        {
//            type = 1;
//        }
//        else if(this.termBtn.getText() == '주')
//        {
//            type = 2;
//        }
//        else if(this.termBtn.getText() == '월')
//        {
//            type = 3;
//        }
//        else if(this.termBtn.getText() == '년')
//        {
//            type = 5;
//        }
//    }
    
//    alert("CompareChartView.prototype.sendArrayDataProcess");
    
    this.onRequestData([arrJongmokRowData[1], arrJongmokRowData[2], arrJongmokRowData[3], type, term], 0);

};

//타임존 설정 함수
CompareChartView.prototype.setTimeZone = function(arrResult)

{
    
	var chartId = this.getElementId();
   
 	var params= [chartId, arrResult[0]];
   
 	if(!this.isDev() && !afc.isSimulator) 
		ChartManager.setTimeZone(params);
    

};

//차트데이터를 더 요청하는 함수
CompareChartView.prototype.onScrollEnd = function()
{
	return;
};

//네이티브 차트에서 데이터를 요청(저장된 차트를 불러와서 요청하는 경우)
CompareChartView.prototype.onRequestData = function(requestArr, selectedIndex)
{
//    if(requestArr[3] == 6 || requestArr[3] == 7)
//    {
//        if(this.clickBtn) requestArr[4] = this.clickBtn.getText();
//    }
//    alert("CompareChartView.prototype.onRequestData");
	this.requestData(requestArr, selectedIndex);
};

//비교차트는 데이터를 순차적으로 던지기 위해 함수를 재정의
CompareChartView.prototype.setData = function(dataArr)
{
	this.updateOutputData(dataArr);
};

//비교차트는 데이터를 순차적으로 던지기 위해 함수를 재정의
CompareChartView.prototype.setQueryData = function(dataArr, keyArr, queryData)
{
	var data = null;
	var queryName = queryData.getQueryName();
	
	if(queryName == 'QR000002' || queryName == 'QR000003' || queryName == 'QR000004' || queryName == 'QR000006'|| queryName == 'QR000015')
	{
		/*
		//2016.07.20 by hyh - 데이터가 없는 경우에는 차트 데이터 초기화 및 리턴
		if(!dataArr || (dataArr.length == 0))
		{
			this.clearChart();
			return;
		}
		*/
		
		this.updateOutputData(dataArr);
	}
};

//일 분 틱 윈도우에서 조회 패턴을 변경할때 비교차트에 맞게 재정의
CompareChartView.prototype.onWindowResult = function(result, awindow)
{
	if(awindow.getId() == "MS0107")
	{
		if(result)
		{
			this.onRequestData([awindow.resultData[0], awindow.resultData[1], awindow.resultData[2], this.searchType, this.term], 1);
		}
	}
	if(awindow.getId() == 'MS000002')
	{
		if(result != undefined)
		{
			var btnCompId = this.clickBtn.getComponentId();
			
			if((btnCompId == 'MinBtn') || (btnCompId == 'TickBtn'))
			{
				// 해외지수일 경우 분/틱 조회 시키지 않음  + 채권종목일 경우
				if(this.isFIndex(this.item) || this.isBIndex(this.item))  
				{
					ChartManager.toast('조회할 수 없는 종목입니다.');
					return;
				}
			}
			
			this.resetBtnState();

			if(this.clickBtn.getComponentId() == 'MinBtn')
			{
				this.setSearchType(1, result);
				this.setLastValue(result);
			}
			else if(this.clickBtn.getComponentId() == 'TickBtn')
			{
				this.setSearchType(2, result);
				this.setLastValue(result);
			}
			else if(this.clickBtn.getComponentId() == 'TermBtn')
			{
				this.setSearchType(0, this.termMap[result]);
				this.setLastValue(this.termMap[result]);
			}
			this.clickBtn.setText(result);

			this.selectBtn = this.clickBtn;
			this.selectBtn.addClass('BT_CO2_NOR');

			/*	
			this.sendIdx = 0;
			this.sendArrayDataProcess();
			*/
			
			this.clearChart();
			this.setCompareArrayFromPopup(this.compareArray, this.compareChecks);
			
		}
	}
};
                    
//window.CompareChartView = CompareChartView;
                    
})();