
// -----------------------  도트 선을 그리기 위한  lib  ----------------------- //
var CP = window.CanvasRenderingContext2D && CanvasRenderingContext2D.prototype;
if (CP && CP.lineTo){
  CP.dashedLine = function(x,y,x2,y2,dashArray){
    console.warn('dashedLine is deprecated, please use drawDashedLine');
    if (!dashArray) dashArray=[10,5];
    if (dashLength==0) dashLength = 0.001; // Hack for Safari
    var dashCount = dashArray.length;
    this.moveTo(x, y);
    var dx = (x2-x), dy = (y2-y);
    var slope = dy/dx;
    var distRemaining = Math.sqrt( dx*dx + dy*dy );
    var dashIndex=0, draw=true;
    while (distRemaining>=0.1){
      var dashLength = dashArray[dashIndex++%dashCount];
      if (dashLength > distRemaining) dashLength = distRemaining;
      var xStep = Math.sqrt( dashLength*dashLength / (1 + slope*slope) );
      if (dx<0) xStep = -xStep;
      x += xStep;
      y += slope*xStep;
      this[draw ? 'lineTo' : 'moveTo'](x,y);
      distRemaining -= dashLength;
      draw = !draw;
    }
  };
}

BaseChart = class BaseChart extends AComponent
{
    constructor()
    {
        super();
        
        this.frwName = 'stock';

        this.canvas = null;	//캔버스 객체
        this.ctx = null;	//캔버스 컨텍스트
        this.data = [];	//드로잉 데이터
        this.pos = {};		//드로잉 포지션 객체
        
        this.eleW = 0;		//캔버스를 감싸고 있는 element 너비		
        this.eleH = 0;		//캔버스를 감싸고 있는 element 높이
        this.compLeft = 0;	//element의 left 위치 값
        this.middleX = 0;	//element의 middle X 값
        
        this.FONT_FAMILY = 'Regular';
        
        //상속받는 차트가 필요한 컬러 정보를 셋팅해야 함
        this.colorObj = {};
        
        this.decimalExp = 0; // 소수점 아래 자리 수 지정
    }
}
//window.BaseChart = BaseChart;

BaseChart.prototype.init = function(context, evtListener)
{
	AComponent.prototype.init.call(this, context, evtListener);
	
	this.canvas = this.element.children[0];
    this.ctx = this.canvas.getContext('2d');
    
    this.canvas.style.backgroundColor = 'transparent';
    
   	this.extractColorObj();
   	
   	//캔버스 겹치는 버그 대응
    this.canvas.style.width = ''; 
    this.canvas.style.height = '';
	
	//설정된 폰트를 사용하도록 처리
    this.FONT_FAMILY = this.$ele.css('font-family');
	
	var thisObj = this;
	if(this.isDev())
	{
		var className = this.className;
		if(!window[className].demoData)
		{
			$.ajax({
				url: 'Framework/stock/asset/'+ className + 'Data.txt',
				async: false,
				success: function(data)
				{
					window[className].demoData = JSON.parse(data);
					thisObj.setData(window[className].demoData, className=='EXMiniChart'?600:undefined);
				},
				error: function(e)
				{
					console.log(e);
				}
			});
		}
		else
		{
			this.setData(window[className].demoData, className=='EXMiniChart'?600:undefined);
		}
	}
		
	setTimeout(function(){ if(thisObj.isValid()) thisObj.updatePosition(); });
};

//차트 색상정보를 추출
BaseChart.prototype.extractColorObj = function()
{
	var targetObj = $(this.element);
	var colorInfo = null;
	for(var key in this.colorObj)
	{
		colorInfo = targetObj.attr('data-color-' + key.toLowerCase());
		if(colorInfo) this.colorObj[key] = colorInfo;
		else if(this.defColorObj) this.colorObj[key] = this.defColorObj[key];
	}
	
	var bgColor = this.element.style.backgroundColor;
	if(!bgColor) bgColor = 'transparent';
	this.colorObj['BACK'] = bgColor;
};

//차트 색상을 this.colorObj에 셋팅
BaseChart.prototype.setColors = function(colors, isDraw)
{
    if(colors)
    {
        for(var key in colors)
            if(colors.hasOwnProperty(key)) this.colorObj[key] = colors[key];
    }
    
    if(isDraw) this.draw();
};

//캔버스 포지션 변경(각 차트들이 재구현 해야함)
BaseChart.prototype.updatePosition = function(pWidth, pHeight)
{
	AComponent.prototype.updatePosition.call(this, pWidth, pHeight);
	
    this.eleW = $(this.element).width();
    this.eleH = $(this.element).height();

    this.canvas.style.width = this.eleW + "px";
    this.canvas.style.height = this.eleH + "px";
    
	var scale = window.devicePixelRatio;
    this.canvas.width = this.eleW * scale;
    this.canvas.height = this.eleH * scale;
	
	this.ctx.scale(scale, scale);
    
    this.compLeft = this._getCompLeft();	//this.element.offsetLeft;
    this.middleX = this._getMiddleX();	//this.eleW/2 + this.compLeft;
    
};

BaseChart.prototype._getCompLeft = function()
{
	return this.getBoundRect().left;
};

BaseChart.prototype._getMiddleX = function()
{
	return $(this.element).width()/2 + this._getCompLeft();
};

//데이터 셋팅(각 차트들이 재구현 해야함)
BaseChart.prototype.setData = function(data)
{
	
};

//정보 갱신후 차트를 update함(각 차트들이 재구현 해야함)
BaseChart.prototype.updateGraph = function()
{
	
};

//차트 드로우 리셋(각 차트들이 재구현 해야함)
BaseChart.prototype.resetDraw = function()
{
	
};

//차트 드로우(각 차트들이 재구현 해야함)
BaseChart.prototype.draw = function()
{
	
};

BaseChart.prototype.drawDashedLine = function(x1, y1, x2, y2, pattern)
{
    const beforelineDash = this.ctx.getLineDash();
    this.ctx.beginPath();
    this.ctx.setLineDash(pattern);
    this.ctx.moveTo(x1, y1);
    this.ctx.lineTo(x2, y2);
    this.ctx.stroke();
    this.ctx.setLineDash(beforelineDash);
};

BaseChart.prototype.setDecimal = function(exp)
{
    this.decimalExp = exp;
};

BaseChart.prototype._getDecimalValue = function(value)
{
	if(this.decimalExp != undefined)
	{
		value = ADataMask.Number.decimalAdjust.func(value, ['floor', this.decimalExp*-1]).toFixed(this.decimalExp);
	}
	return ADataMask.Number.money.func(value);
};