
//afc.import("Framework/stock/component/EXHogaGrid.js");
/**
 * @author asoocool
 */

class EXHogaView extends AView
{
    static isAutoCalcQuantityChange = false;

    constructor()
    {
        super();

        this.frwName = 'stock';
        
        this.isAutoResizeChildren = true;
        this.showCount = 11;	// 현재 뷰에서 보여줄 호가개수
    }
}

window.EXHogaView = EXHogaView;

EXHogaView.prototype.init = function(context, evtListener)
{
    AView.prototype.init.call(this, context, evtListener);
    
    var thisObj = this, children = this.getChildren();
    
	this.hogaGrid = children[0];
	this.askGrid = children[1];
    this.bidGrid = children[2];
 	this.rView = children[3];
 	this.lView = children[4];

	if(this.isDev() && (this.hogaGrid.quoteCount + this.hogaGrid.midRowCnt > this.askGrid.getRowCount()))
	{
		let displayNone = this.hogaGrid.getMidPriceMode()==false;
		
		let $clone = $(this.askGrid.getRow(0)).clone();
		if(displayNone) $clone.css('display', 'none');
		$(this.askGrid.getRow(0)).after($clone);
		
		$clone = $(this.bidGrid.getRow(0)).clone();
		if(displayNone) $clone.css('display', 'none');
		$(this.bidGrid.getRow(0)).after($clone);

		//매핑정보도 변경
		//askGrid 는 하단에 매핑추가하면 되서 작업 필요 없음
		let queryNames = this.bidGrid.getAttr(afc.ATTR_QUERY_NAME);
		if(queryNames) {
			let keyBlocks, tmp;
			queryNames.split('|').forEach(qryName => {
				keyBlocks = this.bidGrid.getAttr('data-blocks-'+qryName).split('|');
				keyBlocks.forEach((block, i) => {
					tmp = block.split(',');
					tmp.splice(1, 0, '');
					keyBlocks[i] = tmp.join(',');
				});
				this.bidGrid.setAttr('data-blocks-'+qryName, keyBlocks.join('|'));
			});
		}
		this.askGrid.initVariables();
		this.bidGrid.initVariables();
		this.askGrid.init(this.askGrid.element);
		this.bidGrid.init(this.bidGrid.element);
	}

	this.isMidPriceMode = null;//this.askGrid.getRow(this.askGrid.getRowCount()-1).style.display != 'none';
	
	var thisObj = this;
	this.hogaGrid.setDelegator(this);
	this.setAutoResizeChildren(this.getAttr('data-auto-resize'));
	this.setAutoCalcQuantityChange(this.getAttr('data-auto-quantity')||EXHogaView.isAutoCalcQuantityChange);
	setTimeout(function(){ if(thisObj.isValid()) thisObj.setShowCount(thisObj.getAttr('data-show-count')); });
};
/*
EXHogaView.prototype.onContextAvailable = function()
{
    AView.prototype.onContextAvailable.call(this);

    const itvl = setInterval(() => {
        if(this.isValid() && this.getHeight())
        {
            this.setShowCount(this.getAttr('data-show-count'));
            clearInterval(itvl);
        }
    }, 10);
};*/

EXHogaView.CONTEXT = 
{
    tag: '<div data-base="EXHogaView" data-class="EXHogaView" class="AView-Style" style="overflow: auto" data-auto-resize="true">\
			<div data-base="EXHogaGrid" data-class="EXHogaGrid" data-nochange-count="true" data-bottom-count="1" data-middle-count="1"\
			  data-hide-header="true" data-selectable="true" data-single-select="true" data-flexible-row="true" class="AGrid-Style" style="width:100%; height:100%">\
				<table align="center" class="grid-header-table" style="width: calc(100% - 14px); border-collapse: collapse; table-layout: fixed;">\
					<colgroup><col width="35%"><col width="30%"><col width="35%"></colgroup>\
					<thead align="center" class="head-prop" style="display: none;">\
						<tr height="22px"><td>col1</td><td>col2</td><td>col3</td></tr>\
					</thead>\
				</table>\
				<div style="height: 100%; overflow-y: auto; overflow-x: hidden;">\
					<table align="center" class="grid-body-table" style="width:100%; border-collapse:collapse; table-layout: fixed;">\
					<colgroup><col width="35%"><col width="30%"><col width="35%"></colgroup>\
						<thead align="center" class="head-prop" style="display: none;">\
							<tr height="22px"><td>col1</td><td>col2</td><td>col3</td></tr>\
						</thead>\
						<tbody align="center" class="body-prop">\
							<tr height="22px">\
								<td style="border: 1px solid #c2c2c2; padding: 0px 5px; text-align: right; background: linear-gradient(90deg, #e7f2ff 0%, #e7f2ff 100%) 100% 50% no-repeat;"></td>\
								<td style="border: 1px solid #c2c2c2; padding: 0px;"></td>\
								<td rowspan="10" style="border: 1px solid #c2c2c2; padding: 0px 5px; text-align: left;"></td>\
							</tr>\
							<tr height="22px">\
								<td style="border: 1px solid #c2c2c2; padding: 0px 5px; text-align: right; background: linear-gradient(90deg, #e7f2ff 0%, #e7f2ff 100%) 100% 50% no-repeat;"></td>\
								<td style="border: 1px solid #c2c2c2; padding: 0px;"></td>\
								<td style="border: 1px solid #c2c2c2; padding: 0px 5px; display: none; text-align: left;"></td>\
							</tr>\
							<tr height="22px;">\
								<td style="border: 1px solid #c2c2c2; text-align: right; padding: 0px 5px; background: linear-gradient(90deg, #e7f2ff 0%, #e7f2ff 100%) 100% 50% no-repeat;"></td>\
								<td style="border: 1px solid #c2c2c2; padding: 0px;"></td>\
								<td style="border: 1px solid #c2c2c2; display: none; text-align: left; padding: 0px 5px;"></td>\
							</tr>\
							<tr height="22px;">\
								<td style="border: 1px solid #c2c2c2; text-align: right; padding: 0px 5px; background: linear-gradient(90deg, #e7f2ff 0%, #e7f2ff 100%) 100% 50% no-repeat;"></td>\
								<td style="border: 1px solid #c2c2c2; padding: 0px;"></td>\
								<td style="border: 1px solid #c2c2c2; display: none; text-align: left; padding: 0px 5px;"></td>\
							</tr>\
							<tr height="22px;">\
								<td style="border: 1px solid #c2c2c2; text-align: right; padding: 0px 5px; background: linear-gradient(90deg, #e7f2ff 0%, #e7f2ff 100%) 100% 50% no-repeat;"></td>\
								<td style="border: 1px solid #c2c2c2; padding: 0px;"></td>\
								<td style="border: 1px solid #c2c2c2; display: none; text-align: left; padding: 0px 5px;"></td>\
							</tr>\
							<tr height="22px;">\
								<td style="border: 1px solid #c2c2c2; text-align: right; padding: 0px 5px; background: linear-gradient(90deg, #e7f2ff 0%, #e7f2ff 100%) 100% 50% no-repeat;"></td>\
								<td style="border: 1px solid #c2c2c2; padding: 0px;"></td>\
								<td style="border: 1px solid #c2c2c2; display: none; text-align: left; padding: 0px 5px;"></td>\
							</tr>\
							<tr height="22px;">\
								<td style="border: 1px solid #c2c2c2; text-align: right; padding: 0px 5px; background: linear-gradient(90deg, #e7f2ff 0%, #e7f2ff 100%) 100% 50% no-repeat;"></td>\
								<td style="border: 1px solid #c2c2c2; padding: 0px;"></td>\
								<td style="border: 1px solid #c2c2c2; display: none; text-align: left; padding: 0px 5px;"></td>\
							</tr>\
							<tr height="22px;">\
								<td style="border: 1px solid #c2c2c2; text-align: right; padding: 0px 5px; background: linear-gradient(90deg, #e7f2ff 0%, #e7f2ff 100%) 100% 50% no-repeat;"></td>\
								<td style="border: 1px solid #c2c2c2; padding: 0px;"></td>\
								<td style="border: 1px solid #c2c2c2; display: none; text-align: left; padding: 0px 5px;"></td>\
							</tr>\
							<tr height="22px;">\
								<td style="border: 1px solid #c2c2c2; text-align: right; padding: 0px 5px; background: linear-gradient(90deg, #e7f2ff 0%, #e7f2ff 100%) 100% 50% no-repeat;"></td>\
								<td style="border: 1px solid #c2c2c2; padding: 0px;"></td>\
								<td style="border: 1px solid #c2c2c2; display: none; text-align: left; padding: 0px 5px;"></td>\
							</tr>\
							<tr height="22px;">\
								<td style="border: 1px solid #c2c2c2; text-align: right; padding: 0px 5px; background: linear-gradient(90deg, #e7f2ff 0%, #e7f2ff 100%) 100% 50% no-repeat;"></td>\
								<td style="border: 1px solid #c2c2c2; padding: 0px;"></td>\
								<td style="border: 1px solid #c2c2c2; display: none; text-align: left; padding: 0px 5px;"></td>\
							</tr>\
							<tr height="22px">\
								<td style="border: 1px solid #c2c2c2; text-align: right; padding: 0px 5px;"></td>\
								<td style="border: 1px solid #c2c2c2; padding: 0px;"></td>\
								<td style="border: 1px solid #c2c2c2; text-align: left; padding: 0px 5px;"></td>\
							</tr>\
							<tr height="22px;">\
								<td rowspan="10" style="border: 1px solid #c2c2c2; text-align: right; padding: 0px 5px;"></td>\
								<td style="border: 1px solid #c2c2c2; padding: 0px;"></td>\
								<td style="border: 1px solid #c2c2c2; text-align: left; padding: 0px 5px; background: linear-gradient(90deg, #ffebed 0%, #ffebed 100%) 0% 50% no-repeat;"></td>\
							</tr>\
							<tr height="22px;">\
								<td style="border: 1px solid #c2c2c2; display: none; text-align: right; padding: 0px 5px;"></td>\
								<td style="border: 1px solid #c2c2c2; padding: 0px;"></td>\
								<td style="border: 1px solid #c2c2c2; text-align: left; padding: 0px 5px; background: linear-gradient(90deg, #ffebed 0%, #ffebed 100%) 0% 50% no-repeat;"></td>\
							</tr>\
							<tr height="22px;">\
								<td style="border: 1px solid #c2c2c2; display: none; text-align: right; padding: 0px 5px;"></td>\
								<td style="border: 1px solid #c2c2c2; padding: 0px;"></td>\
								<td style="border: 1px solid #c2c2c2; text-align: left; padding: 0px 5px; background: linear-gradient(90deg, #ffebed 0%, #ffebed 100%) 0% 50% no-repeat;"></td>\
							</tr>\
							<tr height="22px;">\
								<td style="border: 1px solid #c2c2c2; display: none; text-align: right; padding: 0px 5px;"></td>\
								<td style="border: 1px solid #c2c2c2; padding: 0px;"></td>\
								<td style="border: 1px solid #c2c2c2; text-align: left; padding: 0px 5px; background: linear-gradient(90deg, #ffebed 0%, #ffebed 100%) 0% 50% no-repeat;"></td>\
							</tr>\
							<tr height="22px;">\
								<td style="border: 1px solid #c2c2c2; display: none; text-align: right; padding: 0px 5px;"></td>\
								<td style="border: 1px solid #c2c2c2; padding: 0px;"></td>\
								<td style="border: 1px solid #c2c2c2; text-align: left; padding: 0px 5px; background: linear-gradient(90deg, #ffebed 0%, #ffebed 100%) 0% 50% no-repeat;"></td>\
							</tr>\
							<tr height="22px;">\
								<td style="border: 1px solid #c2c2c2; display: none; text-align: right; padding: 0px 5px;"></td>\
								<td style="border: 1px solid #c2c2c2; padding: 0px;"></td>\
								<td style="border: 1px solid #c2c2c2; text-align: left; padding: 0px 5px; background: linear-gradient(90deg, #ffebed 0%, #ffebed 100%) 0% 50% no-repeat;"></td>\
							</tr>\
							<tr height="22px;">\
								<td style="border: 1px solid #c2c2c2; display: none; text-align: right; padding: 0px 5px;"></td>\
								<td style="border: 1px solid #c2c2c2; padding: 0px;"></td>\
								<td style="border: 1px solid #c2c2c2; text-align: left; padding: 0px 5px; background: linear-gradient(90deg, #ffebed 0%, #ffebed 100%) 0% 50% no-repeat;"></td>\
							</tr>\
							<tr height="22px;">\
								<td style="border: 1px solid #c2c2c2; display: none; text-align: right; padding: 0px 5px;"></td>\
								<td style="border: 1px solid #c2c2c2; padding: 0px;"></td>\
								<td style="border: 1px solid #c2c2c2; text-align: left; padding: 0px 5px; background: linear-gradient(90deg, #ffebed 0%, #ffebed 100%) 0% 50% no-repeat;"></td>\
							</tr>\
							<tr height="22px;">\
								<td style="border: 1px solid #c2c2c2; display: none; text-align: right; padding: 0px 5px;"></td>\
								<td style="border: 1px solid #c2c2c2; padding: 0px;"></td>\
								<td style="border: 1px solid #c2c2c2; text-align: left; padding: 0px 5px; background: linear-gradient(90deg, #ffebed 0%, #ffebed 100%) 0% 50% no-repeat;"></td>\
							</tr>\
							<tr height="22px;">\
								<td style="border: 1px solid #c2c2c2; display: none; text-align: right; padding: 0px 5px;"></td>\
								<td style="border: 1px solid #c2c2c2; padding: 0px;"></td>\
								<td style="border: 1px solid #c2c2c2; text-align: left; padding: 0px 5px; background: linear-gradient(90deg, #ffebed 0%, #ffebed 100%) 0% 50% no-repeat;"></td>\
							</tr>\
							<tr height="22px;">\
								<td style="border: 1px solid #c2c2c2; text-align: right; padding: 0px 5px;"></td>\
								<td style="border: 1px solid #c2c2c2; padding: 0px;"></td>\
								<td style="border: 1px solid #c2c2c2; text-align: left; padding: 0px 5px;"></td>\
							</tr>\
						</tbody>\
					</table>\
				</div>\
			</div>\
			<div class="AGrid-Style" data-base="AGrid" data-class="AGrid" data-hide-header="true" data-flexible-row="true"\
			style="width: 15%; height: 221px; left: 0px; top: 0px; background-color: rgba(0, 0, 0, 0);">\
				<table align="center" class="grid-header-table" style="width: calc(100% - 14px); border-collapse: collapse; table-layout: fixed;">\
                   	<colgroup><col></colgroup>\
                   	<thead align="center" class="head-prop" style="display: none;">\
                      		<tr height="22px"><td>col1</td></tr>\
					</thead>\
				</table>\
				<div style="height: 100%; overflow-y: auto; overflow-x: hidden;">\
					<table align="center" class="grid-body-table" style="width:100%; border-collapse:collapse; table-layout: fixed;">\
						<colgroup><col></colgroup>\
						<thead align="center" class="head-prop" style="display: none;">\
							<tr height="22px"><td>col1</td></tr>\
						</thead>\
						<tbody align="center" class="body-prop">\
							<tr height="22px;"><td style="border: 1px solid transparent"></td></tr>\
							<tr height="22px;"><td style="border: 1px solid transparent"></td></tr>\
							<tr height="22px;"><td style="border: 1px solid transparent"></td></tr>\
							<tr height="22px;"><td style="border: 1px solid transparent"></td></tr>\
							<tr height="22px;"><td style="border: 1px solid transparent"></td></tr>\
							<tr height="22px;"><td style="border: 1px solid transparent"></td></tr>\
							<tr height="22px;"><td style="border: 1px solid transparent"></td></tr>\
							<tr height="22px;"><td style="border: 1px solid transparent"></td></tr>\
							<tr height="22px;"><td style="border: 1px solid transparent"></td></tr>\
							<tr height="22px;"><td style="border: 1px solid transparent"></td></tr>\
							<tr height="22px;"><td style="border: 1px solid transparent"></td></tr>\
						</tbody>\
					</table>\
				</div>\
			</div>\
			<div class="AGrid-Style" data-base="AGrid" data-class="AGrid" data-hide-header="true" data-flexible-row="true"\
			style="width: 15%; height: 221px; top: 220px; background-color: rgba(0, 0, 0, 0); right: 0px;">\
				<table align="center" class="grid-header-table" style="width: calc(100% - 14px); border-collapse: collapse; table-layout: fixed;">\
					<colgroup><col></colgroup>\
					<thead align="center" class="head-prop" style="display: none;">\
						<tr height="22px"><td>col1</td></tr>\
					</thead>\
				</table>\
				<div style="height: 100%; overflow-y: auto; overflow-x: hidden;">\
					<table align="center" class="grid-body-table" style="width:100%; border-collapse:collapse; table-layout: fixed;">\
						<colgroup><col></colgroup>\
						<thead align="center" class="head-prop" style="display: none;">\
							<tr height="22px"><td>col1</td></tr>\
						</thead>\
						<tbody align="center" class="body-prop">\
							<tr height="22px"><td style="border: 1px solid transparent"></td></tr>\
							<tr height="22px"><td style="border: 1px solid transparent"></td></tr>\
							<tr height="22px"><td style="border: 1px solid transparent"></td></tr>\
							<tr height="22px"><td style="border: 1px solid transparent"></td></tr>\
							<tr height="22px"><td style="border: 1px solid transparent"></td></tr>\
							<tr height="22px"><td style="border: 1px solid transparent"></td></tr>\
							<tr height="22px"><td style="border: 1px solid transparent"></td></tr>\
							<tr height="22px"><td style="border: 1px solid transparent"></td></tr>\
							<tr height="22px"><td style="border: 1px solid transparent"></td></tr>\
							<tr height="22px"><td style="border: 1px solid transparent"></td></tr>\
							<tr height="22px"><td style="border: 1px solid transparent"></td></tr>\
						</tbody>\
					</table>\
				</div>\
			</div>\
			<div data-base="AView" data-class="AView" class="AView-Style" style="right:1px; top:1px; width:35%; height: 219px;"></div>\
			<div data-base="AView" data-class="AView" class="AView-Style" style="left:1px; top:221px; width:35%; height: 219px;"></div>\
		</div>',

    defStyle: 
    {
        width:'400px', height:'463px'
    },

    //events: ['swipe', 'longtab', 'scroll', 'scrollleft', 'scrollright', 'scrolltop', 'scrollbottom', 'drop', 'dragStart', 'dragEnd' ]
    events: ['swipe', 'longtab', 'scroll', 'scrollleft', 'scrollright', 'scrolltop', 'scrollbottom' ]
};

EXHogaView.prototype.updatePosition = function(pWidth, pHeight)
{
	AView.prototype.updatePosition.call(this, pWidth, pHeight);
	/*
	var h = this.getHeight(),
		rowH = parseInt(h/this.hogaGrid.getRowCount());
	*/
	
	// 자동으로 자식들의 위치, 높이를 변경하지 않을 경우 리턴처리
	if(!this.isAutoResizeChildren) return;

	var len = this.hogaGrid.quoteCount, midRowCnt = 1;
	const midRow = this.hogaGrid.getRow(len);
	var askH = 0, bidH = 0, midH = 0;
	if(midRow.style.display != 'none') midH = $(midRow).outerHeight();
	
	this.hogaGrid.tBody.find('tr:lt('+len+')').each(function(){ askH += $(this).outerHeight(); });
	this.hogaGrid.tBody.find('tr:lt('+(len*2+midRowCnt)+'):gt('+(len-1+midRowCnt)+')').each(function(){ bidH += $(this).outerHeight(); });

	this.bidGrid.setStyle('top', askH+'px');
	this.lView.setStyle('top', (askH+midH+1)+'px');
	this.askGrid.setHeight(askH+midH);
	this.bidGrid.setHeight(bidH+midH);
	this.rView.setHeight(askH-1);
	this.lView.setHeight(bidH-1);
	this.rView.setWidth($(this.hogaGrid.getCell(0, 2)).outerWidth()-1);
	this.lView.setWidth($(this.hogaGrid.getCell(0, 0)).outerWidth()-1);
};

EXHogaView.prototype.setShowCount = function(cnt, noUpdatePosition)
{
	// 호가 그리드의 높이를 변경하는 것은 개발시에는 필요하지 않기에 수정(런타임에서만)
	if(!this.isDev() && this.hogaGrid.getAttr('data-flexible-row'))
	{
		if(cnt != undefined && cnt>0)
		{
			var len = this.hogaGrid.quoteCount;
			this.showCount = cnt = cnt*1;

			if(cnt > len)
			{
				this.hogaGrid.setHeight('100%');
				//this.setStyle('overflow', 'visible');
			}
			else
			{
				var h = this.getHeight()/(cnt*2);
				var thisObj = this;

				this.hogaGrid.setHeight(h*this.hogaGrid.getRowCount());
				//this.setStyle('overflow', 'auto');

				if(!this.isDev())
				{
					setTimeout(function() {
						if(thisObj.isValid())
						{
							thisObj.scrollToQuoteCenter();
							//thisObj.scrollTo(h*(len-cnt)-1);
						}
					});
				}
			}
		}
	}
	
    if(!noUpdatePosition) this.updatePosition();
};

EXHogaView.prototype.scrollToQuoteCenter = function()
{
	var h = this.getHeight(),
		sh = this.element.scrollHeight,
		midRowCnt = this.hogaGrid.midRowCnt;
	
	var lCnt = this.hogaGrid.quoteCount*2 - 1 + midRowCnt;
	var minusH = 0;
	this.hogaGrid.tBody.find('tr:gt('+lCnt+')').each(function(){ minusH += $(this).outerHeight(); });
	
	this.scrollTo(parseInt((sh - minusH - h)/2));
	
	/*this.hogaGrid.tBody.find('tr').get(this.hogaGrid.quoteCount/2).scrollIntoView();
	this.scrollOffset(1);*/
};

EXHogaView.prototype.getShowCount = function()
{
	return this.showCount;
};

EXHogaView.prototype.setAutoResizeChildren = function(isAuto)
{
	this.isAutoResizeChildren = isAuto;
};

EXHogaView.prototype.getAutoResizeChildren = function()
{
	return this.isAutoResizeChildren;
};

// 호가그리드의 행개수가 변경될 때 호출되는 함수
EXHogaView.prototype.onRowCountChange = function()
{
	var quoteCount = this.hogaGrid.quoteCount,
		midRowCnt = this.hogaGrid.midRowCnt,
		arr = [this.askGrid, this.bidGrid],
		grid, rowCount, $row;
	
	for(var i=0; i<arr.length; i++)
	{
		grid = arr[i];
		rowCount = grid.getRowCount();
		
		if(rowCount > quoteCount)
		{
			for(var j=rowCount-1; j>=quoteCount+midRowCnt; j--) grid.removeRow(j);
		}
		else
		{
			$row = $(grid.getRow(0));
			for(var j=rowCount; j<quoteCount+midRowCnt; j++) $row.after($row.clone());
		}
		
		grid.initVariables();
		grid.init(grid.element);
	}
	
	this.setShowCount(this.showCount);
	//this.updatePosition();
};

EXHogaView.prototype.getMidPriceMode = function()
{
	return this.hogaGrid.getMidPriceMode();
};

EXHogaView.prototype.setMidPriceMode = function(isMidPriceMode)
{
	if(this.isMidPriceMode == isMidPriceMode) return;
	this.isMidPriceMode = isMidPriceMode;
	
	const quoteCount = this.hogaGrid.quoteCount;
	this.hogaGrid.setMidPriceMode(isMidPriceMode, true);
	this.askGrid.getRow(quoteCount).style.display = isMidPriceMode?'':'none';
	this.bidGrid.getRow(0).style.display = isMidPriceMode?'':'none';

	this.updatePosition();
};

EXHogaView.prototype.setAutoCalcQuantityChange = function(isAuto)
{
	if(isAuto) {
		const thisObj = this;
		this.hogaGrid.onQuantityChange = function(askArr, bidArr)
		{
			thisObj.askGrid.setQueryData(askArr, Object.keys(askArr[0]));
			thisObj.bidGrid.setQueryData(bidArr, Object.keys(bidArr[0]));
		}
	} else {
		this.hogaGrid.onQuantityChange = null;
	}
};


/*
EXHogaView.prototype.setData = function(dataArr){};
EXHogaView.prototype.setQueryData = function(dataArr, keyArr, queryData)
{
    
    
};

EXHogaView.prototype.getQueryData = function(dataArr, keyArr, queryData)
{
    
    
};*/
