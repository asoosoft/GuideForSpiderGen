               
/**
 * @author asoocool
 */

var EXIscdBoxEvent = {};

EXIscdBoxEvent.select = function(acomp, itemList)
{
    if(itemList)
    {
        itemList.bind(afc.ACTION_DOWN, function(e)
        {
            acomp.isTouchLeave = false;
            
            //android 4.3 이하, BugFix
            //드랍박스는 기본적으로 상위로 전달되지 않도록 처리한다. 박스가 동적으로 생성되기 때문에 
            if(afc.andVer<4.4)
            {
				//스크롤이 작동되기 위해 상위로 전달되는 것을 막음.
				if(acomp.isScroll()) e.stopPropagation();
			}
            
            //var oe = e.originalEvent.changedTouches[0];
            acomp.startX = e.pageX;
            acomp.startY = e.pageY;
        });
        
        itemList.bind(afc.ACTION_MOVE, function(e) 
        {
            //var oe = e.originalEvent.changedTouches[0];
    
            if(Math.abs(e.pageY - acomp.startY) > 10)
            {
                acomp.isTouchLeave = true;
            }
        });
    
        itemList.bind(afc.ACTION_UP, function(e)
        {        
            if(!acomp.isTouchLeave) 
            {
				$(this).addClass('dropboxCellOver');
				
				if(	acomp.filterType != EXIscdBox.CME )
				{
					acomp.addIscdItem(this.data.text, this.data.data);
					this.index = 0;
				}
				acomp.selectItem(this.index);
                
                var touchItem = this;
				setTimeout(function() 
				{ 
					acomp.dropWin.close();
					acomp.reportEvent('select', touchItem);
				}, 10);
				
				//딜레이 10이상 주지 말것. 아이폰에서 오류날 수 있음.
				//10 이상 주려면 AppManager.touchDelay 를 먼저 호출해 줄것.(과거의 오류, 현재도 발생하는지 확인 필요)
				
            }
			//else e.stopPropagation();
        });
    }
    
    //이벤트 핸들러를 등록한 경우
    //동적으로 이벤트가 적용되도록
    else acomp.isEventApply = true;
};

