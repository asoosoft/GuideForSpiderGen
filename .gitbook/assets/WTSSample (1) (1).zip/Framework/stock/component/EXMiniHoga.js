(async function(){

await afc.import("Framework/afc/component/AGrid.js");


/**
* 미니호가 그리드 객체 입니다.
*
* class EXMiniHoga
* @constructor
*/

EXMiniHoga = class EXMiniHoga extends AGrid
{
    static rateMode = false;
    static rateSuffixStr = '%';
    static setRateSuffixStr(str)
    {
	    EXMiniHoga.rateSuffixStr = str;
    }

    constructor()
    {
        super();
        
        this.frwName = 'stock';
        
        this.quoteCount = 10;			// 호가단계를 지정(10호가)
        this.rowLen = 0; 				// 호가가 적용된 로우개수
        this.colLen = 0;
        this.btmRowCnt = 0; //하단 데이터 영역 row 갯수 : 2 = 합계,시간외
        this.midRowCnt = 0; //중간가 데이터 영역 row 갯수 : 1

        this.basePrice = undefined;		// 호가의 색상을 구분하기 위한 기준가
        this.basePriceKey = '';			// 쿼리에서 기준가를 가져오기 위한 키
        
        this.curPriceKey = '';			// 쿼리에서 현재가를 가져오기 위한 키
        this.currentCellArr = [];		// 현재가가 있는 셀을 저장한다.
        this.currentPrice = undefined;	// 현재가
        this.curPriceStyleArr = null;	// 현재가를 선택하는 스타일 배열[상승색, 보합색, 하락색]
        
        this.upColor = StockColor.UP_COLOR;			//'#ff0000';	// 기본 상승색
        this.downColor = StockColor.DOWN_COLOR;		//'#0070ff';	// 기본 하락색
        this.steadyColor = StockColor.STEADY_COLOR;	//'#000000';	// 기본 보합색
        
        this.barSize = '70%'			// 매도, 매수 잔량을 표시하는 바 높이
        
        // 값 저장 배열(2차원), 그리드 형태와 동일
        this._valArr = null;
        
        this.rateMode = EXMiniHoga.rateMode;
        this.rateClass = '';
        this.rateStyle = '';
        this.rateSuffixStr = EXMiniHoga.rateSuffixStr;
    }
}

//window.EXMiniHoga = EXMiniHoga;

EXMiniHoga.CONTEXT =
{
	tag: '<div data-base="EXMiniHoga" data-class="EXMiniHoga" data-nochange-count="true" data-bottom-count="0" data-middle-count="1"\
		  data-hide-header="true" data-selectable="true" data-single-select="true" data-flexible-row="true" class="AGrid-Style">\
			<table align="center" class="grid-header-table" style="width: calc(100% - 14px); border-collapse: collapse; table-layout: fixed;">\
				<colgroup><col width="50%"><col width="50%"></colgroup>\
				<thead align="center" class="head-prop" style="display: none;">\
					<tr height="22px"><td>col1</td><td>col2</td></tr>\
				</thead>\
			</table>\
			<div style="height: 100%; overflow-y: auto; overflow-x: hidden;">\
				<table align="center" class="grid-body-table" style="width:100%; border-collapse:collapse; table-layout: fixed;">\
				<colgroup><col width="50%"><col width="50%"></colgroup>\
					<thead align="center" class="head-prop" style="display: none;">\
						<tr height="22px"><td>col1</td><td>col2</td></tr>\
					</thead>\
                    <tbody align="center" class="body-prop">\
						<tr height="22px">\
							<td style="padding: 0px 5px; text-align: right;"></td>\
							<td style="padding: 0px 5px; text-align: right; background: linear-gradient(90deg, #e7f2ff 0%, #e7f2ff 100%) 100% 50% no-repeat;"></td>\
						</tr>\
						<tr height="22px">\
							<td style="padding: 0px 5px; text-align: right;"></td>\
							<td style="padding: 0px 5px; text-align: right; background: linear-gradient(90deg, #e7f2ff 0%, #e7f2ff 100%) 100% 50% no-repeat;"></td>\
						</tr>\
						<tr height="22px;">\
							<td style="padding: 0px 5px; text-align: right;"></td>\
							<td style="padding: 0px 5px; text-align: right; background: linear-gradient(90deg, #e7f2ff 0%, #e7f2ff 100%) 100% 50% no-repeat;"></td>\
						</tr>\
						<tr height="22px;">\
							<td style="padding: 0px 5px; text-align: right;"></td>\
							<td style="padding: 0px 5px; text-align: right; background: linear-gradient(90deg, #e7f2ff 0%, #e7f2ff 100%) 100% 50% no-repeat;"></td>\
						</tr>\
						<tr height="22px;">\
							<td style="padding: 0px 5px; text-align: right;"></td>\
							<td style="padding: 0px 5px; text-align: right; background: linear-gradient(90deg, #e7f2ff 0%, #e7f2ff 100%) 100% 50% no-repeat;"></td>\
						</tr>\
						<tr height="22px;">\
							<td style="padding: 0px 5px; text-align: right;"></td>\
							<td style="padding: 0px 5px; text-align: right; background: linear-gradient(90deg, #e7f2ff 0%, #e7f2ff 100%) 100% 50% no-repeat;"></td>\
						</tr>\
						<tr height="22px;">\
							<td style="padding: 0px 5px; text-align: right;"></td>\
							<td style="padding: 0px 5px; text-align: right; background: linear-gradient(90deg, #e7f2ff 0%, #e7f2ff 100%) 100% 50% no-repeat;"></td>\
						</tr>\
						<tr height="22px;">\
							<td style="padding: 0px 5px; text-align: right;"></td>\
							<td style="padding: 0px 5px; text-align: right; background: linear-gradient(90deg, #e7f2ff 0%, #e7f2ff 100%) 100% 50% no-repeat;"></td>\
						</tr>\
						<tr height="22px;">\
							<td style="padding: 0px 5px; text-align: right;"></td>\
							<td style="padding: 0px 5px; text-align: right; background: linear-gradient(90deg, #e7f2ff 0%, #e7f2ff 100%) 100% 50% no-repeat;"></td>\
						</tr>\
						<tr height="22px;">\
							<td style="padding: 0px 5px; text-align: right;"></td>\
							<td style="padding: 0px 5px; text-align: right; background: linear-gradient(90deg, #e7f2ff 0%, #e7f2ff 100%) 100% 50% no-repeat;"></td>\
						</tr>\
						<tr height="22px;">\
							<td style="padding: 0px 5px; text-align: right;"></td>\
							<td style="padding: 0px 5px; text-align: right;"></td>\
						</tr>\
						<tr height="22px;">\
							<td style="padding: 0px 5px; text-align: right;"></td>\
							<td style="padding: 0px 5px; text-align: right; background: linear-gradient(90deg, #ffebed 0%, #ffebed 100%) 100% 50% no-repeat;"></td>\
						</tr>\
						<tr height="22px;">\
							<td style="padding: 0px 5px; text-align: right;"></td>\
							<td style="padding: 0px 5px; text-align: right; background: linear-gradient(90deg, #ffebed 0%, #ffebed 100%) 100% 50% no-repeat;"></td>\
						</tr>\
						<tr height="22px;">\
							<td style="padding: 0px 5px; text-align: right;"></td>\
							<td style="padding: 0px 5px; text-align: right; background: linear-gradient(90deg, #ffebed 0%, #ffebed 100%) 100% 50% no-repeat;"></td>\
						</tr>\
						<tr height="22px;">\
							<td style="padding: 0px 5px; text-align: right;"></td>\
							<td style="padding: 0px 5px; text-align: right; background: linear-gradient(90deg, #ffebed 0%, #ffebed 100%) 100% 50% no-repeat;"></td>\
						</tr>\
						<tr height="22px;">\
							<td style="padding: 0px 5px; text-align: right;"></td>\
							<td style="padding: 0px 5px; text-align: right; background: linear-gradient(90deg, #ffebed 0%, #ffebed 100%) 100% 50% no-repeat;"></td>\
						</tr>\
						<tr height="22px;">\
							<td style="padding: 0px 5px; text-align: right;"></td>\
							<td style="padding: 0px 5px; text-align: right; background: linear-gradient(90deg, #ffebed 0%, #ffebed 100%) 100% 50% no-repeat;"></td>\
						</tr>\
						<tr height="22px;">\
							<td style="padding: 0px 5px; text-align: right;"></td>\
							<td style="padding: 0px 5px; text-align: right; background: linear-gradient(90deg, #ffebed 0%, #ffebed 100%) 100% 50% no-repeat;"></td>\
						</tr>\
						<tr height="22px;">\
							<td style="padding: 0px 5px; text-align: right;"></td>\
							<td style="padding: 0px 5px; text-align: right; background: linear-gradient(90deg, #ffebed 0%, #ffebed 100%) 100% 50% no-repeat;"></td>\
						</tr>\
						<tr height="22px;">\
							<td style="padding: 0px 5px; text-align: right;"></td>\
							<td style="padding: 0px 5px; text-align: right; background: linear-gradient(90deg, #ffebed 0%, #ffebed 100%) 100% 50% no-repeat;"></td>\
						</tr>\
						<tr height="22px;">\
							<td style="padding: 0px 5px; text-align: right;"></td>\
							<td style="padding: 0px 5px; text-align: right; background: linear-gradient(90deg, #ffebed 0%, #ffebed 100%) 100% 50% no-repeat;"></td>\
						</tr>\
					</tbody>\
				</table>\
			</div>',
    defStyle: 
    {
        width:'400px', height:'463px'
    },
    
    events: ['dblclick', 'longtab', 'select', 'scrolltop', 'scrollbottom']
};

EXMiniHoga.prototype.init = function(context, evtListener)
{
	AGrid.prototype.init.call(this, context, evtListener);
	
	this.btmRowCnt = parseInt(this.getAttr('data-bottom-count'));

	cnt = this.getAttr('data-middle-count');
	if(cnt) this.midRowCnt = parseInt(cnt);
	
	this.rowLen = this.getRowCount() - this.btmRowCnt;
    this.colLen = this.getColumnCount();
	this.quoteCount = (this.rowLen - this.midRowCnt)/2;

	//중간가 로우가 없는 버전이므로 추가해준다.
	if(this.isDev() && !this.midRowCnt) //this.isDev()
	{
		this.rowLen += 1;
		this.midRowCnt = 1;
		this.setAttr('data-middle-count', this.midRowCnt);
		const $clone = $(this.getRow(1)).clone();
		$clone.css('display', 'none');	//setMidPriceMode fales(hide) 상태로 추가
		$clone.children().last().css('background', '');
		$(this.getRow(this.quoteCount-1)).after($clone);

		//매핑정보도 변경
		let queryNames = this.getAttr(afc.ATTR_QUERY_NAME);
		if(queryNames) {
			let keyBlocks, tmp, arr = new Array(this.colLen);
			arr.fill('');
			queryNames.split('|').forEach(qryName => {
				keyBlocks = this.getAttr('data-blocks-'+qryName).split('|');
				keyBlocks.forEach((block, i) => {
					tmp = block.split(',');
					tmp.splice((this.quoteCount*this.colLen)+1, 0, ...arr); //중간가 항목 추가
					keyBlocks[i] = tmp.join(',');
				});
				this.setAttr('data-blocks-'+qryName, keyBlocks.join('|'));
			});
		}

		this.initVariables();
		this.init(this.element);
		return;
	}
	
    //Current Price Cell Style
	this.setCurrentPriceStyleArr([
		this.getAttr('data-select-up'),
		this.getAttr('data-select-down'),
		this.getAttr('data-select-steady')
	]);
	
	// 현재가, 기준가 필드명
	this.curPriceKey = this.getAttr('data-field-curprc');
	this.basePriceKey = this.getAttr('data-field-baseprc');
	
	// 상승 하락 보합 색상
	this.setUpColor(this.getAttr('data-up-color'));
	this.setDownColor(this.getAttr('data-down-color'));
	this.setSteadyColor(this.getAttr('data-steady-color'));
	
	// 바 사이즈를 세팅하면 개발시점에는 잔량바를 표시한다.
	// ** 추후 아예 저장안되는 방법이 생기면 바꾸기
	this.setBarSize(this.getAttr('data-bar-size'));
	// 기본적으로 초기화 시점에는 잔량바가 표시되면 안되므로 초기화한다.
	this.initBar();
	
	// 개발시점에서는 선택이 되어야 셀정보를 변경하기 쉽기 때문에
	if(!this.isDev()) this.selectStyleName = null;
	
	this._clearValArr();

	this.setRateMode(this.getAttr('data-rate-mode'));
};

EXMiniHoga.prototype.clearContents = function()
{
	this._clearValArr();
    this.tBody.find('td').each(function()
    {
        this.textContent = '';
		if(this.dm) this.dm.setOriginal('');
		//this.style.background = '';
    });
	this.initBar();
};

EXMiniHoga.prototype.resetGrid = function()
{
	this._clearValArr();
	this.removeAll();
    this.addRow([]);
};

EXMiniHoga.prototype.setBasePrice = function(basePrice)
{
	if(!basePrice) basePrice = undefined;
	this.basePrice = basePrice;
	
	var i, mapCell, value, colIdx = 0;
	for(i=0; i<this.rowLen; i++)
	{
		mapCell = this.getCell(i, colIdx);
		if(mapCell.style.display == 'none') continue;

		value = this._valArr[i][colIdx];
		
		if(this.basePrice < value) mapCell.style.color = this.upColor;
		else if(this.basePrice > value) mapCell.style.color = this.downColor;
		else mapCell.style.color = this.steadyColor;
	}
};

EXMiniHoga.prototype.setBasePriceKey = function(basePriceKey)
{
	this.basePriceKey = basePriceKey;
};

EXMiniHoga.prototype.setCurrentPrice = function(currentPrice)
{
	this.currentPrice = currentPrice;
	
	var i, mapCell, value, colIdx = 0;
	for(i=0; i<this.rowLen; i++)
	{
		mapCell = this.getCell(i, colIdx);
		if(mapCell.style.display == 'none') continue;

		value = this._valArr[i][colIdx];

		// 현재가 세팅하기
		if(this.currentPrice == value)
		{
			this.selectCurrentCell(mapCell, true);
			// return;
		}
	}
};

EXMiniHoga.prototype.setCurPriceKey = function(keyName)
{
	this.curPriceKey = keyName;
};

EXMiniHoga.prototype.setUpColor = function(color)
{
	if(color) this.upColor = color;
};

EXMiniHoga.prototype.setDownColor = function(color)
{
	if(color) this.downColor = color;
};

EXMiniHoga.prototype.setSteadyColor = function(color)
{
	if(color) this.steadyColor = color;
};

EXMiniHoga.prototype.getUpColor = function(color)
{
	return this.upColor;
};

EXMiniHoga.prototype.getDownColor = function(color)
{
	return this.downColor;
};

EXMiniHoga.prototype.getSteadyColor = function(color)
{
	return this.steadyColor;
};

EXMiniHoga.prototype.setRateMode = function(enable)
{
	this.rateMode = enable;
};

EXMiniHoga.prototype.getRateMode = function()
{
	return this.rateMode;
};

EXMiniHoga.prototype.getRateSuffixStr = function()
{
	return this.rateSuffixStr;
};

EXMiniHoga.prototype.setRateSuffixStr = function(str)
{
	this.rateSuffixStr = str;
};

EXMiniHoga.prototype.selectCurrentCell = function(mapCell, isAdd)
{
	if(!isAdd) this._clearCurrentCell();

	let $cell = $(mapCell);
	this.currentCellArr.push($cell);
	
	if(this.basePrice == undefined) $cell.addClass(this.curPriceStyleArr[2]);
	else if(this.basePrice < this.currentPrice) $cell.addClass(this.curPriceStyleArr[0]);
	else if(this.basePrice > this.currentPrice) $cell.addClass(this.curPriceStyleArr[1]);
	else $cell.addClass(this.curPriceStyleArr[2]);

	this._currentCellBordoerRight = $cell[0].style.getPropertyValue('border-right');
	this._currentCellBordoerBottom = $cell[0].style.getPropertyValue('border-bottom');

	$cell[0].style.setProperty('border-right', 'none','important');
	$cell[0].style.setProperty('border-bottom', 'none','important');
};

EXMiniHoga.prototype._clearCurrentCell = function()
{
	this.currentCellArr.forEach($cell =>
	{
		$cell.removeClass(this.curPriceStyleArr[0]);
		$cell.removeClass(this.curPriceStyleArr[1]);
		$cell.removeClass(this.curPriceStyleArr[2]);
		$cell[0].style.setProperty('border-right', this._currentCellBordoerRight);
		$cell[0].style.setProperty('border-bottom', this._currentCellBordoerBottom);
	});

	this.currentCellArr.length = 0;
};

EXMiniHoga.prototype.setCurrentPriceStyleArr = function(styleArr)
{
	this.curPriceStyleArr = ['EXMiniHoga-CurPrice-Up', 'EXMiniHoga-CurPrice-Down', 'EXMiniHoga-CurPrice-Steady'];
	if(styleArr[0]) this.curPriceStyleArr[0] = styleArr[0];
	if(styleArr[1]) this.curPriceStyleArr[1] = styleArr[1];
	if(styleArr[2]) this.curPriceStyleArr[2] = styleArr[2];
};

EXMiniHoga.prototype.initBar = function()
{
	// 최대 10호가까지의 셀의 스타일을 초기화한다.
	var half = 10, cell;
	for(var i=0; i<half; i++)
	{
		cell = this.getCell(i, 1);
		if(cell) cell.style['background-size'] = '0px';//'0% ' + this.barSize;
		cell = this.getCell(i+half+this.midRowCnt, 1);
		if(cell) cell.style['background-size'] = '0px';//'0% ' + this.barSize;
	}
	
	if(this.isDev())
	{
		half = this.quoteCount;
		for(var i=0; i<half; i++)
		{
			//this.getCell(i, 0).style['background'] = ((i+1)/half*100)+'% ' + this.barSize;
			//this.getCell(i+half, 2).style['background'] = ((half-i)/half*100)+'% ' + this.barSize;
			this.getCell(i, 1).style['background-size'] = ((i+1)/half*100)+'% ' + this.barSize;
			this.getCell(i+half+this.midRowCnt, 1).style['background-size'] = ((half-i)/half*100)+'% ' + this.barSize;
		}
	}
};

//barSize - '7px', '80%' 등
EXMiniHoga.prototype.setBarSize = function(barSize)
{
	if(!barSize) barSize = '70%'
	this.barSize = barSize;
	
	var half = this.quoteCount, tmp;
	for(var i=0; i<half; i++)
	{
		tmp = this.getCell(i, 1).style['background-size'];
		if(tmp) tmp = tmp.split(' ')[0];
		else tmp = '0px';
		this.getCell(i, 1).style['background-size'] = tmp + ' ' + this.barSize;
		
		tmp = this.getCell(i+half+this.midRowCnt, 1).style['background-size'];
		if(tmp) tmp = tmp.split(' ')[0];
		else tmp = '0px';
		this.getCell(i+half+this.midRowCnt, 1).style['background-size'] = tmp + ' ' + this.barSize;
	}
};

EXMiniHoga.prototype.getBarSize = function()
{
	return this.barSize;
};

EXMiniHoga.prototype.setAskBarBgImg = function(bgImage)
{
	for(var i=0; i<this.quoteCount; i++)
	{
		this.getCell(i, 1).style['background-image'] = bgImage;
		this.getCell(i, 1).style['background-repeat'] = 'no-repeat';
	}
};

EXMiniHoga.prototype.getAskBarBgImg = function()
{
	return this.getCell(0, 1).style['background-image'];
};

EXMiniHoga.prototype.setBidBarBgImg = function(bgImage)
{
	for(var i=this.quoteCount+this.midRowCnt; i<this.rowLen; i++)
	{
		this.getCell(i, 1).style['background-image'] = bgImage;
		this.getCell(i, 1).style['background-repeat'] = 'no-repeat';
	}
};

EXMiniHoga.prototype.getBidBarBgImg = function()
{
	return this.getCell(this.quoteCount+this.midRowCnt, 1).style['background-image'];
};

EXMiniHoga.prototype.setAskBarPositionX = function(pos)
{
	for(var i=0; i<this.quoteCount; i++)
	{
		this.getCell(i, 1).style['background-position-x'] = pos;
	}
};

EXMiniHoga.prototype.getAskBarPositionX = function()
{
	return this.getCell(0, 1).style['background-position-x'];
};

EXMiniHoga.prototype.setAskBarPositionY = function(pos)
{
	for(var i=0; i<this.quoteCount; i++)
	{
		this.getCell(i, 1).style['background-position-y'] = pos;
	}
};

EXMiniHoga.prototype.getAskBarPositionY = function()
{
	return this.getCell(0, 1).style['background-position-y'];
};

EXMiniHoga.prototype.setBidBarPositionX = function(pos)
{
	for(var i=this.quoteCount+this.midRowCnt; i<this.rowLen; i++)
	{
		this.getCell(i, 1).style['background-position-x'] = pos;
	}
};

EXMiniHoga.prototype.getBidBarPositionX = function()
{
	return this.getCell(this.quoteCount+this.midRowCnt, 1).style['background-position-x'];
};

EXMiniHoga.prototype.setBidBarPositionY = function(pos)
{
	for(var i=this.quoteCount+this.midRowCnt; i<this.rowLen; i++)
	{
		this.getCell(i, 1).style['background-position-y'] = pos;
	}
};

EXMiniHoga.prototype.getBidBarPositionY = function()
{
	return this.getCell(this.quoteCount+this.midRowCnt, 1).style['background-position-y'];
};

EXMiniHoga.prototype.setBottomRowCount = function(btmRowCnt)
{
	if(btmRowCnt < 0) btmRowCnt = 0;
	this.btmRowCnt = btmRowCnt = btmRowCnt*1;
	this.changeRowCount(this.rowLen + btmRowCnt, false);
};

EXMiniHoga.prototype.getBottomRowCount = function()
{
	return this.btmRowCnt;
};

EXMiniHoga.prototype.setQuoteCount = function(cnt)
{
	cnt = cnt * 1;
	if(cnt == 10)
	{
		var $row = $(this.getRow(1));
		for(var i=this.quoteCount; i<cnt; i++) $row.after($row.clone());
		//this.getCell(0,2).setAttribute('rowspan', cnt);
		
		$row = $(this.getRow(cnt+1));
		for(var i=this.quoteCount; i<cnt; i++) $row.after($row.clone());
		//this.getCell(cnt,0).setAttribute('rowspan', cnt);
	}
	else if(cnt == 5)
	{
		// rowspan 값 변경 및 로우 제거
		//this.getCell(this.quoteCount,0).setAttribute('rowspan', cnt);
		for(var i=0; i<cnt; i++) this.removeRow(this.quoteCount+1);	
		
		// rowspan 값 변경 및 로우 제거
		//this.getCell(0,2).setAttribute('rowspan', cnt);
		for(var i=0; i<cnt; i++) this.removeRow(1);
	}

	this.initVariables();
	this.init(this.element);
	
	if(this.delegator && this.delegator.onRowCountChange) this.delegator.onRowCountChange();
};

EXMiniHoga.prototype.getQuoteCount = function()
{
	return this.quoteCount;
};

// 델리게이터를 설정한 객체에 quoteCount가 변경될 때, bottomRowCount가 변경될 때
// change 이벤트로 알려준다.
EXMiniHoga.prototype.setDelegator = function(delegator)
{
	this.delegator = delegator;
};

//기존 Hoga데이터에 Contrast Ratio를 덧붙인다. 
EXMiniHoga.prototype.toggleRateMode = function()
{
	if(this.rateMode)
	{
		this.rateMode = false;
		for(var i=0; i<this.rowLen; i++)
		{
			$($(this.getCell(i, 0)).children()[0]).remove();
		}
	}
	else
	{
		this.rateMode = true;
		var value, $cell;
		for(var i=0; i<this.rowLen; i++)
		{
			$cell = $(this.getCell(i, 0));
			value = $cell.text();
			if(value.trim()) this.setRateTag(value, $cell[0]);//$cell.append(this.setRateTag(value));//, afc.toFixed2, this.basePrice));
		}
	}
};

EXMiniHoga.prototype.setRateTag = function(value, ele)
{
	var txt = '';
	if(this.basePrice)
	{
		// value가 0인 경우는 값을 세팅하지 않는다.
		if(value)
		{
			value = ADataMask.Number.removeComma.func(value) - this.basePrice;
			txt = ADataMask.Number.money.func(((value/this.basePrice)*100).toFixed(2)) + this.rateSuffixStr;
		}
	}
	else txt = ' - ';

	if(txt == '') txt = '　';
	if(ele.lastElementChild) ele.lastElementChild.textContent = txt;
	else $(ele).append('<span class="'+this.rateClass+'" style="padding:0 0 0 10px; display: block; ' + this.rateStyle + '">'+ txt + '</span>');
};

EXMiniHoga.prototype.setMidPriceMode = function(isMidPriceMode)
{
	if(!this.midRowCnt) return;

	this.getRow(this.quoteCount).style.display = isMidPriceMode?'':'none';
};

EXMiniHoga.prototype.getMidPriceMode = function()
{
	if(!this.midRowCnt) return;

	return this.getRow(this.quoteCount).style.display!='none';
};

EXMiniHoga.prototype.setQueryData = function(dataArr, keyArr, queryData)
{
	if(!keyArr) return;
	var data = dataArr[0];
	
	// ------------------------------------------------------------------
	// 키에 해당하는 값이 있는 경우 현재가와 기준가를 세팅한다.
	// ------------------------------------------------------------------
	if(data[this.curPriceKey]) this.currentPrice = data[this.curPriceKey];
	if(data[this.basePriceKey]) this.basePrice = data[this.basePriceKey];
	
	var row, keyName, inx = -1, value = 0, maxQty = 0, i, j, mapCell;

	this._clearCurrentCell();

	// ------------------------------------------------------------------
	// 그리드의 셀과 동일한 구조로 데이터를 저장한다.
	// 잔량 최대값을 구한다. 구하는 위치는 고정 (0,0)~(0,9) (10,2)~(19,2)
	// 현재가가 위치한 셀을 선택처리한다.
	// ------------------------------------------------------------------
	for(i=0; i<this.rowLen; i++)
	{
		row = this.getRow(i);
		for(j=0; j<this.columnCount; j++)
		{
			mapCell = this.getCell(row, j);
			if(mapCell.style.display == 'none') continue;

			inx++;
			keyName = keyArr[inx];
			if(!keyName) continue;

			value = this._valArr[i][j] = data[keyName]*1;
			if(j==0)
			{
				// 현재가 세팅하기
				if(this.currentPrice == value) this.selectCurrentCell(mapCell, true);
				
				if(this.basePrice < value) mapCell.style.color = this.upColor;
				else if(this.basePrice > value) mapCell.style.color = this.downColor;
				else mapCell.style.color = this.steadyColor;
				// continue;
			}

			if(maxQty < value) maxQty = value;
		}
	}

	// ------------------------------------------------------------------
	// 기존 그리드처럼 데이터를 세팅한다.
	// ------------------------------------------------------------------
	AGrid.prototype.setQueryData.call(this, dataArr, keyArr, queryData);

	// 최대값이 0일때 잔량표시바가 갱신되지않아서 maxQty값을 1로 세팅
	if(maxQty == 0) maxQty = 1;


	// ------------------------------------------------------------------
	// 잔량표시바를 값에 맞는값으로 세팅한다.
	// ------------------------------------------------------------------
	inx=-1;
	for(i=0; i<this.rowLen; i++)
	{
		row = this.getRow(i);
		for(j=0; j<this.columnCount; j++)
		{
			if(i == this.quoteCount) continue;

			mapCell = this.getCell(row, j);
			if(mapCell.style.display == 'none') continue;

			inx++;
			value = this._valArr[i][j];
			if(j==0)
			{
				if(this.rateMode) this.setRateTag(value, mapCell);
				continue;
			}

			keyName = keyArr[inx];
			if(!keyName) continue;

			value = this._valArr[i][j];
			mapCell.style.setProperty("background-size", (value/maxQty*100).toFixed(1)+'% ' + this.barSize, 'important');
			//mapCell.style.setProperty("background-size", parseInt(value/maxQty*100, 10)+'% ' + this.barSize, 'important');
		}
	}
};

EXMiniHoga.prototype._getDataStyleObj = function()
{
	var ret = AComponent.prototype._getDataStyleObj.call(this);
	
	var keyArr = ['data-select-class', 'data-style-header', 'data-style-body',
				  'data-select-up', 'data-select-down', 'data-select-steady'], val;
	
	for(var i=0; i<keyArr.length; i++)
	{
		if(i==1) val = this.$ele.find('thead').attr(keyArr[i]);
		else if(i==2) val = this.$ele.find('tbody').attr(keyArr[i]);
		else val = this.getAttr(keyArr[i]);	//data-select-class

		//attr value 에 null 이나 undefined 가 들어가지 않도록
		ret[keyArr[i]] = val ? val : '';
	}
	
	return ret;
};

// object 형식의 css class 값을 컴포넌트에 셋팅한다.
// default style 값만 셋팅한다.
EXMiniHoga.prototype._setDataStyleObj = function(styleObj)
{
	for(var p in styleObj)
	{
		if(p==afc.ATTR_STYLE) this._set_class_helper(this.$ele, null, styleObj, p);	//화면에 바로 적용
		else if(p=='data-style-header') this._set_class_helper(this.$ele.find('thead'), null, styleObj, p);	//화면에 바로 적용
		else if(p=='data-style-body') this._set_class_helper(this.$ele.find('tbody'), null, styleObj, p);	//화면에 바로 적용
		else this.setAttr(p, styleObj[p]);	//data-select-class, attr 값만 셋팅
	}
};

EXMiniHoga.prototype._clearValArr = function()
{
	// 값 저장 배열(2차원), 초기화
	this._valArr = new Array(this.rowLen);
	for(var i=0; i<this.rowLen; i++)
	{
		this._valArr[i] = new Array(this.colLen);
		for(var j=0; j<this.colLen; j++)
			this._valArr[i][j] = 0;
	}
};
                    
//window.EXMiniHoga = EXMiniHoga;
                    
})();