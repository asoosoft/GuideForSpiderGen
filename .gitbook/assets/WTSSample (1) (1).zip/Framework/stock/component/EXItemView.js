(async function(){          

afc.import("Framework/stock/component/EXSearchView.js");
afc.import("Framework/stock/library/HistoryInfo.js");

await afc.import("Framework/stock/library/MasterInfo.js");


/**
 * @author 
 * history의 구조는 무조건 [code, name, type] 으로 구성한다.
 * itemInfo 외의 정보를 조회하기 위해서는 masterInfo의 getItemByInfo 를 사용한다.
 */

EXItemView = class EXItemView extends AView
{
    constructor()
    {
        super();

        this.frwName = 'stock';
        this.dropMaxCount = 5;
        this.typeArr = null;
        this.unshift = false;
    }
}

//window.EXItemView = EXItemView;

EXItemView.prototype.init = function(context, evtListener)
{
    AView.prototype.init.call(this, context, evtListener);
	
	// 종목 타입을 지정한다.
	var keys = this.getAttr('data-type-keys');
	if(keys)
	{
		keys = keys.split(',');
		keys.forEach(function(t, i, a){ a[i] = t.trim(); });
		this.setTypeArr(keys);
	}
	
	// 종목 예외 키를 지정한다.
	keys = this.getAttr('data-except-keys');
	if(keys)
	{
		keys = keys.split(',');
		keys.forEach(function(t, i, a){ a[i] = t.trim(); });
		this.setExceptArr(keys);
	}
	/*
	this.dropUrl = this.getAttr('data-drop-url');
	this.searchUrl = this.getAttr('data-search-url');
	
	this.dropMaxCount = this.getAttr('data-drop-count');
	if(!this.dropMaxCount) this.dropMaxCount = 5;
	*/
	const searchTxf = this.findCompById('searchTxf')
	if(searchTxf && searchTxf.setText) this.searchTxf = searchTxf;
	
	/*
	if(!this.searchTxf.events['change']) this.searchTxf.addEventListener('change', this, 'onTextFieldChange');
	if(!this.searchTxf.events['focus']) this.searchTxf.addEventListener('focus', this, 'onTextFieldFocus');
	if(!this.searchTxf.events['blur']) this.searchTxf.addEventListener('blur', this, 'onTextFieldBlur');
	if(!this.searchTxf.events['actionup']) this.searchTxf.addEventListener('actionup', this, 'onTextFieldActionUp');
	
	if(!children[1].events['click']) children[1].addEventListener('click', this, 'onDropBtnClick');
	if(!children[2].events['click']) children[2].addEventListener('click', this, 'onOpenSearchBtnClick');*/
};

EXItemView.CONTEXT = 
{
    tag:'<div data-base="EXItemView" data-class="EXItemView" class="AView-Style">\
			<div data-base="AView" data-class="AView" class="AView-Style" style="width: 100%; height: 50%; left: 0px; top: 0px; background: transparent;">\
				<input data-base="ATextField" data-class="ATextField" type="text" value="" class="ATextField-Style" data-sgap-width="1" data-stretch-width="true" data-sgap-height="1" data-stretch-height="true" style="left: 10px; top: 10px; width: calc((100% - 10px) - 100px); height: calc((100% - 10px) - 10px);"/>\
				<button data-base="AButton" data-class="AButton" class="AButton-Style" data-sgap-height="1" data-stretch-height="true" style="right: 60px; top: 10px; width: 40px; height: calc((100% - 10px) - 10px);"></button>\
				<button data-base="AButton" data-class="AButton" class="AButton-Style" style="right: 10px; width: 40px; height: calc((100% - 10px) - 10px); top: 10px;" data-sgap-height="1" data-stretch-height="true"></button>\
			</div>\
			<div data-base="AView" data-class="AView" class="AView-Style" style="width: 100%; height: 50%; left: 0px; top: 50%; background: transparent;">\
				<div class="AFlexLayout-Style" data-base="AFlexLayout" data-class="AFlexLayout" style="width: auto; height: 100%; top: 0px; align-items: center; place-content: flex-start; left: 30px;">\
            		<div>\
                		<span data-class="ALabel" data-maskfunc="Number.money" data-base="ALabel" class="ALabel-Style" data-maskorigin="" data-maskparam="&quot;&quot;" style="width: auto; height: auto; left: 0px; top: 0px; position: relative; font-size: 24px;"></span>\
            </div>\
            <div><label class="ALabel-Style" data-base="ALabel" data-class="ALabel" style="width: auto; height: auto; left: 0px; top: 0px; font-size: 24px; color: rgb(141, 141, 141); position: relative; margin-left: 10px;"></label></div>\
        </div><div class="AFlexLayout-Style dev_AFlexLayout_Style dev_AFlexLayout-Style" data-base="AFlexLayout" data-class="AFlexLayout" style="width: auto; height: auto; place-content: flex-start flex-end; align-items: center; right: 30px; bottom: 50%; margin-bottom: -2px;">\
            <div>\
                <div class="EXTriangle-Style" color-arrow-down="#418dff" color-arrow-up="#ff5353" data-base="EXTriangle" data-class="EXTriangle" style="width: 10px; height: 10px; overflow: visible; position: relative; left: 0px; top: 1px;">\
                    <div style="border-style: solid; width: 0px; height: 0px; border-color: transparent; border-width: 0px; margin-top: 0px;"></div>\
                    <div style="margin: 0px auto; width: 4px; height: 6px; background: transparent;"></div>\
                </div>\
            </div>\
            <div>\
                <span data-class="ALabel" data-maskfunc="Number.abs|Number.money" data-base="ALabel" class="ALabel-Style" data-maskorigin="" data-maskparam="&quot;&quot;|&quot;&quot;" style="width: auto; height: auto; position: relative; margin-left: 5px; left: 0px; top: 0px; font-size: 24px;"></span>\
            </div>\
            <div><span data-class="ALabel" data-maskfunc="Number.abs|Number.percent" data-base="ALabel" class="ALabel-Style" data-maskorigin="" data-maskparam="&quot;&quot;|&quot;&quot;" style="width: auto; height: auto; position: relative; margin-left: 15px; left: 0px; top: 0px; font-size: 24px;">%</span></div>\
        </div><label data-maskorigin="" class="ALabel-Style NotoSansKR-Medium SZ18" data-base="ALabel" data-class="ALabel" data-maskfunc="Number.money" data-maskparam="&quot;&quot;" data-style="NotoSansKR-Medium SZ18" style="width: auto; height: auto; position: absolute; top: 30px; color: rgb(0, 0, 0); right: 30px; margin-top: -2px; font-size: 24px;"></label></div>\
			</div>\
		</div>',

    defStyle: 
    {
        width:'100%', height:'120px'
    },

    //events: ['swipe', 'longtab', 'scroll', 'scrollleft', 'scrollright', 'scrolltop', 'scrollbottom', 'drop', 'dragStart', 'dragEnd' ]
    events: ['change', 'swipe', 'longtab', 'scroll', 'scrollleft', 'scrollright', 'scrolltop', 'scrollbottom' ]
};

EXItemView.historyInfo = new HistoryInfo();	//{getRecent:function(){}, search:function(){}, set:function(){}, saveInfo:function(){}};
EXItemView.masterInfo = new MasterInfo();	//{get:function(){}, getInfoByItem:function(){}, getDefaultItemInfo:function(){}, getItem:function(){}};

// 히스토리를 관리할 객체를 지정하는 함수
EXItemView.setHistoryInfo = function(historyInfo)
{
	EXItemView.historyInfo = historyInfo;
};

// 히스토리를 관리할 객체를 리턴하는 함수
EXItemView.getHistoryInfo = function()
{
	return EXItemView.historyInfo;
};

// 전체 종목을 관리하는 객체를 지정하는 함수
EXItemView.setMasterInfo = function(masterInfo)
{
	EXItemView.masterInfo = masterInfo;
};

// 전체 종목을 저장하는 함수
EXItemView.getMasterInfo = function()
{
	return EXItemView.masterInfo;
};

/*
// 타입에 해당하는 Item 들을 리턴한다.
EXItemView.prototype.getItemsOfTypes = function(typeArr)
{
	if(EXItemView.masterInfo.getItemsOfTypes) return EXItemView.masterInfo.getItemsOfTypes(typeArr);
	else return null;
};*/

EXItemView.prototype.setItemInfo = function(itemInfo, isReport)
{
	// 최근 종목 세팅
	if(!itemInfo) itemInfo = EXItemView.historyInfo.getRecent(this.typeArr);
	
	// 기본 종목 세팅
 	if(!itemInfo) itemInfo = EXItemView.masterInfo.getDefaultItemInfo(this.typeArr);
	
	EXItemView.historyInfo.set(itemInfo, this.unshift);
	EXItemView.historyInfo.saveInfo();
	
	this.itemInfo = itemInfo;
	this.setText(itemInfo[1]);

	if(isReport) this.reportEvent('change', itemInfo);
};

EXItemView.prototype.getItemInfo = function()
{
	return this.itemInfo;
};

EXItemView.prototype.setText = function(text)
{
	if(this.searchTxf && this.searchTxf.setText) this.searchTxf.setText(text);
};

EXItemView.prototype.getItem = function()
{
	if(this.itemInfo)
	{
		return EXItemView.masterInfo.getItem(this.itemInfo[0], this.itemInfo[2]);
	}
};

// 종목 중 원하는 타입 배열을 저장한다.
EXItemView.prototype.setTypeArr = function(typeArr)
{
	this.typeArr = typeArr;
};

// 타입배열을 리턴한다.
EXItemView.prototype.getTypeArr = function()
{
	return this.typeArr;
};

// 종목 검색시 제외할 키 배열을 저장한다.
EXItemView.prototype.setExceptArr = function(exceptArr)
{
	this.exceptArr = exceptArr;
};

// 제외할 키 배열을 리턴한다.
EXItemView.prototype.getExceptArr = function()
{
	return this.exceptArr;
};

EXItemView.prototype.setDropMaxCount = function(dropMaxCount)
{
	this.dropMaxCount = dropMaxCount;
};

EXItemView.prototype.getDropMaxCount = function()
{
	return this.dropMaxCount;
};

EXItemView.prototype.openDrop = function(itemsArr)
{
	// 개발 시점에는 드랍뷰를 띄우지 않는다.
	if(this.isDev()) return;
	if(!this.searchTxf) return;

	var thisObj = this, winH = 0,
		$search	= this.searchTxf.$ele,
		txfH = this.searchTxf.getHeight();
	
	if(itemsArr)
	{
		winH = itemsArr.length * txfH + 1;
		if(itemsArr.length > this.dropMaxCount) winH = this.dropMaxCount * txfH + 1;
	}
	
	if(this.dropWin)
	{
		this.dropWin.setHeight(winH);

		if(this.dropWin.getView().setData) this.dropWin.getView().setData(itemsArr);
		else
		{
			var dropGrid = this.dropWin.getView().getChildren()[0];
			dropGrid.removeAll();
			for(var i=0; i<itemsArr.length; i++)
			{
				dropGrid.addRowWithData([itemsArr[i][1]], itemsArr[i]);
			}
		}
	}
	else
	{
		if(!itemsArr || itemsArr.length == 0) return;

		this.dropWin = new AWindow('SearchDropView');
		this.dropWin.setWindowOption({
			isModal: true,
			isFocusLostClose: true,	//모달인 경우 포커스를 잃을 때 창을 닫을지
			modalBgOption: 'none'	//none, light, dark 모달인 경우 배경을 어둡기 정도
		});

		this.dropWin.open('Framework/stock/layout/dropview.html', this.getContainer(), $search.offset().left, $search.offset().top+$search.outerHeight(), $search.outerWidth(), winH)
		.then(function()
		{
			var dropGrid = thisObj.dropWin.getView().getChildren()[0];
			dropGrid.$rowTmpl.attr('height', txfH);
			dropGrid.addEventListener('select', thisObj, 'onDropGridSelect');
			for(var i=0; i<itemsArr.length; i++)
			{
				dropGrid.addRowWithData([itemsArr[i][1]], itemsArr[i]);
			}
		});

		this.dropWin.setResultCallback(function(result, itemInfo)
		{
			thisObj.dropWin = null;
			if(result==0)
			{
				thisObj.setItemInfo(itemInfo, true);
			}
		});
	}
};

EXItemView.prototype.openSearchWindow = async function()
{
	// 개발 시점에는 검색창을 띄우지 않는다.
	if(this.isDev()) return;
	
	var thisObj = this,
		win;
	
	win = this.searchWin = new AFrameWnd('SearchWindow');
	var sview = new EXSearchView();
	sview.init();
	sview.setStyleObj({width: '100%', height: '100%', position:'relative', background: 'white'});
	win.setWindowOption({
		isModal: true,
		isFocusLostClose: true,
		isResizable: false
	});
	await win.openFull(sview, this.getContainer());
	win.setTitleText('');

	sview.setData(EXItemView.masterInfo.get());
	var view = sview.getChildren()[0];

	sview.txf = view.getChildren()[0];
	sview.btn = view.getChildren()[1];
	sview.grd = sview.getChildren()[1];

	view.setStyle('background','transparent');
	sview.btn.setText('검색');
	sview.btn.setStyleObj({
		'background-image': 'linear-gradient(rgb(255, 255, 255), rgb(234, 234, 234) 100%)',
		'border': '1px solid rgb(193, 193, 193)'
	});
	sview.txf.setStyle('background','transparent');

	sview.txf.addEventListener('change', this, 'onSearchTextFieldChange');
	sview.btn.addEventListener('click', this, 'onSearchTextFieldChange');
	sview.grd.addEventListener('select', this, 'onSearchGridSelect');
	var result = sview.searchData(null, this.typeArr, this.exceptArr);
	for(var i=0; i<result.length; i++)
	{
		sview.grd.addRowWithData([EXItemView.masterInfo.getInfoByItem(result[i])[1]], result[i]);
	}
	
	win.setResultCallback(function(result, item)
	{
		thisObj.searchWin = null;
		if(result==0)
		{
			thisObj.setItemInfo(EXItemView.masterInfo.getInfoByItem(item), true);
		}
	});
};
/*
//--------------------------------------------------------------------------------------------------------------
// 검색어가 변경될 때 호출되는 이벤트 함수
EXItemView.prototype.onTextFieldChange = function(comp, info, e)
{
	var itemsArr;
	itemsArr = EXItemView.historyInfo.search(info, this.typeArr);
	this.openDrop(itemsArr);
};

EXItemView.prototype.onTextFieldFocus = function(comp, info, e)
{
	comp.setText('');
	var itemsArr = EXItemView.historyInfo.search('', this.typeArr);
	this.openDrop(itemsArr);
};

EXItemView.prototype.onTextFieldActionUp = function(comp, info, e)
{
	comp.setText('');
	var itemsArr = EXItemView.historyInfo.search('', this.typeArr);
	this.openDrop(itemsArr);
	comp.get$ele().focus();
};

EXItemView.prototype.onTextFieldBlur = function(comp, info, e)
{
	this.setText( this.getItem() );
};

EXItemView.prototype.onDropBtnClick = function(comp, info, e)
{
	this.openDrop( EXItemView.historyInfo.search('', this.typeArr) );
};

EXItemView.prototype.onOpenSearchBtnClick = function(comp, info, e)
{
	this.openSearchWindow();
};*/
//--------------------------------------------------------------------------------------------------------------
// 검색 윈도우
// 검색시 호출되는 함수
EXItemView.prototype.onSearchTextFieldChange = function(comp, info, e)
{
	var sview = this.searchWin.getView();
	var result = sview.searchData(sview.txf.getText(), this.typeArr, this.exceptArr);
	sview.grd.removeAll();
	for(var i=0; i<result.length; i++)
	{
		sview.grd.addRowWithData([EXItemView.masterInfo.getInfoByItem(result[i])[1]], result[i]);
	}
};

// 그리드의 로우를 클릭시 호출되는 함수
EXItemView.prototype.onSearchGridSelect = function(comp, info, e)
{
	if(this.searchWin)
	{
		this.searchWin.close(0, comp.getDataByOption(info));
	}
};
//--------------------------------------------------------------------------------------------------------------
// 드랍 윈도우
// 그리드의 로우를 클릭시 호출되는 함수
EXItemView.prototype.onDropGridSelect = function(comp, info, e)
{
	if(this.dropWin)
	{
		var data = comp.getDataByOption(info);
		this.dropWin.close(0, data);
	}
};
//--------------------------------------------------------------------------------------------------------------


//window.EXItemView = EXItemView;


})();