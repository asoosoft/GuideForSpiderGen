                  
//afc.import("Framework/afc/component/AGrid.js");

/**
 * @author asoocool
 */

class EXPivotView extends AView
{
    constructor()
    {
        super();
        
        this.frwName = 'stock';
        
        this.pivotGrid = null;
        this.scrollGrid = null;
        //좌우 스크롤 뷰
        this.scrollView = null;
    }
}

window.EXPivotView = EXPivotView;

EXPivotView.CONTEXT = 
{
    tag: '<div data-flag="0100" data-base="EXPivotView" data-class="EXPivotView" class="AView-Style EXPivotView-Style">\
    		<div data-base="AGrid" data-class="AGrid" data-selectable="true" data-clear-rowtmpl="true" class="AGrid-Style" style="left:0px; top:0px; width:25%; height:100%;">\
				<table class="grid-header-table" align="center" style="width:100%; border-collapse:collapse; table-layout: fixed;">\
					<colgroup><col></colgroup>\
					<thead align="center" class="head-prop">\
						<tr height="22px"><td>col1</td></tr>\
					</thead>\
				</table>\
				<div style="height:100%; overflow-y:auto; overflow-x:hidden; -webkit-overflow-scrolling:touch;">\
					<table class="grid-body-table" align="center" style="width:100%; border-collapse:collapse; table-layout: fixed;">\
						<colgroup><col></colgroup>\
						<thead align="center" class="head-prop">\
							<tr height="22px"><td>col1</td></tr>\
						</thead>\
						<tbody align="center" class="body-prop">\
							<tr height="22px"><td>data 1,1</td></tr>\
						</tbody>\
					</table>\
				</div>\
			</div>\
	        <div data-base="AView" data-class="AView" class="AView-Style" style="left:25%; top:0px; width:75%; height:100%;">\
	    		<div data-base="AGrid" data-class="AGrid" data-selectable="true" data-clear-rowtmpl="true" class="AGrid-Style" style="left:0px; top:0px; width:225%; height:100%;">\
					<table class="grid-header-table" align="center" style="width:100%; border-collapse:collapse; table-layout: fixed;">\
						<colgroup><col><col><col></colgroup>\
						<thead align="center" class="head-prop">\
							<tr height="22px"><td>col1</td><td>col2</td><td>col3</td></tr>\
						</thead>\
					</table>\
					<div style="height:100%; overflow-y:auto; overflow-x:hidden; -webkit-overflow-scrolling:touch;">\
						<table class="grid-body-table" align="center" style="width:100%; border-collapse:collapse; table-layout: fixed;">\
							<colgroup><col><col><col></colgroup>\
							<thead align="center" class="head-prop">\
								<tr height="22px"><td>col1</td><td>col2</td><td>col3</td></tr>\
							</thead>\
							<tbody align="center" class="body-prop">\
								<tr height="22px"><td>data 1,1</td><td>data 1,2</td><td>data 1,3</td></tr>\
							</tbody>\
						</table>\
					</div>\
				</div>\
	         </div>\
         </div>',
    defStyle: 
    {
        width:'400px', height:'300px'
    },
    
    events: ['swipe']
};

EXPivotView.prototype.beforeInit = function()
{
	//피봇 그리드는 무조건 fullrow select 롤 셋팅
	this.element.children[0].setAttribute('data-fullrow-select', true);
	this.element.children[1].children[0].setAttribute('data-fullrow-select', true);
};

EXPivotView.prototype.init = function(context, evtListener)
{
	AView.prototype.init.call(this, context, evtListener);
	
	var thisObj = this, children = this.getChildren();
	
	this.pivotGrid = children[0];
	this.scrollView = children[1];
	this.scrollGrid = this.scrollView.getChildren()[0];
	this.scrollGrid.isStoppagation = false;
	
	this.pivotGrid.setStyle('z-index', '2');
	this.scrollView.setStyle('z-index', '1');

	this.pivotGrid.enableScrlManager(null, this.scrollGrid.scrollArea[0]);
	this.scrollGrid.enableScrlManager(this.pivotGrid.scrollArea[0], null);
	this.scrollView.enableScrlManagerX();
	
	this.scrollView.scrlManagerX.addDisableManager(this.scrollGrid.scrlManager);
	this.scrollGrid.scrlManager.addDisableManager(this.scrollView.scrlManagerX);
	
	//피봇 그리드는 무조건 fullrow select 롤 셋팅
	//this.pivotGrid.option.isFullRowSelect = this.scrollGrid.option.isFullRowSelect = true;
	
	//두 값이 다르면 true 로 셋팅
	if(this.pivotGrid.option.isSingleSelect!=this.scrollGrid.option.isSingleSelect)
	{
		this.pivotGrid.option.isSingleSelect = this.scrollGrid.option.isSingleSelect = true;
	}
	
	
	// 런타임
	if(!this.isDev())
	{
		//개발중에는 선택 이벤트를 수정하지 않는다.
		
		//두 개의 그리드의 selectCell 함수 변경
		this.setAllGridSelect();
		
		//EXPivotVIew-Style 안의 pivotGrid, scrollGrid, scrollView의 스크롤바를 display: none; 처리를 했기 떄문에 스크롤 영역 체크하지 않게 처리한다.
		this.addClass('EXPivotView-Style');
		this.pivotGrid.isCheckScrl = false;
		this.scrollGrid.isCheckScrl = false;
		
		//스크롤Arrow 태그가 저장되므로 런타임에만 생성시킨다.
		// 그리드 옵션 해더 숨길시 스크롤 top 0으로 셋팅
		//this.pivotGrid.setScrollArrow();
	}
	
	if(afc.isScrollIndicator) this.enableScrollIndicator();
};

EXPivotView.prototype.enableScrollIndicator = function()
{
	var thisObj = this;
	
	//자동으로 생성된 pivotGrid 의 스크롤 인디케이터는 제거하고
	this.pivotGrid.scrlIndicator.destroy();
	this.pivotGrid.scrlIndicator = null;
	
	//우측의 스크롤 그리드의 스크롤 인디케이터의 위치를 보정하기 위해...
	//callback 으로 필요한 시점에 호출된다.
	this.scrollGrid.scrlIndicator.resetScrollPos(function()
	{
		if(!thisObj.isValid() || !thisObj.scrollView.isValid()) return;
		//우측의 스크롤 그리드의 스크롤 인디케이터의 위치를 보정한다.
		var newLeft = thisObj.scrollView.getWidth() + thisObj.scrollView.element.scrollLeft - ScrollIndicator.scrlWidth;
		
		// 'this' is scrollIndicator
		this.setStyle({left: newLeft+'px', right:''});
	});
	
	//상하 스크롤은 하지 않으므로 제거
	if(this.scrollView.scrlIndicatorY)
	{
		this.scrollView.scrlIndicatorY.destroy();
		this.scrollView.scrlIndicatorY = null;
	
	}
	
	//scrollView 의 스크롤이 발생하면 scrollGrid 의 ScrollIndicator 같이 움직이는 현상을 방지한다.
	this.scrollView.element.addEventListener('scroll', function(e)
	{
		thisObj.scrollGrid.scrlIndicator.hide();
	});
	
};

//EXPivotView 가 스크롤 가능 영역에 추가되어져 있을 경우
//EXPivotView 스크롤이 끝나고(ex, scrollBottom) 상위 스크롤이 연속적으로 발생되도록 하려면
//상위 스크롤은 enableScrlManager 가 호출되어져야 하고 자신은 overscrollBehavior 함수를 호출해야 한다.
EXPivotView.prototype.overscrollBehavior = function(disableScrlManager)
{
	this.pivotGrid.overscrollBehavior(disableScrlManager);
	this.scrollGrid.overscrollBehavior(disableScrlManager);
};

//------------------------------------------------------------------------------------------

EXPivotView.prototype.lockScrollView = function()
{
	this.scrollView.scrlManagerX.removeAllDisableManager();
	this.scrollGrid.scrlManager.removeAllDisableManager();
	this.scrollView.scrlManagerX.enableScroll(false);
};

EXPivotView.prototype.unlockScrollView = function()
{
	this.scrollView.scrlManagerX.addDisableManager(this.scrollGrid.scrlManager);
	this.scrollGrid.scrlManager.addDisableManager(this.scrollView.scrlManagerX);
	this.scrollView.scrlManagerX.enableScroll(true);
};


EXPivotView.prototype.scrollViewLeft = function()
{
	this.scrollView.element.scrollLeft = this.scrollGrid.getWidth();
};

//하나의 row 를 추가한다.
EXPivotView.prototype.addRow = function(pivotData, scrollData)
{
	var row1 = this.pivotGrid.addRow(pivotData),
		row2 = this.scrollGrid.addRow(scrollData);

	//this._heightSync(row1, row2);

	return [row1, row2];
};

EXPivotView.prototype.prependRow = function(pivotData, scrollData)
{
	var row1 = this.pivotGrid.prependRow(pivotData),
		row2 = this.scrollGrid.prependRow(scrollData);
		
	//this._heightSync(row1, row2);

	return [row1, row2];
};

EXPivotView.prototype.setRow = function(rowInx, pivotData, scrollData, start, end)
{
	var row1 = this.pivotGrid.setRow(rowInx, pivotData, start, end);
	var row2 = this.scrollGrid.setRow(rowInx, scrollData, start, end);
	
	//this._heightSync(row1, row2);
	
	return [row1, row2];
};

//row가 여러줄 일 경우 다 같이 높이가 변한다.
/*
EXPivotView.prototype._heightSync = function(row1, row2)
{
	//height() 함수 호출이, 시간 소요가 크다.
	var h1 = row1.height(), h2 = row2.height();

	//컨텐츠에 따라 두 row 의 높이가 달라진 경우 높이를 맞춰준다. 대부분 같으므로 아래와 같이 처리하는 것이 성능에 유리
	if(h1!=h2)
	{
		var h = Math.max(h1, h2);
		row1.height(h);
		row2.height(h);
		
		//cell 의 높이를 직접 셋팅한 경우는 작동하지 않는지 테스트 필요, 안되면 다음과 같이
		//row1.children().height(h);
		//row2.children().height(h);
	}
};
*/

EXPivotView.prototype.removeRow = function(rowIdx)
{
	this.pivotGrid.removeRow(rowIdx);
	this.scrollGrid.removeRow(rowIdx);
};

EXPivotView.prototype.removeFirst = function()
{
	this.pivotGrid.removeFirst();
	this.scrollGrid.removeFirst();
};

EXPivotView.prototype.removeLast = function()
{
	this.pivotGrid.removeLast();
	this.scrollGrid.removeLast();
};

// 오작동으로 인해 주석처리, 필요하다면 hide, show override 처리
/*
EXPivotView.prototype.show = function(showType)
{
	this.pivotGrid.show(showType);
	this.scrollGrid.show(showType);

	//AView.prototype.show.call(this, showType);
};
*/

EXPivotView.prototype.removeAll = function()
{
	this.pivotGrid.removeAll();
	this.scrollGrid.removeAll();
};

EXPivotView.prototype.createBackup = function(maxRow, restoreCount)
{
	this.pivotGrid.createBackup(maxRow, restoreCount);
	this.scrollGrid.createBackup(maxRow, restoreCount);
};

EXPivotView.prototype.destroyBackup = function()
{
	this.pivotGrid.destroyBackup();
	this.scrollGrid.destroyBackup();
};

//추가되는 순간 화면에 표시되지 않고 바로 백업되도록 한다. append 인 경우만 유효
EXPivotView.prototype.setDirectBackup = function(isDirect)
{
	this.pivotGrid.setDirectBackup(isDirect);
	this.scrollGrid.setDirectBackup(isDirect);
};

EXPivotView.prototype.applyBackupScroll = function()
{
	this.pivotGrid.applyBackupScroll();
	return this.scrollGrid.applyBackupScroll();
};


EXPivotView.prototype.setAllGridSelect = function()
{
	var thisObj = this;
	
	//----------------------------------------------------------------
	//   select cell  
	//----------------------------------------------------------------

	//	isFullRowSelect 가 참이면 cellArr 은 tr element 의 array or jQuery 집합.
	//	rowSet 이 여러개인 경우 인 경우 여러개의 row 객체들을 가지고 있다.

	//	cellArr 는 element 를 담고 있는 배열이거나 jQuery 집합 객체이다.
	//	그룹지어야 할 cell 이나 row 들을 배열이나 jQuery 집합으로 모아서 넘긴다.

	//	※ 주의, cellArr 는 특정 cell 이나 row 를 그룹짓고 있는 배열이나 집합이므로 
	//	동등 비교를 할 경우 this.selectedCells[i][0] === cellArr[0] 과 같이 해야 함.
	//	그룹지어져 있는 경우 첫번째 원소의 주소만 비교하면 같은 그룹임
	this.pivotGrid.selectCell = this.scrollGrid.selectCell = function(cellArr, e)
	{
		AGrid.prototype.selectCell.call(this, cellArr, e);
		
		var otherGrid = null;

		if(this===thisObj.pivotGrid) otherGrid = thisObj.scrollGrid;
		else otherGrid = thisObj.pivotGrid;
		
		//헤드부분은 무조건 셀이 넘어온다. 같은 셀을 넘겨주면 클리어처리
		if(cellArr[0].isHeader) otherGrid.clearSelected(); //AGrid.prototype.selectCell.call(otherGrid, cellArr, e);
		else
		{
			var startIdx = this.indexOfRow(cellArr[0]),
				endIdx = this.indexOfRow(cellArr[cellArr.length-1]) + 1;

			AGrid.prototype.selectCell.call(otherGrid, otherGrid.getRows(startIdx, endIdx), e);
		}
		
		/*
		if(!this.option.isSelectable) return;
		
		if(this.option.isFullRowSelect)
		{
			var startIdx = this.indexOfRow(cell[0]),
				endIdx = this.indexOfRow(cell[cell.length-1]) + 1;
			
			AGrid.prototype.selectCell.call(thisObj.pivotGrid, thisObj.pivotGrid.getRows(startIdx, endIdx), e);
			AGrid.prototype.selectCell.call(thisObj.scrollGrid, thisObj.scrollGrid.getRows(startIdx, endIdx), e);
		}
		else
		{
			AGrid.prototype.selectCell.call(this, cell, e);
		}
		*/
	};
};

EXPivotView.prototype.setScrollComp = function(acomp)
{
	if(acomp) acomp.setStyle('z-index', 3);
	this.pivotGrid.setScrollComp(acomp);
	this.scrollGrid.setScrollComp(acomp);
};

//-----------------------------------------------------
//	about scroll
EXPivotView.prototype.scrollTo = function(pos)
{
	this.pivotGrid.scrollTo(pos);
	this.scrollGrid.scrollTo(pos);
};

EXPivotView.prototype.scrollOffset = function(offset)
{
	this.pivotGrid.scrollOffset(offset);
	this.scrollGrid.scrollOffset(offset);
};

//row or rowIndex
EXPivotView.prototype.scrollIntoArea = function(row, isAlignTop)
{
	this.pivotGrid.scrollIntoArea(row, isAlignTop);
	this.scrollGrid.scrollIntoArea(row, isAlignTop);
};

EXPivotView.prototype.scrollToTop = function()
{
	this.pivotGrid.scrollToTop();
	this.scrollGrid.scrollToTop();
};

EXPivotView.prototype.scrollToBottom = function()
{
	this.pivotGrid.scrollToBottom();
	this.scrollGrid.scrollToBottom();
};

EXPivotView.prototype.scrollToCenter = function()
{
	this.pivotGrid.scrollToCenter();
	this.scrollGrid.scrollToCenter();
};

//------------------------------------------------

EXPivotView.prototype.setData = function(dataArr){};
EXPivotView.prototype.setQueryData = function(dataArr, keyArr, queryData)
{
	this.pivotGrid.updateChildMappingComp(dataArr, queryData);
	this.scrollGrid.updateChildMappingComp(dataArr, queryData);
};

EXPivotView.prototype.getQueryData = function(dataArr, keyArr, queryData)
{
};


