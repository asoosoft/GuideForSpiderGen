                    
/**
 Constructor
 Do not call Function in Constructor. 
 
 */
 
class ChartView extends AView
{
    constructor()
    {
        super();
        
        this.frwName = 'stock';
            
    //{
    //	'일': 1,
    //	'주': 2,
    //	'월': 3,
    //	'분기': 4,
    //	'년': 5
    //	'분': 6,
    //	'틱': 7,
    //};

        this.delegator = null;
        
        this.item = null;
        this.isMultiChart = false;
        this.selectBtn = null;
        this.isInit = false;
        this.sendItemArr = new Array();
        this.isSending = false;
        this.realQueryName = 'QR000001';
        this.noSend = false;
        this.noReal = false;
        this.term = 1;

        this.termMap = 
        {
            '일': 1,
            '주': 2,
            '월': 3,
            '년': 5
        };
        
        this.termMap2 = 
        {
            '1': '일',
            '2': '주',
            '3': '월',
            '5': '년'
        };
        
        
        this.jipyoMap = 
        {
            '미결제약정' : { chkMid: [ '005','006', '012', '013', '014', '016', '018', '019', '062', '067', '091', '099', '100', '103', '104', '105', '114' ], 
                        qryName: 'QR000011', gidCode: 51, seqArr:[], func: this.func6, fid:'D1미결제약정수량' },
            '기관 순매수' :        { chkMid: ['001','003'], qryName: 'QR000009', gidCode: 52, seqArr:[8], joinType: 0, func: this.func1, fid:'D1투자자순매수수량' },
            '기관 순매수 누적' :  { chkMid: ['001','003'], qryName: 'QR000009', gidCode: 52, seqArr:[8], joinType: 0, func: this.func2 },
            '시가총액':          { chkMid: ['001','003'], qryName: 'QR000009', gidCode: 51, seqArr:[8], func: this.func1, fid:'D1시가총액' },
            '외국인 보유비중':      { chkMid: ['001','003'], qryName: 'QR000009', gidCode: 51, seqArr:[11], func: this.func1, fid:'D1외국인보유율_당일' },
            '외국인 보유량': { chkMid: ['001','003'], qryName: 'QR000009', gidCode: 51, seqArr:[11], func: this.func1, fid:'D1외국인보유주식수' },
            '외국인 순매수': { chkMid: ['001','003'], qryName: 'QR000009', gidCode: 51, seqArr:[14], func: this.func1, fid:'D1투자자순매수수량' },
            '종목거래량회전률': { qryName: 'QR000009', gidCode: 51, seqArr:[11], func: this.func1, fid:'D1거래량회전율' },
            '거래대금회전률': { qryName: 'QR000009', gidCode: 51, seqArr:[11], func: this.func3 },
            '투자자별(거래소)': { qryName: 'QR000005', gidCode: 52, seqArr:[10,14,8,9], joinType: 1, func: this.func7, fid:'종목투자자별순매수거래량', item:{'D1단축코드':'1', 'D1시장분류코드': '002'} },
            '투자자별(코스닥)': { qryName: 'QR000005', gidCode: 52, seqArr:[10,14,8,9], joinType: 1, func: this.func7, fid:'종목투자자별순매수거래량', item:{'D1단축코드':'1', 'D1시장분류코드': '004'} },
            '투자자별(콜옵션)': { qryName: 'QR000012', gidCode: 52, seqArr:[10,11,8,9], joinType: 0, func: this.func4, fid:'D1투자자콜순매수수량', item:{'D1단축코드':'00000000', 'D1시장분류코드': '006'} },
            '투자자별(풋옵션)': { qryName: 'QR000012', gidCode: 52, seqArr:[10,11,8,9], joinType: 0, func: this.func4, fid:'D1투자자풋순매수수량', item:{'D1단축코드':'00000000', 'D1시장분류코드': '006'} },
            '투자자별(K200선물)': { qryName: 'QR000013', gidCode: 52, seqArr:[10,11,8,9], joinType: 0, func: this.func4, fid:'D1SPREAD합산전체투자자순매수수량', item:{'D1단축코드':'00000000', 'D1시장분류코드': '005'} },
            '투자자별(K200)': { qryName: 'QR000005', gidCode: 52, seqArr:[10,14,8,9], joinType: 1, func: this.func7, fid:'종목투자자별순매수거래량', item:{'D1단축코드':'51', 'D1시장분류코드': '002'} },
            '프로그램순매수 거래소': { chkMid: ['001', '003'], qryName: 'QR000010', gidCode: 54, seqArr:[], func: this.func5, fid:'D1전체프로그램매매순매수거래대금', item:{'D1시장분류코드': '001'} },
            '프로그램순매수 코스닥': { chkMid: ['001', '003'], qryName: 'QR000010', gidCode: 54, seqArr:[], func: this.func5, fid:'D1전체프로그램매매순매수거래대금', item:{'D1시장분류코드': '003'} }
        };
        
        this.midRoundMap =
        {
            //코스콤 서버 및 키론 기준 마켓 코드
            '001': 0, // KOSPI주식(X)
            '002': 2, // KOSPI업종(O)
            '003': 0, // KOSDAQ 주식(X)
            '004': 2, // KOSDAQ 업종(O)
            '005': 2, // 선물(O)
            '006': 2, // 옵션(O)
            '009': 0, // 신주인수권(X)
            '010': 0, // 프리보드KOTC
            '012': 2, // 주식옵션(O)
            '013': 2, // USB선물(O)
            '014': 2, // USD옵션(O)
            '016': 2, // 국채선물10년(O)
            '017': 2, // 국채선물(O)
            '018': 2, // YEN선물(O)
            '019': 1, // EURO선물(O) -> 1자리
            '023': 1, // 
            '062': 2, // 국채선물5년(O)
            '064': 2, // CME K200선물(O)
            '067': 2, // 스타선물(O)
            '068': 0, // ELW(X)
            '079': 2, // 일본지수(O)
            '080': 2, // 홍콩지수(O)
            '081': 2, // 대만지수(O)
            '082': 2, // 상하이선전지수(O)
            '084': 2, // 미국지수(O)
            '086': 2, // 기타세계지수(O)
            '088': 1, //
            '089': 1, //
            '091': 0, // 주식선물(X)
            '099': 2, // 변동성지수선물(O)
            '100': 2, // 섹터지수선물(O)
            '102': 2, // CME USD선물(O)
            '103': 2, // 미니선물(O)
            '104': 2, // 미니옵션(O)
            '105': 2, // CNH선물(O)
            '114': 0, // MINI GOLD선물(O) -> X로 변경 됐음
            '118': 0, // KONEX종목(X)
            '121': 2, // KONEX업종(O)
            '167': 2, // 섹터업종(O)
            '171': 2  //
        };
        
        
        this.termBtn = null;
        this.minBtn = null;
        this.tickBtn = null;
        this.termBtn2 = null;
        this.tickBtn2 = null;
        this.win = null;
        
        this.beforeOption = null;
        this.afterOptions = null;
        this.chartConfig =
        {
            useAdPrice: 0,
            minList: ['1:1','1:3','1:5','1:10','1:15','1:30','1:45','1:60'],
            tickList: ['1:1','1:3','1:5','1:10','1:20','1:30','1:60','1:120'],
            lastValue : [0,1],	//[type, termval]
            limitCnt: 200
        };
        
        this.searchType = 0;	//일주년월(0) or 분(1) or tic(2)
        this.nextKey = 0;
        this.nextDate = '';
        
        this.realData = {};
        this.mainKeyInfo = null;
        this.itemBoxView = null;
    }
}

window.ChartView = ChartView;

ChartView.CONTEXT = 
{
    tag: '<div data-base="ChartView" data-class="ChartView" class="AView-Style"></div>',

    defStyle: 
    {
        width:'400px', height:'200px'
    },

    //events: ['swipe', 'longtab', 'scroll', 'scrollleft', 'scrollright', 'scrolltop', 'scrollbottom', 'drop', 'dragStart', 'dragEnd' ]
    events: ['swipe', 'longtab', 'scroll', 'scrollleft', 'scrollright', 'scrolltop', 'scrollbottom', 'drop', 'dragstart', 'dragend' ]
};

//======================================================
// 차트 색상 입력은 아래 두 가지 방식 지원
//======================================================
//hex: 000000
//dec: 255,0,0
//======================================================
ChartView.chartColorBasic = [ //블랙 테마
                             //차트 기본색상
                             "ff0000", //0: 상승
                             "0070ff", //1: 하락
                             "000000", //2: 보합
                             "000000", //3: 거래량
                             
                             //주가 이동평균
                             "ff3e47", //이평1 기간
                             "007aff", //거래량 상승, 이평2 기간
                             "ae6428", //거래량 하락, 이평3 기간
                             "00b07c", //거래량 보합, 이평4 기간
                             "ff33ff", //200일
                             "102, 0, 153", //300일
                             
                             //10~11:MACD
                             "152, 116, 232", //B_Ratio -- 10
                             "158,  40, 255", //기간 -- 11
                             "230, 100,  39", //기간 -- 12
                             "125, 125, 125", //투자자 주가 라인색      2013. 8. 19 추가
                             "ff3e47",  //투자자 상승색           2013. 8. 19 추가
                             "007aff",  //투자자 하락색            2013. 8. 19 추가
                             
                             //16~20:비교차트
                             "ff3e47", //비교차트 1
                             "007aff", //비교차트 2
                             "ae6428", //비교차트 3
                             "00b07c", //비교차트 4
                             "ff33ff", //비교차트 5
                             
                             //21~...:차트 UI
                             "171926", //0. 기본 버튼 nor 배경 :
                             "f0f0f0", //1. 기본 버튼 nor 글씨 :
                             "171926", //2. 기본 버튼 touch 배경:
                             "f0f0f0", //3. 기본 버튼 touch 글자:
                             "171926", //4. 취소 버튼 nor 배경, 다이얼로그창 하단 버튼 nor배경 end색:
                             "f0f0f0", //5. 취소 버튼 nor 글씨:
                             "171926", //6. 취소 버튼 touch 글자, 다이얼로그창 하단 버튼 touch배경 start색:
                             "f0f0f0", //7. 취소 버튼 touch 글자:
                             "171926", //8. 확인 버튼 nor 배경:
                             "f0f0f0", //9. 확인 버튼 nor 글씨:
                             "171926", //10. 확인 버튼 touch 배경:
                             "f0f0f0", //11. 확인 버튼 touch 글자:
                             "0c5196", //12. 팝업 상단 배경, 설정 상단 배경 :
                             "ffffff", //13. 팝업 상단 글씨 :
                             "ffffff", //14. 팝업 중간 배경 :
                             "000000", //15. 팝업 중간 글씨 :
                             "ffffff", //16. 팝업 하단 상단 라인 :
                             "ffffff", //17. 팝업 하단 배경 :
                             "ffffff", //18. 리스트 배경 :
                             "303047", //19. 리스트 글씨 1단 :
                             "000000", //20. 리스트 글씨 2단 :
                             "7f7f7f", //21. 리스트 최상단 라인 :
                             "dfdfdf", //22. 리스트 중간 라인 :
                             "7f7f7f", //23. 리스트 최하단 라인 :
                             "ffffff", //24. 설정 바닥 색상 :
                             "ffffff", //25. 설정 리스트 색상 :
                             "000000", //26. 설정 리스트 nor 글씨, 체크박스 우측 글씨 :
                             "22223b", //27. 설정 리스트 touch 글자, 체크박스 우측 글씨 checked:
                             "dfdfdf", //28. 설정 리스트 중간 라인 색상 :
                             "ffffff", //29. 설정 중복지표 바닥 색상 :
                             "c6c6ce", //30. 분틱설정 세로선 색상 :
                             "dfdfdf", //31. 분틱설정 가로선 색상 :
                             "7a7c8b", //32. 분틱설정 상단 글씨 색상 :
                             "171926", //33. 바닥고정버튼 nor 배경:
                             "ffffff", //34. 바닥고정버튼 nor 글씨:
                             "171926", //35. 바닥고정버튼 touch 배경:
                             "ffffff", //36. 바닥고정버튼 touch 글자:
                             "ffffff", //37. 바닥고정버튼 배경색 :
                             "ffffff", //38. 바닥고정버튼 라인색 :
                             "7a7c8b", //39. 설정 서브헤더 글씨 색상 :
                             "e4e5ec", //40. 설정 서브헤더 배경 색상 :
                             "c6c6ce", //41. 설정 서브헤더 라인 색상 :
                             "494b61", //42. TextField Border 색상 nor, 버튼 Border 색상 :
                             "ffffff", //43. TextField 배경 색상 nor :
                             "000000", //44. TextField 텍스트 색상 nor :
                             "e4e5ec", //45. TextField Border 색상 disable :
                             "f1f3f5", //46. TextField 배경 색상 disable :
                             "22223c", //47. TextField 텍스트 색상 disable :
                             "222a43", //48. 팝업상단의 하단라인 색상:
                             "ffffff", //49. 팝업상단의 x버튼 컬러
                             "0c5196", //50. 설정 탭 ,지표설정 탭 배경 touch 색상 :
                             "f0f0f0", //51. 설정 탭, 지표설정 탭 글씨 touch 색상,  :
                             "737373", //52. 지표설정 탭 글씨 nor 색상 :
                             "1b1e2d", //53. 지표설정 탭 배경 색상, saveload메뉴배경:
                             "414450", //54. 다이얼로그창 하단 버튼 nor배경 start색, touch배경 end색
                             
                             
                             //한글화 색상 설정 (20)
                             "ff0000", //55: 상승
                             "0070ff", //56: 하락
                             "000000", //57: 보합
                             "000000", //58: 거래량 //50
                             "ffffff", //59: 배경
                             "",       //60: temp1
                             "",       //61: temp1
                             "",       //62: temp1
                             "",       //63: temp1
                             "",       //64: temp1
                             "",       //65: temp1
                             "",       //66: temp1
                             "",       //67: temp1
                             "",       //68: temp1
                             "",       //69: temp1
                             "",       //70: temp1
                             "",       //71: temp1
                             "",       //72: temp1
                             "",       //73: temp1
                             "",       //74: temp1
                             
                             //영문화 색상 설정 (20)
                             "18a709", //75: 상승
                             "ff0000", //76: 하락
                             "ff0000", //77: 보합
                             "000000", //78: 거래량 //50
                             "000000", //79: 배경
                             "",       //80: temp1
                             "",       //81: temp1
                             "",       //82: temp1
                             "",       //83: temp1
                             "",       //84: temp1
                             "",       //85: temp1
                             "",       //86: temp1
                             "",       //87: temp1
                             "",       //88: temp1
                             "",       //89: temp1
                             "",       //90: temp1
                             "",       //91: temp1
                             "",       //92: temp1
                             "",       //93: temp1
                             "",       //94: temp1
                             
                             
                             ];

ChartView.chartColorWhite = [
                             //차트 기본색상
                             "ff0000", //0: 상승
                             "0070ff", //1: 하락
                             "000000", //2: 보합
                             "000000", //3: 거래량
                             
                             //주가 이동평균
                             "ff3e47", //이평1 기간
                             "007aff", //거래량 상승, 이평2 기간
                             "ae6428", //거래량 하락, 이평3 기간
                             "00b07c", //거래량 보합, 이평4 기간
                             "ff33ff", //200일
                             "102, 0, 153", //300일
                             
                             //10~11:MACD
                             "152, 116, 232", //B_Ratio -- 10
                             "158,  40, 255", //기간 -- 11
                             "230, 100,  39", //기간 -- 12
                             "125, 125, 125", //투자자 주가 라인색      2013. 8. 19 추가
                             "ff3e47",  //투자자 상승색           2013. 8. 19 추가
                             "007aff",  //투자자 하락색            2013. 8. 19 추가
                             
                             //16~20:비교차트
                             "ff3e47", //비교차트 1
                             "007aff", //비교차트 2
                             "ae6428", //비교차트 3
                             "00b07c", //비교차트 4
                             "ff33ff", //비교차트 5
                             
                             //21~...:차트 UI
                             "eaeaea", //0. 기본 버튼 nor 배경:
                             "000000", //1. 기본 버튼 nor 글씨:
                             "dedede", //2. 기본 버튼 touch 배경:
                             "000000", //3. 기본 버튼 touch 글자:
                             "eaeaea", //4. 취소 버튼 nor 배경, 다이얼로그창 하단 버튼 nor배경 end색:
                             "000000", //5. 취소 버튼 nor 글씨:
                             "dedede", //6. 취소 버튼 touch 글자, 다이얼로그창 하단 버튼 touch배경 start색:
                             "000000", //7. 취소 버튼 touch 글자: ffffff / ffffff
                             "eaeaea", //8. 확인 버튼 nor 배경: ff6835 / ff6835
                             "000000", //9. 확인 버튼 nor 글씨: ffffff / ffffff
                             "dedede", //10. 확인 버튼 touch 배경: d84413 / d84413
                             "000000", //11. 확인 버튼 touch 글자: ffffff / ffffff
                             "0c5196", //12. 팝업 상단 배경, 설정 상단 배경 : 222a43 / f7f7fc
                             "ffffff", //13. 팝업 상단 글씨 : ffffff / 22223b
                             "ffffff", //14. 팝업 중간 배경 : f9f9f9 / f9f9f9
                             "000000", //15. 팝업 중간 글씨 : 22223b / 22223b
                             "ffffff", //16. 팝업 하단 상단 라인 : c6c6ce / c6c6ce
                             "ffffff", //17. 팝업 하단 배경 : f9f9f9 / f9f9f9
                             "ffffff", //18. 리스트 배경 : f8f8f8 / f8f8f8
                             "303047", //19. 리스트 글씨 1단 : 303047 / 303047
                             "000000", //20. 리스트 글씨 2단 : 7a7c8b / 7a7c8b
                             "7f7f7f", //21. 리스트 최상단 라인 : c6c6ce / c6c6ce
                             "dfdfdf", //22. 리스트 중간 라인 : e4e5ec / e4e5ec
                             "7f7f7f", //23. 리스트 최하단 라인 : c6c6ce / c6c6ce
                             "ffffff", //24. 설정 바닥 색상 : f7f7fc / f7f7fc
                             "ffffff", //25. 설정 리스트 색상 : f7f7fc / f7f7fc
                             "000000", //26. 설정 리스트 nor 글씨, 체크박스 우측 글씨 : 81818d / 81818d
                             "22223b", //27. 설정 리스트 touch 글자, 체크박스 우측 글씨 checked: 22223b / 22223b
                             "dfdfdf", //28. 설정 리스트 중간 라인 색상 : ffffff / ffffff
                             "ffffff", //29. 설정 중복지표 바닥 색상 : f8f8fa / f8f8fa
                             "c6c6ce", //30. 분틱설정 세로선 색상 : c6c6ce / c6c6ce
                             "dfdfdf", //31. 분틱설정 가로선 색상 : ffffff / ffffff
                             "7a7c8b", //32. 분틱설정 상단 글씨 색상 : 7a7c8b / 7a7c8b
                             "eaeaea", //33. 바닥고정버튼 nor 배경: 161b33 / 161b33
                             "000000", //34. 바닥고정버튼 nor 글씨: ffffff / ffffff
                             "dedede", //35. 바닥고정버튼 touch 배경: 0d101f / 0d101f
                             "000000", //36. 바닥고정버튼 touch 글자: ffffff / ffffff
                             "ffffff", //37. 바닥고정버튼 배경색 : 161b33 / 161b33
                             "ffffff", //38. 바닥고정버튼 라인색 : 5a5d7a / 5a5d7a
                             "7a7c8b", //39. 설정 서브헤더 글씨 색상 : 7a7c8b / 7a7c8b
                             "e4e5ec", //40. 설정 서브헤더 배경 색상 : e4e5ec / e4e5ec
                             "c6c6ce", //41. 설정 서브헤더 라인 색상 : c6c6ce / c6c6ce
                             "c1c1c1", //42. TextField Border 색상 nor, 버튼 Border 색상 :
                             "ffffff", //43. TextField 배경 색상 nor : ffffff / ffffff
                             "000000", //44. TextField 텍스트 색상 nor : 22223c / 22223c
                             "c1c1c1", //45. TextField Border 색상 disable : e4e5ec / e4e5ec
                             "ffffff", //46. TextField 배경 색상 disable : f1f3f5 / f1f3f5
                             "000000", //47. TextField 텍스트 색상 disable : 22223c / 22223c
                             "dbdde7", //48. 팝업상단의 하단라인 색상 : 222a43 / dbdde7
                             "ffffff", //49. 팝업상단의 x버튼 컬러 : 5e637d / 9499b3
                             "0c5196", //50. 설정 탭 ,지표설정 탭 배경 touch 색상 : 0c5196 /
                             "ffffff", //51. 설정 탭, 지표설정 탭 글씨 touch 색상 : ffffff/
                             "737373", //52. 지표설정 탭 글씨 nor 색상 : 0c5196/
                             "ffffff", //53. 지표설정 탭 배경 색상 : ffffff/
                             "ffffff", //54. 다이얼로그창 하단 버튼 nor배경 start색, touch배경 end색
                             
                             //한글화 색상 설정 (20)
                             "ff0000", //55: 상승
                             "0070ff", //56: 하락
                             "000000", //57: 보합
                             "000000", //58: 거래량 //50
                             "000000", //59: 배경
                             "",       //60: temp1
                             "",       //61: temp1
                             "",       //62: temp1
                             "",       //63: temp1
                             "",       //64: temp1
                             "",       //65: temp1
                             "",       //66: temp1
                             "",       //67: temp1
                             "",       //68: temp1
                             "",       //69: temp1
                             "",       //70: temp1
                             "",       //71: temp1
                             "",       //72: temp1
                             "",       //73: temp1
                             "",       //74: temp1
                             
                             //영문화 색상 설정 (20)
                             "ff0000", //75: 상승
                             "0070ff", //76: 하락
                             "000000", //77: 보합
                             "000000", //78: 거래량 //50
                             "000000", //79: 배경
                             "",       //80: temp1
                             "",       //81: temp1
                             "",       //82: temp1
                             "",       //83: temp1
                             "",       //84: temp1
                             "",       //85: temp1
                             "",       //86: temp1
                             "",       //87: temp1
                             "",       //88: temp1
                             "",       //89: temp1
                             "",       //90: temp1
                             "",       //91: temp1
                             "",       //92: temp1
                             "",       //93: temp1
                             "",       //94: temp1
                             
                             ];


//차트뷰 init시 컨테이너에 차트를 사용한다라고 셋팅
ChartView.prototype.init = function(context, evtListener)
{
    AView.prototype.init.call(this, context, evtListener);
	if(!this.isDev())
	{
    	this.getContainer().useNative = true;
		if(!this.getContainer().chartViewList) this.getContainer().chartViewList = new Array();
    	this.getContainer().chartViewList.push(this);
		
//     	this.getParent().useNative = true;
//     	this.getParent().chartViewList.push(this);
	}
};

//해외지수인지 확인하는 함수
ChartView.prototype.isFIndex = function(item)
{
	if($.inArray(item[2], ['079', '080', '081', '082', '084', '086', '107']) > -1) return true;
	else return false;
};

ChartView.prototype.setDelegator = function(delegator)
{
	this.delegator = delegator;
};

//차트의 리얼쿼리네임을 변경시키는 함수
ChartView.prototype.setRealQueryName = function(qryName)
{
	this.realQueryName = qryName;
};

//차트에 적용할 단축코드 및 시장분류코드 , 종목명 셋팅
ChartView.prototype.setItemInfo = function(itemArr)
{
	this.unregisterReal();
	
	this.item = itemArr;
	
	this.mainKeyInfo = {};
	this.mainKeyInfo['D1단축코드'] = itemArr[0];	
	this.mainKeyInfo['D1단축명'] = itemArr[1];
	this.mainKeyInfo['D1시장분류코드'] = itemArr[2];
};

//가로모드 세로모드 일경우 차트 역 사이즈 변경
ChartView.prototype.updatePosition = function(width, height)
{
	AView.prototype.updatePosition.call(this, width, height);
	if(!this.isDev() && !afc.isSimulator) ChartManager.setChartSize(this.$ele);
};

//차트의 검색타입을 설정(0:일주월,1:분,2:틱,3:해외지수)
ChartView.prototype.setSearchType = function(type, term)
{
	this.searchType = type;
	if(term) this.term = term;
};

//차트의 검색타입을 반환(0:일주월,1:분,2:틱,3:해외지수)
ChartView.prototype.getSearchType = function()
{
	var typeList = [this.searchType];
	if(this.term) typeList.push(this.term);
	return typeList;
};

ChartView.prototype.onIndicatorSignalList = function(chartId, selectedDate, jsonData)
{
    if(this.delegator && this.delegator.onIndicatorSignalList) this.delegator.onIndicatorSignalList(chartId, selectedDate, jsonData);
};

ChartView.prototype.onSignalDateChange = function(chartId, selectedDate)
{
    if(this.delegator && this.delegator.onSignalDateChange) this.delegator.onSignalDateChange(chartId, selectedDate);
};

//차트 보임
ChartView.prototype.showChart = function()
{
	if(!this.isDev() && !afc.isSimulator) ChartManager.showChart([this.getElementId()]);
};

//차트 숨김
ChartView.prototype.hideChart = function()
{
	if(!this.isDev() && !afc.isSimulator) ChartManager.hideChart([this.getElementId()]);
};

//일주월분틱 버튼이 있으면 셋팅하는 함수
ChartView.prototype.settingBtns = function(btnArr, itemBoxView)
{
	if(btnArr)
	{
		this.termBtn = btnArr[0];
		this.minBtn = btnArr[1];
		this.tickBtn = btnArr[2];

		this.termBtn.addEventListener('click', this, 'onTermBtnClick');
		this.minBtn.addEventListener('click', this, 'onMinBtnClick');
		this.tickBtn.addEventListener('click', this, 'onTickBtnClick');
	}
	
	this.itemBoxView = itemBoxView;
};

//일주월분틱 버튼이 있으면 셋팅하는 함수 > 버튼 2개
ChartView.prototype.settingBtns2 = function(btnArr, itemBoxView)
{
	if(btnArr)
	{
		this.termBtn2 = btnArr[0];
		this.tickBtn2 = btnArr[1];

		this.termBtn2.addEventListener('click', this, 'onTermBtn2Click');
		this.tickBtn2.addEventListener('click', this, 'onTickBtn2Click');

		this.win = AWindow.setView('Framework/stock/layout/ChartTypeWindow.html', 'MS000002');
		this.win.setWindowOption({
			isFocusLostClose: true,	//모달인 경우 포커스를 잃을 때 창을 닫을지
			modalBgOption: 'none'	//none, light, dark 모달인 경우 배경을 어둡기 정도
		});
	}
	
	this.itemBoxView = itemBoxView;
};

//차트 데이터의 길이 저장하는 함수
ChartView.prototype.setViewDataCount = function(nViewNum)
{
	this.chartConfig.limitCnt = nViewNum;
	if(!this.isDev() && !afc.isSimulator) ChartManager.setViewDataCount([this.getElementId(), nViewNum]); //차트아이디, 봉개수
};

//일주월,분틱 상세 주기 선택하는 윈도우 호출 함수
ChartView.prototype.showWin = function(comp, data)
{
	var win = new AWindow('ChartTypeWindow');

	//init 이 호출되지 않은 경우 
	if(!win.element) win.init();
	win.onCreateDone = function()
	{
		this.getView().setData();
	};

	win.setView('Framework/stock/layout/ChartTypeWindow.html');
	win.setWindowOption({
		isFocusLostClose: true,	//모달인 경우 포커스를 잃을 때 창을 닫을지
		modalBgOption: 'none'	//none, light, dark 모달인 경우 배경을 어둡기 정도
	});
	win.setResultListener(this);
	
	this.clickBtn = comp;
	win.getView().listData = data;
	win.open(null, this.getContainer(), comp.$ele.offset().left, comp.$ele.offset().top+comp.$ele.outerHeight(), comp.$ele.outerWidth(), data.length*comp.$ele.outerHeight());
};
//일주월버튼 클릭이벤트
ChartView.prototype.onTermBtnClick = function(comp, info)
{
	this.showWin(comp, ['일', '주', '월', '년']);
};

//일주월분틱버튼 클릭이벤트
ChartView.prototype.onTermBtn2Click = function(comp, info)
{
	this.showWin(comp, ['일', '주', '월', '년', '분', '틱']);
};

//분버튼 클릭이벤트
ChartView.prototype.onMinBtnClick = function(comp, info)
{
	this.showWin(comp, this.chartConfig.minList);
};

//틱버튼 클릭이벤트
ChartView.prototype.onTickBtnClick = function(comp, info)
{
	this.showWin(comp, this.chartConfig.tickList);
};

//틱버튼 클릭이벤트
ChartView.prototype.onTickBtn2Click = function(comp, info)
{
	if(this.termBtn2.getText() == '분') {
		this.showWin(comp, this.chartConfig.minList);
	} else if(this.termBtn2.getText() == '틱') {
		this.showWin(comp, this.chartConfig.tickList);
	}
};

//차트 설정값에 의해 검색조건을 셋팅하는 함수
ChartView.prototype.initConfig = function()
{
	this.resetBtnState();
	
	//(1:일별, 2:주별, 3:월별 4:분기, 5:년별)
	var chartCfg = this.getChartConfig();
	this.searchType = chartCfg.lastValue[0];
	if(this.searchType == 1)
	{
		this.minBtn.setText(chartCfg.lastValue[1]);
		this.selectBtn = this.minBtn;
	}
	else if(this.searchType == 2)
	{
		this.tickBtn.setText(chartCfg.lastValue[1]);
		this.selectBtn = this.tickBtn;
	}
	else
	{
		//lastValue[0] > lastValue[1]로 수정 2016.11.13. 황청유
		if(chartCfg.lastValue[1] == 1)
		{
			this.termBtn.setText('일');
		}
		else if(chartCfg.lastValue[1] == 2)
		{
			this.termBtn.setText('주');	
		}
		else if(chartCfg.lastValue[1] == 3)
		{
			this.termBtn.setText('월');
		}
		else if(chartCfg.lastValue[1] == 5)
		{
			this.termBtn.setText('년');
		}
		this.selectBtn = this.termBtn;
	}
	this.selectBtn.addClass('BT_CO2_NOR');
	this.setSearchType(chartCfg.lastValue[0],chartCfg.lastValue[1]);
};

//차트의 옵션값을 셋팅하는 함수
ChartView.prototype.setChartOption = function(beforeOptions, afterOptions)
{
     this.beforeOptions = beforeOptions;
    this.afterOptions = afterOptions;
//    this.beforeOptions["ChartColor"] = ChartView.chartColorWhite;
    
    
    //2016.07.14 by hyh -  차트 테마 적용
//    alert("theApp.themeMode:"+theApp.themeMode);
    //밝은/어두운 설정 (메인설정 값을 받아와서 처리해야 함)
    if(theApp.themeMode == 'WHITE' || theApp.themeMode == undefined) //밝은
    {
        this.beforeOptions["ChartColor"] = ChartView.chartColorWhite;
    }
    else if(theApp.themeMode == 'BLACK')//어두운
    {
        this.beforeOptions["ChartColor"] = ChartView.chartColorBasic;
    }
    
    //차트 상승/하락 색상 변경 (메인설정 값을 받아와서 처리해야 함)
    if(theApp.colorMode == 'kor' || theApp.colorMode == undefined) //빨간/파란
    {
//        //"ff0000", //75: 상승
//        //"0070ff", //76: 하락
        this.beforeOptions["ChartColor"][0] = "ff0000";
        this.beforeOptions["ChartColor"][1] = "0070ff";
    }
    else if(theApp.colorMode == 'eng')//초록/빨간
    {
        //"18a709", //75: 상승
        //"ff0000", //76: 하락
        this.beforeOptions["ChartColor"][0] = "18a709";
        this.beforeOptions["ChartColor"][1] = "ff0000";
    }
    
//    this.beforeOptions["IndicatorList"] = theApp.systemInfo.get('FirmChartIndicator');		
};

//차트의 설정값을 로드하는 함수
ChartView.prototype.loadChartConfig = function()
{
	if(this.beforeOptions['LoadChart'])
	{
		var chartConfig = localStorage.getItem(this.beforeOptions['LoadChart']);
    	if(chartConfig) this.chartConfig = JSON.parse(chartConfig);
	}
};

//차트에 설정값을 리턴하는 함수
ChartView.prototype.getChartConfig = function()
{
    return this.chartConfig;
};

ChartView.prototype.setMoreData = function(isMore)
{
    this.realData['D1연속여부'] = isMore;
};

//네이티브에 차트영역을 할당하라는 함수
ChartView.prototype.loadChartLayout = function()	
{
	//this.sendItemArr = new Array();
	this.isInit = false;

// 	if(theApp.configInfo.get('BMENU_ONOFF') == 'OFF') theApp.frmPage.floatMenuBtn.$ele.hide();
	
	this.loadChartConfig();
	if(this.termBtn) this.initConfig();
    if(!this.isDev() && !afc.isSimulator) ChartManager.loadChartLayout(this.$ele, this.beforeOptions, this.afterOptions);
    if(!this.isDev() && !afc.isSimulator) ChartManager.setDelegator(this);
};

//네이티브 차트가 준비간 된 시점에 날라오는 이벤트
ChartView.prototype.onChartInit = function()
{
	this.isInit = true;
	
	if(this.tempData)
	{
		this.updateOutputData(this.tempData);
		this.tempData = null;
	}
};

//네이티브 차트에 전송할 header 고정 데이터 셋팅
ChartView.prototype.setFixedData = function(fixData)
{
	for(var key in fixData)
	{
		this.realData[key] = fixData[key];
	}	
};

//네이티브 차트에 전송할 header 조회 데이터 셋팅
ChartView.prototype.setSearchData = function(searchData)
{
	for(var key in searchData)
	{
		this.realData[key] = searchData[key];
	}
};

//분틱시 선택할수 있는 상세 숫자 리턴
ChartView.prototype.onGetPeriodInfo = function()
{
    return this.chartConfig.minList.join(';')+'/'+this.chartConfig.tickList.join(';');
};

//다이얼로그를 띄움
ChartView.prototype.openDlg = function(comp, dlgType)
{
   	if(!this.isDev() && !afc.isSimulator) ChartManager.openDlg([this.getElementId(), comp.$ele, dlgType]);
};

//네이티브 차트 클리어
ChartView.prototype.clearChart = function()
{
	if(!this.isDev() && !afc.isSimulator) ChartManager.setDataClear([this.getElementId(), '1']);
};

//네이티브 차트에 조회데이터를 업데이트하는 함수
ChartView.prototype.updateOutputData = function(tempData)
{
	var thisObj = this;
	if(this.isDev() || afc.isSimulator) return;
	ChartManager.tabManager = this.getContainer().view;
	ChartManager.updateOutputData([this.getElementId(), {
		ref: thisObj.realData,
		data: tempData
	}]);
	if(!this.isInit)
	{
		this.tempData = tempData;
	}	
};

//네이티브 차트에 리얼 데이터를 업데이트하는 함수
ChartView.prototype.updateRealData = function()
{
    if(!this.isDev() && !afc.isSimulator) ChartManager.updateRealData([this.getElementId(), this.realData]);	
};

//3가지버튼 초기화
ChartView.prototype.resetBtnState = function()
{
	if(this.termBtn)
	{
		this.termBtn.removeClass('BT_CO2_NOR');
		this.termBtn.setText('일');
	}
	if(this.minBtn)
	{
		this.minBtn.removeClass('BT_CO2_NOR');
		this.minBtn.setText('분');
	}
	if(this.tickBtn)
	{
		this.tickBtn.removeClass('BT_CO2_NOR');
		this.tickBtn.setText('틱');
	}
	if(this.termBtn2)
	{
		this.termBtn2.removeClass('BT_CO2_NOR');
		this.termBtn2.setText('일');
	}
	if(this.tickBtn2)
	{
		this.tickBtn2.removeClass('BT_CO2_NOR');
		this.tickBtn2.setText('1');
	}
};

//네이티브 차트에서 데이터를 요청(저장된 차트를 불러와서 요청하는 경우)
ChartView.prototype.onRequestData = function(requestArr, selectedIndex)
{
	this.requestData(requestArr, selectedIndex);
	/*
	this.sendItemArr.push([requestArr, selectedIndex]);
	this.manageSend();
	*/
};
/*
//전송을 순차적으로 날리기위해 관리하는 함수
function ChartView*manageSend(isDone)
{
	//전송이 다 끝났을때 처리
	if(isDone)
	{
		this.sendItemArr.shift();
		this.isSending = false;
	}
	
	if(!this.isSending && (this.sendItemArr.length > 0))
	{
		this.isSending = true;
		this.requestData(this.sendItemArr[0][0], this.sendItemArr[0][1]);
	}
};
*/

//한건 한건의 데이터 요청
ChartView.prototype.requestData = function(requestArr, selectedIndex)
{
	this.resetBtnState();
	
	var code = requestArr[0];	//종목코드
	var name = requestArr[1];	//종목명
	var mid = requestArr[2];	//시장구분
	var type = requestArr[3];	//주기
	var term = (requestArr[4]) ? requestArr[4] : 1;	//분틱주기값
	
	var selectBtn2;
	
	//분조회
	if(type == 6)
	{
		this.searchType = 1;
		this.setLastValue(term);
		if(this.minBtn)
		{
			this.minBtn.setText(term);
			this.selectBtn = this.minBtn;
		}
		if(this.tickBtn2)
		{
			this.tickBtn2.$ele.show();
			this.tickBtn2.setText(term);
			this.termBtn2.setText('분');
			selectBtn2 = this.tickBtn2;
		}
	}
	//틱조회
	else if(type == 7)
	{
		this.searchType = 2;
		this.setLastValue(term);
		if(this.tickBtn)
		{
			this.tickBtn.setText(term);
			this.selectBtn = this.tickBtn;
		}
		if(this.tickBtn2)
		{
			this.tickBtn2.$ele.show();
			this.tickBtn2.setText(term);
			this.termBtn2.setText('틱');
			selectBtn2 = this.tickBtn2;
		}
	}
	else
	{
		//해외지수 초기화 시 에러 발생으로 searchType 3일 때 유지
		if(this.searchType != 3) this.searchType = 0;
		
		this.setLastValue(this.termMap[type]);
		if(type == 1)
		{
			if(this.termBtn) this.termBtn.setText('일');
			if(this.termBtn2) {
				this.termBtn2.setText('일');
				if(this.tickBtn2) this.tickBtn2.$ele.hide();
				selectBtn2 = this.termBtn2;
			}
		}
		else if(type == 2)
		{
			if(this.termBtn) this.termBtn.setText('주');	
			if(this.termBtn2) {
				this.termBtn2.setText('주');
				if(this.tickBtn2) this.tickBtn2.$ele.hide();
				selectBtn2 = this.termBtn2;
			}
		}
		else if(type == 3)
		{
			if(this.termBtn) this.termBtn.setText('월');
			if(this.termBtn2) {
				this.termBtn2.setText('월');
				if(this.tickBtn2) this.tickBtn2.$ele.hide();
				selectBtn2 = this.termBtn2;
			}
		}
		else if(type == 5)
		{
			if(this.termBtn) this.termBtn.setText('년');
			if(this.termBtn2) {
				this.termBtn2.setText('년');
				if(this.tickBtn2) this.tickBtn2.$ele.hide();
				selectBtn2 = this.termBtn2;
			}
		}
		
		if(this.termBtn)
		{
			this.selectBtn = this.termBtn;
		}
	}
	
	if(this.selectBtn) this.selectBtn.addClass('BT_CO2_NOR');
	if(selectBtn2) selectBtn2.addClass('BT_CO2_NOR');
	
	if(this.itemBoxView) this.itemBoxView.setItemInfo([code, name, mid], true);
	else
	{
		this.setItemInfo([code, name, mid]);
		this.sendDataManage();
	}
	
};

//리얼데이터를 받기위해 전송하는 함수
ChartView.prototype.sendDataManage = function()
{
	//if(!isFirst && !this.isInit) return;
	
	var thisObj = this;
	
	//this.clearChart();
	
	this.getContainer().view.sendData(this.realQueryName, function(queryData, groupName)
	{
		var mainKeyBlock = queryData.getBlockData('InBlock1');
		mainKeyBlock[0] = thisObj.mainKeyInfo;
		
		if(!thisObj.noReal)
		{
			this.registerReal(thisObj.realQueryName, mainKeyBlock, null, [thisObj], 0 );
			queryData.enableFlag('realFlag');
		}
		
	},
	function(queryData, groupName)
	{
		if(queryData)
		{
			thisObj.setFixedData({
				'D1에러여부': false,
				'D1초기화여부': true,
				'D1수정주가여부': thisObj.chartConfig.useAdPrice,
				'D1데이터개수': thisObj.chartConfig.limitCnt,
				'D1단축코드': thisObj.item[0],
				'D1종목명': thisObj.item[1],
				'D1시장분류코드': thisObj.item[2],
				'D1가격소수점자리수' : (thisObj.midRoundMap[MasterInfo.formatMarketCode(thisObj.item[2])]) ? thisObj.midRoundMap[ MasterInfo.formatMarketCode( thisObj.item[2] ) ] : 0
			});	
			
			thisObj.sendChartData(0);
		}
		else
		{
			//보조지표
			if(thisObj.searchType == -1) thisObj.clearChart();
		}
	});
};

//차트데이터를 더 요청하는 함수
ChartView.prototype.onScrollEnd = function()
{
	this.sendChartData(1);
};

//초기화 및 연속 여부 셋팅
ChartView.prototype.setDefaultAndMore = function(isMore)
{
	if(isMore)
	{
		this.setFixedData({ 'D1초기화여부': false, 'D1연속여부': isMore });
	}
	else
	{
		this.setFixedData({ 'D1초기화여부': true, 'D1연속여부': isMore });
		this.nextKey = 0;
		this.nextDate = '';
	}
};

//차트데이터를 요청
ChartView.prototype.sendChartData = function(isMore)
{
	if(isMore)
	{
		if(this.nextKey == 0)
		{
			ChartManager.toast(Message.LastList);
			return;
		}
	}

	this.setDefaultAndMore(isMore);
	
	var thisObj = this;
	this.setMarketCategory(this.item[2]);
	
	if(this.searchType == 0 || this.searchType == 3)
	{
		//해외지수인지 체크
		if(this.isFIndex(this.item))
		{
			this.searchType = 3;
		}
		else this.searchType = 0;
	}
	
	//보조지표
	if(this.searchType == -1)
	{
		this.setPeriod([1, '']);
		
		var isStockMarket = (thisObj.mainKeyInfo['D1시장분류코드'] == '001') || (thisObj.mainKeyInfo['D1시장분류코드'] == '003');
		
		this.getContainer().view.sendData( isStockMarket ? 'QR000006' : 'QR000002', function(queryData, groupName)
		{
			var mainKeyBlock = queryData.getBlockData('InBlock1');
			mainKeyBlock[0] = thisObj.mainKeyInfo;
			
			var InBlock3 = queryData.getBlockData('InBlock3');
			InBlock3[0] =
			{
				'D1metrix의갯수' : thisObj.chartConfig.limitCnt,
				'D1GID_CODE' : 53,
				'D1일_주_월_분기_년' : 1,
				'D1prev' : 0,
				'D1next' : thisObj.nextKey
			};
		},
		function(queryData, groupName)
		{
			if(!queryData)
			{
				thisObj.clearChart();
				return;
			}
			if(thisObj.isMultiChart)
			{
				if(thisObj.selectedIndex > -1) thisObj.nextKeyArr[thisObj.selectedIndex] = queryData.getNextKey();
				else thisObj.nextKeyArr[thisObj.tempIndex] = queryData.getNextKey();
			}
			else thisObj.nextKey = queryData.getNextKey();
		});
	}
	
	//년월주일 조회일 경우
	else if(this.searchType == 0)
	{
		var term = (this.termBtn) ? this.termMap[this.termBtn.getText()]: this.term;

		var isStockMarket = (thisObj.mainKeyInfo['D1시장분류코드'] == '001') || (thisObj.mainKeyInfo['D1시장분류코드'] == '003');

		if (!isStockMarket)
		{
			this.chartConfig.useAdPrice = 0;
		}
		
		this.setPeriod([term, '']);
		this.getContainer().view.sendData(((this.chartConfig.useAdPrice == 0) && isStockMarket ) ? 'QR000006' : 'QR000002', function(queryData, groupName)
		{
			var mainKeyBlock = queryData.getBlockData('InBlock1');
			mainKeyBlock[0] = thisObj.mainKeyInfo;
			
			var InBlock3 = queryData.getBlockData('InBlock3');
			InBlock3[0] =
			{
				'D1metrix의갯수' : thisObj.chartConfig.limitCnt,
				'D1GID_CODE' : 53,
				'D1일_주_월_분기_년' : term,
				'D1prev' : 0,
				'D1next' : thisObj.nextKey
			};
		},
		function(queryData, groupName)
		{
			if(!queryData) return;
			
			if(thisObj.isMultiChart)
			{
				if(thisObj.selectedIndex > -1) thisObj.nextKeyArr[thisObj.selectedIndex] = queryData.getNextKey();
				else thisObj.nextKeyArr[thisObj.tempIndex] = queryData.getNextKey();
			}
			else thisObj.nextKey = queryData.getNextKey();
		});
	}
	//분 조회일 경우
	else if(this.searchType == 1)
	{
		var term = (this.minBtn) ? this.minBtn.getText(): this.term;
		this.setPeriod([6, term]);
		this.getContainer().view.sendData('QR000003', function(queryData, groupName)
		{
			var mainKeyBlock = queryData.getBlockData('InBlock1');
			mainKeyBlock[0] = thisObj.mainKeyInfo;
		
			var InBlock3 = queryData.getBlockData('InBlock3');
			InBlock3[0] =
			{
				'D1metrix의갯수' : thisObj.chartConfig.limitCnt,
				'D1GID_CODE' : 111,
				'D1Intra주기' : term*60,
				'D1조회일수' : 20,		//조회일수(최대20일)와 D1end_date는 꼭 입력
				'D1end_date' : thisObj.nextDate,
				'D1next' : thisObj.nextKey
			};
		},
		function(queryData, groupName)
		{
			if(!queryData) return;
			
			if(thisObj.isMultiChart)
			{
				if(thisObj.selectedIndex > -1)
				{
					thisObj.nextKeyArr[thisObj.selectedIndex] = queryData.getNextKey();
					thisObj.nextDateArr[thisObj.selectedIndex] = queryData.getNextDate();
				}
				else
				{
					thisObj.nextKeyArr[thisObj.tempIndex] = queryData.getNextKey();
					thisObj.nextDateArr[thisObj.tempIndex] = queryData.getNextDate();
				}
			}
			else
			{
				thisObj.nextKey = queryData.getNextKey();
				thisObj.nextDate = queryData.getNextDate();
			}
			
		});
	}
	//틱 조회일 경우
	else if(this.searchType == 2)
	{
		var term;
		if(this.tickBtn) term = this.tickBtn.getText();
		else term = 1;
		this.setPeriod([7, term]);
		
		this.getContainer().view.sendData('QR000004', function(queryData, groupName)
		{
			var mainKeyBlock = queryData.getBlockData('InBlock1');
			mainKeyBlock[0] = thisObj.mainKeyInfo;
			
			var InBlock3 = queryData.getBlockData('InBlock3');
			InBlock3[0] =
			{
				'D1metrix의갯수' : thisObj.chartConfig.limitCnt,
				'D1GID_CODE' : 2,
				'D1조회일수' : 20, //조회일수(최대20일)와 D1end_date는 꼭 입력
				'D1end_date' : thisObj.nextDate,
				'D1next' : thisObj.nextKey,
				'D1틱봉처리시틱개수' : term
			};
		},
		function(queryData, groupName)
		{
			if(!queryData) return;
			
			if(thisObj.isMultiChart)
			{
				if(thisObj.selectedIndex > -1)
				{
					thisObj.nextKeyArr[thisObj.selectedIndex] = queryData.getNextKey();
					thisObj.nextDateArr[thisObj.selectedIndex] = queryData.getNextDate();
				}
				else
				{
					thisObj.nextKeyArr[thisObj.tempIndex] = queryData.getNextKey();
					thisObj.nextDateArr[thisObj.tempIndex] = queryData.getNextDate();
				}
			}
			else
			{
				thisObj.nextKey = queryData.getNextKey();
				thisObj.nextDate = queryData.getNextDate();
			}
		});
	}
	
	//해외지수조회
	else if(this.searchType == 3)
	{
		var term = this.term;
		
		this.setPeriod([term, '']);
		this.getContainer().view.sendData('QR000015', function(queryData, groupName)
		{
			var mainKeyBlock = queryData.getBlockData('InBlock1');
			mainKeyBlock[0] = thisObj.mainKeyInfo;
			
			var InBlock3 = queryData.getBlockData('InBlock3');
			InBlock3[0] =
			{
				'D1metrix의갯수' : thisObj.chartConfig.limitCnt,
				'D1GID_CODE' : 51,
				'D1일_주_월_분기_년' : term,
				'D1prev' : 0,
				'D1next' : thisObj.nextKey
			};
		},
		function(queryData, groupName)
		{
			if(!queryData) return;
			queryData.printQueryData();
			if(thisObj.isMultiChart)
			{
				if(thisObj.selectedIndex > -1) thisObj.nextKeyArr[thisObj.selectedIndex] = queryData.getNextKey();
				else thisObj.nextKeyArr[thisObj.tempIndex] = queryData.getNextKey();
			}
			else thisObj.nextKey = queryData.getNextKey();
		});
	}
};

//차트에 설정된 분틱 주기 값을 얻어옴
ChartView.prototype.onChangePeriodOnStorage = function(minList, tickList)
{
    this.chartConfig.minList = minList;
    this.chartConfig.tickList = tickList;
    this.saveConfigInfo();
};

//데이터 조회개수를 저장함
//ChartView.prototype.onByNumber = function(viewnum)
//{
////    alert("onByNumber111:"+viewnum);
//    this.chartConfig.limitCnt = viewnum;
//    this.saveConfigInfo();
//    this.onRequestByNumber(viewnum);
//};

//네이티브 차트에서 설정한 수정주가여부 적용함수
ChartView.prototype.onChangeAdjustedStock = function(isAdjustedStock)
{
	var thisObj = this;
	var isStockMarket = (thisObj.mainKeyInfo['D1시장분류코드'] == '001') || (thisObj.mainKeyInfo['D1시장분류코드'] == '003');

	if (!isStockMarket) {
		isAdjustedStock = false;
	}

	if (isAdjustedStock == true || isAdjustedStock == "1") {
		this.chartConfig.useAdPrice = 1;
	}
	else {
		this.chartConfig.useAdPrice = 0;
	}

    this.saveConfigInfo();
	this.setFixedData({ 'D1수정주가여부': this.chartConfig.useAdPrice });
	this.sendChartData(0);
};

//마지막에 저장했던 검색 주기 셋팅
ChartView.prototype.setLastValue = function(term)
{
    this.chartConfig.lastValue = [this.searchType, term];
    this.saveConfigInfo();
};

//리얼 해제
ChartView.prototype.unregisterReal = function()
{
	if(!this.noReal && this.mainKeyInfo)
	{
// 		theApp.infoNetManager.unregisterReal(this.realQueryName, [this.mainKeyInfo], null, [ this ] );
	}
	this.realData = new Object();
};

//차트를 소멸시킴
ChartView.prototype.destroyChart = function()
{
   this.unregisterReal();
    if(!this.isDev() && !afc.isSimulator) ChartManager.destroy(this.getElementId());
	
// 	if(theApp.configInfo.get('BMENU_ONOFF') == 'OFF') theApp.frmPage.floatMenuBtn.$ele.show();

   //2016.07.06 by hyh - Native 차트를 초기화 하더라도 isInit은 남아있어서 데이터를 받지 못하는 에러 수정
    this.isInit = false;
};

ChartView.prototype.setAccrueName = function(arrResult)
{
    var params= [this.getElementId(), arrResult];
    if(!this.isDev() && !afc.isSimulator) ChartManager.setAccrueName(params);    
};

ChartView.prototype.setAccrueData = function(arrResult)
{
    var params= [this.getElementId(), arrResult];
    if(!this.isDev() && !afc.isSimulator) ChartManager.setAccrueData(params);
};

//디테일 정보 보기 함수
ChartView.prototype.setShowCrossLine = function(arrResult)
{
    var chartId = this.getElementId();
    
    var params= [chartId, arrResult[0]];
    if(!this.isDev() && !afc.isSimulator) ChartManager.setShowCrossLine(params);
    
};

//타임존 설정 함수
ChartView.prototype.setTimeZone = function(arrResult)
{
    var chartId = this.getElementId();
    var params= [chartId, arrResult[0]];
    if(!this.isDev() && !afc.isSimulator) ChartManager.setTimeZone(params);
    
};

//멀티 index 설정 함수
ChartView.prototype.setDivideNum = function(arrResult)
{
    var chartId = this.getElementId();
    var params= [chartId, arrResult[0]];
    if(!this.isDev() && !afc.isSimulator) ChartManager.setDivideNum(params);
    
};

//차트 설정값 저장
ChartView.prototype.saveConfigInfo = function()
{
    localStorage.setItem(this.beforeOptions['LoadChart'], JSON.stringify(this.chartConfig));
};

//일주월,분틱 조회 조건을 셋팅
ChartView.prototype.setPeriod = function(arrResult)
{
    var chartId = this.getElementId();
    
    var params= [chartId, arrResult[0], arrResult[1]];
   	if(!this.isDev() && !afc.isSimulator) ChartManager.setPeriod(params);
};

//시장구분코드를 셋팅
ChartView.prototype.setMarketCategory = function(arrResult)
{
    var chartId = this.getElementId();
    
    var params= [chartId, arrResult];
    if(!this.isDev() && !afc.isSimulator) ChartManager.setMarketCategory(params);
};

//기타지표 설정
ChartView.prototype.onRequestMarketIndicatorName = function(strMarketIndicatorTitle, nDataCount)
{
	if(this.searchType != 0) return;
	else
	{
		var term = (this.termBtn) ? this.termMap[this.termBtn.getText()]: this.term;
		if(term != 1) return;
	}
	
	var thisObj = this;
	var jipyoKey = this.jipyoMap[strMarketIndicatorTitle];
	var mainKeyTemp = {};
	
	for(var key in this.mainKeyInfo)
	{
		mainKeyTemp[key] = this.mainKeyInfo[key];
	}
	
	if(jipyoKey.item)
	{
		for(var key in jipyoKey.item)
		{
			mainKeyTemp[key] = jipyoKey.item[key];
		}
	}
	
	//mid에 맞는 시장지표인지 체크
	if(jipyoKey.chkMid && jipyoKey.chkMid.length > 0)
	{
		var isExist = false;
		for(var i = 0; i<jipyoKey.chkMid.length; i++)
		{
			if(jipyoKey.chkMid[i] == mainKeyTemp['D1시장분류코드'])
			{
				isExist = true;
				break;
			}
		}
		if(!isExist) return;
	}
	
	this.getContainer().view.sendData(jipyoKey.qryName, function(queryData, groupName)
	{
		var inBlock1 = queryData.getBlockData('InBlock1');
		inBlock1[0] = mainKeyTemp;
		
		if(jipyoKey.seqArr.length > 0)
		{
			var inBlock2 = queryData.getBlockData('InBlock2');

			//조인인 경우
			if(jipyoKey.joinType)
			{
				var keyName = '', obj;
				
				inBlock2[0] = obj = {};

				for(var i=0; i<jipyoKey.seqArr.length; i++)
				{
					inBlock1[i] = mainKeyTemp;
				
					keyName = 'D' + (i+1) + '종목투자자별SEQ';
					obj[keyName] = [ jipyoKey.seqArr[i] ];
				}
			}
			else
			{
				inBlock2[0] = { 'D1투자자SEQ' : jipyoKey.seqArr };
			}
			
		}

		var inBlock3 = queryData.getBlockData('InBlock3');
		inBlock3[0] =
		{
			'D1metrix의갯수' : nDataCount,
			'D1GID_CODE' : jipyoKey.gidCode,
			'D1일_주_월_분기_년' : 1,
			'D1prev' : '',
			'D1next' : ''
		};
		
		/*
		if(jipyoKey.joinType != undefined)
		{
			inBlock3[0]['D1join유형_0_and_1_or_2_first'] = jipyoKey.joinType;
		}
		*/
	},
	function(queryData, groupName)
	{
		if(queryData)
		{
		
			//2016.07.20 by hyh - QR000005 쿼리에 해당하는 function, 로직 작성
			if(thisObj.jipyoMap.queryName == "QR000005")
			{
				var resultDataArr = jipyoKey.func(queryData.getBlockData('OutBlock1'), jipyoKey.fid);
				var resultData = null;
				var title = new Array();

				title.push(strMarketIndicatorTitle+"_개인");
				title.push(strMarketIndicatorTitle+"_외국인");
				title.push(strMarketIndicatorTitle+"_기관계");
				title.push(strMarketIndicatorTitle+"_기타법인");

				for(var i = 0; i<title.length; i++)
				{
					resultData = resultDataArr[i];
					if(thisObj.isDev() || afc.isSimulator) return;
					ChartManager.setMarketData(thisObj.getElementId(), {
						ref : {
							marketIndicatorTitle : title[i],
							dataCount : resultData.length,
						},
						data : resultData
					});
				}
			}
			else 
			{
				var resultDataArr = jipyoKey.func(queryData.getBlockData('OutBlock1'), jipyoKey.fid);
				var resultData = null;
				var title = new Array();
				if(resultDataArr.length > 1)
				{
					title.push(strMarketIndicatorTitle+"_개인");
					title.push(strMarketIndicatorTitle+"_외국인");
					title.push(strMarketIndicatorTitle+"_기관계");
					title.push(strMarketIndicatorTitle+"_기타법인");
				}
				else
				{
					title.push(strMarketIndicatorTitle);
				}

				for(var i = 0; i<resultDataArr.length; i++)
				{
					resultData = resultDataArr[i];
					if(thisObj.isDev() || afc.isSimulator) return;
					ChartManager.setMarketData(thisObj.getElementId(), {
						ref : {
							marketIndicatorTitle : title[i],
							dataCount : resultData.length,
						},
						data : resultData
					});
				}
			}
		}
	});
	
};

ChartView.prototype.func1 = function(outBlock1, fid)
{
	var rowOne = null;
	var dataArr = new Array();

	for(var i = 0; i<outBlock1.length; i++)
	{
		rowOne = outBlock1[i];
		//dataArr = rowOne['D1입회일'];
		dataArr.push(rowOne[fid]);
	}
	
	
	return [dataArr];
};

ChartView.prototype.func2 = function(outBlock1)
{
	var rowOne = null;
	var dataArr = new Array();
	var totalSum = 0;
	
	var dataLen = outBlock1.length;
	dataArr.length = dataLen;

	for(var i = dataLen-1; i>-1; i--)
	{
		rowOne = outBlock1[i];
		totalSum += rowOne['D1투자자순매수수량'];
		dataArr[i] = totalSum;
	}
	return [dataArr];
};

ChartView.prototype.func3 = function(outBlock1)
{
	var rowOne = null;
	var dataArr = new Array();

	for(var i = 0; i<outBlock1.length; i++)
	{
		rowOne = outBlock1[i];
		
		var value = rowOne['D1거래대금_30609과동일']/rowOne['D1시가총액']*100;
		value = value.toFixed(2);
		
		dataArr.push(value);
	}
	return [dataArr];
};

ChartView.prototype.func4 = function(outBlock1, fid)
{
	var rowOne = null;
	var dataArr = new Array();
	var data1Arr = new Array();
	var data2Arr = new Array();
	var data3Arr = new Array();
	var data4Arr = new Array();
	
	for(var i = 0; i<outBlock1.length; i++)
	{
		rowOne = outBlock1[i];
		if(i%4 == 0)
		{
			data1Arr.push(rowOne[fid]);
		}
		else if(i%4 == 1)
		{
			data2Arr.push(rowOne[fid]);
		}
		else if(i%4 == 2)
		{
			data3Arr.push(rowOne[fid]);
		}
		else if(i%4 == 3)
		{
			data4Arr.push(rowOne[fid]);
		}
	}
	
	dataArr.push(data1Arr);
	dataArr.push(data2Arr);
	dataArr.push(data3Arr);
	dataArr.push(data4Arr);

	return dataArr;
};

ChartView.prototype.func5 = function(outBlock1, fid)
{
	var rowOne = null;
	var dataArr = new Array();

	for(var i = 0; i<outBlock1.length; i++)
	{
		rowOne = outBlock1[i];
		dataArr.push(rowOne[fid]/1000);
	}
	return [dataArr];
};

ChartView.prototype.func6 = function(outBlock1, fid)
{
	var rowOne = null;
	var dataArr = new Array();

	for(var i = 0; i<outBlock1.length; i++)
	{
		rowOne = outBlock1[i];
		dataArr.push(Math.round(rowOne[fid]/100));
	}
	return [dataArr];
};

//2016.07.20 by hyh - QR000005 쿼리에 해당하는 function 작성
ChartView.prototype.func7 = function(outBlock1, fid)
{
   var rowOne = null;
   var dataArr = new Array();
   var data1Arr = new Array();
   var data2Arr = new Array();
   var data3Arr = new Array();
   var data4Arr = new Array();

   for(var i = 0; i<outBlock1.length; i++)
   {
      rowOne = outBlock1[i];
      data1Arr.push(rowOne["D1"+fid]);
      data2Arr.push(rowOne["D2"+fid]);
      data3Arr.push(rowOne["D3"+fid]);
      data4Arr.push(rowOne["D4"+fid]);
   }

   dataArr.push(data1Arr);
   dataArr.push(data2Arr);
   dataArr.push(data3Arr);
   dataArr.push(data4Arr);

   return dataArr;
};

ChartView.prototype.onWindowResult = function(result, data, awindow)
{
	if(awindow.getId() == 'ChartTypeWindow')
	{
		if(result != undefined)
		{
			this.resetBtnState();
			var clickedBtn;
			
			switch(this.clickBtn.getComponentId())
			{
				case 'MinBtn':	
					this.setSearchType(1, result);
					this.setLastValue(result);
					clickedBtn = this.clickBtn;
					break;
					
				case 'TickBtn':
					this.setSearchType(2, result);
					this.setLastValue(result);
					clickedBtn = this.clickBtn;
					break;
					
				case 'TermBtn':
					this.setSearchType(0, this.termMap[result]);
					this.setLastValue(this.termMap[result]);
					clickedBtn = this.clickBtn;
					break;
				
				case 'MinBtn2':
					if($.inArray(result, ['일', '주', '월', '년'] ) > -1) {
						this.setSearchType(0, this.termMap[result]);
						this.setLastValue(this.termMap[result]);	
						
						//termBtn이 존재하면(세로모드에 일반적으로 존재), sendChartData에서 우선적으로 termBtn text 값을 기반으로 조회
						if(this.termBtn) this.termBtn.setText(result);	

						this.tickBtn2.setText('1');
						this.tickBtn2.$ele.hide();
						clickedBtn = this.clickBtn;
						
					} else if(result == "분" ){
						this.tickBtn2.$ele.show();
						
						//minBtn이 존재하면(세로모드에 일반적으로 존재), sendChartData에서 우선적으로 minBtn text 값을 기반으로 조회
						if(this.minBtn) this.minBtn.setText('1');
						
						this.setSearchType(1, '1');
						this.setLastValue('1');
						clickedBtn = this.tickBtn2;
						
					} else if(result == '틱') {
						this.tickBtn2.$ele.show();
						
						//tickBtn이 존재하면(세로모드에 일반적으로 존재), sendChartData에서 우선적으로 tickBtn text 값을 기반으로 조회
						if(this.tickBtn) this.tickBtn.setText('1');
						
						this.setSearchType(2, '1');
						this.setLastValue('1');	
						clickedBtn = this.tickBtn2;
					}
					break;
					
				case "TickBtn2":
					if(this.getSearchType()[0] == 1) {
						this.termBtn2.setText('분');
						
						//minBtn이 존재하면(세로모드에 일반적으로 존재), sendChartData에서 우선적으로 minBtn text 값을 기반으로 조회
						if(this.minBtn) this.minBtn.setText(result);
						
						this.setSearchType(1, result);
						this.setLastValue(result);
						clickedBtn = this.clickBtn;
					} 
					else if(this.getSearchType()[0] == 2) {
						this.termBtn2.setText('틱');
						
						//tickBtn이 존재하면(세로모드에 일반적으로 존재), sendChartData에서 우선적으로 tickBtn text 값을 기반으로 조회
						if(this.tickBtn) this.tickBtn.setText(result);
						
						this.setSearchType(2, result);
						this.setLastValue(result);
						clickedBtn = this.clickBtn;
					}
					break;
				
				default: 
					break;
			}	
			this.clickBtn.setText(result);

			this.selectBtn = clickedBtn;
			this.selectBtn.addClass('BT_CO2_NOR');

			this.sendChartData(0);
		}
	}
};

//가로보기에서 세로보기로 변경 시 btn 세팅 연동
ChartView.prototype.landscape2portrait = function()
{
	//세로보기 버튼 초기화
	if(this.termBtn)
	{
		this.termBtn.removeClass('BT_CO2_NOR');
		this.termBtn.setText('일');
	}
	if(this.minBtn)
	{
		this.minBtn.removeClass('BT_CO2_NOR');
		this.minBtn.setText('분');
	}
	if(this.tickBtn)
	{
		this.tickBtn.removeClass('BT_CO2_NOR');
		this.tickBtn.setText('틱');
	}
	
	//[ '일,분,틱' / '단위']
	var typelist = this.getSearchType();
	
	//세로보기 버튼 세팅
	switch(typelist[0])
	{
		//일, 주, 월, 년
		case 0:
			if(this.termBtn) {
				var temp = (typelist[1]) ? typelist[1] : 0;
				this.termBtn.setText(this.termMap2[temp]);
				this.termBtn.addClass('BT_CO2_NOR');
			}
			break;
		
		//분
		case 1:
			if(this.minBtn) {
				var temp = (typelist[1]) ? typelist[1] : 1;
				this.minBtn.setText(temp);
				this.minBtn.addClass('BT_CO2_NOR');
			}
			break;
		
		//틱
		case 2:
			if(this.tickBtn) {
				var temp = (typelist[1]) ? typelist[1] : 1;
				this.tickBtn.setText(temp);
				this.tickBtn.addClass('BT_CO2_NOR');
			}
			break;
			
		default:
			break;
	}
};

//세로보기에서 가로보기로 변경 시 btn 세팅 연동
ChartView.prototype.portrait2landscape = function()
{
	//가로보기 버튼 초기화
	if(this.termBtn2)
	{
		this.termBtn2.removeClass('BT_CO2_NOR');
		this.termBtn2.setText('일');
	}
	if(this.tickBtn2)
	{
		this.tickBtn2.removeClass('BT_CO2_NOR');
		this.tickBtn2.setText('1');
	}
	
	var typelist = this.getSearchType();
	
	//세로보기 버튼 세팅
	switch(typelist[0])
	{
		//일, 주, 월, 년
		case 0:
			if(this.termBtn2) {
				var temp = (typelist[1]) ? typelist[1] : 0;
				this.termBtn2.setText(this.termMap2[temp]);
				this.termBtn2.addClass('BT_CO2_NOR');
				this.tickBtn2.$ele.hide();
			}
			break;
		
		//분
		case 1:
			if(this.tickBtn2 && this.termBtn2) {
				var temp = (typelist[1]) ? typelist[1] : 1;
				this.tickBtn2.$ele.show();
				this.termBtn2.setText('분');
				this.tickBtn2.setText(temp);
				this.tickBtn2.addClass('BT_CO2_NOR');
			}
			break;
		
		//틱
		case 2:
			if(this.tickBtn2 && this.termBtn2) {
				var temp = (typelist[1]) ? typelist[1] : 1;
				this.tickBtn2.$ele.show();
				this.termBtn2.setText('틱');
				this.tickBtn2.setText(temp);
				this.tickBtn2.addClass('BT_CO2_NOR');
			}
			break;
			
		default:
			break;
	}
};


ChartView.prototype.onConfigViewPanalChange = function(isShow)
{
   if(this.getContainer().view.onIndiBtnClick) {
      if(isShow == "0" || isShow == 0) {
         if(this.getContainer().view.isCross) {
            var comp = this.getContainer().view.infoBtn;

            if(comp) {
               this.getContainer().view.onIndiBtnClick(comp);
            }
         }
      }
   }
   else {
      var tbvManager = this.getContainer().view.tbvManager;
	  var activeView;

	  if(tbvManager){
	  		activeView = this.getContainer().view.tbvManager.getActiveView();
	  }
	  else{
		  return;
	  }

      if(activeView.onIndiBtnClick) {
         if(isShow == "0" || isShow == 0) {
            if(activeView.isCross) {
               var comp = activeView.infoBtn;

               if(comp) {
                  activeView.onIndiBtnClick(comp);
               }
            }
         }
      }
   }
};

ChartView.prototype.setData = function(dataArr)
{
	if(!dataArr || (dataArr.length == 0))
	{
		this.clearChart();
		return;
	}

	if(this.isInit)
	{
		this.tempData = null;
		this.updateOutputData(dataArr);
	}
	else this.tempData = dataArr;

};

ChartView.prototype.setQueryData = function(dataArr, keyArr, queryData)
{
	var data = null;
	var queryName = queryData.getQueryName();
	
	if(queryName == this.realQueryName)
	{
		//2016.07.20 by hyh - 데이터가 없는 경우에는 차트 데이터 초기화 및 리턴 (리얼은 초기화 하지 않음)
		if(!dataArr || (dataArr.length == 0)) return;
		
		data = dataArr[0];
		if(queryData.isReal)
		{
			for(var key in data)
			{
				if(this.realData.hasOwnProperty(key))
				{
					this.realData[key] = data[key];
				}
			}
			this.updateRealData();
		}
		else
		{
			this.setSearchData(data);
		}
	}
	else if(queryName == 'QR000002' || queryName == 'QR000003' || queryName == 'QR000004' || queryName == 'QR000006'|| queryName == 'QR000015')
	{
		//다음 전송할 데이터가 있는지 체크 후 추가전송
		//this.manageSend(true);
	
		//2016.07.20 by hyh - 데이터가 없는 경우에는 차트 데이터 초기화 및 리턴
		if(!dataArr || (dataArr.length == 0))
		{
			this.clearChart();
			return;
		}

		if(this.isInit)
		{
			this.tempData = null;
			this.updateOutputData(dataArr);
		}
		else this.tempData = dataArr;
		
	}
};

ChartView.prototype.getMappingCount = function()
{
	return 2;
};
