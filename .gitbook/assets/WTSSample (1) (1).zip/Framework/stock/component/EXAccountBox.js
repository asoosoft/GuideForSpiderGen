     
/**
 * @author asoocool
 */
 
class EXAccountBox extends AComponent
{
    constructor()
    {
        super();
        
        this.frwName = 'stock';
        
        this.accList = new Array();
        this.accNoField = new Array(); 	//계좌번호 표시 필드
        this.accNmField = null;     	//계좌명 표시 필드
        this.accButton = null;     		//계좌번호 팝업창 띄우는 버튼
        this.accWindow = null;      	//계좌를 선택하는 팝업창
        this.pwViewShowType = AComponent.VISIBLE;   	//비밀번호뷰 숨김여부
        this.isGroup = false;			//그룹바이여부
        this.isShowChildAccount = true;	//자계좌표시여부
        
        this.accChangeCnt = 0;			//계좌순서가 변경됐을경우 싱크를 맞추기 위한 카운트 수
        
        //계좌정보 오브젝트
        this.accInfo = null;
        //this.lastAccInfo = null;
        this.preData = null;
        this.isBtnClickOpen = false;
        
        this.pwCallback = null;
        this.accType = 4;
        
        this.filterMap = 
        [	
            //0: 주식
            { '100': 1, '102': 1, '103': 1, '104': 1, '107': 1, '112': 1, '117': 1 },
            
            //1 선옵 / 야간CME
            { '101': 1 },
            
            //2 이체,바로이체
            { '100': 1, '101': 1, '102': 1, '103': 1, '104': 1, '107': 1, '108': 1, '109': 1, '112': 1, '114': 1, '115': 1, '117': 1, '118': 1, '119': 1, '120': 1, '121': 1, '122': 1 },
            
            //3 제휴이체
            { '107': 1, '117': 1 },
            
            //4: 통합거래내역, 나의자산_계좌
            { '100': 1, '101': 1, '102': 1, '103': 1, '104': 1, '107': 1, '108': 1, '109': 1, '112': 1, '113': 1, '114': 1, '115': 1, '117': 1, '118': 1, '119': 1, '120': 1, '121': 1, '122': 1 }
            
        ];
        
        this.filterType = null;
    }
}

window.EXAccountBox = EXAccountBox;

EXAccountBox.CONTEXT = 
{
    tag: '<div data-base="EXAccountBox" data-class="EXAccountBox" class="EXAccountBox-Style">'+
			'<input type="text" class="accountLabel" value = "Text" placeholder = "계좌번호선택"/><span class="accountButton"></span></div>',
         
    defStyle: 
    {
        width:'240px', height:'40px'
    },

    events: ['change']
};

EXAccountBox.ALLOWID = null;
EXAccountBox.ISFIRST = true;
EXAccountBox.STOCK = 0;
EXAccountBox.FOCME = 1;
EXAccountBox.TRANS = 2;
EXAccountBox.AFFIL = 3;
EXAccountBox.REPOR = 4;
EXAccountBox.LASTACCARR = [];
EXAccountBox.OPENACCWIN = null;


EXAccountBox.prototype.init = function(context, evtListener)
{
	AComponent.prototype.init.call(this, context, evtListener);
	
	this.accNoField[0] = this.element.children[0];
// 	this.accNoField[0].setAttribute('placeholder', '계좌번호선택');
	this.accButton = this.element.children[1];
	
	//this.accList = theApp.getLoginInfo('OutBlock3');
	this.accList = new Array();
	
	//EXAccountBoxEvent.implement(this);
};

EXAccountBox.prototype.defaultAction = function()
{
	var thisObj = this;
	
	this.$ele.bind(afc.ACTION_UP, function(e) 
    {
        thisObj.openWindow(true);
    });
    
};

//컨테이너 아이디를 받았을 경우 this.filterMap에 맞는 type로 변경
EXAccountBox.prototype.getFilterType = function(containerId)
{
	
	var filterType = null;
	this.firstStr = containerId.substring(0, 1);
	
	if(this.firstStr == '1') filterType = EXAccountBox.STOCK;
	else if(this.firstStr == '2') filterType = EXAccountBox.FOCME;
	else if(this.firstStr == '3')
	{
		var secondStr = containerId.substring(1, 2);
		if(secondStr == '1') filterType = EXAccountBox.TRANS;
		else if(secondStr == '2') filterType = EXAccountBox.REPOR;
	}
	return filterType;
};


EXAccountBox.prototype.setAccType = function(accType, pageId)
{
	this.isGroup = false;
	
	if( typeof(accType) == 'string')
	{
		this.accType = this.getFilterType(accType);
	}
	else this.accType = accType;
	
	this.refreshAccData();
};

EXAccountBox.prototype.refreshAccData = function()
{
	
	//var userAccArr = theApp.getLoginInfo('OutBlock3');
	var userAccArr = new Array();
	var filterObj = null;
	filterObj = this.filterMap[this.accType];
	var accOneData = null;
	var filterOneData = null;
	
	this.accList = new Array();
	for( var i = 0; i < userAccArr.length; i++ )
	{
		accOneData = userAccArr[i];
		filterOneData = filterObj[accOneData['PRCD']];
		if(filterOneData)
		{
			if(this.isShowChildAccount) this.accList.push(accOneData);
			else
			{
				if(accOneData['SELF_ACNT_YN'] == 'Y') this.accList.push(accOneData);
			}
		}
	}
	
	if(this.isGroup) this.setGroupByAccInfo();
	
};


EXAccountBox.prototype.getAccType = function()
{
	if(this.accInfo)
	{
		for( var i = 0; i < this.filterMap.length; i++ )
		{
			if(this.filterMap[i][this.accInfo['PRCD']]) return i;
		}	
	}
	return -1;
};


EXAccountBox.prototype.showChildAccount = function(isShowChildAccount)
{
	this.isShowChildAccount = isShowChildAccount;	
	if(!this.isShowChildAccount)
	{
		var tempArr = new Array();
		for(var i = 0; i < this.accList.length; i++)
		{
			if(this.accList[i]['SELF_ACNT_YN'] == 'Y') tempArr.push(this.accList[i]);
		}
		this.accList = tempArr;	
	}
};

EXAccountBox.prototype.setGroupByAccInfo = function()
{
	this.isGroup = true;
	var filterObj = new Object();
	var accInfoOne = null;
	var tempArr = new Array();
	var tempAcno = null;
	for(var i = 0; i < this.accList.length; i++)
	{
		accInfoOne = this.accList[i];
		tempAcno = accInfoOne['REG_ACNO'];	
		if(filterObj[tempAcno]) continue;
		else
		{
			filterObj[tempAcno] = 1;
			if(this.isShowChildAccount) tempArr.push(accInfoOne);
			else if(accInfoOne['SELF_ACNT_YN'] == 'Y') tempArr.push(accInfoOne);
		}
	}
	this.accList = tempArr;
};


EXAccountBox.prototype.getExistAccInfoIdx = function()
{
	var lastAccInfo = null;
	
	for(var i = 0; i < EXAccountBox.LASTACCARR.length; i++)
	{
		lastAccInfo = EXAccountBox.LASTACCARR[i];
		for( var j = 0; j < this.accList.length; j++ )
		{
			if(afc.makeAccText(this.accList[j], this.isGroup) == afc.makeAccText(lastAccInfo, this.isGroup)) 
				return j;	
		}	
	}
	return -1;
};

EXAccountBox.prototype.removeLastAccInfo = function(accInfo)
{
	var lastAccInfo = null;
	
	for(var i = EXAccountBox.LASTACCARR.length - 1; i >=0 ; i--)
	{		
		if(afc.makeAccText(EXAccountBox.LASTACCARR[i], this.isGroup) == afc.makeAccText(accInfo, this.isGroup))
			EXAccountBox.LASTACCARR.splice(i, 1);
	}
};

EXAccountBox.prototype.addLastAccInfo = function(accInfo)
{
	this.removeLastAccInfo(accInfo);
	EXAccountBox.LASTACCARR.unshift(accInfo);
};


//기존에 쓰던 계좌가 있으면 그 계좌 데이터로 셋팅
EXAccountBox.prototype.setDefaultData = function()
{
	//계좌순서가 변경됐을 경우 이전 목록을 갱신시킴
	if(theApp.accountChangedCount > this.accChangeCnt)
	{
		this.refreshAccData();
		this.accChangeCnt = theApp.accountChangedCount;
	}
	
	if(this.accList)
	{
		if(this.accList.length > 0) 
		{
			var searchIdx = this.getExistAccInfoIdx();
			if(searchIdx > -1) this.setAccData(this.accList[searchIdx]);
			else this.setAccData(null);
		}
		else this.setAccData(null);
	}
	else this.setAccData(null);
};

EXAccountBox.prototype.setNameLabel = function(labelComp)
{
    this.accNmField = labelComp.element;
};

EXAccountBox.prototype.addNoLabel = function(labelArr)
{
	for(var i=0; i<labelArr.length; i++)
	{
		this.accNoField.push(labelArr[i]);
	}
};

EXAccountBox.prototype.clearNoLabel = function()
{
	this.accNoField.length = 1;
};

EXAccountBox.prototype.setWindow = function(window)
{
    this.accWindow = window;
};

EXAccountBox.prototype.showPwView = function(showType)
{
    this.pwViewShowType = showType;
};

EXAccountBox.prototype.selectItemByText = function(text)
{
	this.selectItem(this.indexOfText(text));
};

EXAccountBox.prototype.setAccText = function()
{
	if(this.accInfo)
	{
		var accText  = afc.makeAccText(this.accInfo, this.isGroup);
		for(var i=0; i<this.accNoField.length; i++)
		{
			this.accNoField[i].value = accText;
		}
		if(this.accNmField)
		{
			this.accNmField.textContent = this.accInfo.CUST_ABWR_NAME;
			//4.1.1버전에서 텍스트 셋팅후 화면갱신 안되는 버그 대응
			$(this.accNmField).hide();
			$(this.accNmField).show();
		}
	}
	else 
	{
		for(var i=0; i<this.accNoField.length; i++)
		{
			$(this.accNoField[i]).val('');
		}
		if(this.accNmField) this.accNmField.textContent = '';
	}
};


EXAccountBox.prototype.setAccData = function(accInfo)
{
	this.accInfo = accInfo;
	this.setAccText();
};

EXAccountBox.prototype.getAccData = function()
{
	return this.accInfo;
};

EXAccountBox.prototype.getAccNoText = function()
{
	return this.accNoField[0].value;
};

EXAccountBox.prototype.setAccNoText = function(value)
{
	this.accNoField[0].setAttribute('value', value);
};

EXAccountBox.prototype.getAccNmText = function()
{
	return this.accInfo.CUST_ABWR_NAME;
};

EXAccountBox.prototype.clearPassword = function()
{
	if(!theApp.ConfigObj.getConfig('ACC_PWD_SAVE'))
	{
		if(this.accInfo)
		theApp.setChiperData('_'+this.accInfo.REG_ACNO, null);
		
		EXAccountBox.ALLOWID = null;
	}
};


//패스워드를 체크하여 팝업창을 띄울지 말지 결정
EXAccountBox.prototype.accPwSaveCheck = function(callback)
{
	//계좌를 묻는창이 기존에 떠있으면 취소시킴
	if(EXAccountBox.OPENACCWIN) return;
	
	this.pwCallback = callback;
	var curPageId = theApp.subNavi.getActivePage().getId();
	
	if(this.accInfo)
	{
		//패스워드 저장여부 체크했거나 같은 페이지에서 또 요청했을경우 그대로 진행
		if(theApp.ConfigObj.getConfig('ACC_PWD_SAVE') || (EXAccountBox.ALLOWID == curPageId))
		{
			var cipData = theApp.PadChiperData['_'+this.accInfo.REG_ACNO];
			if(cipData) 
			{
				this.pwCallback(true);
				this.pwCallback = null;
				
				return;
			}
		}
	}
	
	this.openWindow();

};

//계좌선택팝업을 띄움
EXAccountBox.prototype.openWindow = function(isBtnClickOpen)
{
	if(this.accList.length > 0)
	{
		//패스워드 체크가 아닌 직접 버튼을 눌러서 open할 경우
		this.isBtnClickOpen = isBtnClickOpen;
		this.preData = this.getAccNoText();
		//비밀번호를 요구하지 않고 계좌만 선택할수도 있는 화면일경우 pwViewShowType = false 임
		this.accWindow.pwViewShowType = this.pwViewShowType;
		this.accWindow.accList = this.accList;
		this.accWindow.preData = this.preData;
		this.accWindow.accType = this.accType;
		this.accWindow.isGroup = this.isGroup;
		this.accWindow.openAsDialog(this);
		EXAccountBox.OPENACCWIN = this.accWindow;
	}
	else AToast.show('계좌가 존재하지 않습니다.');
	
};

EXAccountBox.prototype.onWindowResult = function(result, awindow)
{	
	EXAccountBox.OPENACCWIN = null;
	
	//계좌팝업 윈도우에서 넘어온 값으로 셋팅
    if(result == 1)
	{
		this.accInfo = awindow.accInfo;
		this.addLastAccInfo(awindow.accInfo);
		this.setAccText();
		
		EXAccountBox.ALLOWID = theApp.subNavi.getActivePage().getId();
		
		if(this.pwCallback) 
		{
			this.pwCallback(true);
			this.pwCallback = null;
		}
		//if(this.isBtnClickOpen && (this.preData != this.getAccNoText()) ) this.reportEvent('change', this.accInfo);
		if(this.isBtnClickOpen) this.reportEvent('change', this.accInfo);
	}
	else
	{
		if(this.pwCallback) 
		{
			this.pwCallback(false);
			this.pwCallback = null;
		}
	}
};

EXAccountBox.prototype.setData = function(dataArr)
{
};

EXAccountBox.prototype.setQueryData = function(dataArr, keyArr)
{
	if(!keyArr) return;
};

EXAccountBox.prototype.getQueryData = function(dataArr, keyArr)
{
	if(!keyArr) return;
	
	var inBlockData = dataArr[0];               //InBlock JSON
	var value = '';
	
    for(var i=0; i<keyArr.length; i++)
    {
        var trKeyName = keyArr[i];
        if(trKeyName)
        {
            //계좌번호일경우
            if(trKeyName == 'ACNO')
            {
                value = this.accInfo.REG_ACNO;
            }
			//계좌일련번호일경우
            else if(trKeyName == 'ASNO')
            {
                value = this.accInfo.REG_ASNO;
            }
			//비밀번호 일경우
            else if(trKeyName == 'ACNT_PWD')
            {
                value = '';
            }
			inBlockData[trKeyName] = value;
        }
    }
};

EXAccountBox.prototype.getMappingCount = function()
{
	return 2;
};
