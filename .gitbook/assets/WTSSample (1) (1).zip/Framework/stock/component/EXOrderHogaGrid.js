
(async function(){

await afc.import("Framework/afc/component/AGrid.js");



/**
 * @author asoocool
 */

EXOrderHogaGrid = class EXOrderHogaGrid extends AGrid
{
    constructor()
    {
        super();
        
        this.frwName = 'stock';
        
        this.basePrice = undefined; //기준가
        this.currentPrice = 0; 
        this.currentCell = null; 
        this.rowLen = 0; 
        this.colLen = 0;
        this.keyLen = 0;
        this.keyHalf = 0;
        this.curPriceKey = 'curprc';
        this.curPriceMap = null;
        this.currentPrice = 0;	
        this.priceMode = false;
        this.curPriceStyleArr = null;
        
        //잔량값 저장 배열(2차원), 그리드 형태와 동일
        this.remainValArr = null;
        
        this.hogaOption = 
        {
            sellBgColor: '#a1c1e8',
            buyBgColor: '#e5b7b5'
        };
    }
}

//window.EXOrderHogaGrid = EXOrderHogaGrid;

EXOrderHogaGrid.CONTEXT =
{
    tag: '<div data-base="EXOrderHogaGrid" data-class="EXOrderHogaGrid" \
    		data-blocks-hogagrid="OutBlock1,D1매도호가잔량5,D1매도호가5,,D1매도호가잔량4,D1매도호가4,,D1매도호가잔량3,D1매도호가3,,D1매도호가잔량2,D1매도호가2,,D1매도호가잔량1,D1매도호가1,,,\
    		D1매수호가1,D1매수호가잔량1,,D1매수호가2,D1매수호가잔량2,,D1매수호가3,D1매수호가잔량3,,D1매수호가4,D1매수호가잔량4,,D1매수호가5,D1매수호가잔량5,,"\
    		data-hide-header="true" data-flexible-row="true" data-query-name="HOGAGRID" data-selectable="true" class="AGrid-Style">\
            <table cellpadding="0" align="center" style="width:100%; border-collapse:collapse;" class="grid-header-table">\
            	<colgroup><col width="50%" /><col width="50%" /></colgroup>\
                <thead align="center" class="head-prop" style="display:none;">\
                    <tr height="0px"><td>col1</td><td>col2</td></tr>\
				</thead>\
			</table>\
			<div style="height:100%; overflow-y:auto; -webkit-overflow-scrolling:touch;">\
			<table align="center" cellpadding="0" class="grid-body-table" style="width:100%; border-collapse:collapse;">\
				<colgroup><col width="50%" /><col width="50%" /></colgroup>\
				<thead align="center" class="head-prop" style="display:none;">\
                    <tr height="0px"><td>col1</td><td>col2</td></tr>\
				</thead>\
                <tbody align="center" class="body-prop">\
                    <tr height="74px" class="normal-prop"><td></td><td></td></tr>\
                    <tr height="74px" class="normal-prop"><td></td><td></td></tr>\
                    <tr height="74px" class="normal-prop"><td></td><td></td></tr>\
                    <tr height="74px" class="normal-prop"><td></td><td></td></tr>\
                    <tr height="74px" class="normal-prop"><td></td><td></td></tr>\
                    <tr height="74px" class="normal-prop"><td></td><td></td></tr>\
                    <tr height="74px" class="normal-prop"><td></td><td></td></tr>\
                    <tr height="74px" class="normal-prop"><td></td><td></td></tr>\
                    <tr height="74px" class="normal-prop"><td></td><td></td></tr>\
                    <tr height="74px" class="normal-prop"><td></td><td></td></tr>\
                    <tr height="74px" class="normal-prop"><td></td><td></td></tr>\
                    <tr height="74px" class="normal-prop"><td></td><td></td></tr>\
                    <tr height="74px" class="normal-prop"><td></td><td></td></tr>\
                    <tr height="74px" class="normal-prop"><td></td><td></td></tr>\
                    <tr height="74px" class="normal-prop"><td></td><td></td></tr>\
                    <tr height="74px" class="normal-prop"><td></td><td></td></tr>\
                    <tr height="74px" class="normal-prop"><td></td><td></td></tr>\
                    <tr height="74px" class="normal-prop"><td></td><td></td></tr>\
                    <tr height="74px" class="normal-prop"><td></td><td></td></tr>\
                    <tr height="74px" class="normal-prop"><td></td><td></td></tr>\
				</tbody>\
			</table>\
			</div>\
		</div>',
    
    defStyle: 
    {
        width:'40%', height:'550px'
    },
    
    events: ['select', 'scrolltop', 'scrollbottom']
};

EXOrderHogaGrid.prototype.init = function(context, evtListener)
{
	AGrid.prototype.init.call(this, context, evtListener);
	
    this.selectStyleName = null;
	
	if(afc.isIos) this.enableScrlManager();
	//BugFix Android 4.1
	else if(afc.andVer < 4.1)
	{
		this.enableScrlManager();
		this.scrollArea.css('overflow', 'hidden');
	}
	
	this.rowLen = this.getRowCount();
	this.colLen = this.getColumnCount();
	
    //Current Price Cell Style
    this.curPriceStyleArr = ['EXOrderHogaGrid-Style-CurPrice', 'EXOrderHogaGrid-Style-CurPrice', 'EXOrderHogaGrid-Style-CurPrice'];
	this.crctClass = 'font-R17';
	this.crctInfo = [];
	
	this.detailMode = false;	// 등락률 표시 여부
	this.rowUnit = 1;			// 등락률 표시하는 경우 로우가 하나 추가되므로
	
    this.maskArr = [ afc.hogaComma, afc.hogaComma ];
    this.colorArr = [ stk.getColorTagCfValue, stk.getAsMaskedIt];
	
	//초기화
	this.remainValArr = new Array(this.rowLen);
	for(var i=0; i<this.rowLen; i++)
	{
		this.remainValArr[i] = new Array(this.colLen);
		
		for(var j=0; j<this.colLen; j++)
			this.remainValArr[i][j] = 0;
	}
};

EXOrderHogaGrid.prototype.resetGrid = function()
{
    this.removeAll();
    
    this.offsetRow = this.addRow([]).get(0);
    this.offsetCol = 0;
};

EXOrderHogaGrid.prototype.setBasePrice = function(basePrice)
{
	if(!basePrice) basePrice = undefined;
	this.basePrice = basePrice;
};

EXOrderHogaGrid.prototype.setCurrentPrice = function(currentPrice)
{
	this.currentPrice = currentPrice;
};

EXOrderHogaGrid.prototype.setCurPriceKey = function(keyName)
{
	this.curPriceKey = keyName;
};

EXOrderHogaGrid.prototype.clearCurrentPrice = function()
{
	this.currentPrice = null;
	this.selectCurrentPrice();
};

EXOrderHogaGrid.prototype.selectCurrentPrice = function()
{
	if(this.currentCell)
	{
		if(this.detailMode)
		{
			var nextTr = this.currentCell.parent().next();
			this.currentCell.parent().removeClass(this.curPriceStyleArr[0]);
			this.currentCell.parent().removeClass(this.curPriceStyleArr[1]);
			this.currentCell.parent().removeClass(this.curPriceStyleArr[2]);
			nextTr.removeClass(this.curPriceStyleArr[0]);
			nextTr.removeClass(this.curPriceStyleArr[1]);
			nextTr.removeClass(this.curPriceStyleArr[2]);
		}
		else
		{
			this.currentCell.removeClass(this.curPriceStyleArr[0]);
			this.currentCell.removeClass(this.curPriceStyleArr[1]);
			this.currentCell.removeClass(this.curPriceStyleArr[2]);
		}
		//this.currentCell[0].style.removeProperty('border-right');
		//this.currentCell[0].style.removeProperty('border-bottom');
	}
	
	if(this.curPriceMap)
	{	
		var cellOne = null, value, idx;
		for(var i = 0; i < this.curPriceMap.length; i++)
		{
			cellOne = this.curPriceMap[i];
			value = this.maskArr[0](this.currentPrice);
			if(cellOne.text() == value)
			{
				this.currentCell = cellOne;
				
				if(this.basePrice == undefined) idx = 1;
				else if(this.basePrice < this.currentPrice) idx = 0;
				else if(this.basePrice > this.currentPrice) idx = 2;
				else idx = 1;
				
				if(this.detailMode)
				{
					var nextTr = this.currentCell.parent().next();
					this.currentCell.parent().addClass(this.curPriceStyleArr[idx]);
					nextTr.addClass(this.curPriceStyleArr[idx]);
				}
				else 
				{
					this.currentCell.addClass(this.curPriceStyleArr[idx]);
				}
				
				//this.currentCell[0].style.setProperty('border-right', 'none','!important');
				//this.currentCell[0].style.setProperty('border-bottom', 'none','!important');
				break;
			}
		}
	}
};

EXOrderHogaGrid.prototype.setCurrentPriceStyleArr = function(styleArr)
{
	if(styleArr) this.curPriceStyleArr = styleArr;
	else this.curPriceStyleArr = ['EXOrderHogaGrid-Style-CurPrice', 'EXOrderHogaGrid-Style-CurPrice', 'EXOrderHogaGrid-Style-CurPrice'];
};

EXOrderHogaGrid.prototype.setHogaOption = function(key, value)
{
	this.option['key'] = value;
};

//valueType - 소수점 2자리 true, 소수점 0자리 false 또는 소수점 2자리 2, 소수점 0자리 0 
EXOrderHogaGrid.prototype.setValueType = function(valueType)
{
	this.valueType = valueType;
	this.setMaskColorInfo();
};

EXOrderHogaGrid.prototype.setMaskColorInfo = function()
{
	this.maskArr = [ afc.hogaComma, afc.hogaComma];
};

EXOrderHogaGrid.prototype.getMaskValue = function(index, data, keyVal, ele)
{
	return this.colorArr[index](data[keyVal], this.maskArr[index], this.basePrice, ele);
};

EXOrderHogaGrid.prototype.getUpdnRateValue = function(index, data, keyVal, ele)
{
	var value = NaN, cmprValue = 0;
	
	if(this.basePrice == undefined) cmprValue = 0;
	else if(parseFloat(data[keyVal]))
	{
		value = afc.removeComma(data[keyVal]) - this.basePrice;
		value = ((value/this.basePrice)*100).toFixed(2);
		cmprValue = value;
	}

	return stk.makeStockTag(cmprValue, 0, this.hogaCommaPercent(value), ele);
};
/*
EXOrderHogaGrid.prototype.getCrctValue = function(index, data, keyVal, ele)
{
	var ret, value;

	if(this.crctInfo[0] == data[keyVal]) value = this.crctInfo[1];
	else value = ''; //'　';

	if(ele) ele.firstChild.textContent = value;
	else ret = '<span class="'+ this.crctClass +'">'+value+'</span>';

	return ret;
};

// [가격, 잔량] 미체결량 세팅하는 함수
EXOrderHogaGrid.prototype.setCrctInfo = function(crctInfo)
{
	if(crctInfo) this.crctInfo = crctInfo;
};

// 미체결량을 표시하는 CSS 클래스명 세팅함수
EXOrderHogaGrid.prototype.setCrctClass = function(className)
{
	this.crctClass = className;
};
EXOrderHogaGrid.prototype.getRestTag = function(value, mask, baseValue, ele)
{
	if(!value) ret = '';
	else
	{
		value = value.toString().split('.');
		var len = 8 - value[1].length;

		var ret = '<span class="font-R04">' + value[0] + '.' + value[1];
		if(len > 0)
		{
			ret += '<font class="font-R17">';
			for (var i=0; i<len; i++) ret += '0';
			ret += '</font>';
		}
		ret += '</span>';
	}
	console.log(ret);

	return ret;
};
*/

EXOrderHogaGrid.prototype.hogaCommaPercent = function(value)
{
	if(isNaN(value)) value = '　';
    else
	{
		if(!value) value = '0.00';
		value = afc.addPercent(afc.addComma(value));
	}
	return value;
};

EXOrderHogaGrid.prototype.setDetailMode = function(detailMode)
{
	var thisObj = this;
	this.detailMode = detailMode;
	this.rowUnit = detailMode?2:1;

	var func = _remove_helper;
	if(this.detailMode) func = _set_helper
	
	for(var i=0; i<this.rowLen; i=i+2)
	{
		func(i);
	}

	function _set_helper(i)
	{
		thisObj.getRow(i).style.setProperty('border-bottom-color', 'transparent', 'important');
		thisObj.getRow(i+1).style.setProperty('border-top-color', 'transparent', 'important');
	}

	function _remove_helper(i, j)
	{
		thisObj.getRow(i).style.removeProperty('border-bottom-color');
		thisObj.getRow(i+1).style.removeProperty('border-top-color');
	}
};

EXOrderHogaGrid.prototype.setQueryData = function(dataArr, keyArr, queryData)
{
	if(!keyArr) return;
	
	var data = dataArr[0], row, keyName, inx = 0, value = 0, maxQty = 0;
	
	if(data[this.curPriceKey]) this.setCurrentPrice(data[this.curPriceKey]);
	/*
	var dataKeyGrp = this.realMap[data.key];
	
	//리얼 쿼리일 경우
	if(queryData.isReal)
	{
		var ret, realCell;//, dataKeyGrp = this.realMap[data.key];
		
		if(!dataKeyGrp) return;
		
		for(var i = 0; i < this.rowLen; i++)
		{
			for(var j=0; j < this.colLen; j++)
			{
				keyName = keyArr[inx++];		
				if(!keyName) continue;
				
				//리얼맵에 등록되지 않은 keyName인 경우 다른 Query이므로 리턴
				//if(!this.realMap[data.key] || !this.realMap[data.key][keyName]) return;
				
				value = data[keyName];
				
				if(value!=undefined)	//data[keyName] != undefined
				{
					if(j==1) this.remainValArr[i][j] = value;
					
					realCell = dataKeyGrp[keyName];
					if(!realCell) continue;
					
					ret = this.getMaskValue(j, data, keyName, realCell );
					if(ret) realCell.textContent = ret;
				}
				
				//max value 구하기
				if(j==1)
				{
					value = this.remainValArr[i][j];
					if(value > maxQty) maxQty = value;
				}
			}
		}	
	}
	
	//조회 쿼리일 경우
	else
	{*/
		var mapCell = null;
		this.keyLen = keyArr.length;
		this.keyHalf = this.keyLen/2;
		
// 		this.realMap[data.key] = dataKeyGrp = {};
		var dataKeyGrp = {};
		
		for(var i = 0; i < this.rowLen; i++)
		{
			row = this.getRow(i);
			for(var j=0; j < this.colLen; j++)
			{
				keyName = keyArr[inx++];
				if(!keyName) continue;
				
				//mapCell = $(this.getCell(row, j));
				mapCell = this.getCell(row, j);
				
				//리얼맵 셋팅
				//if(this.realMap) dataKeyGrp[keyName] = mapCell;
				dataKeyGrp[keyName] = mapCell;
				
				mapCell.innerHTML = this.getMaskValue(j, data, keyName);//mapCell.html(this.getMaskValue(j, data, keyName));
				
				if(this.detailMode && j==0)
				{
					this.getCell(i+1, j).innerHTML = this.getUpdnRateValue(3, data, keyName);
					//this.getCell(i+1, j+1).innerHTML = this.getCrctValue(4, data, keyName);
				}
				else if(j==1) 
				{
					value = data[keyName];
					this.remainValArr[i][j] = value;
					if(value > maxQty) maxQty = value*1;
				}
				/*
				//소수점 데이터인 경우 0.00 으로 들어와서 화면에 표시되어 체크
				if( parseFloat(data[keyName]).toFixed(2) != 0.00 ) mapCell.innerHTML = this.getMaskValue(j, data, keyName);//mapCell.html(this.getMaskValue(j, data, keyName));
				else
				{
					mapCell.textContent = '　';
					if(j==1) mapCell.style.setProperty("background-size", '0% 7px', 'important');
				}
				*/
				/*
				value = data[keyName];
				if(value)
				{
					if(j < 1)
					{
						mapCell.html(stk.getStockColorCompare(value, this.basePrice));
						
						if(this.priceMode)
							mapCell.next().html(stk.getStockColorCompare(afc.removeComma(value) - this.basePrice, 0));
					}
					else
					{
						if(value > maxQty) maxQty = value;
						if(!this.priceMode) mapCell.text(afc.addComma(value));
					}
				}
				else
				{
					mapCell.text('');
					if(j==1) mapCell[0].style.setProperty("background-size", '0% 7px', 'important');
				}
				*/
			}
		}
		
		if(!queryData.isReal)
		{
			//현재가를 그리기위한 셀셋팅
			this.curPriceMap = 
			[
				$(this.getCell(this.rowLen/2-(1*this.rowUnit), 0)),
				$(this.getCell(this.rowLen/2, 0)),
				$(this.getCell(this.rowLen/2-(2*this.rowUnit), 0)),
				$(this.getCell(this.rowLen/2+(1*this.rowUnit), 0)),
				$(this.getCell(this.rowLen/2-(3*this.rowUnit), 0)),
				$(this.getCell(this.rowLen/2+(2*this.rowUnit), 0))
			];

			var thisObj = this;	
			 setTimeout(function(){ thisObj.scrollToCenter(); }, 10);
		}
	//}
	
	this.selectCurrentPrice();
	/*
	if(!maxQty)
	{
		for(var j = 1; j < this.keyLen; j+=2)
		{
			keyName = keyArr[j];
			if(!keyName) continue;
			
			value = parseInt(afc.removeComma(this.realMap[data.key][keyName].textContent), 10);
			if(value > maxQty) maxQty = value;
		}
	}
	*/
	
	// 최대값이 0일때 잔량표시바가 갱신되지않아서 maxQty값을 1로 세팅
	if(maxQty == 0) maxQty = 1;
	
	inx=-1;
	for(var j = 0; j<this.rowLen; j++)
	{
		row = this.getRow(j);
		for(var k = 0; k<this.colLen; k++)
		{	
			inx++;
			if(k==0) continue;
			
			keyName = keyArr[inx];
			if(!keyName) continue;
			
			//value = data[keyName];
			
			value = this.remainValArr[j][k];
			//if(!value) value = parseInt(afc.removeComma(this.realMap[data.key][keyName].textContent),10);
			//if(value)
			//{
				dataKeyGrp[keyName].style.setProperty("background-size", parseInt(value/maxQty*100, 10)+'% 7px', 'important');
			//}
		}
	}
	
	
	
	/*
	//체결량 막대
	for(var j = 1; j < this.keyLen; j+=2)
	{
		keyName = keyArr[j];
		if(!keyName) continue;
		
		value = this.remainValArr[j][k];
		//if(!value) value = parseInt(afc.removeComma(this.realMap[data.key][keyName].textContent),10);
		//if(value)
		//{
			dataKeyGrp[keyName].style.setProperty("background-size", parseInt(value/maxQty*100, 10)+'% 7px', 'important');
		//}
	}
	*/
	
	/*
	//매수 체결량 막대
	for(var j = this.keyHalf; j < this.keyLen; j+=2)
	{
		keyName = keyArr[j];
		if(!keyName) continue;
		
		value = data[keyName];
		if(!value) value = parseInt(afc.removeComma(this.realMap[data.key][keyName].text()),10);
		if(value)
		{
			this.realMap[data.key][keyName][0].style.setProperty("background-size", parseInt(value/maxQty*100, 10)+'% 7px', 'important');
		}
	}*/
};

                    
//window.EXOrderHogaGrid = EXOrderHogaGrid;
                    
})();