(async function(){

await afc.import("Framework/stock/component/BaseChart.js");



EXMiniChart = class EXMiniChart extends BaseChart
{
    constructor()
    {
        super();
	
        this.frwName = 'stock';
        
        this.basePrice = 0;
        
        this.maxCount = 52;
        
        this.colorMode = 'black';
        
        this.dateKey = 0;
        this.valueKey = 1;
        
        this.priceArr = null;
        this.timeArr = null;
        this.timeEnd = 0;
        
        this.mode = 'price';
        this.termW = 0;
        
        this.isRealMode = false;
        
        this.maxAm = 0;
        this.minAm = Number.MAX_VALUE;
        
        this.defColorObj = {
            BACK : StockColor.BACK_D,
            DIVLINE: StockColor.DIVLINE_D,
            BASELINE: StockColor.BASELINE_D,
            TEXT: StockColor.TEXT_D,
            TEXT_BASE : StockColor.TEXT_BASE_D,
            TIMELINE: StockColor.TIMELINE_D,
            UP: StockColor.UP_COLOR_D,
            DOWN: StockColor.DOWN_COLOR_D,
            TEXT_TIME: StockColor.TEXT_TIME_D,
            TEXT_LEFT: StockColor.TEXT_LEFT_D,
            CONT_BACK: StockColor.CONT_BACK_D,
            CONT_ROUND: StockColor.CONT_ROUND_D
        };
        
        this.colorObj = {
            BACK : StockColor.BACK_D,
            DIVLINE: StockColor.DIVLINE_D,
            BASELINE: StockColor.BASELINE_D,
            TEXT: StockColor.TEXT_D,
            TEXT_BASE : StockColor.TEXT_BASE_D,
            TIMELINE: StockColor.TIMELINE_D,
            UP: StockColor.UP_COLOR_D,
            DOWN: StockColor.DOWN_COLOR_D,
            TEXT_TIME: StockColor.TEXT_TIME_D,
            TEXT_LEFT: StockColor.TEXT_LEFT_D,
            CONT_BACK: StockColor.CONT_BACK_D,
            CONT_ROUND: StockColor.CONT_ROUND_D
        };
        
        //포지션에 관련된 객체
        this.pos = 
        {  
            txtX : 0,
            grpSY : 0,
            hourSY : 0,
            hourY : 0,
            grpEY : 0,
            grpH : 0,
            baseY : 0,
            grpR : 0, 
            grpLeft: 80,  
            grpTp : null
        };
        
        this.updateTime = 5 * 60;
    }
}

//window.EXMiniChart = EXMiniChart;

EXMiniChart.CONTEXT	=
{
    tag: '<div data-base="EXMiniChart" data-class="EXMiniChart" class="EXMiniChart-Style" >'+
            '<canvas width="300px" height="200px"></canvas></div>',

    defStyle: 
    {
        width:'300px', height:'200px'
    },

    events: []
};


EXMiniChart.prototype.init = function(context, evtListener)
{
	BaseChart.prototype.init.call(this, context, evtListener);
	
	if(theApp.themeMode && theApp.themeMode == 'MO') this.setColorMode('white');
	
};

EXMiniChart.prototype.getMaxCount = function()
{
    return this.maxCount;
};

EXMiniChart.prototype.setMaxCount = function(maxCount)
{
  	this.maxCount = maxCount;
    this.termW = (this.eleW-this.pos.grpLeft)/this.maxCount;
};

EXMiniChart.prototype.setColorMode = function(colorMode)
{
  	this.colorMode = colorMode;
  	
  	if(this.colorMode == 'white')
  	{
		this.defColorObj = {
			BACK : StockColor.BACK,
	        DIVLINE: StockColor.DIVLINE,
	        BASELINE: StockColor.BASELINE,
	        TEXT: StockColor.TEXT,
	        TEXT_BASE: StockColor.TEXT_BASE,
	        TIMELINE: StockColor.TIMELINE,
	        UP: StockColor.UP_COLOR,
	        DOWN: StockColor.DOWN_COLOR,
	        TEXT_TIME: StockColor.TEXT_TIME,
	        TEXT_LEFT: StockColor.TEXT_LEFT,
	        CONT_BACK: StockColor.CONT_BACK,
	        CONT_ROUND: StockColor.CONT_ROUND
		};
  		this.colorObj = {
			BACK : StockColor.BACK,
	        DIVLINE: StockColor.DIVLINE,
	        BASELINE: StockColor.BASELINE,
	        TEXT: StockColor.TEXT,
	        TEXT_BASE: StockColor.TEXT_BASE,
	        TIMELINE: StockColor.TIMELINE,
	        UP: StockColor.UP_COLOR,
	        DOWN: StockColor.DOWN_COLOR,
	        TEXT_TIME: StockColor.TEXT_TIME,
	        TEXT_LEFT: StockColor.TEXT_LEFT,
	        CONT_BACK: StockColor.CONT_BACK,
	        CONT_ROUND: StockColor.CONT_ROUND
	    };	
  	}
  	else
  	{
		this.defColorObj = {
			BACK : StockColor.BACK_D,
	        DIVLINE: StockColor.DIVLINE_D,
	        BASELINE: StockColor.BASELINE_D,
	        TEXT: StockColor.TEXT_D,
	        TEXT_BASE: StockColor.TEXT_BASE_D,
	        TIMELINE: StockColor.TIMELINE_D,
	        UP: StockColor.UP_COLOR_D,
	        DOWN: StockColor.DOWN_COLOR_D,
	        TEXT_TIME: StockColor.TEXT_TIME_D,
	        TEXT_LEFT: StockColor.TEXT_LEFT_D,
	        CONT_BACK: StockColor.CONT_BACK_D,
	        CONT_ROUND: StockColor.CONT_ROUND_D
		};
  		this.colorObj = {
			BACK : StockColor.BACK_D,
	        DIVLINE: StockColor.DIVLINE_D,
	        BASELINE: StockColor.BASELINE_D,
	        TEXT: StockColor.TEXT_D,
	        TEXT_BASE: StockColor.TEXT_BASE_D,
	        TIMELINE: StockColor.TIMELINE_D,
	        UP: StockColor.UP_COLOR_D,
	        DOWN: StockColor.DOWN_COLOR_D,
	        TEXT_TIME: StockColor.TEXT_TIME_D,
	        TEXT_LEFT: StockColor.TEXT_LEFT_D,
	        CONT_BACK: StockColor.CONT_BACK_D,
	        CONT_ROUND: StockColor.CONT_ROUND_D
	    };
  	}
  	
};

EXMiniChart.prototype.setColors = function(colors, isDraw)
{
    if(colors)
    {
        for(var key in colors)
            if(colors.hasOwnProperty(key)) this.colorObj[key] = colors[key];
    }
    
    if(isDraw) this.draw();
};

EXMiniChart.prototype.updatePosition = function(pWidth, pHeight)
{
	BaseChart.prototype.updatePosition.call(this, pWidth, pHeight);
    this.setMaxCount(this.maxCount);
	this.calcPosition(this.eleW, this.eleH);
	//if(this.data) this.updateGraph();
	this.updateGraph();
};

EXMiniChart.prototype.setData = function(data, basePrice)
{
	if(basePrice != undefined) this.basePrice = basePrice;
    this.data = data;
	this.maxAm = 0;
	this.minAm = Number.MAX_VALUE;
	this.priceArr = null;
  	this.timeArr = null;
  	//this.maxCount = 52;
  	
  	if(this.data.length >= this.maxCount) this.data.length = this.maxCount;
  	else this.setMaxCount(this.data.length);
  	
	this.updateGraph();
};

//차트 배열이 오브젝트일경우 키값 세팅   
EXMiniChart.prototype.setKeys = function(dateKey, valueKey)
{
    this.dateKey = dateKey;
  	this.valueKey = valueKey;
};

EXMiniChart.prototype.addNewData = function(newData)
{
	if(!this.data) return;
	
	if(this.data.length >= this.maxCount) this.data.length = this.maxCount;
	if(this.data[0][0] == newData[0] || (newData[0]%5 != 0))
	{
		this.data[0] = newData;
	} 
	else
	{
		if(this.data.length >= this.maxCount) this.data.pop();
		this.data.unshift(newData);	
	} 
    
	this.maxAm = 0;
	this.minAm = Number.MAX_VALUE;
	this.updateGraph();
};

//드로우 가능한 상태인지를 체크
EXMiniChart.prototype.checkDrawPossible = function()
{
	if(this.data && this.eleW > 0 && this.eleH > 0) return true;
	else return false;
};

//1.컴포넌트의 너비와 높이값을 이용하여 canvas에 들어갈 영역 x y 셋팅   
EXMiniChart.prototype.calcPosition = function(elWidth, elHeight)
{
    //그래프영역과 시간텍스트 영역 나누기
    if(this.mode != 'line')
    {
    	this.pos.grpLeft = 80;
    	this.pos.txtX = this.pos.grpLeft/2;
    } 
    else this.pos.grpLeft = 0;
    this.pos.grpSY = this.eleH*0.1;
   	//this.pos.grpSY = 10;
    this.pos.hourSY = this.eleH-30;
    
    this.pos.hourY = this.eleH - (this.eleH - this.pos.hourSY)/3;
    this.pos.grpEY = this.pos.hourSY - this.pos.grpSY;
    this.pos.grpH = this.pos.grpEY - this.pos.grpSY;
    
};

EXMiniChart.prototype.setMaxMin = function()
{
	this.priceArr = new Array();
  	this.timeArr = new Array();
  	
  	var val = 0, time = 0;
  	
	for(var i=0; i<this.data.length; i++)
    {
        val = this.data[i][this.valueKey];
        time = this.data[i][this.dateKey];
        if(time%100 == 5)
        {
        	this.timeArr.push([i, time.substring(0,2)+':00']);
        } 
        if(val > this.maxAm) this.maxAm = val;
        if(val < this.minAm) this.minAm = val;
        
    }
    
    if(this.minAm >= this.basePrice)
    {
        this.pos.baseY = this.pos.grpEY;
        this.pos.grpR = this.pos.grpH/(this.maxAm - this.basePrice);  
        this.pos.grpTp = 'up';
    }
    else
    {
        if(this.maxAm <= this.basePrice){
            this.pos.grpR = this.pos.grpH/(this.basePrice - this.minAm);
            this.pos.baseY = this.pos.grpSY;
            this.pos.grpTp = 'down';
        }   
        else{
            this.pos.grpR = this.pos.grpH/(this.maxAm - this.minAm);
            this.pos.baseY = this.pos.grpSY + (this.maxAm - this.basePrice)*this.pos.grpR;
            this.pos.grpTp = 'both';
        }
    }
    
    this.priceArr = [[this.maxAm, this.pos.grpSY], [this.minAm, this.pos.grpEY], [this.basePrice, this.pos.baseY]];		
};

EXMiniChart.prototype.updateGraph = function()
{
	if(!this.basePrice || !this.data)
	{
		this.ctx.clearRect(0,0, this.eleW, this.eleH);
		this.tempDraw();
		return;
	}
	
	this.setMaxMin();
	this.draw();
};

EXMiniChart.prototype.clearGraph = function()
{
	this.isRealMode = false;
	this.maxAm = 0;
	this.minAm = Number.MAX_VALUE;
    this.ctx.clearRect(0,0, this.eleW, this.eleH);
};

EXMiniChart.prototype.setMode = function(mode)
{
	this.mode = mode;
	/*
	if(this.mode == 'line') this.timeEnd = 1;
	else this.timeEnd = 0;
	*/
	this.calcPosition(this.eleW, this.eleH);
};

EXMiniChart.prototype.tempDraw = function()
{
	this.canvas.width = this.eleW;
    this.canvas.height = this.eleH;

    this.ctx.clearRect(0,0, this.eleW, this.eleH);
    
    this.ctx.font = "16px '"+this.FONT_FAMILY+"'";
	
	this.ctx.fillStyle = this.colorObj.CONT_BACK;
	this.ctx.fillRect(this.pos.grpLeft, 0, this.eleW-this.pos.grpLeft, this.pos.hourSY);
	this.ctx.rect(this.pos.grpLeft, 0, this.eleW-this.pos.grpLeft, this.pos.hourSY);
	
	this.ctx.strokeStyle = this.colorObj.CONT_ROUND;
    this.ctx.lineWidth = '2.0';
	this.ctx.stroke();
	
	this.priceArr = [['', this.pos.grpSY], ['', this.pos.grpEY], [0, this.pos.grpEY]];
	
	if(this.mode != 'line')
	{
		this.ctx.fillStyle = this.colorObj.TEXT_LEFT;
	    this.ctx.textAlign = 'center';
	    this.ctx.textBaseline="middle";
	    
		this.ctx.fillStyle = this.colorObj.BASELINE;
	    this.fillRoundedRect(0, this.priceArr[2][1]-10, this.pos.grpLeft, 20, 10);
	    	
	    this.ctx.fillStyle = this.colorObj.TEXT_BASE;
	    //기준가 값 그리기
	    this.ctx.fillText(this._getDecimalValue(this.priceArr[2][0]), this.pos.txtX, this.priceArr[2][1]);
	}
	
	this.ctx.beginPath();
	this.ctx.lineWidth = '1.0';
	
	//max값 라인
    this.ctx.strokeStyle = this.colorObj.DIVLINE;
    this.ctx.moveTo(this.pos.grpLeft, this.pos.grpSY);
    this.ctx.lineTo(this.eleW, this.pos.grpSY);
    this.ctx.stroke();
    this.ctx.closePath();
    
    this.ctx.beginPath();
    this.ctx.webkitImageSmoothingEnabled = true;
    this.ctx.moveTo(this.pos.grpLeft, this.pos.grpEY);
    this.ctx.lineTo(this.eleW, this.pos.grpEY);
    this.ctx.strokeStyle = this.colorObj.DOWN;
    this.ctx.lineWidth = '3.0';
    this.ctx.stroke();
    this.ctx.closePath();
    //this.drawTemp();
    
};

EXMiniChart.prototype.draw = function()
{
	if(this.data && this.data.length == 0) return;
    this.ctx.webkitImageSmoothingEnabled = true;
	
	this.canvas.width = this.eleW;
    this.canvas.height = this.eleH;

    //this.ctx.fillStyle = this.colorObj.BACK;
    this.ctx.clearRect(0,0, this.eleW, this.eleH);
    
    this.drawBack();
    this.drawHLine();
    
    if(this.pos.grpTp == 'both') this.drawBoth();
    else this.drawOnly();
    
    //this.drawCurrentTime();
};

EXMiniChart.prototype.fillRoundedRect = function(x, y, w, h, r)
{
	this.ctx.beginPath();
	this.ctx.moveTo(x+r, y);
	this.ctx.lineTo(x+w-r, y);
	this.ctx.quadraticCurveTo(x+w, y, x+w, y+r);
	this.ctx.lineTo(x+w, y+h-r);
	this.ctx.quadraticCurveTo(x+w, y+h, x+w-r, y+h);
	this.ctx.lineTo(x+r, y+h);
	this.ctx.quadraticCurveTo(x, y+h, x, y+h-r);
	this.ctx.lineTo(x, y+r);
	this.ctx.quadraticCurveTo(x, y, x+r, y);
	this.ctx.fill();        
};

EXMiniChart.prototype.drawBack = function()
{
	if(this.data && this.data.length == 0) return;
	this.ctx.font = "16px '"+this.FONT_FAMILY+"'";
	
	this.ctx.fillStyle = this.colorObj.CONT_BACK;
	this.ctx.fillRect(this.pos.grpLeft, 0, this.eleW-this.pos.grpLeft, this.pos.hourSY);
	this.ctx.rect(this.pos.grpLeft, 0, this.eleW-this.pos.grpLeft, this.pos.hourSY);
	
	this.ctx.strokeStyle = this.colorObj.CONT_ROUND;
    this.ctx.lineWidth = '2.0';
	this.ctx.stroke();
	
	this.ctx.fillStyle = this.colorObj.TEXT_TIME;
    
    this.ctx.textAlign = 'center';
	var oneValue = null, timeStr = '';
	for(var i = 1; i<this.timeArr.length-this.timeEnd; i++)
	{
		oneValue = this.timeArr[i];
		timeStr = oneValue[1].toString();
		this.ctx.fillText(timeStr, this.eleW-(oneValue[0]*this.termW), this.pos.hourY);
	}
	oneValue = this.timeArr[0];
	
	//마지막 시간이 현재리얼 시간과 겹칠때 표시 안함
	if(oneValue && oneValue[0]*this.termW>50)
	{
		timeStr = oneValue[1].toString();
		this.ctx.fillText(timeStr, this.eleW-(oneValue[0]*this.termW), this.pos.hourY);
	}
	
	this.ctx.fillStyle = this.colorObj.TEXT;
    this.ctx.textAlign = 'right';
    this.ctx.fillText((this.data[0][this.dateKey]+'').substring(0,2)+":"+(this.data[0][this.dateKey]+'').substring(2,4), this.eleW, this.pos.hourY);
	
	if(this.mode != 'line')
	{
		this.ctx.fillStyle = this.colorObj.TEXT_LEFT;
	    this.ctx.textAlign = 'center';
	    this.ctx.textBaseline="middle";
	    
	    //max값 / min값 그리기
	    for(var i = 0; i<2; i++)
	    {
	    	this.ctx.fillText(this._getDecimalValue(this.priceArr[i][0]), this.pos.txtX, this.priceArr[i][1]);		
	    }
		
		this.ctx.fillStyle = this.colorObj.BASELINE;
	    this.fillRoundedRect(0, this.priceArr[2][1]-10, this.pos.grpLeft, 20, 10);
	    	
	    this.ctx.fillStyle = this.colorObj.TEXT_BASE;
	    //기준가 값 그리기
	    this.ctx.fillText(this._getDecimalValue(this.priceArr[2][0]), this.pos.txtX, this.priceArr[2][1]);
	}
	
	this.ctx.fillStyle = this.colorObj.TEXT_TIME;
	this.ctx.textAlign = 'right';
	this.ctx.textBaseline = "top";
    this.ctx.fillText('5분', this.eleW-2, 2);
};

EXMiniChart.prototype.drawHLine = function()
{
	
	this.ctx.lineWidth = '1.0';
	
	//max값 라인
    this.ctx.strokeStyle = this.colorObj.DIVLINE;
    this.ctx.moveTo(this.pos.grpLeft, this.pos.grpSY);
    this.ctx.lineTo(this.eleW, this.pos.grpSY);
    this.ctx.stroke();
    this.ctx.closePath();
    
	//min값 라인    
    this.ctx.beginPath();
    this.ctx.moveTo(this.pos.grpLeft, this.pos.grpEY);
    this.ctx.lineTo(this.eleW, this.pos.grpEY);
    this.ctx.stroke();
    this.ctx.closePath();
    
    //기준가 라인
    this.ctx.beginPath();
    this.ctx.strokeStyle = this.colorObj.BASELINE;
    this.ctx.moveTo(this.pos.grpLeft, this.pos.baseY);
    this.ctx.lineTo(this.eleW, this.pos.baseY);
    this.ctx.stroke();
    this.ctx.closePath();
};


//상한 또는 하한 한가지 경우
EXMiniChart.prototype.drawOnly = function()
{
    this.ctx.lineJoin = 'bevel';
    this.ctx.lineCap = 'round';
    
    var maxVal, lineColor, gradColor, gradSY, gradEY, lastX = this.eleW; 
    
    if(this.pos.grpTp == 'up'){
        lineColor = this.colorObj.UP;
        gradColor = this.colorObj.UP;
        gradSY = this.pos.grpSY;
        gradEY = this.pos.baseY;
        maxVal = this.maxAm;
    } 
    else if(this.pos.grpTp == 'down'){
        lineColor = this.colorObj.DOWN;
        gradColor = this.colorObj.DOWN;
        gradSY = this.pos.grpEY;
        gradEY = this.pos.baseY;
        maxVal = this.basePrice;
    } 

    this.ctx.beginPath();
    this.ctx.webkitImageSmoothingEnabled = true;
    var dataLenth = this.data.length;
    this.ctx.moveTo(lastX, this.pos.grpSY + (maxVal - this.data[0][this.valueKey])*this.pos.grpR);
    for(var i=1; i<dataLenth; i++)
    {
        lastX -= this.termW;
        this.ctx.lineTo(lastX, this.pos.grpSY + (maxVal - this.data[i][this.valueKey])*this.pos.grpR);
    }

    this.ctx.strokeStyle = lineColor;
    this.ctx.lineWidth = '3.0';
    this.ctx.stroke();
    this.ctx.closePath();
    
    /*
    this.ctx.lineTo(lastX, this.pos.baseY);
    this.ctx.lineTo(this.eleW, this.pos.baseY);
    this.ctx.lineTo(this.eleW, this.data[0][this.valueKey]);
    //this.drawGradient(gradSY, gradEY, gradColor);
    */
};

//상한과 하한이 섞인경우
EXMiniChart.prototype.drawBoth = function()
{
	
    var dataLength = this.data.length;
    var maxVal = this.maxAm;
    var preX = this.eleW, firstVal = this.data[0][this.valueKey], preUp, lineColor, gradColor;
    
    this.ctx.lineJoin = 'bevel';
    this.ctx.lineCap = 'round';
    
    this.ctx.beginPath();
	
	this.ctx.moveTo(this.eleW, this.pos.grpSY + (maxVal - firstVal)*this.pos.grpR);
    
    if(firstVal >= this.basePrice)
    {
        preUp = true;
        this.ctx.strokeStyle = this.colorObj.UP;
        gradColor = '';
    }
    else
    {
        preUp = false;
        this.ctx.strokeStyle = this.colorObj.DOWN;
        gradColor = '';
    } 
	
	this.ctx.lineWidth = '3.0';
	
    var lastX = this.eleW, nextVal = 0, tempX;
    for(var i=1; i<dataLength; i++)
    {
        lastX -= this.termW;
        nextVal = this.data[i][this.valueKey];
        if(preUp)
        {
            if(this.basePrice > nextVal)
            {
                tempX = lastX + this.termW*( Math.abs(nextVal-this.basePrice) / Math.abs(nextVal-this.data[i-1][this.valueKey]));
                //중간 앞영역 레드 그리기
                this.ctx.lineTo(tempX, this.pos.baseY);
                this.ctx.strokeStyle = this.colorObj.UP;
                this.ctx.stroke();
                
                //this.ctx.lineTo(preX, this.pos.baseY);
                this.ctx.beginPath();
                this.ctx.moveTo(tempX, this.pos.baseY);
                
                //레드 그라디언트 그리기
                //this.drawGradient(this.pos.grpSY, this.pos.baseY, this.colorObj.UP);
                this.ctx.lineTo(lastX, this.pos.grpSY + (maxVal - nextVal)*this.pos.grpR);
                
                this.ctx.strokeStyle = this.colorObj.DOWN;
                this.ctx.stroke();
                
                //블루 그라디언트 그리기
                //this.drawGradient(this.pos.grpEY, this.pos.baseY, this.colorObj.DOWN);
                
                preUp = false;
            }
            else
            {
                this.ctx.lineTo(lastX, this.pos.grpSY + (maxVal - nextVal)*this.pos.grpR);
            }
        }
        else
        {
            if(this.basePrice < nextVal)
            {
                //중간 앞영역 블루 그리기
                tempX = lastX + this.termW*( Math.abs(nextVal-this.basePrice) / Math.abs(nextVal-this.data[i-1][this.valueKey]));
                this.ctx.strokeStyle = this.colorObj.DOWN;
                this.ctx.lineTo(tempX, this.pos.baseY);
                this.ctx.stroke();
                
                this.ctx.beginPath();
                this.ctx.moveTo(tempX, this.pos.baseY);
                
                //중간 뒷영역 레드 그리기
                this.ctx.strokeStyle = this.colorObj.UP;
                this.ctx.lineTo(lastX, this.pos.grpSY + (maxVal - nextVal)*this.pos.grpR);
                this.ctx.stroke();
                
                //레드 그라디언트 그리기
                //this.drawGradient(this.pos.grpSY, this.pos.baseY, this.colorObj.UP);
                
                preUp = true;
            }
            else
            {
                this.ctx.lineTo(lastX, this.pos.grpSY + (maxVal - nextVal)*this.pos.grpR);
            }
        }
    }
    
	this.ctx.stroke();
    this.ctx.closePath();
    
};

EXMiniChart.prototype.drawGradient = function(gradSY, gradEY, gradColor)
{
	var rgbaArr = [];
	if(gradColor.length > 26)
	{
		var rgba = gradColor.match(/^rgba?\((\d+),\s*(\d+),\s*(\d+),\s*(\d\.?\d+)\)$/);
		rgbaArr = [ rgba[1], rgba[2], rgba[3], rgba[4] ]; 
	}
	else if(gradColor.length > 15)
	{
		var rgb = gradColor.match(/^rgba?\((\d+),\s*(\d+),\s*(\d+)\)$/);
        rgbaArr = Util.RGBtoRGBA(rgb[1], rgb[2], rgb[3]);
	}
	else rgbaArr = Util.RGBtoRGBA(gradColor);
	
 	var grd = this.ctx.createLinearGradient(0, gradSY, 0, gradEY);
	//grd.addColorStop(0, gradColor);
	grd.addColorStop(0, 'rgba('+rgbaArr[0]+', '+rgbaArr[1]+', '+rgbaArr[2]+', 0.8)');
	grd.addColorStop(1, 'rgba('+rgbaArr[0]+', '+rgbaArr[1]+', '+rgbaArr[2]+', 0.8)');
	this.ctx.fillStyle = grd;
	this.ctx.globalAlpha = 0.5;
	this.ctx.fill();
};

// 매핑가능한 개수를 리턴한다.
EXMiniChart.prototype.getMappingCount = function()
{
	return ['Time', 'Value'];
};

EXMiniChart.prototype.getQueryData = function(dataArr, keyArr)
{
	if(!keyArr) return;
};

EXMiniChart.prototype.setQueryData = function(dataArr, keyArr, queryData)
{
	if(!keyArr) return;
	
	if(queryData.isReal)
	{
		//var dataArr = AQueryData.getDataKeyObj(dataArr[0].key);
		var data = dataArr[0];
		if(data[keyArr[1]])
		{
			//if(time.length == 7) time = '0'+time;
			//if(time.length >= 8) this.addNewData([time.substring(0,4), dataArr[keyArr[1]]]);

			var prevTime = this.data[0][0];
			var time = data[keyArr[0]];
			time = time.substr(0,2)*3600 + time.substr(2,2)*60 + time.substr(4,2)*1;
			prevTime = prevTime.substr(0,2)*3600 + prevTime.substr(2,2)*60 + prevTime.substr(4,2)*1;

			if(prevTime >= time) this.addNewData([this.data[0][0], data[keyArr[1]]]);
			else
			{
				time = parseInt((time - prevTime)/this.updateTime);
				prevTime += (time + 1) * this.updateTime;
				var h, m;
				h = parseInt(prevTime/3600);
				prevTime = prevTime%3600;
				m = parseInt(prevTime/60);
				//time = [h<10?'0'+h:h, m<10?'0'+m:m].join('');
				//this.addNewData([time.substring(0,4), data[keyArr[1]]]);
				this.addNewData([[h<10?'0'+h:h, m<10?'0'+m:m].join(''), data[keyArr[1]]]);
			}
		}
	}
	else
	{
		var timeArr = new Array();
		var time = null;
		for(var i = 0; i<dataArr.length; i++)
		{
			time = dataArr[i][keyArr[0]].toString();
			if(time.length == 7) time = '0'+time;
			if(time.length >= 8) timeArr.push([time.substring(0,4), dataArr[i][keyArr[1]]]);
		}
		
		this.setData(timeArr, this.basePrice);
	}
};

                    
//window.EXMiniChart = EXMiniChart;
                    
})();