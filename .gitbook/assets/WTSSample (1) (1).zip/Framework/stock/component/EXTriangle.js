
class EXTriangle extends AComponent
{

	constructor()
	{
		//AComponent.call(this);
		super();
			
		this.frwName = 'stock';

		this.arrowEl = null;
		this.arrowH = 0;
		this.headH = 0;
		this.bodyH = 0;
		/*
		this.headColorArr = 
		[
			'transparent transparent transparent',
			'transparent transparent '+StockColor.UP_COLOR+' transparent',
			'transparent transparent '+StockColor.UP_COLOR+' transparent',
			'transparent transparent transparent',
			StockColor.DOWN_COLOR+' transparent transparent transparent',
			StockColor.DOWN_COLOR+' transparent transparent transparent',
			
			'transparent transparent '+StockColor.UP_COLOR+' transparent',
			'transparent transparent '+StockColor.UP_COLOR+' transparent',
			StockColor.DOWN_COLOR+' transparent transparent transparent',
			StockColor.DOWN_COLOR+' transparent transparent transparent'
		];

		this.bodyColorArr = 
		[
			'transparent', StockColor.UP_COLOR, 'transparent', 'transparent', StockColor.DOWN_COLOR, 'transparent' ,StockColor.UP_COLOR, 'transparent', StockColor.DOWN_COLOR, 'transparent'
		];	*/
	}
	
}



EXTriangle.CONTEXT = 
{
	tag: '<div data-base="EXTriangle" data-class="EXTriangle" class="EXTriangle-Style" data-use-stockcolor="true" data-color-up="'+StockColor.UP_COLOR+'" data-color-down="'+StockColor.DOWN_COLOR+'">\
			<div></div><div></div></div>',

    defStyle: 
    {
        width:'20px', height:'20px'
    },
    
    events: []
};

EXTriangle.prototype.init = function(context, evtListener)
{
	AComponent.prototype.init.call(this, context, evtListener);
	
	this.$ele.css('overflow', 'visible');

	this.arrowEl = this.element.children[0];
	this.arrowBodyEl = this.element.children[1];
	
	if(this.arrowBodyEl == undefined)
	{
		this.arrowBodyEl = $('<div></div>')[0];
		$(this.element).append(this.arrowBodyEl);
	}
	
	$(this.arrowBodyEl).css('margin', '0 auto');
	
	this.arrowEl.style.borderStyle = 'solid';
	this.arrowEl.style.width = '0px';
	this.arrowEl.style.height = '0px';
	
	// 상승, 하락색 지정
	if(this.getAttr('data-use-stockcolor')) this.setUpDownColor(StockColor.UP_COLOR, StockColor.DOWN_COLOR);
	else this.setUpDownColor();
	
	this.initPos();
	this.setDirection(this.getAttr('data-direction'));

};

EXTriangle.prototype.initPos = function()
{
	this.arrowW = parseInt(this.getWidth(), 10)/2;
	this.arrowH = parseInt(this.getHeight(), 10);
	this.headH = this.arrowH*0.8;
	this.bodyW = this.arrowW;
	this.bodyH = this.arrowH*0.6;
	this.topPadding = this.arrowH*-0.2;
	
	if(this.bodyW%2 == 1) this.bodyW -= 1;
	this.arrowBodyEl.style.width = (this.bodyW)+'px';
	this.arrowBodyEl.style.height = this.bodyH+'px';
	
	this.headStyleArr = 
	[
	
  	 //['border',																'margin-top']
  	 
	   ['0px', 																	'0px'],
	   ['0px ' + this.arrowW+'px ' + this.headH+'px ' + this.arrowW+'px', 		this.topPadding+'px'],
	   ['0px ' + this.arrowW+'px ' + this.arrowH+'px ' + this.arrowW+'px', 		'0px'],
	   ['0px', '0px'],
	   [this.headH+'px ' + this.arrowW+'px 0px ' + this.arrowW+'px', 			(this.topPadding+this.bodyH)+'px'],
	   [this.arrowH+'px ' + this.arrowW+'px 0px ' + this.arrowW+'px', 			'0px'],
	   
	   ['0px ' + this.arrowW+'px ' + this.headH+'px ' + this.arrowW+'px', 		this.topPadding+'px'],
	   ['0px ' + this.arrowW+'px ' + this.arrowH+'px ' + this.arrowW+'px', 		'0px'],
	   [this.headH+'px ' + this.arrowW+'px 0px ' + this.arrowW+'px', 			(this.topPadding+this.bodyH)+'px'],
	   [this.arrowH+'px ' + this.arrowW+'px 0px ' + this.arrowW+'px', 			'0px']
	];
	
	this.bodyStyleArr = 
	[
		//'margin-top'
	   	'0px', '-1px', '0px', '0px', ((this.headH+this.bodyH-2)*-1)+'px', '0px', '-1px', '0px', ((this.headH+this.bodyH-1)*-2)+'px', '0px'
	];
};

EXTriangle.prototype.setUpDownColor = function(upColor, downColor)
{
	if(!upColor) upColor = this.getAttr('data-color-up') || StockColor.UP_COLOR;
	if(!downColor) downColor = this.getAttr('data-color-down') || StockColor.DOWN_COLOR;
	
	this.headColorArr = 
	[
        'transparent transparent transparent',
        'transparent transparent '+upColor+' transparent',
        'transparent transparent '+upColor+' transparent',
        'transparent transparent transparent',
        downColor+' transparent transparent transparent',
        downColor+' transparent transparent transparent',
        
        'transparent transparent '+upColor+' transparent',//기세상한
        'transparent transparent '+upColor+' transparent',//기세상승
        downColor+' transparent transparent transparent',//기세하한
        downColor+' transparent transparent transparent'//기세하락
	];
	
	this.bodyColorArr = 
	[
		'transparent', upColor, 'transparent', 'transparent', downColor, 'transparent', upColor, upColor, downColor, downColor
	];
	
	if(this.dir) this.setDirection(this.dir);
};

EXTriangle.prototype.setDirection = function(dir)
{
	if(!dir || isNaN(dir)) dir = 0;
	this.dir = dir;
	
    this.arrowEl.style.borderColor = this.headColorArr[dir];
    this.arrowEl.style.borderWidth = this.headStyleArr[dir][0];
	this.arrowEl.style.marginTop = this.headStyleArr[dir][1];
    
	this.arrowBodyEl.style.background = this.bodyColorArr[dir];
	this.arrowBodyEl.style.marginTop = this.bodyStyleArr[dir];
};

EXTriangle.prototype.getDirection = function()
{
	return this.dir;
};

EXTriangle.prototype.setData =  function(data)
{
	this.setDirection(data);
};

EXTriangle.prototype.setQueryData =  function(dataArr, keyArr, queryData)
{
	if(!keyArr) return;
	var value = dataArr[0][keyArr[0]];
	
	if(value==undefined) return;
	// 금융IT에서 커스텀하여 처리한 부분이 들어감. 주석처리함
// 	if(value > 0) value	= 7;
// 	else if(value < 0) value = 9;
// 	else value = 0;
	
	this.setDirection(value);
};

EXTriangle.prototype.updatePosition = function(pWidth, pHeight)
{
	AComponent.prototype.updatePosition.call(this, pWidth, pHeight);
	
	if(this.isShow())
	{
		if(this.dir != 0 && this.dir != 3)
		{
			this.initPos();
			this.setDirection(this.dir);
		}
	}
};

// EXTriangle.prototype.getMappingCount = function()
// {
// 	return 2;
// };


window['EXTriangle'] = EXTriangle;