(async function(){

await afc.import("Framework/stock/component/BaseChart.js");


EXCenterPivotView = class EXCenterPivotView extends BaseChart
{
    constructor()
    {
        super();
    
        this.isCandleChart = false;
        
        this.lineData = [];
        this.lineDataText = [];
        
        this.lineDataColor = StockColor.COMPARE_COLORS;
        this.lineRate = [];
            
        this.delegator = null;
        
        this.preScale = 1;
        this.rateVal = 1;
        this.zoomState = 0;
        
        this.lastDist = 0;
        this.scollSX = 0;
        this.scollEX = 0;
        this.speed = 10;
        
        //-----------------------------------
        //이동시간을 구함
        this.mStartTime = 0;
        this.mOldTime = 0;
        //이동거리를 구함
        this.mStartX = 0;
        this.mEndX = 0;
        this.mScrollLR = false;
        this.timer = null;
        //----------------------------------------------
        
        this.offset = 0;
        this.startIdx = 0;
        this.startLineX = 0;
        this.endIdx = 0;
        this.BAR_CNT = 50;
        this.subType = 0;          //서브 그래프 타입 0~6까지
        this.prdCls = 0;			//0:월, 1:주, 2:일, 5:분, 7틱
        
        //this.prdCls구분에 따른 datetime 표시
        this.dateformatFunc = 
        [
            afc.formatDate,
            afc.formatDate,
            afc.formatMonth,
            null,
            null,
            afc.formatDateTime,
            null,
            afc.formatTic
        ];
        this.dateformat = this.dateformatFunc[this.prdCls];
        this.dashType = [1.5,4];
        this.TEXT_SIZE = '16px';
        
        this.colorObj = 
        {
            BACK : StockColor.BACK,
            TEXT : StockColor.TEXT,        			//일반 폰트색
            DOT : StockColor.DOT,          			//도트색
            DIVLINE : StockColor.DIVLINE,  			//상단 하단 그래프 구분선색
            UP : StockColor.UP_COLOR,    			//현재가 상승색
            DOWN : StockColor.DOWN_COLOR		//현재가 하락색	
        };
        
        //상승하락 색상
        this.COLOR_ARR = [ this.colorObj.DOWN, this.colorObj.UP, this.colorObj.DOWN ];
        
        this.touchEvent = null;
        this.isFirst = true;

        this.ROW_CNT = 18;          //금액 로우 간격 나누기 계산용 변수
        this.AM_R_WIDTH = 100;      //상단,하단 오른쪽 금액영역 너비
        this.AM_L_WIDTH = 0;      	//상단,하단 왼쪽 금액영역 너비
        this.MAX_BAR_W = 80;		//최대 봉 너비
        this.DEF_BAR_W = 8;       	//기본 봉 너비
        this.BAR_TERM = 1;          //봉차트간 간격
        
        this.SIGAIDX = 1;           //시가 인덱스
        this.GOGAIDX = 2;           //고가 인덱스
        this.JEOGAIDX = 3;          //저가 인덱스
        this.JONGGAIDX = 4;         //종가 인덱스
        this.DEALQTIDX = 5;         //체결량 인덱스
        
        this.upGrpMaxAm = 0;       	//상단 그래프 최대값
        this.upGrpMinAm = 0;       	//상단 그래프 최소값
        
        //포지션에 관련된 객체
        this.pos = 
        {     
            cavasW: 0,          //전체 캔버스 너비
            cavasH: 0,          //전체 캔버스 높이
            grpW: 0,            //상단,하단 그래프영역 너비
            grpEX: 0,           //상단,하단 그래프영역 끝 X좌표
            dtXs: [],           //상단,하단 그래프 세로구분 X좌표 배열 [1, 2, 3번째]
            amYs: [],           //상단 그래프 금액 구분선 Y좌표 배열[금액1, 금액2, 금액3, 금액4, 금액5]
            amPad: 0,           //금액 오른쪽 정렬시 마진
            txtY: 0,            //텍스트 세로 중간 정렬을 위한 Y위치  
            
            upGrpSY: 0,         //상단 그래프 시작 Y좌표
            upDtY: 0,           //상단 그래프 Date 영역 Y
            upGrpEY: 0,         //상단 그래프 끝 Y좌표
            upGrpH: 0,          //상단 그래프 그리는 영역 높이
            dwDtY: 0,           //하단 그래프 Date 영역 Y
            
            upRateH:  0,        //상단 높이 비율
            
            barW: this.DEF_BAR_W, //봉차트 너비
            
            barTot: 0           //봉차트 너비에 봉과 봉사이의 간격을 더한값(한봉이 그려지는 영역)
        };    
        
        this.drawBackType = null;   //하단 7개 그래프 백그라운드 그리는 함수 저장 변수
        this.drawTextType = null;   //하단 7개 그래프 금액 그리는 함수 저장 변수
        this.drawChartType = null;  //하단 7개 그래프 그리는 함수 저장 변수
        
        this.compLeft = 0;  //엘리먼트의 Left 지점
        this.middleX = 0;   //엘리먼트의 중간X 지점
        
    }
}

//window.EXCompareChart = EXCompareChart;

EXCompareChart.prototype.init = function(context, evtListener)
{
    BaseChart.prototype.init.call(this, context, evtListener);
    
    this.isFirst = true;
    
    this.infoDiv = this.element.children[1];
    this.longXdiv = this.element.children[2];
    this.longYdiv = this.element.children[3];
	
	this.zoomDiv = this.element.children[4];
	this.zoomInDiv = this.zoomDiv.children[0];
	this.zoomOutDiv = this.zoomDiv.children[1];
	
	this.initEvent();
	
};

//차트 색상정보를 추출
EXCompareChart.prototype.extractColorObj = function()
{	
	BaseChart.prototype.extractColorObj.call(this);
	this.COLOR_ARR = [ this.colorObj.DOWN, this.colorObj.UP, this.colorObj.DOWN ];
};

EXCompareChart.prototype.initEvent = function()
{
	this.setTouchEvent();
    this.setZoomEvent();	
};

//그래프의 너비 및 높이를 업데이트
EXCompareChart.prototype.updatePosition = function(pWidth, pHeight)
{
    BaseChart.prototype.updatePosition.call(this, pWidth, pHeight);
    this.calcPosition(this.eleW, this.eleH);
    //this.setData(bong_data);
};

EXCompareChart.prototype.setZoomEvent = function()
{
	var thisObj = this;
	
	//zoomIn 버튼 클릭 리스너
	$(this.zoomInDiv).bind(afc.ACTION_UP, function(event){
		
		if(!thisObj.data || thisObj.data.length == 0) return;
		
		if(thisObj.zoomState != 1)
		{
			thisObj.rateVal = 1.0;
			thisObj.zoomState = 1;
		}
		thisObj.rateVal = parseFloat(thisObj.rateVal) + 0.01;
		thisObj.zoomInOut();
	});
	
	//zoomOut 버튼 클릭 리스너
	$(this.zoomOutDiv).bind(afc.ACTION_UP, function(event){
		
		if(!thisObj.data || thisObj.data.length == 0) return;
		
		if(thisObj.zoomState != 2)
		{
			thisObj.rateVal = 1.0;
			thisObj.zoomState = 2;
		}
		thisObj.rateVal = parseFloat(thisObj.rateVal) - 0.01;
		thisObj.zoomInOut();
	});	
};

//델리게이터를 셋팅(데이터를 더 필요로할때 이벤트를 날려줌)
EXCompareChart.prototype.setDelegator = function(delegator)
{
    this.delegator = delegator;
};

//1.컴포넌트의 너비와 높이값을 이용하여 canvas에 들어갈 영역 x y 셋팅   
EXCompareChart.prototype.calcPosition = function(elWidth, elHeight)
{
            
    this.pos.cavasW = elWidth;
    this.pos.cavasH = elHeight;
    
    this.pos.grpEX = elWidth - this.AM_R_WIDTH;
    this.pos.grpW = this.pos.grpEX - this.AM_L_WIDTH;
	
    this.pos.amPad = elWidth - 5; 
    
    this.pos.dtXs = [ this.AM_L_WIDTH + this.pos.grpW*0.25, this.AM_L_WIDTH + this.pos.grpW*0.5, this.AM_L_WIDTH + this.pos.grpW*0.75 ]; 
    
    this.pos.upGrpSY = elHeight/this.ROW_CNT;
    this.pos.txtY = (this.pos.upGrpSY/2);
    this.pos.upGrpEY = this.pos.upGrpSY*17;
    this.pos.upGrpH = this.pos.upGrpEY - this.pos.upGrpSY;  
    this.pos.upDtY = this.pos.upGrpEY + this.pos.txtY; 
    this.pos.amYs = [ this.pos.upGrpSY, this.pos.upGrpSY*5, this.pos.upGrpSY*9, this.pos.upGrpSY*13, this.pos.upGrpEY ];
    
    this.pos.dwDtY = this.pos.upGrpEY + this.pos.txtY;
    
    //텍스트 사이즈 셋팅
    if(elWidth < elHeight) this.TEXT_SIZE = (this.pos.cavasW*0.03) + 'px';  
    else this.TEXT_SIZE = (this.pos.cavasH*0.03) + 'px';
	
    this.pos.barTot = this.pos.grpW/this.BAR_CNT;
    this.pos.barW = (this.pos.barTot - this.BAR_TERM);
	this.startLineX = this.pos.grpEX + this.pos.barW/2;
	//this.DEF_BAR_W = this.pos.barW;
    
};


EXCompareChart.prototype.addCompareData = function(compareData)
{
	if(this.lineData.length > 15)
	{
		AToast.show('더이상 추가할 수 없습니다.');
		return;
	} 
	this.lineDataText.push(compareData[0]);
	this.lineData.push(compareData[1]);
	this.updateGraph();
};

//데이터 입력
EXCompareChart.prototype.setData = function(dataArr, keyArr)
{
	this.resetData();
	if(!keyArr)
	{
		var keyLength = dataArr[0].length;
		
		keyArr = new Array();
		for(var i = 0; i<keyLength; i++)
		{
			keyArr.push(i);
		}
	}
	
	this.lineData.push([]);
	this.lineDataText.push("기본종목");
	
	this.makeChartCanvasData(dataArr, keyArr);
	this.updateGraph();
};

//맨처음 데이터를 불러오는지 여부 셋팅
EXCompareChart.prototype.setIsFirst = function(isFirst)
{
    this.isFirst = isFirst;
};

//맨처음 데이터를 불러오는지 여부 가져오기
EXCompareChart.prototype.getIsFirst = function()
{
    return this.isFirst;
};

//일자 또는 시간일 경우에 따른 표현 포멧 함수 셋팅
EXCompareChart.prototype.setPrdCls = function(prdCls)
{
    this.prdCls = prdCls;
	this.dateformat = this.dateformatFunc[this.prdCls];
};


//차트 드로잉데이터를 리셋
EXCompareChart.prototype.resetData = function()
{
	
	this.lineData = new Array();
	this.lineDataText = new Array();
	
	this.preScale = 1;
	this.rateVal = 1;
	this.zoomState = 0;
    
    this.lastDist = 0;
    this.scollSX = 0;
    this.scollEX = 0;
    this.speed = 0;
    
    //-----------------------------------
    //이동시간을 구함
    this.mStartTime = 0;
    this.mOldTime = 0;
    //이동거리를 구함
    this.mStartX = 0;
    this.mEndX = 0;
    this.mScrollLR = false;
    this.timer = null;
    //----------------------------------------------
    
    this.offset = 0;
    this.startIdx = 0;
    this.endIdx = 0;
	
	//주석처리 해봐야 할것 50일 넣으면 오른쪽으로 밀리는 현상 발견
	//this.BAR_CNT = 50;
	this.pos.barTot = this.pos.grpW/this.BAR_CNT;
    this.pos.barW = (this.pos.barTot - this.BAR_TERM);
    
    this.isFirst = true;
    
    this.upGrpMaxAm = 0;       //상단 그래프 최대값
    this.upGrpMinAm = 0;       //상단 그래프 최소값
    
	this.nextIqryDate = '';
    this.data = new Array();
	
	this.upDownArr = new Array();
	
	//this.lineData = new Array();
	
	//백그라운드 클리어
    //this.ctx.fillStyle = this.colorObj.BACK;
    this.ctx.clearRect(0, 0, this.pos.cavasW, this.pos.cavasH);
	
	this.drawBackLine();
	
};

//차트 드로우 함수 모음
EXCompareChart.prototype.draw = function()
{   
    //백그라운드 클리어
    //this.ctx.fillStyle = this.colorObj.BACK;
    this.ctx.clearRect(0, 0, this.pos.cavasW, this.pos.cavasH);
    
    //텍스트 기본 셋팅
    this.ctx.font = this.TEXT_SIZE +" '"+this.FONT_FAMILY+"'";
    this.ctx.textBaseline = 'middle';
    
    this.drawBackLine();
    this.drawBackText();
    this.drawGraph();
};

//백그라운드 기본 라인 그리기
EXCompareChart.prototype.drawBackLine = function()
{

    //도트 그리기
    this.ctx.beginPath();
    this.ctx.lineWidth = 1.5;
    this.ctx.strokeStyle = this.colorObj.DOT;
    
    //가로선
    for(var i = 0; i<5; i++)
        this.drawDashedLine(this.AM_L_WIDTH + 0, this.pos.amYs[i], this.pos.grpEX, this.pos.amYs[i], this.dashType);    
    
    //세로선
    for(var i = 0; i<3; i++)
        this.drawDashedLine(this.pos.dtXs[i]-1, 0, this.pos.dtXs[i], this.pos.upGrpEY, this.dashType);
        
    this.ctx.stroke();
    this.ctx.closePath();
    
    
    //우측 금액 구분선 그리기
    this.ctx.beginPath();
    this.ctx.lineWidth=1;
    this.ctx.strokeStyle = this.colorObj.DIVLINE;
    this.ctx.moveTo(this.pos.grpEX, 0);
    this.ctx.lineTo(this.pos.grpEX, this.pos.cavasH);
    this.ctx.stroke();
    this.ctx.closePath();
    
};  

//상태에 따른 백그라운드 고정 텍스트 그리기
EXCompareChart.prototype.drawBackText = function()
{
    var txt = '', nextX = this.AM_L_WIDTH, termX = 10;
    
    this.ctx.textAlign = 'left';
    
    var i = 0; 
    if(this.isCandleChart) i = 1; 
        
    for(; i<this.lineDataText.length; i++)
    {
        nextX += this.ctx.measureText(txt).width+termX;
        txt = this.lineDataText[i];
        this.ctx.fillStyle = this.lineDataColor[i];
        this.ctx.fillText(txt, nextX, this.pos.txtY);
    }
};

//상 하단 그래프 최대최소 구하기
EXCompareChart.prototype.setMaxMin = function()
{
    this.upGrpMaxAm = 0;
    this.upGrpMinAm = Number.MAX_VALUE;
    
    var maxmin = null;
    
    for(var i = this.startIdx; i < this.endIdx; i++)
    {
		this.upGrpMaxAm = Math.max( this.upGrpMaxAm, this.data[i][4] );
        this.upGrpMinAm = Math.min( this.upGrpMinAm, this.data[i][4] );
    }
    this.pos.upRateH = (this.pos.upGrpEY - this.pos.upGrpSY)/(this.upGrpMaxAm - this.upGrpMinAm);
    
    var lineDataOne = null;
    var maxAm = 0;
    var minAm = Number.MAX_VALUE;
    var rateH = 0;
    this.lineRate = new Array();
    
    this.lineRate.push([this.upGrpMaxAm, this.pos.upRateH]);
    
    for(var i = 1; i<this.lineData.length; i++)
    {
    	lineDataOne = this.lineData[i];
    	for(var j = this.startIdx; j < this.endIdx; j++)
	    {
			maxAm = Math.max( maxAm, lineDataOne[j] );
	        minAm = Math.min( minAm, lineDataOne[j] );
	    }
	    rateH = (this.pos.upGrpEY - this.pos.upGrpSY)/(maxAm - minAm);
		this.lineRate.push([maxAm, rateH]);
    }
    
};

//그래프 그리기
EXCompareChart.prototype.drawGraph = function()
{
	if(!this.data || this.data.length == 0) return;
    var data = this.data;
    var dataOne = null;
	
    var lineX = this.startLineX;
    var lineY = 0;
	var lineY1 = 0;
    
    //상하단 텍스트 그리기
    this.ctx.fillStyle = this.colorObj.TEXT;
    this.ctx.textAlign = 'center';
	
	var dtX1 = data[parseInt(this.BAR_CNT*0.75) + this.startIdx];
	var dtX2 = data[parseInt(this.BAR_CNT*0.5) + this.startIdx];
	var dtX3 = data[parseInt(this.BAR_CNT*0.25) + this.startIdx];
	
	if(dtX1) this.ctx.fillText(this.dateformat(dtX1[0]), this.pos.dtXs[0], this.pos.dwDtY);
	if(dtX2) this.ctx.fillText(this.dateformat(dtX2[0]), this.pos.dtXs[1], this.pos.dwDtY);
	if(dtX3) this.ctx.fillText(this.dateformat(dtX3[0]), this.pos.dtXs[2], this.pos.dwDtY);
    
    this.ctx.textAlign = 'right';
    
    this.ctx.fillText(afc.addComma(parseInt(this.upGrpMaxAm)), this.pos.amPad, this.pos.amYs[0]);
    this.ctx.fillText(afc.addComma(parseInt(this.upGrpMaxAm - ((this.upGrpMaxAm-this.upGrpMinAm)*0.25))), this.pos.amPad, this.pos.amYs[1]);
    this.ctx.fillText(afc.addComma(parseInt(this.upGrpMaxAm - ((this.upGrpMaxAm-this.upGrpMinAm)*0.5))), this.pos.amPad, this.pos.amYs[2]);
    this.ctx.fillText(afc.addComma(parseInt(this.upGrpMaxAm - ((this.upGrpMaxAm-this.upGrpMinAm)*0.75))), this.pos.amPad, this.pos.amYs[3]);
    this.ctx.fillText(afc.addComma(parseInt(this.upGrpMinAm)), this.pos.amPad, this.pos.amYs[4]);
    
    if(this.isCandleChart)
    {
    	for(var i = this.startIdx; i < this.endIdx; i++)
	    {
	        dataOne = data[i];
			
	        lineX -= this.pos.barTot;
	        lineY = this.pos.upGrpSY + Math.abs((this.upGrpMaxAm - data[i][this.GOGAIDX]))*this.pos.upRateH;
	        
	        this.ctx.beginPath();
	        this.ctx.lineWidth = this.pos.barW;
	        
	        //상승과 하락을 결정하여 색상을 셋팅
			this.ctx.strokeStyle = this.COLOR_ARR[this.upDownArr[i][0]];
	          
	        this.ctx.moveTo( lineX , this.pos.upGrpSY + (this.upGrpMaxAm - dataOne[this.SIGAIDX])*this.pos.upRateH );
			
			lineY1 = this.pos.upGrpSY + (this.upGrpMaxAm - dataOne[this.JONGGAIDX])*this.pos.upRateH;
			this.ctx.lineTo( lineX , lineY1 + this.upDownArr[i][1] );
			
	        this.ctx.stroke();
	        this.ctx.closePath();
	
	        //고가 저가 선 그리기
	        this.ctx.beginPath();
	        this.ctx.lineWidth="1.5";
	        this.ctx.moveTo( lineX , lineY );
	        this.ctx.lineTo( lineX , lineY + Math.abs(dataOne[this.GOGAIDX] - dataOne[this.JEOGAIDX])*this.pos.upRateH);
	        this.ctx.stroke();
	        this.ctx.closePath();
	        
	    }
    }
    
    this.drawCompareLine();
    
};

//비교할 라인 선 그리기
EXCompareChart.prototype.drawCompareLine = function()
{
	var lineDataOne = null;
	
	var color = null;
	var lineX = null;
	var lineY = null;
	var isOver = false;
	
	var i = 0;
	if(this.isCandleChart) i = 1;
	
	for(; i<this.lineData.length; i++)
	{
		color = this.lineDataColor[i];
		
		lineX = this.startLineX - this.pos.barTot;
		
		this.ctx.beginPath();
	    this.ctx.strokeStyle = color;
		lineDataOne = this.lineData[i];
		
		this.ctx.moveTo( lineX , this.pos.upGrpSY + (this.lineRate[i][0] - lineDataOne[this.startIdx])*this.lineRate[i][1] );
		
		for(var j = this.startIdx+1; j < this.endIdx; j++)
		{
			lineX -= this.pos.barTot;
			this.ctx.lineTo( lineX , this.pos.upGrpSY + (this.lineRate[i][0] - lineDataOne[j])*this.lineRate[i][1] );
		}
	    this.ctx.stroke();
	    this.ctx.closePath();	
	}
};

//데이터가 더 필요한지를 체크
EXCompareChart.prototype.isExistNextData = function()
{
	if((this.startIdx + this.BAR_CNT) > this.data.length) return false;
    else return true;	
};

//현재 그리는 데이터 오프셋 가져오기
EXCompareChart.prototype.getOffset = function()
{       
	var tempInx = this.startIdx + this.BAR_CNT;
	if(tempInx > this.data.length) this.endIdx = this.data.length;
	else this.endIdx = tempInx;
};

//캔들의 너비를 바꿈
EXCompareChart.prototype.barWidthChange = function()
{       
	this.pos.barTot = this.pos.barW + this.BAR_TERM;
    this.BAR_CNT = parseInt(this.pos.grpW/this.pos.barTot, 10);
	this.startLineX = this.pos.grpEX + this.pos.barW/2;
};

//왼쪽에서 오른쪽으로 스크롤 시킴
EXCompareChart.prototype.scrollLToR = function(add)
{   
	
    if(!this.isExistNextData())
	{
		this.getOffset();
		return;
	}
	
	this.startIdx += add;
	this.updateGraph(); 
    
};

//오른쪽에서 왼쪽으로 스크롤 시킴
EXCompareChart.prototype.scrollRToL = function(add)
{
	
	if(this.data.length < 1)
	{
		this.getOffset();
		return;
	}
	
    this.startIdx -= add;
    if(this.startIdx < 0) this.startIdx = 0;
    this.updateGraph();    
};

//그래프 업데이트
EXCompareChart.prototype.updateGraph = function()
{
    if(this.isExistNextData() || !this.nextIqryDate)
	{
		this.getOffset();
		this.setMaxMin();
		this.draw();
	}
	else if(this.delegator) this.delegator.callNextData(this.nextIqryDate);
};

//줌 인아웃 
EXCompareChart.prototype.zoomInOut = function()
{
	
	if(this.preScale == this.rateVal) return;
	
	this.preScale = this.rateVal;	
	this.pos.barW *= this.preScale;
	
	if(this.pos.barW < this.DEF_BAR_W)
	{
		this.pos.barW = this.DEF_BAR_W;
		return;
	}
	else if(this.pos.barW > this.MAX_BAR_W)
	{
		this.pos.barW = this.MAX_BAR_W;
		return;
	}
	this.barWidthChange();
	this.updateGraph();    

};

//롱탭시 안내선 보이기
EXCompareChart.prototype.drawLongTabData = function(touchX)
{
    var oriX = touchX - this._getCompLeft();
    var offsetX = this.pos.grpEX - oriX;
    var curPos = parseInt(offsetX/this.pos.barTot);
    var curPer = offsetX%this.pos.barTot;
    
    if(curPer > this.pos.barTot) curPos += 1;
	
	var newOffset = this.startIdx + curPos;
	
	if(newOffset < this.startIdx ||  newOffset > this.endIdx) return;
        
    var detData = this.data[newOffset];
    var compareData = null;
    var tagHtml = "";
	if(detData)
	{
		tagHtml += '<span>'+this.dateformat(detData[0])+'</span></br>';
		
		for(var i = 0; i<this.lineDataText.length; i++)
		{
			compareData = this.lineData[i][newOffset]; 
			tagHtml += '<span style="color:'+this.lineDataColor[i]+';">'+this.lineDataText[i]+' : '+afc.addComma(compareData)+'</span></br>';
			//else tagHtml += '<span style="margin-left:20px;color:'+this.lineDataColor[i]+';">'+this.lineDataText[i]+' : '+afc.addComma(compareData)+'</span></br>';
		}
		this.infoDiv.innerHTML = tagHtml; 
		/*
		this.infoDiv.innerHTML = '<span>'+this.dateformat(detData[0])+'</span></br><span>시가 : '+afc.addComma(detData[1])+
			                     '</span><span style="margin-left:20px;">고가 : '+afc.addComma(detData[2])+
			                     '</span></br><span>저가 : '+afc.addComma(detData[3])+
			                     '</span><span style="margin-left:20px;">종가 : '+afc.addComma(detData[4])+
			                     '</span>';
		*/
		this.longXdiv.style.left = (this.startLineX - (curPos+1)*this.pos.barTot)+'px';
		this.longYdiv.style.top = (this.pos.upGrpSY + (this.upGrpMaxAm - detData[4])*this.pos.upRateH)+'px'; 
	}
};

// -----------------------  그래프 터치 이벤트  ----------------------- //
//자동스크를
EXCompareChart.prototype.autoScroll = function(speed)
{
    var thisObj = this;
    
    if(speed>150 || !this.isExistNextData()) return;
    
    this.timer = setTimeout(function()
    {
		thisObj.timer = null;
		
        if(thisObj.mScrollLR) thisObj.scrollLToR(1);
        else thisObj.scrollRToL(1);
        thisObj.autoScroll(speed + speed/4);
    }, speed);
};

//터치이벤트 셋팅
EXCompareChart.prototype.setTouchEvent = function()
{
    var thisObj = this;
    var touch1, touch2, pageX1, pageY1, pageX2, pageY2;
    
    this.canvas.addEventListener(afc.ACTION_DOWN, function(e) 
    {
    	this.isDown = true;
    	
		if(!thisObj.data || thisObj.data.length == 0) return;
		
        e.preventDefault();
        e.stopPropagation();
        
        if(afc.isPC) e.touches = [ { clientX:e.clientX, clientY:e.clientY, pageX:e.pageX, pageY:e.pageY } ];
        
        touch1 = e.touches[0];
        touch2 = e.touches[1];
        
        pageX1 = touch1.pageX;
        
        if(thisObj.timer)
        {
            clearTimeout(thisObj.timer);
            thisObj.timer = null;
        }
        
        thisObj.scollSX = pageX1;

        //------------------------      
        thisObj.mStartTime = new Date().getTime();
        thisObj.mOldTime = thisObj.mStartTime;
        thisObj.mStartX = pageX1;
        thisObj.mEndX = thisObj.mStartX;
        
        //-------------------------------------
        //롱탭을 눌렀을시
        //-------------------------------------
        if(!touch2)
        {
            this.longTime = setTimeout(function()
            {
                thisObj.mode = 1;
                
                thisObj.infoDiv.style.display = '';
                thisObj.longXdiv.style.display = '';
                thisObj.longYdiv.style.display = '';
                
                thisObj.moveX = pageX1;
                thisObj.drawLongTabLines();
                
            }, 500);
        }
        
    });
    
    function getDistance(p1, p2)
    {
        return Math.sqrt(Math.pow((p2.x - p1.x), 2) + Math.pow((p2.y - p1.y), 2));
    }
    
    this.canvas.addEventListener(afc.ACTION_MOVE, function(e) 
    {
        clearTimeout(this.longTime);
        
		if(!thisObj.data || thisObj.data.length == 0) return;
        
        e.preventDefault();
        e.stopPropagation();
        
        if(afc.isPC) 
        {
        	if(!this.isDown) return;
        	e.touches = [ { clientX:e.clientX, clientY:e.clientY, pageX:e.pageX, pageY:e.pageY } ];
        }
        
        touch1 = e.touches[0];
        touch2 = e.touches[1];
        
        pageX1 = touch1.pageX;
        pageY1 = touch1.pageY;
        
        //멀티터치
        if(touch2)
        {
            pageX2 = touch2.pageX;
            pageY2 = touch2.pageY;
            
            if(touch1 && touch2) {
                
                var dist = getDistance({
                    x: pageX1,
                    y: pageY1
                }, {
                    x: pageX2,
                    y: pageY2
                });
                if(!thisObj.lastDist) {
                    thisObj.lastDist = dist;
                }
				thisObj.rateVal = (dist/thisObj.lastDist).toFixed(2);
				thisObj.zoomState = 0;
                thisObj.zoomInOut();
                thisObj.lastDist = dist;
            }    
        }
        
        //일반 스크롤
        else
        {
            //--------------------------------------
            //롱탭 후 드래그 했을시
            if(thisObj.mode == 1)
            {
            	thisObj.moveX = pageX1;
            	thisObj.drawLongTabLines();
            }
            //일반 스크롤시
            else
            {
                //--------------------------------------
                var newTime = new Date().getTime();
                //멈춰있는 시간이 일정시간 이상이면 초기화
                if((newTime - thisObj.mOldTime)>100) 
                {
                    thisObj.mStartTime = newTime;
                    thisObj.mOldTime = newTime;
                    thisObj.mStartX = pageX1;
                    thisObj.mEndX = thisObj.mStartX;
                }
                
                else 
                {
                    thisObj.mOldTime = newTime;
                    thisObj.mEndX = pageX1;
                }
                
                //--------------------------------------
                var chkW = Math.abs(thisObj.scollSX - pageX1);
                if(chkW > thisObj.pos.barW)//+graph.distance
                {
                    if(thisObj.scollSX > pageX1)
                    {
                        thisObj.mScrollLR = false;
                        var count = parseInt((chkW/thisObj.pos.barW), 10);
                        thisObj.scrollRToL(count);
                    }
                    else
                    {
                        thisObj.mScrollLR = true;
                        var count = parseInt((chkW/thisObj.pos.barW), 10); 
                        thisObj.scrollLToR(count);
                    }
                    thisObj.scollSX = pageX1;
                }
            }
        }
        
    });

    this.canvas.addEventListener(afc.ACTION_UP, function(e) 
    {
    	this.isDown = false;
		if(!thisObj.data || thisObj.data.length == 0) return;
		
        clearTimeout(this.longTime);
        
        if(afc.isPC) e.touches = [ { clientX:e.clientX, clientY:e.clientY, pageX:e.pageX, pageY:e.pageY } ];
        
        thisObj.mode = 0;
        if(thisObj.infoDiv)
        {
            thisObj.infoDiv.style.display = 'none';
            thisObj.longXdiv.style.display = 'none';
            thisObj.longYdiv.style.display = 'none';
        } 
        
        e.preventDefault();
        e.stopPropagation();

        //------------------
        var interval = new Date().getTime() - thisObj.mStartTime;
        thisObj.speed = Math.abs(thisObj.mEndX - thisObj.mStartX)/interval;
        //속도값이 아주 작은 것은 무시한다.
        if(thisObj.speed > 0.5)
        {
            thisObj.autoScroll((4 - thisObj.speed)/2);
        }
        //----------------------------------
        
        thisObj.lastDist = null;
    });
};

EXCompareChart.prototype.addNewData = function(dataArr, keyArr)
{
	
	if(!dataArr) return;
	
	this.startId--;
		
	if(!keyArr)
	{
		var keyLength = dataArr.length;
		
		keyArr = new Array();
		for(var i = 0; i<keyLength; i++)
		{
			keyArr.push(i);
		}
	}
	this.upDownArr.unshift([]);
	
	
	// 01.봉차트를 그리기 위한 순수배열 데이터
	//   0       1      2      3       4       5         6  
	//['일시', '시가', '고가', '저가', '종가', '거래량', '거래대금' ]
	
	this.SIGAVAL = dataArr[keyArr[1]];
	this.GOGAVAL = dataArr[keyArr[2]];
	this.JEGAVAL = dataArr[keyArr[3]];
	this.JONGGAVAL = dataArr[keyArr[4]];
	this.QTYVAL = dataArr[keyArr[5]];
	
	this.data.unshift([ dataArr[keyArr[0]], this.SIGAVAL, this.GOGAVAL, this.JEGAVAL, this.JONGGAVAL, this.QTYVAL, dataArr[keyArr[6]] ]);
	
	//02.상승하락 구분 배열 데이터
	//      0                1            2          3
	//['상하색상구분', '보합일경우 높이', '상승한값', '하락한값']
	
	this.curOffset = 0;
	
	//02.상승하락 구분 배열 데이터
	this.makeUpDownData();
	
	//롱탭중일시에 정보 갱신
	if(this.mode == 1) this.drawLongTabLines();
	
};

//롱탭시 보여질 상세 데이터 표시
EXCompareChart.prototype.drawLongTabLines = function()
{
	var middleX = this._getMiddleX();
	if(this.isShowLeft)
    {
        if(middleX > this.moveX)
        {
            this.infoDiv.style.left = '';
            this.infoDiv.style.right = '10px';
            this.isShowLeft = false;
        }
    }
    else
    {
        if(middleX < this.moveX)
        {
            this.infoDiv.style.right = '';
            this.infoDiv.style.left = '10px';
            this.isShowLeft = true;
        }
    }
    this.drawLongTabData(this.moveX);
};

//차트를 그릴 원시데이터 가공
EXCompareChart.prototype.makeChartCanvasData = function(dataArr, keyArr)
{

	var len = dataArr.length;
	
	if(len < 1) return;
	
	var preDataLen = this.data.length;
	this.data.length += len;
	
	if(!this.lineData[0]) this.lineData[0] = new Array();
	this.lineData[0].length += len;
	
	this.termCnt = 0;
	this.curOffset = 0;
	this.preTermIdx = 0;
	
	this.upDownArr.length += len;
	
	this.SIGAVAL = 0; this.GOGAVAL = 0; this.JEGAVAL = 0; this.JONGGAVAL = 0; this.QTYVAL = 0; this.DISTVAL = 0;
	
	this.preUpDown = 2;
	var servRow = null;
	var convRow = new Array();
		//일시키               //시가키                //고가키               //저가키                //종가키                 //거래량키             // 거래대금키
	var dateKey = keyArr[0], sigaKey = keyArr[1], gogaKey = keyArr[2], jegaKey = keyArr[3], jonggaKey = keyArr[4], qtyKey = keyArr[5], prcKey = keyArr[6];
	
	    //시가     //고가     //저가     //종가      //거래량   
	var SIGA = 0, GOGA = 0, JEGA = 0, JONGGA = 0, QTY = 0;
	
	this.EMA1 = this.EMA2 = dataArr[0][jonggaKey];
	
	for( var i = len-1 ; i > -1 ; i-- )
	{
		// 01.봉차트를 그리기 위한 순수배열 데이터
		//   0       1      2      3       4       5         6  
		//['일시', '시가', '고가', '저가', '종가', '거래량', '거래대금' ]
		
		servRow = dataArr[i]; 
		convRow = new Array();
	    convRow.push(servRow[dateKey]);
	    
	    /*
		this.SIGAVAL = SIGA = servRow[sigaKey];
		this.GOGAVAL = GOGA = servRow[gogaKey];
		this.JEGAVAL = JEGA = servRow[jegaKey];
		this.JONGGAVAL = JONGGA = servRow[jonggaKey];
		this.QTYVAL = QTY = servRow[qtyKey];
        convRow.push(SIGA);
		convRow.push(GOGA);
		convRow.push(JEGA);
		convRow.push(JONGGA);
        convRow.push(QTY);
		convRow.push(servRow[prcKey]);
		*/
		
		this.SIGAVAL = SIGA = (sigaKey) ? servRow[sigaKey] : servRow[jonggaKey];
        this.GOGAVAL = GOGA = (gogaKey) ? servRow[gogaKey] : servRow[jonggaKey];
        this.JEGAVAL = JEGA = (jegaKey) ? servRow[jegaKey] : servRow[jonggaKey];
        this.JONGGAVAL = JONGGA = servRow[jonggaKey];
        this.QTYVAL = QTY = (qtyKey) ? servRow[qtyKey] : 0;
        convRow.push(SIGA);
        convRow.push(GOGA);
        convRow.push(JEGA);
        convRow.push(JONGGA);
        convRow.push(QTY);
        convRow.push((prcKey) ? servRow[prcKey] : 0);
		
		this.curOffset = preDataLen+i;
		
		this.data[this.curOffset] = convRow;
		this.lineData[0][this.curOffset] = JONGGA; 
		
		//02.상승하락 구분 배열 데이터
		this.makeUpDownData();
		
	}
};

//02.상승하락 구분 배열 데이터
EXCompareChart.prototype.makeUpDownData = function()
{
	//      0                1            2          3
	//['상하색상구분', '보합일경우 높이', '상승한값', '하락한값']
	this.DISTVAL = this.JONGGAVAL - this.SIGAVAL;
	
	if(this.DISTVAL > 0 )
	{
		this.preUpDown = 1;
		this.upDownArr[this.curOffset] = [ this.preUpDown, 0, this.DISTVAL, 0 ];
	}
	else if(this.DISTVAL < 0)
	{
		this.preUpDown = 2;
		this.upDownArr[this.curOffset] = [ this.preUpDown, 0, 0, this.DISTVAL*-1 ];
	}
	else
	{
		this.upDownArr[this.curOffset] = [ this.preUpDown, 2, 0, 0 ];
	}	
};

EXCompareChart.prototype.getQueryData = function(dataArr, keyArr)
{
    
};

EXCompareChart.prototype.setQueryData = function(dataArr, keyArr)
{
    if(!keyArr) return;
	
	if(dataArr.length == 0)
	{
		AToast.show('데이터가 존재하지 않습니다.');
		return;
	}
	
	this.makeChartCanvasData(dataArr, keyArr);
	this.updateGraph();
};
                    
//window.EXCompareChart = EXCompareChart;
                    
})();