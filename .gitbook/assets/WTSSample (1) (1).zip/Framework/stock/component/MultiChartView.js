(async function(){

await afc.import("Framework/stock/component/ChartView.js");


MultiChartView = class MultiChartView extends ChartView
{
	constructor() {
		super();
		//ChartView.call(this);
		
		this.frwName = 'stock';
		
		this.selectedIndex = -1;	//현재 멀티차트 선택된 index
		this.firstItem = null;	//0번째에 선택되어 있는 종목 저장
		this.nextKeyArr = null;	//종목별 각각의 넥스트키 저장 배열
		this.nextDateArr = null;	//종목별 각각의 넥스트날짜 저장 배열
		this.realKeyArr = null;	//리얼 키 저장 배열
		this.tempIndex = -1;		//맨처음 조회시 index정보가 없을때 사용하는 임시 index변수
		this.isDivideChart = false;	
	}
	
}
//afc.extendsClass(MultiChartView, ChartView);

MultiChartView.CONTEXT = 
{
    tag: '<div data-base="MultiChartView" data-class="MultiChartView" class="AView-Style"></div>',

    defStyle: 
    {
        width:'400px', height:'200px'
    },

    //events: ['swipe', 'longtab', 'scroll', 'scrollleft', 'scrollright', 'scrolltop', 'scrollbottom', 'drop', 'dragStart', 'dragEnd' ]
    events: ['swipe', 'longtab', 'scroll', 'scrollleft', 'scrollright', 'scrolltop', 'scrollbottom', 'drop', 'dragstart', 'dragend' ]
};

MultiChartView.prototype.loadChartLayout = function()
{
	this.isMultiChart = true;
	this.selectedIndex = -1;
	
	this.realKeyArr = ['','','',''];
	this.nextDateArr = ['','','',''];
	this.nextKeyArr = [0,0,0,0];
	this.tempIndex = -1;
	this.isDivideChart = false;
	
	ChartView.prototype.loadChartLayout.call(this);
	
};

MultiChartView.prototype.setItemInfo = function(itemArr)
{
	this.item = itemArr;
	
	if(this.selectedIndex == -1) this.unregisterRealOne();
	
	this.mainKeyInfo = {};
	this.mainKeyInfo['D1단축코드'] = itemArr[0];	
	this.mainKeyInfo['D1단축명'] = itemArr[1];
	this.mainKeyInfo['D1시장분류코드'] = itemArr[2];
	
	//onDivide가 호출되기 전에 임시 array 생성 또는 multi 개수가 1개일때 대처
	if(this.selectedIndex == -1)
	{
		this.tempIndex++;
		this.realKeyArr[this.tempIndex] = this.makeRealKey(itemArr);
	}
	else
	{
		this.tempIndex = -1;
		this.realKeyArr[this.selectedIndex] = this.makeRealKey(itemArr);
		
		this.checkUnregisterReal();	
	}
	
};

//차트의 검색타입을 설정(0:일주월,1:분,2:틱,3:해외지수)
MultiChartView.prototype.setSearchType = function(type, term, btnUpdate)
{
	ChartView.prototype.setSearchType.call(this, type, term);
	
	if(btnUpdate)
	{
		this.resetBtnState();
		
		if(type == 1)
		{
			this.minBtn.setText(this.term);
			this.selectBtn = this.minBtn;
		}
		else if(type == 2)
		{
			this.tickBtn.setText(this.term);
			this.selectBtn = this.tickBtn;
		}
		else
		{
			this.termBtn.setText(this.termMap2[this.term]);
			this.selectBtn = this.termBtn;
		}
		
		 this.selectBtn.addClass('BT_CO2_NOR');
	}
	
};

MultiChartView.prototype.makeRealKey = function(itemArr)
{
	var realKeyStr = parseInt(itemArr[2], 10)+'_';

	//시장분류코드가 코스피,코스닥,KONEX종목,섹터지수일 때는 단축코드를 숫자타입으로 바꿈
	if(itemArr[2] == 2 || itemArr[2] == 4 || itemArr[2] == 118 || itemArr[2] == 167)
	{
		realKeyStr += parseInt(itemArr[0], 10);
	}
	else realKeyStr += itemArr[0];
	return realKeyStr+'_';
};

//특정 index의 종목이 변경 됐을시 체크하여 리얼해제
MultiChartView.prototype.checkUnregisterReal = function()
{
	var thisObj = this;
	
	for(var key in this.realData)
	{
		var isExistReal = false;
		for(var i = 0; i<thisObj.realKeyArr.length; i++)
		{
			if(thisObj.realKeyArr[i] == key)
			{
				isExistReal = true;
				break;
			}
		}
		
		//배열에 리얼키가 존재하지 않으면 제거
		if(!isExistReal)
		{
			//alert('존재하지 않습니다 : key : '+ key +" = "+thisObj.realData[key]['D1종목명']);
			theApp.infoNetManager.unregisterReal(thisObj.realQueryName, [thisObj.realData[key]], null, [ thisObj ] );
			delete thisObj.realData[key];
		}
	}
};

//현재 리얼맵에 리얼키가 존재하는지 확인
MultiChartView.prototype.isExistRealKey = function(key)
{
	return this.realData.hasOwnProperty(key);
};

//
MultiChartView.prototype.unregisterRealOne = function()
{
	if(this.mainKeyInfo)
		theApp.infoNetManager.unregisterReal(this.realQueryName, [this.mainKeyInfo], null, [ this ] );
};


//멀티차트에 연결된 리얼데이터 해제
MultiChartView.prototype.unregisterReal = function()
{
	var thisObj = this;
	for(var key in this.realData)
	{
		theApp.infoNetManager.unregisterReal(thisObj.realQueryName, [thisObj.realData[key]], null, [ thisObj ] );	
	}
	this.realData = new Object();
};

//네이티브 차트에 전송할 header 고정 데이터 셋팅
MultiChartView.prototype.setFixedData = function(fixData, realKey)
{
	if(!realKey) realKey = this.makeRealKey(this.item);
	if(!this.realData[realKey]) this.realData[realKey] = new Object();
	
	for(var key in fixData)
	{
		this.realData[realKey][key] = fixData[key];
	}
};

//네이티브 차트에 전송할 header 조회 데이터 셋팅
MultiChartView.prototype.setSearchData = function(searchData, realKey)
{
	if(!realKey) realKey = this.makeRealKey(this.item);
	if(!this.realData[realKey]) this.realData[realKey] = new Object();
	
	for(var key in searchData)
	{
		this.realData[realKey][key] = searchData[key];
	}
};

//네이티브 차트에 조회데이터를 업데이트하는 함수
MultiChartView.prototype.updateOutputData = function(tempData, realKey)
{
	var thisObj = this;
	if(afc.isSimulator) return;
	
	ChartManager.updateOutputData([this.getElementId(), {
		ref: thisObj.realData[realKey],
		data: tempData
	}]);
	
	if(!this.isInit) {
		this.tempData = tempData;
	}	
	
};

//네이티브 차트에 리얼 데이터를 업데이트하는 함수
MultiChartView.prototype.updateRealData = function(realKey)
{
	if (!this.realData[realKey]) return;
	if ($.trim(this.realData[realKey]) == '' ) return;
	if (!this.realData[realKey]["key"])  return;

    var key = this.realData[realKey]["key"].split('_');
    var sCode = this.realData[realKey]["D1단축코드"];
	
	if (key) var code = key[1];

    if (sCode != code) {
        return;
    };

    if(!afc.isSimulator) ChartManager.updateRealData([this.getElementId(), this.realData[realKey]]);	
};


//네이티브 차트에서 데이터를 요청(저장된 차트를 불러와서 요청하는 경우)
MultiChartView.prototype.onRequestData = function(requestArr, selectedIndex)
{
	this.selectedIndex = selectedIndex;
	ChartView.prototype.onRequestData.call(this, requestArr, selectedIndex);
};

//리얼데이터를 받기위해 전송하는 함수
MultiChartView.prototype.sendDataManage = function()
{
	//if(!isFirst && !this.isInit) return;

	var thisObj = this;
	
	//this.clearChart();
	
	this.getContainer().sendData(this.realQueryName, function(queryData, groupName)
	{
		var mainKeyBlock = queryData.getBlockData('InBlock1');
		mainKeyBlock[0] = thisObj.mainKeyInfo;
		
		if(!thisObj.isExistRealKey(thisObj.makeRealKey([thisObj.mainKeyInfo['D1단축코드'], '', thisObj.mainKeyInfo['D1시장분류코드']])))
		{
			this.registerReal(thisObj.realQueryName, mainKeyBlock, null, [thisObj], 0 );
			queryData.enableFlag('realFlag');
		}
	},
	function(queryData, groupName)
	{
		if(queryData)
		{
			var blockData = queryData.getBlockData('OutBlock1');
			if(blockData.length > 0)
			{
				thisObj.setFixedData({
					'D1에러여부': false,
					'D1초기화여부': true,
					'D1수정주가여부': thisObj.chartConfig.useAdPrice,
					'D1데이터개수': thisObj.chartConfig.limitCnt,
					'D1단축코드': thisObj.item[0],
					'D1종목명': thisObj.item[1],
					'D1시장분류코드': thisObj.item[2],
					'D1가격소수점자리수' : (thisObj.midRoundMap[MasterInfo.formatMarketCode(thisObj.item[2])]) ? thisObj.midRoundMap[ MasterInfo.formatMarketCode( thisObj.item[2] ) ] : 0
				}, blockData[0].key);	

				thisObj.sendChartData(0);
			}
		}
	});
};

//초기화 및 연속 여부 셋팅
MultiChartView.prototype.setDefaultAndMore = function(isMore)
{
	var realKey = null;
	if(this.selectedIndex > -1) realKey = this.realKeyArr[this.selectedIndex];
	else realKey = this.realKeyArr[this.tempIndex];
	
	if(isMore)
	{
		this.setFixedData({ 'D1초기화여부': false, 'D1연속여부': isMore }, realKey);
	}
	else
	{
		this.setFixedData({ 'D1초기화여부': true, 'D1연속여부': isMore }, realKey);
		this.nextKey = 0;
		this.nextDate = '';
	}
};

//네이티브 차트에서 설정한 수정주가여부 적용함수
MultiChartView.prototype.onChangeAdjustedStock = function(isAdjustedStock)
{
	var thisObj = this;
	var isStockMarket = (thisObj.mainKeyInfo['D1시장분류코드'] == '001') || (thisObj.mainKeyInfo['D1시장분류코드'] == '003');

	if (!isStockMarket) {
		isAdjustedStock = false;
	}

	if (isAdjustedStock == true || isAdjustedStock == "1") {
		this.chartConfig.useAdPrice = 1;
	}
	else {
		this.chartConfig.useAdPrice = 0;
	}

    this.saveConfigInfo();
	
	var realKey = null;
	if(this.selectedIndex > -1) realKey = this.realKeyArr[this.selectedIndex];
	else realKey = this.realKeyArr[this.tempIndex];
	
	this.setFixedData({ 'D1수정주가여부': this.chartConfig.useAdPrice }, realKey);
	this.sendChartData(0);
};

MultiChartView.prototype.sendChartData = function(isMore)
{	
	if(this.selectedIndex > -1)
	{
		
		this.nextKey = this.nextKeyArr[this.selectedIndex];
		this.nextDate = this.nextDateArr[this.selectedIndex];
		if(this.selectedIndex == 0) this.firstItem = [this.item, this.searchType, this.term];
	}
	else
	{
		this.nextKey = this.nextKeyArr[this.tempIndex];
		this.nextDate = this.nextDateArr[this.tempIndex];
		this.firstItem = [this.item, this.searchType, this.term];
	}
	
	ChartView.prototype.sendChartData.call(this, isMore);
};

//차트 영역 개수가 변경됐을때 호출(맨 처음 시작시에도 호출)
MultiChartView.prototype.onDivideChart = function(nTotNum, sCodeData, sRealData, sMarket)
{
    //멀티차트 분할 후 작업 소스 추가해주세요.
	//1. 여기가 실행 되면
	//2. 리얼 모두 해제
	//3. sRealData ; 으로 splite
	//4. sRealData 에 있는 종목의 mid 각각 가져오기
	//5. sRealData 에 해당하는 리얼 등록
	
	this.isDivideChart = true;
	
	var thisObj = this;
	var realOriData = sRealData.split(';');
	var realMidData = sMarket.split(';');
	var itemCode = null, itemMid = null;
	
	var arrLength = realOriData.length-1;
	
	this.realKeyArr = new Array();
	
	for(var i = 0; i<arrLength; i++)
	{
		itemCode = realOriData[i];
		if(itemCode) this.realKeyArr.push(this.makeRealKey([realOriData[i], '', realMidData[i]]));
		else this.realKeyArr.push(new Array());
	}
	
	this.checkUnregisterReal();
	
};

//멀티창에서 종목영역 하나를 선택했을 경우 오는 이벤트
MultiChartView.prototype.onSelectedChart = function(selectedIndex, strInfo)
{
	//onDivideChart 후 0째 종목으로 다시 재 셋팅 되므로 그때는 조회TR을 날림
	if(this.isDivideChart)
	{
		this.noSend = false;
		this.selectedIndex = selectedIndex-1;
		this.onRequestData(strInfo.split(';'), this.selectedIndex);
	}
	else
	{
		//멀티차트에서 같은 index를 눌렀을 경우 리턴
		if(this.selectedIndex == (selectedIndex-1)) return;

		//차트에서 종목 선택시 차트 데이터를 날리지 않음
		this.noSend = true;
		this.selectedIndex = selectedIndex-1;
		this.onRequestData(strInfo.split(';'), this.selectedIndex);
	}
	
	this.isDivideChart = false;
};

//종목을 선택하는 팝업 호출
MultiChartView.prototype.onRequestCodeControl = function(index)
{
	this.selectedIndex = index-1;
	var codeFindWin = null;
	
	if(Define.PRJ_TYPE==Define.MC) codeFindWin = AWindow.createWindow("MC/window/MC0102.lay", "MS0107");
	else codeFindWin = AWindow.createWindow("MS/window/MS0107.lay", "MS0107");
	
	codeFindWin.popupMode = true;
	codeFindWin.selIdx = this.selectedIndex;
	codeFindWin.open(this, 0, 0, "100%", "100%");
};

MultiChartView.prototype.setData = function(dataArr)
{
	if(!dataArr || (dataArr.length == 0))
	{
		this.clearChart();
		return;
	}

	if(dataArr[0].key) realKey = dataArr[0].key;

	if(this.isInit)
	{
		this.tempData = null;
		this.updateOutputData(dataArr, realKey);
	}
	else this.tempData = dataArr;
};

MultiChartView.prototype.setQueryData = function(dataArr, keyArr, queryData)
{
	var data = null, realKey = null;
	var queryName = queryData.getQueryName();
	
	if(queryName == this.realQueryName)
	{
		//2016.07.20 by hyh - 데이터가 없는 경우에는 차트 데이터 초기화 및 리턴 (리얼은 초기화 하지 않음)
		if(!dataArr || (dataArr.length == 0)) return;
		
		if(dataArr[0].key) realKey = dataArr[0].key;
		
		data = dataArr[0];
		if(queryData.isReal)
		{
			var realDataOne = this.realData[realKey];
			if(realDataOne)
			{
				for(var key in data)
				{
					if(realDataOne.hasOwnProperty(key))
					{
						realDataOne[key] = data[key];
					}
				}
				this.updateRealData(realKey);
			}
		}
		else
		{
			if(dataArr[0].key) this.setSearchData(data, dataArr[0].key);
		}
	}
	else if(queryName == 'QR000002' || queryName == 'QR000003' || queryName == 'QR000004' || queryName == 'QR000006'|| queryName == 'QR000015')
	{
		//다음 전송할 데이터가 있는지 체크
		//this.manageSend(true);
		
		//2016.07.20 by hyh - 데이터가 없는 경우에는 차트 데이터 초기화 및 리턴
		if(!dataArr || (dataArr.length == 0))
		{
			this.clearChart();
			return;
		}
		
		if(dataArr[0].key) realKey = dataArr[0].key;
	
		if(this.isInit)
		{
			this.tempData = null;
			this.updateOutputData(dataArr, realKey);
		}
		else this.tempData = dataArr;
		
	}
};

MultiChartView.prototype.onWindowResult = function(result, awindow)
{
	var thisObj = this;
	if(awindow.getId() == "MS0107")
	{
		if(result)
		{
			//Check에서는 멀티차트가 여러개의 화면으로 분기되어 있음
			//해당 MID가 연결될 수 있는 화면이 있으면 onRequestData수행
			if(Define.PRJ_TYPE == Define.MC) {
				if(theApp.menuInfo.isChartAvailable(awindow.resultData, this.getContainer().getId()))
				{
					//채권 연결지표 데이터 조회
					if(awindow.resultData[0].indexOf('KTB')>-1) {
						this.onConnSendQuery('CP877500', awindow.resultData, function(cb){
							if(cb)
							{
								awindow.resultData[0] = cb['D1단축코드'];
								thisObj.onRequestData([awindow.resultData[0], awindow.resultData[1], awindow.resultData[2], 0, thisObj.term], awindow.selIdx);	
							}
						});		
					}
					//일반 종목 데이터 조회
					else this.onRequestData([awindow.resultData[0], awindow.resultData[1], awindow.resultData[2], 0, this.term], awindow.selIdx);
				}
				else ChartManager.toast('추가할 수 없는 종목입니다.');
				
			} else {
				if(theApp.menuInfo.isDifPageByCntId(awindow.resultData, this.getContainer().getId())[0] == 0)
				{
					this.onRequestData([awindow.resultData[0], awindow.resultData[1], awindow.resultData[2], 0, this.term], awindow.selIdx);
				}
				else ChartManager.toast('추가할 수 없는 종목입니다.');			
			}
		}
	}
	else if(awindow.getId() == 'MS000002')
	{
		if(result != undefined)
		{
			var btnCompId = this.clickBtn.getComponentId();
			
			if((btnCompId == 'MinBtn') || (btnCompId == 'TickBtn'))
			{
				// 해외지수일 경우 분/틱 조회 시키지 않음  + 채권종목일 경우
				if(this.isFIndex(this.item) || this.isBIndex(this.item))  
				{
					ChartManager.toast('조회할 수 없는 종목입니다.');
					return;
				}
			}
		
			this.resetBtnState();
			var clickedBtn;
			
			switch(btnCompId)
			{
				case 'MinBtn':	
					this.setSearchType(1, result);
					this.setLastValue(result);
					clickedBtn = this.clickBtn;
					break;
			
				case 'TickBtn':
					this.setSearchType(2, result);
					this.setLastValue(result);
					clickedBtn = this.clickBtn;
					break;
					
				case 'TermBtn':
					this.setSearchType(0, this.termMap[result]);
					this.setLastValue(this.termMap[result]);
					clickedBtn = this.clickBtn;
					break;
			
				case 'MinBtn2':
					if($.inArray(result, ['일', '주', '월', '년'] ) > -1) {
						this.setSearchType(0, this.termMap[result]);
						this.setLastValue(this.termMap[result]);	
						
						//termBtn이 존재하면(세로모드에 일반적으로 존재), sendChartData에서 우선적으로 termBtn text 값을 기반으로 조회
						if(this.termBtn) this.termBtn.setText(result);	

						this.tickBtn2.setText('1');
						this.tickBtn2.$ele.hide();
						clickedBtn = this.clickBtn;
						
					} else if(result == "분" ){
						this.tickBtn2.$ele.show();
						
						//minBtn이 존재하면(세로모드에 일반적으로 존재), sendChartData에서 우선적으로 minBtn text 값을 기반으로 조회
						if(this.minBtn) this.minBtn.setText('1');
						
						this.setSearchType(1, '1');
						this.setLastValue('1');
						clickedBtn = this.tickBtn2;
						
					} else if(result == '틱') {
						this.tickBtn2.$ele.show();
						
						//tickBtn이 존재하면(세로모드에 일반적으로 존재), sendChartData에서 우선적으로 tickBtn text 값을 기반으로 조회
						if(this.tickBtn) this.tickBtn.setText('1');
						
						this.setSearchType(2, '1');
						this.setLastValue('1');	
						clickedBtn = this.tickBtn2;
					}
					break;
					
				case "TickBtn2":
					if(this.getSearchType()[0] == 1) {
						this.termBtn2.setText('분');
						
						//minBtn이 존재하면(세로모드에 일반적으로 존재), sendChartData에서 우선적으로 minBtn text 값을 기반으로 조회
						if(this.minBtn) this.minBtn.setText(result);
						
						this.setSearchType(1, result);
						this.setLastValue(result);
						clickedBtn = this.clickBtn;
					} 
					else if(this.getSearchType()[0] == 2) {
						this.termBtn2.setText('틱');
						
						//tickBtn이 존재하면(세로모드에 일반적으로 존재), sendChartData에서 우선적으로 tickBtn text 값을 기반으로 조회
						if(this.tickBtn) this.tickBtn.setText(result);
						
						this.setSearchType(2, result);
						this.setLastValue(result);
						clickedBtn = this.clickBtn;
					}
					break;
				
				default: 
					break;
			}
						
			this.clickBtn.setText(result);

			this.selectBtn = clickedBtn;
			this.selectBtn.addClass('BT_CO2_NOR');

			this.sendDataManage();
		}
	}
};


//연결채권 데이터바인딩
MultiChartView.prototype.onConnSendQuery = function(queryName, itemBoxData, callback)
{	
	var thisObj = this;
	
	this.getContainer().sendData(queryName, function(queryData, groupName)
	{
		//마스트에 잘못된 종목코드임-정상종목코드로 변경
		if(itemBoxData[0]=="KTBSI10") itemBoxData[0]="KTBI10"
	
		var InBlock1 = queryData.getBlockData('InBlock1');
		InBlock1[0] = {
			'D1시장분류코드': 161,
			'D1단축코드': itemBoxData[0]
		};

		var optionBlock = queryData.getBlockData('InBlock3');
		optionBlock[0] = {
			"D1metrix의갯수": 1
		};
	},
	function(queryData, groupName)
	{
		if(!queryData) return;
		//queryData.printQueryData();
		var OutBlock1 = queryData.getBlockData('OutBlock1')[0];

		if(OutBlock1!=null)
		{
			callback({"D1단축코드": OutBlock1['D1국제표준코드']});
		}
	});
};
                    
//window.MultiChartView = MultiChartView;

//window['MultiChartView'] = MultiChartView;

})();