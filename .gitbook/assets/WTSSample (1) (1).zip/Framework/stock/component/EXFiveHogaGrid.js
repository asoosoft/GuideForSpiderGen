
(async function(){

await afc.import("Framework/afc/component/AGrid.js");

/**
* 5호가 그리드 객체 입니다.
*
* class EXFiveHogaGrid
* @constructor
*/

EXFiveHogaGrid = class EXFiveHogaGrid extends AGrid
{
    constructor()
    {
        super();
	
        this.frwName = 'stock';
        
        this.basePrice = 0;	//호가의 색상을 구분하기 위한 전일 기준가
        
        this.rowLen = 0; 
        this.colLen = 0;
        this.keyLen = 0;
        this.keyHalf = 0;
        this.btmRowCnt = 0; //하단 데이터 영역 row 갯수 : 2 = 합계,시간외
        this.btmCellCnt = 0; //하단 데이터 영역 cell 갯수 : 6 = 2*3
        this.endHalf = 30;
        this.startHalf = 32;
        
        this.curPriceKey = 'D1현재가';
        this.curPriceMap = null;
        this.currentCell = null;
        this.currentPrice = 0;
        this.curPriceStyleArr = null;
        
        //잔량값 저장 배열(2차원), 그리드 형태와 동일
        this.remainValArr = null;
        
        this.hogaOption = 
        {
            sellBgColor: '#a1c1e8',
            buyBgColor: '#e5b7b5'
        };
        
        this.ctrtMode = false;
    }
}

//window.EXFiveHogaGrid = EXFiveHogaGrid;

EXFiveHogaGrid.CONTEXT =
{
    tag: '<div data-base="EXFiveHogaGrid" data-class="EXFiveHogaGrid" \
    		data-blocks-hogagrid="OutBlock1,D1매도호가잔량5,D1매도호가5,,D1매도호가잔량4,D1매도호가4,,D1매도호가잔량3,D1매도호가3,,D1매도호가잔량2,D1매도호가2,,D1매도호가잔량1,D1매도호가1,,,\
    		D1매수호가1,D1매수호가잔량1,,D1매수호가2,D1매수호가잔량2,,D1매수호가3,D1매수호가잔량3,,D1매수호가4,D1매수호가잔량4,,D1매수호가5,D1매수호가잔량5,,"\
    		data-hide-header="true" data-flexible-row="true" data-query-name="HOGAGRID" data-selectable="true" class="AGrid-Style">\
            <table cellpadding="0" align="center" style="width:100%; border-collapse:collapse;" class="grid-header-table">\
            	<colgroup><col width="35%" /><col width="30%" /><col width="35%" /></colgroup>\
                <thead align="center" class="head-prop" style="display:none;">\
                    <tr height="0px"><td>col1</td><td>col2</td><td>col3</td></tr>\
				</thead>\
			</table>\
			<div style="height:100%; overflow-y:auto; -webkit-overflow-scrolling:touch;">\
			<table align="center" cellpadding="0" class="grid-body-table" style="width:100%; border-collapse:collapse;">\
				<colgroup><col width="35%" /><col width="30%" /><col width="35%" /></colgroup>\
				<thead align="center" class="head-prop" style="display:none;">\
                    <tr height="0px"><td>col1</td><td>col2</td><td>col3</td></tr>\
				</thead>\
                <tbody align="center" class="body-prop">\
                    <tr height="40px" class="normal-prop"><td></td><td></td><td></td></tr>\
                    <tr height="40px" class="normal-prop"><td></td><td></td><td></td></tr>\
                    <tr height="40px" class="normal-prop"><td></td><td></td><td></td></tr>\
                    <tr height="40px" class="normal-prop"><td></td><td></td><td></td></tr>\
                    <tr height="40px" class="normal-prop"><td></td><td></td><td></td></tr>\
                    <tr height="40px" class="normal-prop"><td></td><td></td><td></td></tr>\
                    <tr height="40px" class="normal-prop"><td></td><td></td><td></td></tr>\
                    <tr height="40px" class="normal-prop"><td></td><td></td><td></td></tr>\
                    <tr height="40px" class="normal-prop"><td></td><td></td><td></td></tr>\
                    <tr height="40px" class="normal-prop"><td></td><td></td><td></td></tr>\
				</tbody>\
			</table>\
			</div>\
		</div>',
    
    defStyle: 
    {
        width:'400px', height:'400px'
    },
    
    events: ['select', 'scrolltop', 'scrollbottom']
};

EXFiveHogaGrid.prototype.init = function(context, evtListener)
{
	AGrid.prototype.init.call(this, context, evtListener);
	
    this.selectStyleName = null;
    
	this.rowLen = this.getRowCount() - this.btmRowCnt;
	this.colLen = this.getColumnCount();
	this.endHalf = this.rowLen*this.colLen/2;
	this.startHalf = this.endHalf + this.colLen-1;

	//Current Price Cell Style
	//this.curPriceStyleArr = ['EXHogaGrid-Style-CurPrice', 'EXHogaGrid-Style-CurPrice', 'EXHogaGrid-Style-CurPrice'];
	this.curPriceStyleArr = ['CR_007', 'CR_009', 'CR_008'];
	this.maskArr = [ afc.hogaComma, afc.hogaComma ,afc.hogaComma];
	this.colorArr = [ stk.getAsMaskedIt, stk.getColorTagCfValue, stk.getAsMaskedIt];
	//this.colorArg = [ '', this.basePrice, ''];

	//초기화
	this.remainValArr = new Array(this.rowLen);
	for(var i=0; i<this.rowLen; i++)
	{
		this.remainValArr[i] = new Array(this.colLen);

		for(var j=0; j<this.colLen; j++)
			this.remainValArr[i][j] = 0;
	}
};

EXFiveHogaGrid.prototype.clearContents = function()
{
    this.tBody.find('td').each(function()
    {
        this.textContent = '';
		this.style.background = '';
    });
};

EXFiveHogaGrid.prototype.resetGrid = function()
{
    this.removeAll();
    this.addRow([]);
};

EXFiveHogaGrid.prototype.setBasePrice = function(basePrice)
{
	this.basePrice = basePrice;
};

EXFiveHogaGrid.prototype.setCurrentPrice = function(currentPrice)
{
	this.currentPrice = currentPrice;
};

EXFiveHogaGrid.prototype.setCurPriceKey = function(keyName)
{
	this.curPriceKey = keyName;
};

EXFiveHogaGrid.prototype.setCtrtMode = function(enable)
{
	this.ctrtMode = enable;
};

EXFiveHogaGrid.prototype.isCtrtMode = function()
{
	return this.ctrtMode;
};

EXFiveHogaGrid.prototype.selectCurrentPrice = function()
{
	if(this.currentCell)
	{
		this.currentCell.removeClass(this.curPriceStyleArr[0]);
		this.currentCell.removeClass(this.curPriceStyleArr[1]);
		this.currentCell.removeClass(this.curPriceStyleArr[2]);	
		this.currentCell[0].style.removeProperty('border-right');
		this.currentCell[0].style.removeProperty('border-bottom');
	}
	
	if(this.curPriceMap)
	{	
		var cellOne = null, value;
		for(var i = 0; i < this.curPriceMap.length; i++)
		{
			cellOne = this.curPriceMap[i];
			value = this.maskArr[1](this.currentPrice);
			if(this.ctrtMode) value += afc.toFixed2(this.calcCtrtRate(this.currentPrice))+'%';
			if(cellOne.text() == value)
			{
				this.currentCell = cellOne;
				if(this.basePrice < this.currentPrice) this.currentCell.addClass(this.curPriceStyleArr[0]);
				else if(this.basePrice > this.currentPrice) this.currentCell.addClass(this.curPriceStyleArr[2]);
				else this.currentCell.addClass(this.curPriceStyleArr[1]);
				this.currentCell[0].style.setProperty('border-right', 'none','!important');
				this.currentCell[0].style.setProperty('border-bottom', 'none','!important');
				break;
			}
		}
	}
};

EXFiveHogaGrid.prototype.calcCtrtRate = function(value)
{
	//basePrice가 없으면 안된다.
	//if(!this.basePrice) return '';
	value = afc.removeComma(value) - this.basePrice;
	return (value/this.basePrice*100);
};

EXFiveHogaGrid.prototype.setCurrentPriceStyleName = function(style)
{
	if(styleArr) this.curPriceStyleArr = styleArr;
	//else this.curPriceStyleArr = ['EXHogaGrid-Style-CurPrice', 'EXHogaGrid-Style-CurPrice', 'EXHogaGrid-Style-CurPrice'];
	else this.curPriceStyleArr = ['CR_007', 'CR_009', 'CR_008'];
};

EXFiveHogaGrid.prototype.setHogaOption = function(key, value)
{
	this.option['key'] = value;
};

//isFloat - 소수점 2자리 true, 소수점 0자리 false 또는 소수점 2자리 2, 소수점 0자리 0 
EXFiveHogaGrid.prototype.setValueType = function(valueType)
{
	this.valueType = valueType;
	this.setMaskColorInfo();
};

//기존 Hoga데이터에 Contrast Ratio를 덧붙인다. 
EXFiveHogaGrid.prototype.toggleCtrtMode = function()
{
	if(this.ctrtMode)
	{
		this.ctrtMode = false;
		for(var i=0; i<this.rowLen; i++)
		{
			$($(this.getCell(i, 1)).children()[1]).remove();
		}
	}
	else
	{
		this.ctrtMode = true;
		var value = null;
		for(var i=0; i<this.rowLen; i++)
		{
			value = $(this.getCell(i, 1)).text();
			if(value.trim()) $(this.getCell(i, 1)).append(stk.getCtrtRateTag(value, afc.toFixed2, this.basePrice));
		}
	}
	this.setMaskColorInfo();
};

EXFiveHogaGrid.prototype.setMaskColorInfo = function()
{
	//if(this.valueType == 1) this.maskArr = [ afc.addComma, afc.floor1, afc.addComma];
	//else if(this.valueType == 2) this.maskArr = [ afc.addComma, afc.floor2, afc.addComma];
	//else this.maskArr = [ afc.addComma, afc.addComma, afc.addComma];
	this.maskArr = [ afc.hogaComma, afc.hogaComma, afc.hogaComma];	
	
	if(this.ctrtMode) this.colorArr = [ stk.getAsMaskedIt, stk.getCtrtTag, stk.getAsMaskedIt];
	else this.colorArr = [ stk.getAsMaskedIt, stk.getColorTagCfValue, stk.getAsMaskedIt];
};

EXFiveHogaGrid.prototype.getMaskValue = function(index, data, keyVal, ele)
{
	return this.colorArr[index](data[keyVal], this.maskArr[index], this.basePrice, ele);
};

EXFiveHogaGrid.prototype.setData = function(dataArr)
{

};

EXFiveHogaGrid.prototype.setQueryData = function(dataArr, keyArr, queryData)
{
	if(!keyArr) return;
	
	var data = dataArr[0], row, keyName, inx = 0, value = 0, maxQty = 0;
	
	if(data[this.curPriceKey]) this.setCurrentPrice(data[this.curPriceKey]);
	
	var dataKeyGrp = this.realMap[data.key];
	
	//리얼 쿼리일 경우
	if(queryData.isReal)
	{
		if(!dataKeyGrp) return;
		
		var ret, realCell;//, dataKeyGrp = this.realMap[data.key];
		
		for(var i = 0; i < this.rowLen; i++)
		{
			row = this.getRow(i);
			
			for(var j=0; j < this.colLen; j++)
			{
				if( this.getCell(row,j).getAttribute('data-span')) continue;
				
				keyName = keyArr[inx++];		
				if(!keyName) continue;
				
				//리얼맵에 등록되지 않은 keyName인 경우 다른 Query이므로 리턴
				//if(!this.realMap[data.key] || !this.realMap[data.key][keyName]) return;
				
				value = data[keyName];
				
				if(value!=undefined)	//data[keyName] != undefined
				{
					if(j!=1) this.remainValArr[i][j] = value;
					
					realCell = dataKeyGrp[keyName];
					if(!realCell) continue;
					
					ret = this.getMaskValue(j, data, keyName, realCell );
					if(ret) realCell.textContent = ret;

/*
					if( value!=0 )//  parseFloat(data[keyName]).toFixed(2) != 0.00 )
					{
						//realCell.html(this.getMaskValue(j, data, keyName));
						ret = this.getMaskValue(j, data, keyName, realCell );
						//if(ret) realCell.innerHTML = ret;
						if(ret) realCell.textContent = ret;
					}
					else
					{
						//realCell.textContent = '　';
						$(realCell).text('　');
						if(j!=1) realCell.style.setProperty("background-size", '0% 7px', 'important');
					}
*/					
				}
				
				//max value 구하기
				if(j!=1)
				{
					value = this.remainValArr[i][j];
					if(value > maxQty) maxQty = value;
				}
			}
		}
	}
	
	//조회 쿼리일 경우
	else
	{
		this.keyLen = keyArr.length - this.btmCellCnt;
		
		this.curPriceMap = new Array();
		
		this.realMap[data.key] = dataKeyGrp = {};
		
		var mapCell; 
		for(var i = 0; i < this.rowLen; i++)
		{
			row = this.getRow(i);
			for(var j=0; j < this.colLen; j++)
			{
				if(this.getCell(i,j).getAttribute('data-span')) continue;
				keyName = keyArr[inx++];
				
				if(!keyName) continue;
				
				//mapCell = $(this.getCell(row, j));
				mapCell = this.getCell(row, j);
				
				//리얼맵 셋팅
				//if(this.realMap) dataKeyGrp[keyName] = mapCell;
				dataKeyGrp[keyName] = mapCell;
				
				mapCell.innerHTML = this.getMaskValue(j, data, keyName);//mapCell.html(this.getMaskValue(j, data, keyName));
				
				if(j!=1) 
				{
					value = data[keyName];
					this.remainValArr[i][j] = value;
					if(value > maxQty) maxQty = value;
				}
				
				//소수점 데이터인 경우 0.00 으로 들어와서 화면에 표시되어 체크
				/*
				if(data[keyName]!=0) mapCell.innerHTML = this.getMaskValue(j, data, keyName);//mapCell.html(this.getMaskValue(j, data, keyName));
				else
				{
					mapCell.textContent = '　';
					if(j!=1) mapCell.style.setProperty("background-size", '0% 7px', 'important'); 
					//mapCell.text('　');
					//if(j!=1) mapCell[0].style.setProperty("background-size", '0% 7px', 'important');
				}
				*/
			}
		}
		
		//현재가를 그리기위한 셀셋팅
		this.curPriceMap = 
			[
			$(this.getCell(this.rowLen/2-1, 1)),	//9  or 4
			$(this.getCell(this.rowLen/2,   1)),	//10 or 5 
			$(this.getCell(this.rowLen/2-2, 1)),	//8  or 3
			$(this.getCell(this.rowLen/2+1, 1)),	//11 or 6
			$(this.getCell(this.rowLen/2-3, 1)),	//7  or 2
			$(this.getCell(this.rowLen/2+2, 1))		//12 or 7
		];
	}
	
	this.selectCurrentPrice();
	
	
	//------------------------------------------
	//	잔량 그리는 로직 성능 개선하기 
	//------------------------------------------
	
	/*
	if(!maxQty)
	{
		inx = -1;
		for(var j = 0; j < this.rowLen; j++)
		{
			row = this.getRow(j);
			for(var k = 0; k < this.colLen; k++)
			{
				if( this.getCell(row, k).getAttribute('data-span')) continue;
				
				inx++;
				if(k==1) continue;
				
				keyName = keyArr[inx];
				if(!keyName) continue;
				
				value = parseInt(afc.removeComma(this.realMap[data.key][keyName].textContent), 10);
				if(value > maxQty) maxQty = value;
			}
		}
	}
	*/
	
	inx=-1;
	for(var j = 0; j<this.rowLen; j++)
	{
		row = this.getRow(j);
		for(var k = 0; k<this.colLen; k++)
		{
			if(this.getCell(row, k).getAttribute('data-span')) continue;
			
			inx++;
			if(k==1) continue;
			
			keyName = keyArr[inx];
			if(!keyName) continue;
			
			//value = data[keyName];
			
			value = this.remainValArr[j][k];
			//if(!value) value = parseInt(afc.removeComma(this.realMap[data.key][keyName].textContent),10);
			//if(value)
			//{
				dataKeyGrp[keyName].style.setProperty("background-size", parseInt(value/maxQty*100, 10)+'% 7px', 'important');
			//}
		}
	}
};
/*
EXFiveHogaGrid.prototype.ctrtQueryData = function(dataArr, keyArr, queryData)
{	
	if(!keyArr) return;
	
	var data = dataArr[0], row, keyName, inx = 0, value = 0, maxQty = 0, realCell, tag;
	
	if(data['D1현재가']) this.setCurrentPrice(data['D1현재가']*1);
	
	//리얼 쿼리일 경우
	if(this.isRealMode)
	{
		inx = 0, value = 0;
		
		for(var i = 0; i < this.rowLen; i++)
		{
			for(var j=0; j < this.colLen; j++)
			{
				if($(this.getCell(i,j)).attr('data-span')) continue;
				keyName = keyArr[inx++];		
				if(!keyName) continue;
				
				//리얼맵에 등록되지 않은 keyName인 경우 다른 Query이므로 리턴
				if(!this.realMap[data.key] || !this.realMap[data.key][keyName]) return;
				
				value = data[keyName];
				if(value)
				{
					realCell = this.realMap[data.key][keyName];
					realCell.html(this.colorArr[j](value, this.maskArr[j], this.basePrice));
				}
			}
		}
	}
	//조회 쿼리일 경우
	else
	{
		this.keyLen = keyArr.length - this.btmCellCnt;
		inx = 0, value = 0, maxQty = 0;
		
		this.curPriceMap = new Array();
		
		if(this.realMap) 
		{
			this.isRealMode = true;
			this.realMap[data.key] = {};
		}
		
		var mapCell; 
		for(var i = 0; i < this.rowLen; i++)
		{
			row = this.getRow(i);
			for(var j=0; j < this.colLen; j++)
			{
				if($(this.getCell(i,j)).attr('data-span')) continue;
				keyName = keyArr[inx++];
				
				if(!keyName) continue;
				
				mapCell = $(this.getCell(row, j));
				
				//리얼맵 셋팅
				if(this.realMap) this.realMap[data.key][keyName] = mapCell;
				
				value = data[keyName];
				if(value) mapCell.html(this.colorArr[j](value, this.maskArr[j], this.basePrice));
			}
		}
		
		//현재가를 그리기위한 셀셋팅
		this.curPriceMap = 
			[
			$(this.getCell(this.rowLen/2-1, 1)),	//9  or 4
			$(this.getCell(this.rowLen/2,   1)),	//10 or 5 
			$(this.getCell(this.rowLen/2-2, 1)),	//8  or 3
			$(this.getCell(this.rowLen/2+1, 1)),	//11 or 6
			$(this.getCell(this.rowLen/2-3, 1)),	//7  or 2
			$(this.getCell(this.rowLen/2+2, 1))		//12 or 7
		];
		
	}
	
	this.selectCurrentPrice();
	
	if(!maxQty)
	{
		inx = -1;
		for(var j = 0; j < this.rowLen; j++)
		{
			for(var k = 0; k < this.colLen; k++)
			{
				if($(this.getCell(j, k)).attr('data-span')) continue;
				inx++;
				if(k==1) continue;
				keyName = keyArr[inx];
				if(!keyName) continue;
				
				value = parseInt(afc.removeComma(this.realMap[data.key][keyName].text()), 10);
				if(value > maxQty) maxQty = value;
			}
		}
	}
	
	inx=-1;
	for(var j = 0; j<this.rowLen; j++)
	{
		for(var k = 0; k<this.colLen; k++)
		{
			if($(this.getCell(j, k)).attr('data-span')) continue;
			inx++;
			if(k==1) continue;
			
			keyName = keyArr[inx];
			if(!keyName) continue;
			value = data[keyName];
			if(!value) value = parseInt(afc.removeComma(this.realMap[data.key][keyName].text()),10);
			if(value)
			{
				this.realMap[data.key][keyName][0].style.setProperty("background-size", parseInt(value/maxQty*100, 10)+'% 7px', 'important');
			}
		}
	}
};
*/
                    
//window.EXFiveHogaGrid = EXFiveHogaGrid;
                    
})();