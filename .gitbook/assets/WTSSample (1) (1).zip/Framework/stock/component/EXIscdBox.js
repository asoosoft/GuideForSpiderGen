
(async function(){

await afc.import("Framework/afc/component/ADropBox.js");


/**
 * @author kyun
 */

EXIscdBox = class EXIscdBox extends ADropBox
{
    constructor()
    {
        super();

        this.frwName = 'stock';
    	this.filterType = 0;
    }
}

//window.EXIscdBox = EXIscdBox;

EXIscdBox.J = 'J';
EXIscdBox.JW = 'JW';
EXIscdBox.FO = 'FO';
EXIscdBox.U = 'U';
EXIscdBox.CME = 'CME';

EXIscdBox.MAXLEN = 10;

//필터된 종목컴포넌트에서 히스토리에 추가가 가능한 시장구분코드맵 
EXIscdBox.FILTERMKCDMAP = 
{
	'J': {'J': 1},
	'JW': {'J': 1, 'W': 1},
	'FO': {'F': 1, 'O': 1, 'JF': 1},
	'U': {'U': 1},
	'CME': {'TF': 1}
};


//종목히스토리에 종목코드가 없을경우 셋팅할 디폴트 종목코드 값
EXIscdBox.DEFAULTISCD = 
{
	'JW': '001720',	//신영증권
	'FO': '',		//근월몰
	'U': '0001',	//종합
	'CME': ''		//근월몰
};

//앱 실행 후 선택한 종목 히스토리 배열
EXIscdBox.HISTORY = 
{
	'JW': [],
	'FO': [],
	'U': [],
	'CME': []
};

//맨 마지막에 선택한 종목 코드
EXIscdBox.LASTISCD =
{
	'JW': '',
	'FO': '',
	'U': '',
	'CME': ''
};

EXIscdBox.prototype.init = function(context, evtListener)
{
	ADropBox.prototype.init.call(this, context, evtListener);
};

//iscd박스 필터 셋팅
EXIscdBox.prototype.setIscdFilterType = function(filterType)
{
	this.filterType = filterType;
	
	if(this.filterType == EXIscdBox.J) this.items = EXIscdBox.HISTORY[EXIscdBox.JW];
	else this.items = EXIscdBox.HISTORY[this.filterType];
	
};

EXIscdBox.prototype.getIscdFilterType = function()
{
	return this.filterType;
};


EXIscdBox.prototype.addIscdItem = function(text, data)
{

	var item = {'text':text, 'data':data};
	
	//기존에 ISCD가 있으면 삭제하고 상단에 등록
	this.removeExistIscd(data.iscd);
	this.items.unshift(item);
	if(this.items.length >= EXIscdBox.MAXLEN) this.items.length = EXIscdBox.MAXLEN;
	
	//히스토리 10개 유지가 필요한 경우 주석해제
	//localStorage.setItem('LastHistory', JSON.stringify(EXIscdBox.HISTORY));
	
};

//기존에 iscd가 있으면 삭제
EXIscdBox.prototype.removeExistIscd = function(iscd)
{
	var recentOneData = null;
	for(var i = this.items.length - 1; i >=0 ; i--)
	{
		recentOneData = this.items[i];
		if(recentOneData.data)
		{
			if(recentOneData.data.iscd == iscd)
				this.items.splice(i, 1);	
		}
	}
};

//iscd가져오기
EXIscdBox.prototype.getIscd = function()
{
	return this.getSelectedItemData().iscd;
};

//mkcd가져오기
EXIscdBox.prototype.getMkcd = function()
{
	return this.getSelectedItemData().mkcd;
};

//iscd박스에서 iscd 셋팅하기
EXIscdBox.prototype.selectItemByIscd = function(iscd)
{
	
	var filTypeStr = EXIscdBox.JW;
	if(this.filterType == EXIscdBox.J) filTypeStr = EXIscdBox.JW;
	else filTypeStr = this.filterType;
	
	var lastIscd = EXIscdBox.LASTISCD[filTypeStr];
	
	if(!iscd)
	{
		//iscd가 널일경우 최근 사용한 값을 셋팅
		if(EXIscdBox.LASTISCD[filTypeStr])
		{
			if(this.filterType == EXIscdBox.J)
			{
				if(theApp.master.getMarketDiv(lastIscd) != 'J')
				{
					var firstJidx = this.findFirstIscdIdxByMkcd(EXIscdBox.J);
					if(firstJidx > -1)
					{
						this.selectItem(firstJidx);
						return;
					}
					else iscd = EXIscdBox.DEFAULTISCD[EXIscdBox.JW];
				}
				else iscd = lastIscd;
			}
			else iscd = lastIscd;
		}
		//최근 사용한 값이 없을 경우 defaultIscd에 셋팅된 값 표시
		else iscd = EXIscdBox.DEFAULTISCD[filTypeStr];
	}
	
	var mkcdIdx = -1;
	var iscdIdx = this.indexOfIscd(iscd);
	if(iscdIdx > -1) this.selectItem(iscdIdx);
	else
	{	
		var resultData = theApp.master.getIscdData(iscd);
		if(!resultData)
		{
			iscd = EXIscdBox.DEFAULTISCD[filTypeStr];
			resultData = theApp.master.getIscdData(iscd);
		}
		
		//셋팅하려는 종목코드의 마켓정보가 현재종목컨트롤의 필터 마켓정보와 동일하면 추가
		var mkcdIdx = theApp.master.getMarketInx(iscd);
		if(EXIscdBox.FILTERMKCDMAP[this.filterType][Master.MARKET[mkcdIdx]])
			this.addIscdItem(resultData[0], { 'iscd': iscd, 'mkcd': Master.MARKET[mkcdIdx] });
		
		this.selectItem(0);
	}
	
};

//iscd박스에서 iscd선택하면 EXIscdBox.LASTISCD에 저장
EXIscdBox.prototype.selectItem = function(index)
{
	var selItem = this.items[index];
	if(selItem.data)
	{
		var filTypeStr = EXIscdBox.JW;
		if(this.filterType == EXIscdBox.J) filTypeStr = EXIscdBox.JW;
		else filTypeStr = this.filterType;
		
		EXIscdBox.LASTISCD[filTypeStr] = selItem.data.iscd;	
		localStorage.setItem('LastIscd', JSON.stringify(EXIscdBox.LASTISCD));
	}
	ADropBox.prototype.selectItem.call(this, index);
};

//mkcd를 넘겨서 가장 첫번째 아이템 idx 가져오기
EXIscdBox.prototype.findFirstIscdIdxByMkcd = function(mkcd)
{

	for(var i=0; i<this.items.length; i++)
	{
		if(this.items[i].data)
		{
			if(this.items[i].data.mkcd == mkcd) return i;
		}
		else continue;
	}
	return -1;
};

//iscd를 넘겨서 해당 아이템 idx 가져오기
EXIscdBox.prototype.indexOfIscd = function(iscd)
{
	for(var i=0; i<this.items.length; i++)
	{
		if(this.items[i].data)
		{
			if(this.items[i].data.iscd == iscd) return i;
		}
		else continue;
	}
	return -1;
};

EXIscdBox.prototype.bindData = function(ulObj)
{
	var thisObj = this;
	
	$.each(this.items, function(i, v){
		
		if(thisObj.filterType == EXIscdBox.J)
		{
			if(v.data.mkcd == 'W') return true;
		}

		var liObjStr = '<li class="dropboxCell" style="width:' + $(thisObj.element).width() + 'px;"><span style="margin:10px;">'+v.text+'</sapn>';
		
		/*  코드와 값을 같이 보여줘야 할경우 셋팅
        if(this.showCode)
        {
            liObjStr +=  '<span style="position:absolute; right:20px;">'+dataArr[i][1]+'</sapn>';   
        }
		*/
		
        liObjStr += '</li>';
        
        var liObj = $(liObjStr);
        liObj[0].data = v;
		liObj[0].index = i;
        ulObj.append(liObj);
	
	});
        
    //EXIscdBoxEvent.implement(this, ulObj.children('li'));
    
    if(this.isEventApply) 
    	EXIscdBoxEvent.select(this, ulObj.children('li'));
};

EXIscdBox.prototype.setData = function(dataArr)
{
};

EXIscdBox.prototype.setQueryData = function(dataArr, keyArr)
{
	if(!keyArr) return;
};

EXIscdBox.prototype.getQueryData = function(dataArr, keyArr)//, queryName)
{
	if(!keyArr) return;
	
    var itemData = this.getSelectedItemData();  //종목박스에 선택된 값
    var inBlockData = dataArr[0];               //InBlock JSON
	
    for(var i=0; i<keyArr.length; i++)
    {
        var trKeyName = keyArr[i];
        if(trKeyName)
        {
            //조건시장분류코드 일 경우
            if(trKeyName == 'FID_COND_MRKT_DIV_CODE')
            {
                inBlockData[trKeyName] = itemData.mkcd;     
            }
            //입력 종목코드일경우
            else if(trKeyName.indexOf('ISCD') > -1)
            {
               inBlockData[trKeyName] = itemData.iscd;
            }
        }
    }
};

                    
//window.EXIscdBox = EXIscdBox;
                    
})();