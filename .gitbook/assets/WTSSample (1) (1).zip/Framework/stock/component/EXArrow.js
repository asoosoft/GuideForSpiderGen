
class EXArrow extends AComponent
{
	constructor()
    {
        super();
	
        this.frwName = 'stock';
        
        this.svgEl = null;
        this.direction = 'top';
        this.stopTagArr = null;
        this.polygonTag = null;
        this.gradientTag = null;
    }
}

window.EXArrow = EXArrow;

EXArrow.CONTEXT = 
{
    tag: '<svg data-base="EXArrow" data-class="EXArrow" data-direction="top" class="EXArrow-Style">' +
         	'<defs><linearGradient id="Linear" gradientTransform="rotate(90)">'+
                   	'<stop offset="0%" stop-color="'+StockColor.START+'" stop-opacity="1.0"></stop>'+
                   	'<stop offset="100%" stop-color="'+StockColor.END+'" stop-opacity="0.0"></stop>'+
                  '</linearGradient></defs>'+
            '<polygon points="20 0, 0 20, 10 20, 10 40, 30 40, 30 20, 40 20 " style="fill:url(#Linear);"></polygon></svg>',
        
    defStyle: 
    {
        width:'40px', height:'40px'
    },
    
    events: []
};



EXArrow.prototype.init = function(context, evtListener)
{
	AComponent.prototype.init.call(this, context, evtListener);
	
	this.svgEl = this.element;
	
	this.stopTagArr = this.svgEl.getElementsByTagName('stop');
    this.polygonTag = this.svgEl.getElementsByTagName('polygon')[0];
    this.gradientTag = this.svgEl.getElementsByTagName('linearGradient')[0];
    
    this.polygonTag.style.fill = "url(#ARW_"+this.element.id+")";
	
	
	if(this.getAttr('data-direction') == 'top')
	{
		this.setStartColor(StockColor.UP_COLOR);
		this.setEndColor(StockColor.UP_COLOR);
	}
	else
	{
		this.setStartColor(StockColor.DOWN_COLOR);
		this.setEndColor(StockColor.DOWN_COLOR);
	}
		
	this.setStartOpacity(1.0);
	this.setEndOpacity(1.0);
	
};

EXArrow.prototype.setDefsId = function()
{
    var newId = new Date().getTime();
    this.gradientTag.id = 'ARW_'+newId; 
    this.polygonTag.style.fill = "url(#"+this.gradientTag.id+")";
};

EXArrow.prototype.setColors = function(sColor, eColor, sOpacity, eOpacity)
{
    if(!eColor)
    {
        this.polygonTag.style.fill = sColor;    
    }
    else
    {
        if(!sOpacity) sOpacity = 1.0;
        if(!eOpacity) sOpacity = 1.0;
        
        this.setDefsId();
        this.stopTagArr[0].setAttribute('stop-color', sColor);
        this.stopTagArr[0].setAttribute('stop-opacity', sOpacity);
        this.stopTagArr[1].setAttribute('stop-color', eColor);
        this.stopTagArr[1].setAttribute('stop-opacity', eOpacity);    
    }
};

EXArrow.prototype.setStartColor = function(color)
{
    this.stopTagArr[0].setAttribute('stop-color', color);
};

EXArrow.prototype.getStartColor = function()
{
    return this.stopTagArr[0].getAttribute('stop-color');
};

EXArrow.prototype.setEndColor = function(color)
{
    this.stopTagArr[1].setAttribute('stop-color', color);
};

EXArrow.prototype.getEndColor = function()
{
    return this.stopTagArr[1].getAttribute('stop-color');
};

EXArrow.prototype.setStartOpacity = function(opacity)
{
    this.stopTagArr[0].setAttribute('stop-opacity', opacity);
};

EXArrow.prototype.getStartOpacity = function()
{
    return this.stopTagArr[0].getAttribute('stop-opacity');
};

EXArrow.prototype.setEndOpacity = function(opacity)
{
    this.stopTagArr[1].setAttribute('stop-opacity', opacity);    
};

EXArrow.prototype.getEndOpacity = function()
{
    return this.stopTagArr[1].getAttribute('stop-opacity');    
};

EXArrow.prototype.setDirection = function(direction)
{
    this.direction = direction;
    if(this.direction == 'left' || this.direction == 'right') this.setRotate(0);
    else this.setRotate(90);
    this.setPoints();
};

EXArrow.prototype.setRotate = function(angle)
{
    this.gradientTag.setAttribute('gradientTransform', 'rotate('+angle+')');
};

EXArrow.prototype.setPoints = function()
{
    var domW = this.svgEl.offsetWidth;
    var domH = this.svgEl.offsetHeight;
    var helfX = domW/2;
    var helfY = domH/2;
    var hhX = helfX/2; 
    var hhY = helfY/2; 
    
    if(this.direction == 'left')
    {
        this.polygonTag.setAttribute('points', '0 '+helfY+', '+helfX+' '+domH+', '+helfX+' '+(helfY+hhY)+', '+domW+' '+(helfY+hhY)+', '+domW+' '+hhY+', '+helfX+' '+hhY+', '+helfX+' 0, 0 '+helfY);  
    }
    else if(this.direction == 'top')
    {
        this.polygonTag.setAttribute('points', helfX+' 0, 0 '+helfY+', '+hhX+' '+helfY+', '+hhX+' '+domH+', '+(helfX+hhX)+' '+domH+', '+(helfX+hhX)+' '+helfY+', '+domW+' '+helfY);    
    }
    else if(this.direction == 'right')
    {
        this.polygonTag.setAttribute('points', domW+' '+helfY+', '+helfX+' 0, '+helfX+' '+hhY+', 0 '+hhY+', 0 '+(helfY+hhY)+', '+helfX+' '+(helfY+hhY)+', '+helfX+' '+domH+', '+domW+' '+helfY);
    }
    else if(this.direction == 'bottom')
    {
        this.polygonTag.setAttribute('points', helfX+' '+domH+', '+domW+' '+helfY+', '+(helfX+hhX)+' '+helfY+', '+(helfX+hhX)+' 0, '+hhX+' 0, '+hhX+' '+helfY+', 0 '+helfY+', '+helfX+' '+domH);        
    }
};
