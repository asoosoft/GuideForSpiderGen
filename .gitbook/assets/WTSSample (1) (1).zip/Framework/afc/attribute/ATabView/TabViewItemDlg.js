

TabViewItemDlg = class TabViewItemDlg extends AView
{
    constructor()
    {
        super()
		
	
		//TODO:edit here
		
		this.prjLoc = '';
		this.isToolTipShow = false;
	

    }
}



TabViewItemDlg.prototype.init = function(context, evtListener)
{
	AView.prototype.init.call(this, context, evtListener);

	this.toolTip = new ATooltip();
	this.toolTip.init();

	const data = this.getContainer().getData();
	if(data) this.settingTextByData(data.id, data.name, data.url);
};

TabViewItemDlg.prototype.onWillDeactive = function()
{
	this.toolTip.hide();	
};

TabViewItemDlg.prototype.settingTextByData = function(id, name, url)
{
	this.idTxf.setText(id);
	this.nameTxf.setText(name);
	this.urlTxf.setText(url);
	
	this.idTxf.$ele.focus();
	this.idTxf.element.setSelectionRange(0, this.idTxf.getText().length);
	
};

TabViewItemDlg.prototype.onOKBtnClick = function(comp, info)
{
	var id = $.trim(this.idTxf.getText());
	var name = $.trim(this.nameTxf.getText());
	var url = $.trim(this.urlTxf.getText());

	if(id && name && url) 
	{
		this.getContainer().close(0, { 'id': id, 'name':name , 'url' : url});
	}
	else
	{
		if(!this.isToolTipShow){
			this.isToolTipShow = true;
			this.toolTip.show('3가지 항목을 모두 입력해 주세요.', comp.getBoundRect());
		}
	}
	
	return true;
};

TabViewItemDlg.prototype.onCancelBtnClick = function(comp, info)
{
	this.getContainer().close(1);
};
