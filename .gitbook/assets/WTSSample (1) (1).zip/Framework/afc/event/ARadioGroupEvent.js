
 


class ARadioGroupEvent extends AViewEvent
{
	constructor(acomp)
	{
		super(acomp);
	}
}
window.ARadioGroupEvent = ARadioGroupEvent;



//---------------------------------------------------------------------------------------------------
//	Component Event Functions





//---------------------------------------------------------------------------------------------------

