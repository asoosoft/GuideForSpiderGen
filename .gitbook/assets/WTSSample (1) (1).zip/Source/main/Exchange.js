
Exchange = class Exchange extends AView
{
	constructor()
	{
		super()

		//TODO:edit here

	}

	init(context, evtListener)
	{
		super.init(context, evtListener)

        
        this.itemInfoView.loadContainer('Source/view/ItemInfoView.lay', 'ItemInfoView').then(cntr => {
            this.itemInfoView = cntr.getView();
            theApp.setItemInfoView(this.itemInfoView);
        })
        this.itemListView.loadContainer('Source/view/ItemListView.lay', 'ItemListView')
        this.chartView.loadContainer('Source/view/ChartView.lay', 'ChartView')
        this.hogaView.loadContainer('Source/view/HogaView.lay', 'HogaView')
        this.orderView.loadContainer('Source/view/OrderView.lay', 'OrderView')
        this.cnclView.loadContainer('Source/view/CnclView.lay', 'CnclView')

	}

	onInitDone()
	{
		super.onInitDone()

		//TODO:edit here

	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)

		//TODO:edit here

	}

}

