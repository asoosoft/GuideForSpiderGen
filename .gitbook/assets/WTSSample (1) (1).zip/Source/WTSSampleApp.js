
WTSSampleApp = class WTSSampleApp extends AApplication
{
	constructor()
	{
		super()

        this.listenerArr = [];
		this.mainFrameType = 1; //0: Container Split 1: View Split
        this.useQuerySystem = true;

        if(!this.useQuerySystem) {
            this.realFuncObj = {};
            this.realDataObj = {};
            this.textDecoder = new TextDecoder();
        }
	}

	onReady()
	{
		super.onReady();

        //this.displayMainPage();
        //서버와 연결 후에 displayMainPage 처리
        this.initRestServer();
        this.connectSocketServer();
	}

    sendAPI(url, params)
    {
        //파라미터가 있는 경우 query string 형태로 만들어준다.
        let paramStr = '';
        if(params) {
            paramStr = '?';
            for(let key in params) {
                if(paramStr.length > 1) paramStr += '&';
                paramStr += `${key}=${params[key]}`;
            }
        }

        return new Promise((resolve, reject) => {
            fetch(`${Define.SERVER_ADDR_REST}${url}${paramStr}`).then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            }).then(data => {
                resolve(data);
            }).catch(error => {
                console.error('api error', error);
                reject(error);
            });
        })
    }

    unregReal(name, codeArr, listener)
    {
        //Query 시스템을 사용하는 경우 리턴처리
        if(theApp.useQuerySystem) return;

        let obj = this.realFuncObj[name];
        if(obj) {
            let idx;
            codeArr.forEach(code => {
                if(!obj[code]) return;
                idx = obj[code].indexOf(listener);
                if(idx > -1) obj[code].splice(idx, 1);
            })
        }
    }

    //sendType 1: RQ&RP 2: REAL 3: 1,2 둘다(default: 3)
    sendTran(name, codeArr, listener, sendType)
    {
        //Query 시스템을 사용하는 경우 리턴처리
        if(theApp.useQuerySystem) return

        if(!codeArr.length) return
        if(sendType == undefined) sendType = 3

        let obj = this.realFuncObj[name],
            codeArrForSend = codeArr.slice(),
            codeArrForReal = []

        if(sendType != 1) {
            codeArrForReal = codeArr.slice()
            if(!obj) {
                obj = this.realFuncObj[name] = {}
                this.realDataObj[name] = {}
            } else if(sendType == 2) {
                let code
                for(let i=codeArrForReal.length; i>-1; i--) {
                    code = codeArrForReal[i]
                    if(obj[code]) {
                        if(obj[code].indexOf(listener)<0) obj[code].push(listener)
                        listener.onReceived(this.realDataObj[name][code])
                        codeArrForReal.splice(i, 1)
                    }
                }
                //등록할 리얼이 없다면 전송하지 않는다.
                if(!codeArrForReal.length) return
            }
        }

        const sendArr = []
        sendArr.push({"ticket": 'Test0_'+Date.now()})
        //조회 요청하는 항목이 있는 경우
        if(sendType&1) {
            sendArr.push({
                type: name,
                codes: codeArrForSend,
                is_only_snapshot: sendType==1,
            })
        }

        let realCodeArr = Object.keys(obj)
        if(sendType==2) realCodeArr = realCodeArr.concat(codeArrForReal)
        else if(sendType==3) {
            //조회+리얼 인 종목 제거 후 실시간만 요청할 목록
            for(let i=realCodeArr.length-1; i>-1; i--) {
                if(codeArrForSend.indexOf(realCodeArr[i]) > -1) realCodeArr.splice(i,1)
            }
        }

        if(realCodeArr.length) {
            //이전까지 실시간 데이터 요청했던 종목 포함하여 다시 전달
            for(let trName in this.realFuncObj) {
                sendArr.push({
                    type: trName,
                    codes: trName==name?realCodeArr:Object.keys(this.realFuncObj[trName]),
                    is_only_realtime: true
                })
            }
        }
        sendArr.push({format: "SIMPLE"})
        
        theApp.nio.sendData(JSON.stringify(sendArr), function(e) {
            console.error('SEND FAIELD', e)
        })

        codeArr.forEach(code => {
            if(!obj[code]) obj[code] = [listener]
            else if(obj[code].indexOf(listener) < 0) obj[code].push(listener)
        })
    }

    displayMainPage()
    {
        if(!theApp.useQuerySystem) {
            //종목 전체 정보를 받아온다.
            this.sendAPI('market/all?is_details=true')
            .then(data => {
                theApp.masterArr = data;
                if(this.mainFrameType == 0) {
                    this.setMainContainer(new MainPage('main'))
                    this.mainContainer.open();
                } else {
                    this.setMainContainer(new APage('main'))
                    this.mainContainer.open('Source/MainView.lay')
                }
            })
            .catch(e => {
                
            });
        } else {
            theApp.qmRest.sendProcessByName('rest_market', null, null, queryData => {
                queryData.getBlockData('InBlock1')[0].is_details = true;
            }, queryData => {
                theApp.masterArr = queryData.getBlockData('OutBlock1');
                if(this.mainFrameType == 0) {
                    this.setMainContainer(new MainPage('main'))
                    this.mainContainer.open();
                } else {
                    this.setMainContainer(new APage('main'))
                    this.mainContainer.open('Source/MainView.lay')
                }
            });
        }
    }
    
    //업비트 rest서버 초기화
    initRestServer()
    {
        if(!theApp.useQuerySystem) return;
        this.qmRest = new RestQueryManager('REST');
		this.qmRest.setNetworkIo(new UbHttpIO(this.qmRest));
		this.qmRest.startManager(Define.SERVER_ADDR_REST);
		this.qmRest.setTimeout(Define.TIMEOUT_SEC);
    }

    //업비트 websocket 서버 초기화
    connectSocketServer()
    {
        AIndicator.beginOltp();

        if(!theApp.useQuerySystem) {
            if(!theApp.nio) theApp.nio = new WebsocketIO(this, true);
            theApp.nio.startIO(Define.SERVER_ADDR_WEBSOCKET);
        } else {
            if(!theApp.qmReal) {
                this.qmReal = new RealQueryManager();
                theApp.nio = new WebsocketIO(this.qmReal, true);
                this.qmReal.setNetworkIo(theApp.nio);
            }

            theApp.qmReal.startManager(Define.SERVER_ADDR_WEBSOCKET);
        }
    }
    
    onConnected(success)
    {
        let style = 'padding:30px; color: white; background-color: black;';
        console.log('%c-----> 소켓 연결 %s', style, success);
        
        if(success)
        {
            theApp.nio.setHeartbeat(null);
            if(!theApp.mainContainer) this.displayMainPage();
        } else {
            setTimeout(() => { theApp.connectSocketServer(); }, 3000);
        }
        
        AIndicator.endOltp();
    }

    onClosed()
    {
        let style = 'padding:30px; color: white; background-color: black;';
        console.log('%c-----> 소켓 끊어짐', style);

        setTimeout(() => { theApp.connectSocketServer(); }, 3000);
    }

    onReceived(data, size)
    {
        let msg = theApp.textDecoder.decode(new Uint8Array(data));
        msg = [JSON.parse(msg)];
        const ty = msg[0].ty, cd = msg[0].cd;
        let tmp = this.realFuncObj[ty];
        if(tmp && tmp[cd]){
            this.realDataObj[ty][cd] = msg;
            tmp[cd].forEach(listener => listener.onReceived(msg));
        }
    }

    getCoinInfo = function(code)
    {
        if(!theApp.masterArr) return;
        for(let idx in theApp.masterArr)
        {
            const info = theApp.masterArr[idx];
            if(info.market == code)
            {
                return info;
            }
        }
    }   

    getItemInfo()
    {
        if(this.itemInfoView) {
            return this.itemInfoView.getItemInfo();
        }
    }

    setItemInfoView(itemInfoView)
    {
        this.itemInfoView = itemInfoView;
        if(this.listenerArr.length) {
            this.listenerArr.forEach(listener => {
                this.itemInfoView.addItemViewListener(listener)
            })
        }
    }

    setItemInfo(itemInfo, isReport)
    {
        this.itemInfoView.setItemInfo(itemInfo, isReport)
    }
    
    addItemViewListener(listener)
    {
        if(this.itemInfoView) this.itemInfoView.addItemViewListener(listener);
        else if(this.listenerArr.indexOf(listener) < 0) this.listenerArr.push(listener);
    }

	unitTest(unitUrl)
	{
		//TODO:edit here

		this.onReady()

		super.unitTest(unitUrl)
	}

}


