
ChartView = class ChartView extends AView
{
	constructor()
	{
		super()

	}

    init(context, evtListener)
	{
		super.init(context, evtListener)

        this.cndlChart.AM_R_WIDTH = 130;
        this.cndlChart.setDelegator(this);
        theApp.addItemViewListener(this);

		this.rbMgr = new RadioBtnManager(this);
        this.subTypeDbx.addItem('거래량', CandleChart.INDICATOR_VOLUME);
        this.subTypeDbx.addItem('OBV', CandleChart.INDICATOR_OBV);
        this.subTypeDbx.addItem('MACD', CandleChart.INDICATOR_MACD);
        this.subTypeDbx.addItem('SLOW', CandleChart.INDICATOR_SLOW);
        this.subTypeDbx.addItem('FAST', CandleChart.INDICATOR_FAST);
        this.subTypeDbx.addItem('이격도', CandleChart.INDICATOR_DISPARITY);
        this.subTypeDbx.addItem('RSI', CandleChart.INDICATOR_RSI);
        this.subTypeDbx.addItem('없음', CandleChart.INDICATOR_EMPTY);
        this.subTypeDbx.selectItem(0);
	}

    onInitDone()
    {
        this.typeBtn2.reportEventDelay('click', null, 10);
    }

    onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)
		if(!isFirst) this.sendData();
	}

    onWillDeactive()
    {
        super.onWillDeactive()
        this.unregReal();
    }

    onTypeButtonClick(comp, info, e)
    {
        this.rbMgr.selectButton(comp);
	    this.sendData();
    }

    onItemViewChange(itemInfo)
    {
        this.sendData();
    }

    sendData(isMore)
    {
        //타입별 조회
        let btn = this.rbMgr.getSelectButton();
        if(!btn) return;
        var type = this.rbMgr.getSelectButton().getComponentId().replace('typeBtn', '');
        if(!isMore) {
            this.unregReal();
            this.nextKey = '';
            
            this.cndlChart.resetData();
            this.cndlChart.setPrdCls(type);
        }
    
        let itemInfo = theApp.getItemInfo();
        if(!itemInfo) return;
        this.marketCode = itemInfo[0];

        if(!theApp.useQuerySystem) {
            let name;
            switch(type) {
                case '0': name = 'candles/months'; break;
                case '1': name = 'candles/weeks'; break;
                case '2': name = 'candles/days'; break;
                case '5': name = 'candles/minutes/1'; break;
            } 
            

            let param = {market: this.marketCode, count: 200};
            if(this.nextKey) param.to = this.nextKey;
            theApp.sendAPI(name, param)
            .then(dataArr => {
                if(!dataArr.length) {
                    this.cndlChart.nextIqryDate = null;
                    return;
                }
                
                this.setChartDecimal(dataArr[0].trade_price);

                dataArr.forEach(data => {
                    data.dateStr = data.candle_date_time_kst.replace(/[^0-9]/g, '').substring(0,8);
                })

                this.cndlChart.makeChartCanvasData(dataArr, [
                    'dateStr', 'opening_price', 'high_price', 'low_price', 'trade_price', 'candle_acc_trade_volume', 'candle_acc_trade_price'
                ]);
                this.cndlChart.updateGraph();

                this.cndlChart.nextIqryDate = dataArr[dataArr.length-1].candle_date_time_utc;
                if(!isMore) {
                    theApp.sendTran('ticker', [this.marketCode], this);
                }
            });
        } else {
            let name;
            switch(type) {
                case '0': name = 'rest_months'; break;// 'candles/months'; break;
                case '1': name = 'rest_weeks'; break;// 'candles/weeks'; break;
                case '2': name = 'rest_days'; break;// 'candles/days'; break;
                case '5': name = 'rest_minutes'; break;// 'candles/minutes/1'; break;
            }
            theApp.qmRest.sendProcessByName(name, this.getContainerId(), null, queryData => {
            	var block = queryData.getBlockData('InBlock1')[0];
            	block.market = this.marketCode;
                if(this.nextKey) block.to = this.nextKey;
                block.count = 200;
            }, queryData => {
            	var blocks = queryData.getBlockData('OutBlock1');
                
                if(!blocks.length) {
                    this.cndlChart.nextIqryDate = null;
                    return;
                }

                this.setChartDecimal(blocks[0].trade_price);

                blocks.forEach(data => {
                    data.dateStr = data.candle_date_time_kst.replace(/[^0-9]/g, '').substring(0,8);
                })

                this.cndlChart.nextIqryDate = blocks[blocks.length-1].candle_date_time_utc;
                if(!isMore) {
                    theApp.qmReal.registerReal('ticker', 'cd', [this.marketCode], [this.cndlChart], 0, queryData => {
                        let data = queryData.getBlockData('OutBlock1')[0];
                        data.DummyField = new Date(data.tms).format('yyyyMMdd');
                    });
                }
            });
        }
    }
    
    callNextData(nextIqryDate)
    {
        if(nextIqryDate) {
            this.nextKey = nextIqryDate;
            this.sendData(true);
        }
    }

    onReceived(dataArr)
    {
        //let data = dataArr[0];
        this.cndlChart.setQueryData(dataArr, ['tms', 'op', 'hp', 'lp', 'tp', 'tv', 'atp24h'], {isReal: true});
    }

    unregReal()
    {
        if(!theApp.useQuerySystem) theApp.unregReal('ticker', [this.marketCode], this);
        else {
            if(this.marketCode) {
                theApp.qmReal.unregisterReal('ticker', [this.marketCode], [this.cndlChart]);
                this.marketCode = null;
            }
        }
    }

    onSubTypeDbxSelect(comp, info, e)
    {
        this.cndlChart.setSubGrpType(comp.getSelectedItemData(), true);
    }

    //가격에 정확하게 맞지는 않지만 차트 소수점처리
    setChartDecimal(tp)
    {
        if(tp > 1000) this.cndlChart.setDecimal(0);
        else {
            let i=3;
            while(tp<Math.pow(10, i)) {
                i--
            }

            this.cndlChart.setDecimal(Math.abs(i-3));
        }
    }
}

