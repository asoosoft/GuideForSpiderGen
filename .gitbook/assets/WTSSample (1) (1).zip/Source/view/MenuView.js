
MenuView = class MenuView extends AView
{
	constructor()
	{
		super()

		//TODO:edit here

	}

	init(context, evtListener)
	{
		super.init(context, evtListener)

		//TODO:edit here

	}

	onInitDone()
	{
		super.onInitDone()

		//TODO:edit here

	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)

		//TODO:edit here

	}

    firstMenuClick()
    {
        //exchange btn click 이벤트 호출
        this.exchange.reportEvent('click');
    }

	onMenuBtnClick(comp, info, e)
	{
        //mainNavi 에 등록된 화면 이동
        theApp.mainNavi.goPage(comp.getComponentId())
	}
}

