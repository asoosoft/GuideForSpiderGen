
ItemListView = class ItemListView extends AView
{
	constructor()
	{
		super()

		//TODO:edit here

	}

	init(context, evtListener)
	{
		super.init(context, evtListener)
	}

	onInitDone()
	{
		super.onInitDone()

		this.sendData();
	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)

		//TODO:edit here

	}

    //2개 이상일 경우 쉼표(,)로 구분
    getMarketList()
    {
        const marketArr = [];

        //일단 테스트로 KRW종목이면서
        for(var i=0; i<theApp.masterArr.length; i++)
        {
            if(theApp.masterArr[i].market.indexOf('KRW') > -1) marketArr.push(theApp.masterArr[i].market);
        }
        return marketArr;
    }

    sendData()
    {
        this.dgrd.setRealMap('market');
        //this.unregReal();

        this.dgrd.removeAllRowData();
        this.dgrd.setRealMap('cd');
        const cdArr = this.getMarketList()
        if(!theApp.useQuerySystem) {
            theApp.sendAPI(`ticker?markets=${cdArr.join(',')}`)
            .then(dataArr => {
                let itemInfo;
                dataArr.forEach(data => {
                    for(let key in data) {
                        data[key.replace(/(?:^|_)([a-zA-Z])[^_]*|_/g, '$1')] = data[key]
                    }
                    data.cd = data.market
                    data.row_data = data
                    data.market_korean = theApp.getCoinInfo(data.cd).korean_name;
                    data.market_name = data.cd.replace(/[\s\S]*?-/, '');
                    data.dummyField = data.market_korean + `<br/><font style="color: red;">${data.market_name}</font>`;

                    if(data.cd == 'KRW-BTC') itemInfo = [data.cd, data.market_korean];
                    theApp.qmReal.realDataObj['ticker'][data.cd] = data;
                })
                this.dgrd.setData(dataArr);

                if(!theApp.useQuerySystem) theApp.sendTran('ticker', cdArr, this, 2);
                else theApp.qmReal.registerReal('ticker', 'cd', cdArr, [this.dgrd], 0);

                if(itemInfo) theApp.itemInfoView.setItemInfo(itemInfo, true);
            })
            .catch(e => {
                
            });
        } else {
            theApp.qmRest.sendProcessByName('rest_ticker', this.getContainerId(), null, queryData => {
                let block = queryData.getBlockData('InBlock1')[0];
                block.markets = cdArr;
            }, queryData => {
                let block = queryData.getBlockData('OutBlock1');
                let itemInfo;
                block.forEach(data => {
                    data.cd = data.market
                    data.row_data = data
                    data.market_korean = theApp.getCoinInfo(data.cd).korean_name;
                    data.market_name = data.cd.replace(/[\s\S]*?-/, '');
                    data.dummyField = data.market_korean + `<br/><font style="color: red;">${data.market_name}</font>`;

                    if(data.cd == 'KRW-BTC') itemInfo = [data.cd, data.market_korean];
                })

                theApp.qmReal.registerReal('ticker', 'cd', cdArr, [this.dgrd], 0);

                if(itemInfo) theApp.itemInfoView.setItemInfo(itemInfo, true);
            });
        }
    }

    onReceived(msg)
    {
        if(this.dgrd.getGridData().length == 0) {
            msg.forEach(data => {
                data.row_data = data
                data.market_korean = theApp.getCoinInfo(data.cd).korean_name;
                data.market_name = data.cd.replace(/[\s\S]*?-/, '');
                data.dummyField = data.market_korean + `<br/><font style="color: red;">${data.market_name}</font>`;
            })
            this.dgrd.setData(msg);
        } else {
            this.dgrd.doRealPattern(msg, this.dgrd.nameKeyArr, null, 0)
        }
    }

	onDgrdSelect(comp, info, e)
	{
        const data = comp.getMetaData(comp.getSelectedRowArrs()[0])
        theApp.mainNavi.getActivePage().getView().itemInfoView.setItemInfo([data.cd, data.market_korean], true);
	}

	onTxfKeydown(comp, info, e)
	{
        if(e.which != afc.KEY_ENTER) return;

        let txt = comp.getText();
        if(this.srchTxt == txt) return;
        this.srchTxt = txt;
        this.dgrd.filter(dataArr => dataArr[0].text.indexOf(txt) > -1)
	}
}

