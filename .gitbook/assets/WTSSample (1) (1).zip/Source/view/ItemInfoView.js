
ItemInfoView = class ItemInfoView extends AView
{
	constructor()
	{
		super()

        this.listenerArr = []
	}

    init(context, evtListener)
    {
        super.init(context, evtListener)

        this.realGrp = this.findCompByGroup('realGrp');
    }

	onInitDone()
	{
		super.onInitDone()
	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)

	}

    setItemInfo(itemInfo, isReport)
    {
        this.itemView.setItemInfo(itemInfo, isReport);
    }
    
    getItemInfo()
    {
        return this.itemView.getItemInfo();
    }

    addItemViewListener(listener)
    {
        if(this.listenerArr.indexOf(listener) < 0) this.listenerArr.push(listener);
    }

    onItemViewChange(comp, info, e)
    {
        if(this.itemInfo) {
            theApp.unregReal('ticker', [this.itemInfo[0]], this);
            theApp.qmReal.unregisterReal('ticker', [this.itemInfo[0]], this.realGrp);
        }
        this.itemInfo = comp.getItemInfo();

        if(!theApp.useQuerySystem) {

            theApp.sendAPI(`ticker?markets=${this.itemInfo[0]}`)
            .then(dataArr => {
                const data = dataArr[0];
                
                for(let key in data) {
                    data[key.replace(/(?:^|_)([a-zA-Z])[^_]*|_/g, '$1')] = data[key]
                }
                    
                data.cd = data.market
                data.row_data = data
                data.market_korean = theApp.getCoinInfo(data.cd).korean_name;
                data.market_name = data.cd.replace(/[\s\S]*?-/, '');
                data.cs = data.signed_change_price>0?2:5;
                
                this.setData(data);

                theApp.sendTran('ticker', [this.itemInfo[0]], this)
            })
            .catch(e => {
                
            });
        } else {
            
            theApp.qmRest.sendProcessByName('rest_ticker', this.getContainerId(), null, queryData => {
                let block = queryData.getBlockData('InBlock1')[0];
                block.markets = this.itemInfo[0];
            }, queryData => {
                let block = queryData.getBlockData('OutBlock1');
                block.forEach(data => {
                    data.cd = data.market
                    data.market_korean = theApp.getCoinInfo(data.cd).korean_name;
                    data.market_name = data.cd.replace(/[\s\S]*?-/, '');
                    data.cs = data.signed_change_price>0?2:5;
                })

                theApp.qmReal.registerReal('ticker', 'market', [this.itemInfo[0]], this.realGrp, 0, queryData => {
                    let block = queryData.getBlockData('OutBlock1')[0];
                    block.cs = block.scp>0?2:5;
                });
            });
        }

        this.listenerArr.forEach(listener => {
            if(listener.onItemViewChange) listener.onItemViewChange();
        })
    }

    onReceived(msg)
    {
        this.setMarketData(msg[0], true);
    }

    setMarketData(data)
    {
        const coinInfo = theApp.getCoinInfo(data.cd);
        this.nameLbl.setText(coinInfo.korean_name);
        this.tri.setData(data.scp > 0?2:5);
        this.marketLbl.setText(data.cd.replace(/[\s\S]*?-/, ''));
        this.setData(data);
    }
}

