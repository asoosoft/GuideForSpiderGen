
HogaView = class HogaView extends AView
{
	constructor()
	{
		super()

	}

	init(context, evtListener)
	{
		super.init(context, evtListener)
        
        theApp.addItemViewListener(this);
	}

	onInitDone()
	{
		super.onInitDone()

	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)

	}

    onItemViewChange(itemInfo)
    {
        this.sendData();
    }

    sendData()
    {
        //기등록된 실시간 해제
        if(this.itemInfo) {
            theApp.unregReal('orderbook', [this.itemInfo[0]], this);
            theApp.qmReal.unregisterReal('orderbook', [this.itemInfo[0]], [this.hogaGrd]);
            theApp.qmReal.unregisterReal('ticker', [this.itemInfo[0]], [this.hogaGrd]);
        }

        this.itemInfo = theApp.getItemInfo();

        if(!theApp.useQuerySystem) {
            let params = {markets: this.itemInfo[0], count: 10};
            if(this.nextKey) params.cursor = this.nextKey;
            theApp.sendAPI('orderbook', params)
            .then(dataArr => {
                theApp.sendTran('orderbook', [this.itemInfo[0]], this);
                
                if(dataArr.length) {
                    this.cnclGrd.setQueryData(dataArr, ['timestamp', 'trade_price', 'trade_volume', 'ask_bid'], {});
                    this.nextKey = dataArr.length?dataArr[dataArr.length-1].sequential_id:null;
                }
            })
        } else {
            theApp.qmRest.sendProcessByName('rest_ticker', this.getContainerId(), null, queryData => {
                let block = queryData.getBlockData('InBlock1')[0]; 
                block.markets = this.itemInfo[0];
            }, queryData => {
                let block = queryData.getBlockData('OutBlock1')[0];
                this.hogaGrd.setBasePrice(block.prev_closing_price);
                this.hogaGrd.setCurrentPrice(block.trade_price);

                theApp.qmReal.registerReal('ticker', 'cd', [this.itemInfo[0]], [this.hogaGrd], 0, queryData => {
                    let block = queryData.getBlockData('OutBlock1')[0];
                    
                    this.hogaGrd.setBasePrice(block.pcp);
                    this.hogaGrd.setCurrentPrice(block.tp);
                });
            });

            theApp.qmRest.sendProcessByName('rest_orderbook', this.getContainerId(), null, queryData => {
                let block = queryData.getBlockData('InBlock1')[0]; 
                block.markets = this.itemInfo[0];
                //block.to = 091010 //09시 10분 10초
                block.count = 10;
            }, queryData => {
                let block = queryData.getBlockData('OutBlock1')[0];
                theApp.qmReal.registerReal('orderbook', 'cd', [this.itemInfo[0]], [this.hogaGrd]);
            });
        }
    }

    onReceived(dataArr)
    {
        let data = dataArr[0];
        let orderArr = data.obu;
        
        for(let key in data) {
            if(Array.isArray(data[key])) {
                data[key].forEach((d, i) => {
                    for(let field in d) {
                        data[`${field}${i}`] = d[field];
                    }
                })
                delete data[w];
            }
        }

        // for(var i=0;i<orderArr.length;i++)
        // {
        //     let item = orderArr[i];
        //     data['ap'+(i+1)] = item.ap;
        //     data['bp'+(i+1)] = item.bp;
        //     data['as'+(i+1)] = item.as;
        //     data['bs'+(i+1)] = item.bs;
        // }

        let cData = [[
            data.as10,  data.ap10,  null,
            data.as9,   data.ap9,
            data.as8,   data.ap8,
            data.as7,   data.ap7,
            data.as6,   data.ap6,
            data.as5,   data.ap5,
            data.as4,   data.ap4,
            data.as3,   data.ap3,
            data.as2,   data.ap2,
            data.as1,   data.ap1,
            null,       null,       null,
            null,       data.bp1,   data.bs1,
                        data.bp2,   data.bs2,
                        data.bp3,   data.bs3,
                        data.bp4,   data.bs4,
                        data.bp5,   data.bs5,
                        data.bp6,   data.bs6,
                        data.bp7,   data.bs7,
                        data.bp8,   data.bs8,
                        data.bp9,   data.bs9,
                        data.bp10,  data.bs10,
            data.tas,   data.tms,   data.tbs,
        ]];
        this.hogaGrd.setData(cData);
    }
}

