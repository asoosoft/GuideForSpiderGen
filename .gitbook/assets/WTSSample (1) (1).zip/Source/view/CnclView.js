
CnclView = class CnclView extends AView
{
	constructor()
	{
		super()

	}

	init(context, evtListener)
	{
		super.init(context, evtListener)
        
        theApp.addItemViewListener(this);

	}

	onInitDone()
	{
		super.onInitDone()

	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)

	}

    onItemViewChange(itemInfo)
    {
        this.sendData();
    }

    sendData(isMore)
    {
        if(!isMore) {
            if(this.itemInfo) {
                theApp.unregReal('trade', [this.itemInfo[0]], this);
                theApp.qmReal.unregisterReal('trade', [this.itemInfo[0]], [this.cnclGrd]);
            }
            this.nextKey = '';
            this.cnclGrd.removeAllRowData();
        }
        
        this.itemInfo = theApp.getItemInfo();

        if(!theApp.useQuerySystem) {
            let params = {market: this.itemInfo[0], count: 200};
            if(this.nextKey) params.cursor = this.nextKey;
            theApp.sendAPI('trades/ticks', params)
            .then(dataArr => {
                if(!isMore) theApp.sendTran('trade', [this.itemInfo[0]], this, 2);
                
                if(dataArr.length) {
                    this.cnclGrd.setQueryData(dataArr, ['timestamp', 'trade_price', 'trade_volume', 'ask_bid'], {});
                    this.nextKey = dataArr.length?dataArr[dataArr.length-1].sequential_id:null;
                }
            })
        } else {
            theApp.qmRest.sendProcessByName('rest_ticks', this.getContainerId(), null, queryData => {
                let block = queryData.getBlockData('InBlock1')[0]; 
                block.market = this.itemInfo[0];
                //block.to = 091010 //09시 10분 10초
                block.count = 200;
                if(this.nextKey) block.cursor = this.nextKey;
                //block.days_ago = 1;//이전날짜 데이터 조회 1~7 
            }, queryData => {
                let blocks = queryData.getBlockData('OutBlock1');
                this.nextKey = blocks.length?blocks[blocks.length-1].sequential_id:null;
                
                if(!isMore) theApp.qmReal.registerReal('trade', 'cd', [this.itemInfo[0]], [this.cnclGrd], -1);
            });
        }
    }

    onReceived(dataArr)
    {
        this.cnclGrd.setQueryData(dataArr, ['tms', 'tp', 'tv', 'ab'], {isReal: true, getRealType:function(){return -1;}})
    }

	onCnclGrdScrollbottom(comp, info, e)
	{
        if(this.nextKey) this.sendData(true);
	}
}

