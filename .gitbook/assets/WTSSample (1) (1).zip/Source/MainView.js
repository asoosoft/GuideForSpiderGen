
MainView = class MainView extends AView
{
	constructor()
	{
		super()

		//TODO:edit here

	}

init(context, evtListener)
{
    super.init(context, evtListener)

    this.menuView.awaitLoadView().then(view => {
        theApp.menuView = view;
        view.firstMenuClick();
    })

    this.naviView.loadContainer().then(cntr => {
        let navi = new ANavigator('mainNavi', cntr)
        navi.registerPage('Source/main/Exchange.lay', 'exchange')
        navi.registerPage('Source/main/Investment.lay', 'investment')
        navi.registerPage('Source/main/Transactions.lay', 'transactions')
        navi.registerPage('Source/main/News.lay', 'news')
        navi.registerPage('Source/main/CustomerCenter.lay', 'customerCenter')
        theApp.mainNavi = navi
    })
}

	onInitDone()
	{
		super.onInitDone()

		//TODO:edit here

	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)

		//TODO:edit here

	}

}

