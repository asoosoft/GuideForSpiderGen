/**
Constructor
*/
RestQueryManager = class RestQueryManager extends QueryManager
{
	constructor(name)
	{
		super(name)

		this.addQueryListener(this);
	}

	onReceived(dataArr, dataLen)
	{
        //check
        let arrKeyArr = [];
        for(let key in dataArr[0]) {
            if(Array.isArray(dataArr[0][key])) {
                arrKeyArr.push(key);
            }
        }
        if(arrKeyArr.length) {
            dataArr.forEach(data => {
                arrKeyArr.forEach(key => {
                    data[key].forEach((d, i) => {
                        for(let field in d) {
                            data[`${field}${i+1}`] = d[field];
                        }
                    })
                    delete data[key];
                });
            })
        }

		this.queryProcess({body: {OutBlock1: dataArr}});
	}

	//특이사항(서버변경불가이슈)
	//실제로 서버에 보낼때는 헤더에 들어가는 정보중 몇가지(연속키 cont_key 등)는
	//헤더에 안들어가고 body.option에 들어가야함. 혼동이 있을수있어서 화면 개발자들은 
	//모두 헤더에 넣도록 하고 옵션으로 변환시킴
	makeHeader(queryData, sendObj, menuNo)
	{
		const packetId = this.makePacketId();
		const tr_name = queryData.getQueryName();
        const contKey = queryData.getContiKey();
		 //헤더 세팅
		sendObj.header = 
		{
			...this.headerInfo,
			...queryData.headerInfo,
            tr_name : tr_name,
            packetId : packetId,
            contKey: contKey,
            url: queryData.getQuery().getValue('url')
		};
		
		return packetId;
	}
	
	// makeQueryData(aquery, isSend)
	// {
	// 	return new RestQueryData(aquery, isSend);
	// }
	
	sendByType(obj)
	{
        //JSON.stringify 한 데이터를 전달하지 않게 수정
		this.sendBufferData(obj.sendObj);
	}

	//에러세팅
	setErrorData(recvObj)
	{
		this.errorData.errCode = recvObj.code;
		this.errorData.errMsg = recvObj.message;
	}

	//정상적인 에러코드가 아닌 통신 장애
	onError(packetId, errorObj)
	{
		AIndicator.endOltp();
		console.log(errorObj.code +', '+errorObj.error);
	}
}