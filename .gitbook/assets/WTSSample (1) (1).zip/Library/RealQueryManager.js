
RealQueryManager = class RealQueryManager extends QueryManager
{
    constructor(name)
    {
        super(name)

        this.addQueryListener(this);
        this.textDecoder = new TextDecoder();
    }

    onReceived(data)
    {
        let msg = this.textDecoder.decode(new Uint8Array(data));
        let cloneMsg = JSON.parse(msg);
        msg = JSON.parse(msg);

        if(msg.error) {
            console.error(msg.error);
            return;
        }

        if(msg.st == 'SNAPSHOT') this.queryProcess({body:{OutBlock1:[msg]}});
        else this.realProcess(msg);
    }

    //	onReceive 함수 내에서 패킷 타입에 따라 분기하여 호출되는 함수
    async realProcess(recvObj)
    {
        if(recvObj.error)
        {
            console.error(recvObj.error);
            return;
        }

        var qryName = recvObj.ty,
            aquery = await AQuery.getSafeQuery(qryName), 
            queryData = null;
        
        queryData = this.makeQueryData(aquery);

        for(let key in recvObj) {
            if(Array.isArray(recvObj[key])) {
                recvObj[key].forEach((data, i) => {
                    for(let field in data) {
                        recvObj[`${field}${i}`] = data[field];
                    }
                })
                delete recvObj[key];
            }
        }

        if(recvObj[""]) debugger;

        queryData.outBlockData({body:{OutBlock1:[recvObj]}});
        this.realDataToComp(recvObj.cd, queryData);
        
        if(recvObj[""]) debugger;
    }

    // makeQueryData(aquery, isSend)
    // {
    // 	return new RealQueryData(aquery, isSend);
    // }

    onConnected(success)
    {
        theApp.onConnected(success);
    }

    onClosed()
    {
        AIndicator.hide();

        theApp.onClosed();
    }

    /**
     * 업비트 리얼데이터는 등록,해제 방식이 아님.
     * 리얼 요청 앞뒤로 티켓필드와 포맷필드가 필요.
     * [{Ticket Field},{Type Field},....,{Type Field},{Format Field}]
     * 
     * 요청을 보내면 이전에 요청중이던 모든것이 날라가버리므로
     * 기존에 요청했던 항목들을 가지고 있다가 갱신해줘야한다.
     * 
     * 참고로 모두다 해제는 Type Field가 없으면 된다.
     * [{Ticket Field},{Format Field}]
     */

    async registerReal()
    {
        if(!theApp.useQuerySystem) return;
        
        await super.registerReal.apply(this, arguments);
    }

    sendRealSet(aquery, isSet, regArr)
    {
        const qryName = aquery.getName();
        const sendArr = [];
        sendArr.push(this.getTicket());
        
        if(isSet)
        {
            if(!this.realTypeMap[qryName]) this.realTypeMap[qryName] = [];

            regArr.forEach(item => {
                if(!this.realTypeMap[qryName].includes(item)) {
                    this.realTypeMap[qryName].push(item);
                }
            });
        }
        else
        {
            this.realTypeMap[qryName] = this.realTypeMap[qryName].filter(item => !regArr.includes(item));
            //일단 해제는 전송은 안함. 등록할때 갱신됨 어차피 
            return;
        }

        const typeArr = this.makeRealType();
        if(typeArr.length > 0) sendArr.push(...this.makeRealType());
        sendArr.push({ "format": "SIMPLE" });

        console.log(sendArr);
        this.sendBufferData(JSON.stringify(sendArr));
    }

    makeTicket()
    {
        this.ticket = 'spider_'+new Date().getTime();
        this.realTypeMap = {};
    }

    makeRealType()
    {
        const arr = [];

        for(let qryName in this.realTypeMap)
        {
            if(!this.realTypeMap[qryName] || this.realTypeMap[qryName].length == 0) continue;
            arr.push({
                "type" : qryName,
                "codes" : this.realTypeMap[qryName],
                "isOnlyRealtime" : true
            });
        }

        return arr;
    }

    getTicket()
    {
        if(!this.ticket) this.makeTicket();

        //return {"ticket":this.ticket}
        return {"ticket":this.ticket+'_'+ this.makePacketId()}
    }

    sendByType(obj)
    {
        this.sendBufferData(JSON.stringify(obj.sendObj.sendArr));
    }
}

