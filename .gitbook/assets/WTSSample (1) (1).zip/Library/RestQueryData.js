/**
Constructor
*/
RestQueryData = class RestQueryData extends AQueryData
{
	constructor(aquery)
	{
		super(aquery)
	
	}
	
	outBlockData(abuf, offset)
	{   
        if(!abuf) abuf = [];

        for(let key in data) {
            data[key.replace(/(?:^|_)([a-zA-Z])[^_]*|_/g, '$1')] = data[key]
        }

        const queryName = this.aquery.getName();
        if(queryName == 'UBREST05')
        {
            this.convertHogaData(abuf);
        }

        let obj = {
            OutBlock1 : abuf
        }

		this.setQueryObj(obj);
	}

    convertHogaData(outblock)
    {
        /*
            ["매도호가1","ask_price1","","","String","10","4"],
            ["매수호가1","bid_price1","","","String","10","4"],
            ["매도 잔량1","ask_size1","","","String","10","4"],
            ["매수 잔량1","bid_size1","","","String","10","4"],

        */
        let orderArr = outblock[0].orderbook_units;
        for(var i=0;i<orderArr.length;i++)
        {
            let item = orderArr[i];
            outblock[0]['ask_price'+(i+1)] = item.ask_price;
            outblock[0]['bid_price'+(i+1)] = item.bid_price;
            outblock[0]['ask_size'+(i+1)] = item.ask_size;
            outblock[0]['bid_size'+(i+1)] = item.bid_size;
        }
    }
}