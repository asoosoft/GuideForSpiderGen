
MainPage = class MainPage extends APage
{
	constructor(containerId)
	{
		super(containerId)

		//TODO:edit here

	}

	init(context)
	{
		super.init(context)

		//TODO:edit here

	}

	onCreate()
	{
		super.onCreate()
        
        let cntrArr = this.createSplit(3, [120, -1, 120], 'column')
        cntrArr[0].setView('Source/view/MenuView.lay').then(view => {
            theApp.menuView = view;
            view.firstMenuClick();
        })
        cntrArr[2].setView('Source/view/StatusView.lay')
        
        let navi = new ANavigator('mainNavi', cntrArr[1])
        navi.registerPage('Source/main/Exchange.lay', 'exchange')
        navi.registerPage('Source/main/Investment.lay', 'investment')
        navi.registerPage('Source/main/Transactions.lay', 'transactions')
        navi.registerPage('Source/main/News.lay', 'news')
        navi.registerPage('Source/main/CustomerCenter.lay', 'customerCenter')
        
        theApp.mainNavi = navi
	}

}

