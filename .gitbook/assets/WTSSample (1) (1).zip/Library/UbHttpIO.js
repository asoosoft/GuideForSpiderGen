/**
 * 
*/
class UbHttpIO extends HttpIO
{
	constructor(listener)
	{
		super(listener)
		
	}

    //업비트 API호출이라 업비트 WAS에서 분배되어야할 내용을 이곳에서 처리함.
    //공통으로 처리하기 애매하기때문에 SWITCH문으로 분배함.
	sendData(data, callback)
	{
        const tr_name = data.header.tr_name,
              packetId = data.header.packetId;

        const apiUrl = this.makeAPIUrl(data);

        if(!apiUrl)
        {
            this.onError(packetId, new Error('Can not make api'));
            return;
        }
        
        console.log(apiUrl)
		fetch(apiUrl).then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        }).then(data => {
			this.listener.packetInfo.packetId = packetId;
            this.onReceived(data, data.length);
        }).catch(error => {
            //this.onError(packetId, error);
            console.error('api error', error);
        });
	}

    //일단 사용자 input값은 inblock1[0]에 있음 무조건 다른 경우는 없음.
    makeAPIUrl(data)
    {
        const tr_name = data.header.tr_name;
        const block = data.body.InBlock1[0];

        let url = this.url;
        url += data.header.url;
        
        let paramStr = '';
        if(block) {
            paramStr = '?';
            for(let key in block) {
                if(block[key]) {
                    if(paramStr.length > 1) paramStr += '&';
                    paramStr += `${key}=${block[key]}`;
                }
            }

            url += paramStr;
        }

        return url;
    }
	
	onReceived(result, packetId, isToSignal)
	{
		if(this.listener) this.listener.onReceived(result, packetId, isToSignal)
	}
	
	onError(packetId, errorObj, isToSignal)
	{
		if(this.listener.onError) this.listener.onError(packetId, errorObj, isToSignal);
	}
}

