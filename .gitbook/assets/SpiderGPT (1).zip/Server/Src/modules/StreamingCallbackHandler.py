from langchain.callbacks.base import AsyncCallbackHandler
from typing import TYPE_CHECKING, Any, Dict, List
from langchain_core.messages import BaseMessage

## LLM 이 답변을 토큰단위로 처리하여 출력할떄 실시간으로 전달하기 위한 콜백
class StreamingCallbackHandler(AsyncCallbackHandler):
    def __init__(self, retriever, exceptionCallback):
        self.retriever = retriever
        self.exceptionCallback = exceptionCallback

    async def on_chat_model_start(self, serialized: Dict[str, Any], messages: List[List[BaseMessage]], **kwargs: Any):
        pass

    async def on_llm_new_token(self, token: str, **kwargs) -> None:
        try:
            if token.endswith('.'):
                print(token)
            else:
                print(token, end = '')

            await self.retriever.sendRespond(True, token)

        except:
            self.exceptionCallback()

    async def on_llm_end(self, response, **kwargs) -> None:
        print("\n")

        try:
            await self.retriever.sendRespond(False, '')            
        except:
            self.exceptionCallback()

    def log(self, log):
        print(log)
        

