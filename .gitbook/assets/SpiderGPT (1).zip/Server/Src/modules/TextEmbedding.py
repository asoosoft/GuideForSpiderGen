import os
import json
from dotenv import load_dotenv
from langchain.text_splitter import RecursiveCharacterTextSplitter  # 올바른 클래스 임포트
from langchain_openai import OpenAIEmbeddings
from langchain_community.vectorstores import Chroma
from langchain_community.document_loaders import DirectoryLoader
from modules.MultibyteTextLoader import MultiByteTextLoader
import tiktoken  # tiktoken 라이브러리 추가

# 환경 변수 로드
load_dotenv()

class TextEmbeddingSystem:
    def __init__(self):
        pass

    def embed(self,textFilePath,embedFilePath,embedModelName,collectionName):

        def tiktoken_len(text):
            tokenizer = tiktoken.get_encoding('cl100k_base')
            tokens = tokenizer.encode(text)
            return len(tokens)
        
        self.emptyDirectory(embedFilePath)

        directoryLoader = DirectoryLoader( textFilePath, glob="**/*.txt", loader_cls=MultiByteTextLoader)
        docList = directoryLoader.load()

        splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=200, length_function=tiktoken_len)

        splitDocList = splitter.split_documents(docList)

        # 임베딩 모델 가져오기
        embeddings = OpenAIEmbeddings(model=embedModelName)

        # 데이터 저장 실행
        chroma = Chroma.from_documents(splitDocList, embeddings, persist_directory=embedFilePath, collection_name=collectionName)
##        data =chroma.get()
##        vectorDb  = Chroma(embedding_function=embeddings,persist_directory=embedFilePath, collection_name=collectionName)
##        data2 = vectorDb.get()

        # 데이터를 JSON 파일로 저장
        self.saveJson(splitDocList, embedFilePath)

    # 데이터 파일로 저장하는 함수 정의
    def saveJson(self, documents, embed_file_path):
        embed_file = os.path.join(embed_file_path, 'embedded_data.json')
        os.makedirs(embed_file_path, exist_ok=True)
        with open(embed_file, 'w', encoding='utf-8') as file:
            json.dump([doc.dict() for doc in documents], file, ensure_ascii=False, indent=4)

    def emptyDirectory(self, directory):
        # 디렉토리 내 모든 파일과 디렉토리 목록을 가져옵니다.
        for filename in os.listdir(directory):
            file_path = os.path.join(directory, filename)
            try:
                if os.path.isfile(file_path):
                    os.remove(file_path)
            except Exception as e:
                print(f"Failed to delete {file_path}. Reason: {e}")


