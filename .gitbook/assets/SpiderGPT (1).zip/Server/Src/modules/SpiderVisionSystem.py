from dotenv import load_dotenv
from langchain.retrievers import EnsembleRetriever
from langchain_community.retrievers import BM25Retriever
from langchain_openai import ChatOpenAI
from langchain.retrievers.multi_query import MultiQueryRetriever
from langchain_openai import OpenAIEmbeddings
from modules.StreamingCallbackHandler import StreamingCallbackHandler
import ConstValue
import os
import json
from langchain.chains import create_retrieval_chain, create_history_aware_retriever
from langchain_core.prompts import MessagesPlaceholder
from langchain.prompts import ChatPromptTemplate
from langchain_core.messages.system import SystemMessage
from langchain_core.messages.human import HumanMessage
from langchain.chains.combine_documents import create_stuff_documents_chain
from langchain_core.retrievers import BaseRetriever
from langchain.storage import InMemoryStore
from modules.EventEmitter import event_emitter
import asyncio

load_dotenv()

class PassthroughRetriever(BaseRetriever):
    def __init__(self, retriever):
        self.retriever = retriever

    def get_relevant_documents(self, query):
        return self.retriever.get_relevant_documents(query)

class SpiderVisionSystem:
    def __init__(self):
        self.userId = None
        self.imageBytes = None
        self.websocket = None
        self.chatModel = os.environ["CHAT_MODEL"]

        self.llm = ChatOpenAI(
            model_name=self.chatModel, 
            base_url = "http://127.0.0.1:1234",
            streaming=True, 
            callbacks=[StreamingCallbackHandler(self,self.exceptionCallback)], 
            temperature=0)

        self.imageBytes = None
        
        # 시스템 메시지 설정
        self.systemMessage = {"type": "text", "text":"당신은 이미지로부터 직원이 근무에 집중중인지 아닌지를 확인하는 도우미이다."}
 
    def onConnected(self, userId, websocket):
        if self.websocket == websocket:
            return
        
        self.userId = userId
        self.websocket = websocket

    async def sendRespond(self, isResponding, token):
        data = {
            'type': ConstValue.RESPOND_VISION_QYERY,
            'isResponding': isResponding,
            'token': token
        }

        await self.websocket.send(json.dumps(data))

    def exceptionCallback(self):
        event_emitter.emit(ConstValue.CONNECTION_CLOSED, self.userId)
        asyncio.current_task().cancel()
        print(f"\nUser {self.userId} Disconnected")
    
    async def query(self, protocol):
        content = []

        input = protocol.get('question')
        imageBytes = protocol.get('imageByte')
        
        if imageBytes is not None:
            image = {
                    "type": "image_url",
                    "image_url": {"url": f"data:image/png;base64,{imageBytes}"}
            }                
            content.append(image)

        question = {"type":"text", "text":input}
        content.append(question)

        message = HumanMessage(content=content)
        try:
            # 대화 이력을 포함한 메시지를 모델에 직접 전달하여 응답 생성
            response = await self.llm.ainvoke([message])
        except Exception as e:
            print(f"Error occurred: {e}")
            return None
        

