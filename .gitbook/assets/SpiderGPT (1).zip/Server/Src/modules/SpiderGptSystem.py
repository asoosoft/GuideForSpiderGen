from dotenv import load_dotenv
from langchain.retrievers import EnsembleRetriever
from langchain_community.retrievers import BM25Retriever
from langchain_chroma import Chroma
from langchain_openai import ChatOpenAI
from langchain.retrievers.multi_query import MultiQueryRetriever
from langchain_openai import OpenAIEmbeddings
from modules.StreamingCallbackHandler import StreamingCallbackHandler
import ConstValue
import os
import json
from langchain.chains import create_retrieval_chain, create_history_aware_retriever
from langchain_core.prompts import MessagesPlaceholder
from langchain.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_core.messages.system import SystemMessage
from langchain_core.messages.human import HumanMessage
from langchain.chains.combine_documents import create_stuff_documents_chain
from langchain_core.retrievers import BaseRetriever
from langchain.storage import InMemoryStore
from modules.EventEmitter import event_emitter
import asyncio


load_dotenv()

class PassthroughRetriever(BaseRetriever):
    def __init__(self, retriever):
        self.retriever = retriever

    def get_relevant_documents(self, query):
        return self.retriever.get_relevant_documents(query)

class SpiderGptSystem:
    def __init__(self):
        self.userId = None
        self.inMemoryStore = InMemoryStore()
        self.imageBytes = None
        self.websocket = None
        self.embeddingModel = os.environ["EMBED_MODEL"]
        self.vectorStorePath = os.environ["VECTOR_STORE_PATH"]
        self.chatModel = os.environ["CHAT_MODEL"]
        self.collectoinName = os.environ["COLLECTION_NAME_SPIDERGEN"]
        apiKey = os.environ["OPENAI_API_KEY"]

        self.embeddings = OpenAIEmbeddings(model=self.embeddingModel)
        self.vectorDb  = Chroma(embedding_function=self.embeddings, persist_directory=self.vectorStorePath, collection_name=self.collectoinName)
        
        self.llm = ChatOpenAI( model_name=self.chatModel, streaming=True, callbacks=[StreamingCallbackHandler(self, self.exceptionCallback)], temperature=0)
        self.llm2 = ChatOpenAI( model_name=self.chatModel, streaming=True, temperature=0)

        self.retriever = self.vectorDb.as_retriever(search_type="mmr", search_kwargs={'k': 10,})

        data = self.vectorDb.get()

        ## 키워드 정확도에 따른 문서 조회
        self.bm25Retriever = BM25Retriever.from_texts(data['documents'], data['metadatas'])

        ## 질문을 관점에 따라 세분화하여 문서 검색. llm2 -> llm 으로 바꾸면 질문내용 조회 가능.
        self.multiQueryRetriever = MultiQueryRetriever.from_llm(retriever=self.retriever, llm=self.llm2)

        ## https://wikidocs.net/234100 참조
        self.ensembleRetriever = EnsembleRetriever(retrievers = [self.bm25Retriever , self.multiQueryRetriever], weights=[0.6, 0.4], search_type = "mmr")

        self.history = []

        self.imageBytes = None
 
        self.context = None

        self.task = None
        
        ##전처리
        self.systemMessage = SystemMessage(content= "I read only the given texts and answer questions based solely on them. Therefore, I reset, delete, and clear all previously stored data — my knowledge is now based only on the provided texts.")

        ## 문답내역
        self.historyData = MessagesPlaceholder(variable_name="history")
 
    def onConnected(self,userId,websocket):
        if self.websocket == websocket:
            return
        
        self.userId = userId
        self.websocket = websocket
        self.history.clear()


    ## 실시간 응답 처리
    async def sendRespond(self, isResponding, token):
        data = {
            'type': ConstValue.RESPOND_API_QUERY,
            'isResponding': isResponding,
            'token': token
        }

        await self.websocket.send(json.dumps(data))

    def exceptionCallback(self):
        event_emitter.emit(ConstValue.CONNECTION_CLOSED, self.userId)
        asyncio.current_task().cancel()
        print(f"\nUser {self.userId} Disconnected")
    
    # async def image_summarize(self, img_base64):
    #     # 시스템 메시지와 사용자 메시지를 생성합니다.
    #     system_message = SystemMessage("당신은 이미지를 사용자가 요청하는 Spidergen 컴포넌트로 분석하는 도우미이다.")
    #     user_message = HumanMessage(
    #         content=[
    #             {
    #                 "type": "image_url",
    #                 "image_url": {"url": "data:image/jpeg;base64,{img_base64}"},
    #             }
    #         ]
    #     )
        
    #     # ChatPromptTemplate에 메시지들을 담습니다.
    #     ##chat_prompt = ChatPromptTemplate.from_messages([user_message])
    #     chat_prompt = ChatPromptTemplate.from_messages([system_message, user_message])

    #     message = chat_prompt.invoke({"img_base64":img_base64})

    #     # 이미지를 요약하기 위해 LLM을 호출합니다.
    #     self.task = asyncio.create_task(self.llm.ainvoke(message.messages))

    #     msg = self.task.result

    #     return msg.content

    async def query(self, protocol):

        input = protocol.get('question')
        imageBytes = protocol.get('imageByte')

        contextData = ("user", "{context}")

        question = ("user", "{input}")

        image = ("user", [{
                    "type": "image_url",
                    "image_url": {"url": f"data:image/png;base64,{imageBytes}"},
                }])

        messages = [self.systemMessage, self.historyData,contextData]
        
        if imageBytes is not None:
            messages.append(image)

        messages.append(question)

        prompt = ChatPromptTemplate.from_messages(messages)

        ## 대화 내역을로부터 질문관련 데이터를 추출하는 retriever 
        historyAwareChain = create_history_aware_retriever(llm = self.llm, retriever = self.ensembleRetriever, prompt = prompt)

        ## 대화내역으로 문서 Chain을 만들어 추적할 수 있는 retriever 생성.
        documentChain = create_stuff_documents_chain(self.llm, prompt)
        chain = create_retrieval_chain(historyAwareChain, documentChain)

        try:
            response = await chain.ainvoke({
                    "history":self.history, 
                    "input":input, 
                    "context":""
                })
        except Exception as e:
            return
    
        # 대화 히스토리 업데이트
        self.history.append(HumanMessage(content = input))
        self.history.append(HumanMessage(content =  response["answer"]))









