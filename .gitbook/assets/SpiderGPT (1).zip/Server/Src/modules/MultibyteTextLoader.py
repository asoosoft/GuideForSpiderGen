from langchain_community.document_loaders.base import BaseLoader
from langchain.schema import Document

## utf-8 형식의 텍스트를 읽기위한 Loader
class MultiByteTextLoader(BaseLoader):
    def __init__(self, path):
        self.path = path

    def load(self):
        try:
            with open(self.path, 'r', encoding='utf-8') as file:
                content = file.read()
            doc = [Document(page_content=content, metadata={"source": self.path})]
            return doc
        except UnicodeDecodeError as e:
            raise RuntimeError(f"Error loading {self.path}") from e
