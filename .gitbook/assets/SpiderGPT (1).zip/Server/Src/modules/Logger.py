from abc import ABC, abstractmethod

class ILogger:
    @abstractmethod
    def log(self, log):
        pass

class StdLogger:
    def log(self, log):
        print(log)

