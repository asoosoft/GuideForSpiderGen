from pyee.asyncio import AsyncIOEventEmitter

event_emitter = AsyncIOEventEmitter()