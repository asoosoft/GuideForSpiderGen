import os

## MD 문서로부터 클래스, 메소드등의 멤버 목록 정리

class ClassExporter:
    def process_markdown_file(self,file_path):
        with open(file_path, 'r', encoding='utf-8') as file:
            content = file.readlines()

        h1_headings = [line.strip() for line in content if line.startswith('# ')]
        h2_headings = []
        h3_dict = {}
        current_h2 = None

        for line in content:
            if line.startswith('## '):
                current_h2 = line.strip()[3:]
                h2_key = current_h2.replace(" ", "").lower()
                h2_headings.append(h2_key)
                h3_dict[h2_key] = []
            elif line.startswith('### '):
                if current_h2:
                    h3_dict[h2_key].append(line.strip()[4:])

        structured_result = {h2: h3_dict[h2] for h2 in h2_headings}
        final_result_json = {
            "class": h1_headings[0][2:],  # h1 값은 그대로 사용
            **structured_result
        }

        return final_result_json

    def export(self,input_folder_path, output_folder_path):        
        if not os.path.exists(output_folder_path):
            os.makedirs(output_folder_path)
        
        class_list = []

        for root, dirs, files in os.walk(input_folder_path):
            for filename in files:
                if(filename.lower() == 'readme.md'):
                    continue
                if filename.endswith(".md"):
                    file_path = os.path.join(root, filename)
                    try:
                        json_result = self.process_markdown_file(file_path)
                        
                        # 클래스 이름을 리스트에 추가
                        class_list.append(json_result["class"])
                        
                        txt_filename = f"{os.path.splitext(filename)[0]}_members.txt"
                        txt_file_path = os.path.join(output_folder_path, txt_filename)
                        
                        with open(txt_file_path, 'w', encoding='utf-8') as txt_file:
                            txt_file.write(f"class: {json_result['class']}\n")
                            for h2_key, h3_values in json_result.items():
                                if h2_key != "class":
                                    txt_file.write(f"{h2_key}:\n")
                                    for h3 in h3_values:
                                        txt_file.write(f"  - {h3}\n")
                    except Exception as e:
                        print(f"Error processing file {file_path}: {e}")
            
        # 클래스 이름 리스트를 텍스트 파일로 저장
        classes_txt_path = os.path.join(output_folder_path, "ClassList.txt")
        with open(classes_txt_path, 'w', encoding='utf-8') as txt_file:
            txt_file.write("컴포넌트 및 클래스 리스트:\n")
            for class_name in class_list:
                txt_file.write(f"  {class_name}\n")

