import os
from langchain.prompts import ChatPromptTemplate
from langchain_openai import ChatOpenAI
from dotenv import load_dotenv
from modules.StreamingCallbackHandler import StreamingCallbackHandler
from modules.Logger import StdLogger
load_dotenv()

class TextExporter:

    def __init__(self, chatModel):
        self.chatModel = chatModel

    def read_md_file(self, file_path):
        print(f"Reading MD file from {file_path}...")
            # 파일이 이미 존재하는지 확인
        
        with open(file_path, 'r', encoding='utf-8') as file:
            content = file.read()
            
        print("MD file read successfully.")
        return content

    def write_text_file(self, data, output_folder, file_name):
        print(f"Writing text file to {output_folder}...")
        os.makedirs(output_folder, exist_ok=True)
        file_path = os.path.join(output_folder, file_name)

        with open(file_path, 'w', encoding='utf-8') as file:
            file.write(data)
        print(f"Text file saved as {file_path}.")

    async def get_plainText_from_gpt(self, md_content):

        print("Sending request to OpenAI API...")

        systemMessage = """
                    You are PlainText Converter.\n
                    1. 첨부 문서를 ChromaDB로 임베딩할 수 있도록 구조화된 Plain Text로 변환해줘\n
                    2. markDown 표시 제거하고 좌측 Trim\n
                    3. 코드표기문법 제거(```js)\n
                    4. 예제코드는 해당 항목의 예제임을 example-컴포넌트명-항목 형식으로 표시"""
        
        promptTempate = ChatPromptTemplate.from_messages([
            ("system", systemMessage),
            ("user","{input}")
        ])

        llm = ChatOpenAI(model_name=self.chatModel, callbacks=[StreamingCallbackHandler(self,StdLogger(), self.exceptionCallback)],streaming=True, temperature=0)

        seq =  promptTempate |llm

        response = await seq.ainvoke({"input": md_content})

        return response.content
    
    async def sendRespond(self, isResponding, token ):
        pass

    async def export(self, folder_path, text_output_folder, overwrite):
        print("Process started.")
        
        for root, dirs, files in os.walk(folder_path):
            for file_name in files:
                if file_name.lower() == "readme.md":
                    continue

                if file_name.endswith('.md'):
                    file_path = os.path.join(root, file_name)
                    print(f"Processing file: {file_path}")

                    text_file_name = f"{os.path.splitext(file_name)[0]}.txt"
                    
                    destFile = text_output_folder + '/' + text_file_name

                    if overwrite is False and os.path.exists(destFile):
                       print(f"File {file_name} already exists. Skipping.")
                       continue

                    md_content = self.read_md_file(file_path)

                    response_content = await self.get_plainText_from_gpt(md_content)
                    
                    text_folder_path = os.path.join(text_output_folder)                    
                    
                    self.write_text_file(response_content, text_folder_path, text_file_name)
                    print(f"Text file saved as {os.path.join(text_folder_path, text_file_name)}.")

    def exceptionCallback(self):
        pass