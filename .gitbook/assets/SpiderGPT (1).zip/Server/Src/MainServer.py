from modules.SpiderGptSystem import SpiderGptSystem
import asyncio
import ConstValue
import websockets
import json
from dotenv import load_dotenv
from modules.EventEmitter import event_emitter
from modules.SpiderVisionSystem import SpiderVisionSystem
from modules.ImageToLaySystem import ImageToLaySystem
import queue
import os

class MainServer:

    def __init__(self) -> None:
        load_dotenv()
        self.clientDic = {}
        event_emitter.on(ConstValue.CONNECTION_CLOSED, self.onConnectionClosed)

        self.systemPool = queue.Queue(ConstValue.MAX_RAGSYSTEM_POOL)

    # SpiderGen API 데이터
    async def onReceive(self,websocket):
        async for respond in websocket:
            protocolJson = json.loads(respond)

            print(f"Received: {protocolJson}")

            userId = protocolJson.get('userId')
            protocolType = protocolJson['type']

            retriever_map = {
                ConstValue.REQUEST_API_QUERY: ConstValue.RETRIEVER_API,
                ConstValue.REQUEST_IMAGETOLAY_QUERY: ConstValue.RETRIEVER_IMAGETOLAY,
                ConstValue.REQUEST_VISION_QUERY: ConstValue.RETRIEVER_VISION
            }

            if protocolType in retriever_map:
                system = self.getSystem(userId, websocket, retriever_map[protocolType])
                await system.query(protocolJson)
    
    def getSystem(self,userId, websocket, type):
        if userId not in self.clientDic:
            if self.systemPool.qsize() == 0:
                self.addSystemPoolItem()

            self.clientDic[userId] = self.systemPool.get_nowait()

        retriever = self.clientDic[userId]
        retriever[type].onConnected(userId, websocket)
        return retriever[type]

    def addSystemPoolItem(self):
        self.systemPool.put([SpiderGptSystem(), ImageToLaySystem(), SpiderVisionSystem()])

    async def startServer(self, port):
        async with websockets.serve(self.onReceive, ConstValue.ServerIp, port):
            print(f'port {port} server Running')
            await asyncio.Future()

    async def run(self):
        for count in range(ConstValue.MAX_RAGSYSTEM_POOL):
            self.addSystemPoolItem()
            print(f"MultiModal RagSystem {count} Created")

        ports = [8765,8766,8767]
        tasks = [self.startServer(port) for port in ports]
        await asyncio.gather(*tasks)

    def onConnectionClosed(self, userId):
        if userId in self.clientDic:
            retriever = self.clientDic[userId]
            self.ragSystemPool.put(retriever)
            del self.clientDic[userId]

if __name__ == "__main__":
    mainServer = MainServer()
    asyncio.run(mainServer.run())