import os
import openai
import asyncio
from dotenv import load_dotenv
from modules.TextExporter import TextExporter
from modules.ClassExporter import ClassExporter
from modules.TextEmbedding import TextEmbeddingSystem

class EmbeddingMain:
    def __init__(self) -> None:
        load_dotenv()
        openai.api_key = os.environ['OPENAI_API_KEY']

        self.chat_model = os.environ['CHAT_MODEL']
        self.embedModelName = os.environ['EMBED_MODEL']
        self.collectionName = os.environ['COLLECTION_NAME_SPIDERGEN']

        self.manual_doc_path =self.makePath(os.environ['MANUAL_DOC_PATH'])
        self.text_output_folder = self.makePath(os.environ['TEXT_DATA_PATH'])
        self.textFilePath = self.makePath(os.environ['TEXT_DATA_PATH'])
        self.vectorStorePath = self.makePath(os.environ['VECTOR_STORE_PATH'])
        self.api_doc_path = self.makePath(os.environ['API_DOC_PATH'])

    def makePath(self, relPath):
        workingDir = os.getcwd()
        path = os.path.abspath(os.path.join(workingDir, relPath))
        return path

    ## 필요한 기능만 주석 해제
    async def run(self):
        ##self.exportClass()
        
        ##await self.exportText(self.api_doc_path, True)
        ##await self.exportText(self.manual_doc_path, False)
        ##await self.exportTemplate(self.manual_doc_path, False)
        self.embedding()

    ## MD 파일에서 클래스 리스트및 클래스별 멤버목록 추출
    def exportClass(self):
        classExporter = ClassExporter()
        classExporter.export(self.api_doc_path,self.textFilePath)

    ## MD 파일을 임베딩시 검색 정확도가 높아질수 있도록 텍스트 형식으로 변환하여 추출
    async def exportText(self,docPath, overwrite):
        textExporter = TextExporter(self.chat_model)
        await textExporter.export(docPath, self.text_output_folder, overwrite)

    def embedding(self):
        embeddingSystem = TextEmbeddingSystem()
        embeddingSystem.embed(self.textFilePath,self.vectorStorePath,self.embedModelName,self.collectionName)

if __name__ == "__main__":
    embeddingMain = EmbeddingMain()
    asyncio.run(embeddingMain.run())















