
import os
import openai
import asyncio
import base64
import uuid
from dotenv import load_dotenv
from unstructured.partition.pdf import partition_pdf
from langchain_text_splitters import CharacterTextSplitter
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate
from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage
from langchain.retrievers.multi_vector import MultiVectorRetriever
from langchain.storage import InMemoryStore
from langchain_community.vectorstores import Chroma
from langchain_core.documents import Document
from langchain_openai import OpenAIEmbeddings
from langchain.storage import LocalFileStore

## 이미지가 포함된 PDF 의 Embedding
class MultiModalEmbeddingMain:
    def __init__(self) -> None:
        load_dotenv()
        openai.api_key = os.environ['OPENAI_API_KEY']

        self.chat_model = os.environ['CHAT_MODEL']
        self.embedModelName = os.environ['EMBED_MODEL']
        self.collectionName = os.environ['COLLECTION_NAME_IMAGETOLAY']
        self.pdfPath = os.environ['PDF_PATH']
        self.imageStorePath = os.environ['IMAGE_STORE_PATH']
        self.vectorStorePath = os.environ['VECTOR_STORE_PATH']
        self.docStorePath = os.environ['DOC_STORE_PATH']
        self.docId = os.environ['DOC_ID']

    def _extractPdf(self, srcPath, outputPath):
        return partition_pdf(
            filename = srcPath,
            extract_images_in_pdf = True,
            infer_tabe_structure = True,
            chunking_strategy = "by_title",
            strategy="hi_res",
            max_characters = 4000,
            new_after_n_chars = 3800,
            combine_text_under_n_chars = 2000,
            extract_image_block_types = ["image", "Table"],
            extract_image_block_to_payload = False,
            extract_image_block_output_dir = outputPath
        )
    
    def _categorize_elements(self, raw_pdf_elements):
        tables = []
        texts = []

        for element in raw_pdf_elements:
            if "unstructured.documents.elements.Table" in str(type(element)):
                tables.append(str(element))  # 테이블 요소 추가
            elif "unstructured.documents.elements.CompositeElement" in str(type(element)):
                texts.append(str(element))  # 텍스트 요소 추가        
        return texts, tables
    
    def generate_text_summaries(self, texts, tables, summarize_texts=False):
        prompt_text = """You are an assistant tasked with summarizing tables and text for retrieval. \
        These summaries will be embedded and used to retrieve the raw text or table elements. \
        Give a concise summary of the table or text that is well optimized for retrieval. Table or text: {element} """
        prompt = ChatPromptTemplate.from_template(prompt_text)

        # 텍스트 요약 체인
        model = ChatOpenAI(temperature=0, model=self.chat_model)
        summarize_chain = {"element": lambda x: x} | prompt | model | StrOutputParser()

        # 요약을 위한 빈 리스트 초기화
        text_summaries = []
        table_summaries = []

        # 제공된 텍스트에 대해 요약이 요청되었을 경우 적용
        if texts and summarize_texts:
            text_summaries = summarize_chain.batch(texts, {"max_concurrency": 5})
        elif texts:
            text_summaries = texts

        # 제공된 테이블에 적용
        if tables:
            table_summaries = summarize_chain.batch(tables, {"max_concurrency": 5})

        return text_summaries, table_summaries

    def encode_image(self,image_path):
        # 이미지 파일을 base64 문자열로 인코딩합니다.
        with open(image_path, "rb") as image_file:
            return base64.b64encode(image_file.read()).decode("utf-8")

    def image_summarize(self,img_base64, prompt):
        # 이미지 요약을 생성합니다.
        chat = ChatOpenAI(model=self.chat_model, max_tokens=2048)

        msg = chat.invoke(
            [
                HumanMessage(
                    content=[
                        {"type": "text", "text": prompt},
                        {
                            "type": "image_url",
                            "image_url": {"url": f"data:image/jpeg;base64,{img_base64}"},
                        },
                    ]
                )
            ]
        )
        return msg.content

    def generate_img_summaries(self,path):
        """
        이미지에 대한 요약과 base64 인코딩된 문자열을 생성합니다.
        path: Unstructured에 의해 추출된 .jpg 파일 목록의 경로
        """

        # base64로 인코딩된 이미지를 저장할 리스트
        img_base64_list = []

        # 이미지 요약을 저장할 리스트
        image_summaries = []

        # 요약을 위한 프롬프트
        prompt = """You are an assistant tasked with summarizing images for retrieval. \
        These summaries will be embedded and used to retrieve the raw image. \
        Give a concise summary of the image that is well optimized for retrieval."""

        # 이미지에 적용
        for img_file in sorted(os.listdir(path)):
            if img_file.endswith(".jpg"):
                img_path = os.path.join(path, img_file)
                base64_image = self.encode_image(img_path)
                img_base64_list.append(base64_image)
                imageSummarize = self.image_summarize(base64_image, prompt)
                image_summaries.append(imageSummarize)

        return img_base64_list, image_summaries
    
    def create_multi_vector_retriever(self, vectorstore, text_summaries, texts, 
                                      table_summaries, tables, image_summaries, images):
        """
        요약을 색인화하지만 원본 이미지나 텍스트를 반환하는 검색기를 생성합니다.
        """

        # 저장 계층 초기화
        store = LocalFileStore(self.docStorePath)
        id_key = self.docId

        # 멀티 벡터 검색기 생성
        retriever = MultiVectorRetriever(
            vectorstore=vectorstore,
            docstore=store,
            id_key=id_key,
        )
        # 문서를 벡터 저장소와 문서 저장소에 추가하는 헬퍼 함수
        def add_documents(doc_summaries, doc_contents):
            # 문서 내용마다 고유 ID 생성
            doc_ids = [
                str(uuid.uuid4()) for _ in doc_contents
            ]  

            summary_docs = [
                Document(page_content=s, metadata={id_key: doc_ids[i]})
                for i, s in enumerate(doc_summaries)
            ]

            # 요약 문서를 벡터 저장소에 추가
            retriever.vectorstore.add_documents(
                summary_docs
            )  
            # 문서 내용을 문서 저장소에 추가
            retriever.docstore.mset(
                list(zip(doc_ids, doc_contents))
            )  


        def encode(textArr):
            bytes = [memoryview(s.encode()) for s in textArr]
            return bytes

        # 텍스트, 테이블, 이미지 추가
        if text_summaries:
            textBytes = encode(texts)
            add_documents(text_summaries, textBytes)

        if table_summaries:
            tableBytes = encode(tables)
            add_documents(table_summaries, tableBytes)

        if image_summaries:
            imageBytes = encode(images)
            add_documents(image_summaries, imageBytes)


    def run(self):
        pdfFullPath = os.path.join(self.pdfPath, "Sample1.pdf")
        pdfElements = self._extractPdf(pdfFullPath, self.imageStorePath)

        texts,tables = self._categorize_elements(pdfElements)

        ## 4000 토큰 단위로 분할. 중복텍스트 500 토큰
        textSplitter = CharacterTextSplitter.from_tiktoken_encoder(chunk_size = 4000, chunk_overlap = 500)

        joined_texts = " ".join(texts)
        texts_4k_token = textSplitter.split_text(joined_texts)
        textSummaries, table_summaries = self.generate_text_summaries(texts_4k_token, tables, summarize_texts=True)
        img_base64_list, image_summaries = self.generate_img_summaries(self.imageStorePath)

        vectorstore = Chroma(collection_name=self.collectionName, embedding_function=OpenAIEmbeddings(), persist_directory = self.vectorStorePath)

        # 검색기 생성
        self.create_multi_vector_retriever(vectorstore,textSummaries,texts,table_summaries,
                                           tables,image_summaries,img_base64_list)
        

if __name__ == "__main__":
    embeddingMain = MultiModalEmbeddingMain()
    embeddingMain.run()



    
    







        
    