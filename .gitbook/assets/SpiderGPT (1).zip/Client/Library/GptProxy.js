class GptProxy{
    constructor(listener){
        this.socketIO = new WebsocketIO(this)
        this.listener = listener;
    }

    connect(ip, port)
    {
        let connected = this.socketIO.socket !== null;
        if(connected){
            connected = this.socketIO.socket.readyState === WebSocket.OPEN;
        }

        if(connected === false){
            this.socketIO.startIO(ip, port);
            return;
        }
    }

    send(protocolObj){
        const protocolData = JSON.stringify(protocolObj);
        this.socketIO.sendData(protocolData);
    }

    onReceived(data, size){
        const jsonObj = JSON.parse(data);
        this.listener.onReceived(jsonObj);
    }

    onConnected(success)
    {
        this.listener.onConnected(success);
    }

    onClosed()
    {
        this.listener.onClosed();
    }

    isConnected() {
        return this.socketIO.socket !== null && this.socketIO.socket.readyState === WebSocket.OPEN;
    }
}