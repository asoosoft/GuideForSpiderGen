window.ComponentFactory = window.ComponentFactory || {};


window.ComponentFactory.createContainer = function(node)
{
    const display = node.style.display;
    if(display === 'flex')
    {
        return ComponentFactory.createFlexLayout(node);
    }

    return ComponentFactory.createView(node);
}

window.ComponentFactory.createView = function(node)
{
    const comp = new AView();
    comp.init();

    return comp;
}

window.ComponentFactory.createFlexLayout = function(node){
    const comp = new AFlexLayout();
    comp.init();


    const direction = node.style.flexDirection;
    comp.setAttr('flex-direction', direction);

    return comp;
}