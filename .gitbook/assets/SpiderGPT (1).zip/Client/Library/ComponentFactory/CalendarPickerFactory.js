window.ComponentFactory = window.ComponentFactory || {};


window.ComponentFactory.createCalendarPicker = function(node)
{
    const comp = new ACalendarPicker();
    comp.init();

    return comp;
}