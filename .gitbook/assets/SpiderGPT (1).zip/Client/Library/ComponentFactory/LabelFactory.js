window.ComponentFactory = window.ComponentFactory || {};


window.ComponentFactory.createLabel = function(node)
{
    const comp = new ALabel();
    comp.init();

    return comp;
}

window.ComponentFactory.createLabelFromSpan = function(node)
{
    const comp = new ALabel();
    comp.init();

    return comp;    
}