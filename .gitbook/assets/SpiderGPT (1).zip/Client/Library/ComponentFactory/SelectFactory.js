window.ComponentFactory = window.ComponentFactory || {};


window.ComponentFactory.createSelect = function(node)
{

    const comp = new ASelectBox();
    comp.init();

    return comp;
    
}