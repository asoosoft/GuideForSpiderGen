window.ComponentFactory = window.ComponentFactory || {};


window.ComponentFactory.createSelectBox = function(node)
{
    const comp = new ASelectBox();

    comp.init();

    return comp;
}