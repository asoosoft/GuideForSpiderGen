window.ComponentFactory = window.ComponentFactory || {};


window.ComponentFactory.createInput = function(node)
{
    const comp = new ATextField();
    comp.init();

    return comp;
}