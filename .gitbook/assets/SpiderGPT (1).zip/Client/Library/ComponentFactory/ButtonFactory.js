window.ComponentFactory = window.ComponentFactory || {};


window.ComponentFactory.createButton = function(node)
{
    const comp = new AButton();
    comp.init();

    const text = comp.getText();
    comp.setText(text);

    return comp;    
}