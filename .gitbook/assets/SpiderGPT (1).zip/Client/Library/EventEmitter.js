const eventEmitter = new EventTarget();

function emitEvent(eventName, data) {
    const event = new CustomEvent(eventName, { detail: data });
    eventEmitter.dispatchEvent(event);
}

function onEvent(eventName, callback) {
    eventEmitter.addEventListener(eventName, (event) => {
        callback(event.detail);
    });
}