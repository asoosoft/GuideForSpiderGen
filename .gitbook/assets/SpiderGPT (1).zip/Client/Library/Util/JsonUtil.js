const fs = nodeRequire('fs');

class JsonUtil
{
    static load(filePath) {
        const curPath = theApp.getCurrentPath();
        const fullPath = curPath + filePath;

        return new Promise((resolve, reject) => { // Promise 사용
            fs.readFile(fullPath, 'utf8', (err, data) => {
                if (err) {
                    console.error('파일 읽기 에러:', err);
                    reject(err); // 에러 발생 시 reject
                    return;
                }
                
                try {
                    // JSON 텍스트를 JavaScript 객체로 변환
                    const jsonObject = JSON.parse(data);
                    resolve(jsonObject); // 성공 시 resolve
                } catch (parseError) {
                    console.error('JSON 파싱 에러:', parseError);
                    reject(parseError); // 파싱 에러 시 reject
                }
            });
        });
    }

    static save(filePath, jsonObj) {
        const jsonString = JSON.stringify(jsonObj, null, 4); // JSON 객체를 문자열로 변환

        return new Promise((resolve, reject) => { // Promise 사용
            fs.writeFile(filePath, jsonString, 'utf8', (err) => { // fs 모듈 사용
                if (err) {
                    console.error('JSON 파일 저장에 실패했습니다.', err);
                    reject(new Error('파일 저장 실패')); // 실패 시 reject
                } else {
                    resolve(); // 성공 시 resolve
                }
            });
        });
    }

    static updataValues(srcObj, destObj) {
        for (const key in destObj) { // destObj의 모든 키를 반복
            if (srcObj.hasOwnProperty(key)) { // srcObj에 해당 키가 존재하는지 확인
                destObj[key] = srcObj[key]; // destObj의 값을 srcObj의 값으로 업데이트
            }
        }
    }
}
