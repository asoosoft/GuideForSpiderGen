CSSUtil = class CSSUtil{
    static collectStyle(view, onUpdate, onUpdateFinish){
        const doc = view.getDoc();
        const docStyleObj = {};
        let styleSheets = doc.styleSheets,
            rules, rule, obj, selectorText, styleArr, style;
        for(let i=0; i<styleSheets.length; i++) {
            rules = styleSheets[i].cssRules;
            for(let j=0; j<rules.length; j++) {
                rule = rules[j];
                selectorText = rule.selectorText;
                if(!selectorText) continue;
                if(selectorText[0] != '.') continue;
                obj = {}

                styleArr = rule.cssText.replace(selectorText, '').replace(/\{|\}/g, '').trim().split(';');
                for(let k=0; k<styleArr.length; k++) {
                    if(styleArr[k]) {
                        style = styleArr[k].trim().split(': ');   

                        const key = style[0];
                        const value = style[1];

                        obj[key] = value;
            
                        if(onUpdate){
                            onUpdate(key, value);
                        }
                    }
                }
                if(onUpdateFinish){                   
                    onUpdateFinish(rule.selectorText)
                }
                docStyleObj[rule.selectorText.slice(1)] = obj;
            }
        }

        return docStyleObj;
    }
}