class AViewUtil {
    static addImageToContentView(contentView, url) {
        const img = document.createElement('img');
        const divimg = document.createElement('divimg');

        divimg.style.width = '350px';
        divimg.style.height = 'auto';
        divimg.style.backgroundColor = "#242323";

        img.src = url;
        img.style.maxWidth = "350px";
        img.style.maxHeight = "350px";
        img.style.backgroundRepeat = 'no-repeat';

        divimg.append(img);
        contentView.$ele.append(divimg);        
        contentView.scrollToBottom();
    }
}
