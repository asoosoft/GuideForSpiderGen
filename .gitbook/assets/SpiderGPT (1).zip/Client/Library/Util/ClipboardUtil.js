class ClipboardUtil 
{
    static containsImage(clipboardData){
        // 클립보드 데이터나 타입이 없는 경우 반환
        if (!clipboardData || !clipboardData.types) return false;

        const types = clipboardData.types;

        // 'text/plain' 타입인 경우 반환
        if (types.indexOf('text/plain') !== -1) return false;

        return true;
    }

    // clipboard 복사한 대상이 파일인 경우
    static getImageFile(clipboardData) {
        const clipboardFiles = clipboardData.files;
        
        // 파일이 있고 경로가 비어 있지 않은 경우
        if (clipboardFiles[0]?.path) {
            for (let i = 0; i < clipboardData.items.length; i++) {
                const file = clipboardData.items[i].getAsFile();
                if (file) return file;
            }
        }
        return null;
    }


    // clipboard 복사한 대상이 스크린 캡쳐인경우
    static async getImageData(clipboardData) {

        if (clipboardData) {
            // 클립보드에 이미지가 있는지 확인
            for (const item of clipboardData.items) {
                if (item.kind === 'file' && item.type.startsWith('image/')) {
                    const file = item.getAsFile();
                    const base64String = await ClipboardUtil.fileToBase64(file); // 파일을 base64로 변환
                    const url = URL.createObjectURL(file);
                    
                    return [url, base64String];
                }
            }
        }
    }
    
    static async fileToBase64(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = () => {
                const base64StringWithoutPrefix = reader.result.replace(/^data:image\/(png|jpeg);base64,/, '');
                resolve(base64StringWithoutPrefix);
            }
            reader.onerror = reject;
            reader.readAsDataURL(file);
        });
    }

    // static async getImageData(clipboardData) {

    //     if (!clipboardData.files[0]?.path) {
    //         const clipboardItems = await navigator.clipboard.read();
    //         for (const clipboardItem of clipboardItems) {
    //             for (const type of clipboardItem.types) {
    //                 if (type.startsWith('image/')) {
    //                     const blob = await clipboardItem.getType(type);
    //                     const arrayBuffer = await blob.arrayBuffer();
    //                     const base64String = ImageUtil.imageToByte(arrayBuffer);
    //                     const url = URL.createObjectURL(blob);

    //                     return [url, base64String];
    //                 }
    //             }
    //         }
    //     } else {
    //         const items = clipboardData.items;
    //         for (const item of items) {
    //             const file = item.getAsFile();
    //             if (file) {
    //                 const { path, base64String } = await ImageUtil.fileToByte(file);
    //                 return [path, base64String];
    //             }
    //         }
    //     }
    //     return null;
    // }
}
