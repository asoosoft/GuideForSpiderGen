class ImageUtil 
{
    static imageToByte(arrayBuffer) {
        let binary = '';
        const uint8Array = new Uint8Array(arrayBuffer);
        for (let i = 0; i < uint8Array.byteLength; i++) {
            binary += String.fromCharCode(uint8Array[i]);
        }
        return window.btoa(binary);
    }

    static async fileToByte(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = () => {
                const arrayBufferReader = new FileReader();
                arrayBufferReader.onload = () => {
                    const imageByte = ImageUtil.imageToByte(arrayBufferReader.result);
                    resolve([file.path, imageByte]);
                };
                arrayBufferReader.onerror = reject;
                arrayBufferReader.readAsArrayBuffer(file);
            };
            reader.onerror = reject;
            reader.readAsDataURL(file);
        });
    }
}
