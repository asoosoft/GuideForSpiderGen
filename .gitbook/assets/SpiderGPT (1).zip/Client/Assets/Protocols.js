

class BaseProtocol
{
    constructor(type)
    {
        this.type = type;
    }

    get type()
    {
        return this.type;
    }
}

class Question extends BaseProtocol
{
    constructor(type, message)
    {
        super(type);
        this.message = message
    }


    get message()
    {
        return this.message;
    }
}

class Respond extends BaseProtocol
{
    constructor(type, isResponding, token)
    {
        super(type);
        this.isResponding = isResponding;
        this.token = token;
    }    
}