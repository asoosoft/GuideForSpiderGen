
/**
 * @author asoocool
 */

class AGridLayoutEvent extends AEvent
{
	constructor(acomp)
	{
		super(acomp);
	}
}
window.AGridLayoutEvent = AGridLayoutEvent;




//---------------------------------------------------------------------------------------------------
//	Component Event Functions





//---------------------------------------------------------------------------------------------------
