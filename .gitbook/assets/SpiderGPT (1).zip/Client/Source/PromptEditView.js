
PromptEditView = class PromptEditView extends AView
{
	constructor()
	{
		super()
	}

	init(context, evtListener)
	{
		super.init(context, evtListener)

		this.srcPromptData = null;
		this.promptData = null;
	}

	onInitDone()
	{
		super.onInitDone()

        const data = this.getContainer().getData();
		
		this.srcPromptData = data.srcPromptData;
        this.systemMessage = data.systemMessage;
        this.userMessage = data.userMessage;

		this.systemMessageTa.setText(this.systemMessage);
		this.userMessageTa.setText(this.userMessage);
	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst);
	}

	// 수정 취소
	onClickCancel(comp, info, e)
	{
        this.getContainer().close(0);
	}

	// 데이터 수정
	onClickOK(comp, info, e)
	{
        const data = {
            systemMessage: this.systemMessageTa.getText(),
            userMessage:this.userMessageTa.getText()
        }

        this.getContainer().close(1, data);
	}

	// 데이터 & 파일 수정
	onClickSave(comp, info, e)
	{
        const data = {
            systemMessage: this.systemMessageTa.getText(),
            userMessage:this.userMessageTa.getText()
        }
        this.getContainer().close(2, data);
	}

	onClickRestore(comp, info, e)
	{
		this.systemMessage = this.srcPromptData[IMAGETOLAY_SYSTEM_MESSAGE];
		this.userMessage = this.srcPromptData[IMAGETOLAY_USERMESSAGE];

		this.systemMessageTa.setText(this.systemMessage);
		this.userMessageTa.setText(this.userMessage);
	}
}

