
ConverterView = class ConverterView extends AView
{
	constructor()
	{
		super()

        this.htmlString = '';
        this.cssString = '';
        this.styleEle = null;
	}

	init(context, evtListener)
	{
		super.init(context, evtListener)
	}

	onInitDone()
	{
		super.onInitDone()

		//TODO:edit here
        const data = this.getContainer().getData();
        this.htmlString = data.html;
        this.cssString = data.css;

        this.layStyleEle = document.createElement('style')
        this.layStyleEle.innerText = this.cssString;
        document.getElementsByTagName('head')[0].append(this.layStyleEle);

        // html 출력
        this.webView.setHtml(this.htmlString);
        
        // html 을 AComponent 로 변환
        const body = this.getBody(this.htmlString);

        this.traverse(body, this.resultView);

        console.log(this.htmlString);
        console.log(this.styleObj);
	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)
	}

    getBody(htmlString)
    {
        const parser = new DOMParser();
        const doc = parser.parseFromString(htmlString , 'text/html');

        return doc.body;
    }
   
    traverse(node, parent) {
        console.log(node.cloneNode(false)); // 현재 노드 출력
        let addFuncStr = 'addComponent';
        if(parent instanceof ALayout) addFuncStr = 'layComponent';

        for(let index =0 ;index < node.childNodes.length; index++)
        {
            const child = node.childNodes[index];

            if(child.nodeType == node.ELEMENT_NODE)
            {
                const comp = this.createComp(child);
                if(comp !== null)
                {
                    parent[addFuncStr](comp);
                }

                if(child.nodeName.toLowerCase() === 'div')
                {
                    parent = comp;
                }
                this.traverse(child, parent)
            }
        }
    }

    createComp(node)
    {
        let compType = node.getAttribute('compType');
        if(compType === null)
        {
            compType = 'div';
        }

        switch(compType)
        {
            case 'div':
            { 
                return ComponentFactory.createContainer(node, this.layStyleEle.sheet);
            }
            case 'span':
            {
                return ComponentFactory.createLabelFromSpan(node, this.layStyleEle.sheet);
            }
            case 'label':
            {
                return ComponentFactory.createLabel(node, this.layStyleEle.sheet);
            }  
            case 'button':
            {
                return ComponentFactory.createButton(node, this.layStyleEle.sheet);
            }
            case 'input':
            {
                switch(node.type)
                {
                    case 'text':
                    {
                        return ComponentFactory.createInput(node, this.layStyleEle.sheet);
                    }
                    case 'date':
                    {
                        return ComponentFactory.createCalendarPicker(node, this.layStyleEle.sheet);
                    }
                }
            }
            case 'select':
            {
                return ComponentFactory.createSelect(node, this.layStyleEle.sheet);
            }
        }
        return null;
    }


	onRefreshBtnClick(comp, info, e)
	{
        this.resultView.removeChildren();
        const body = this.getBody(this.htmlString);
        this.traverse(body, this.resultView);
    }
}

