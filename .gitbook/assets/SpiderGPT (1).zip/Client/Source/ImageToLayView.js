ImageToLayView = class ImageToLayView extends AView
{
	constructor()
	{
		super()
        this.promptData = {};
        this.promptFilePath = 'Assets/PromptData.json'
	}

	init(context, evtListener)
	{
		super.init(context, evtListener);

        this.imageBytes =[];
        this.str = "";
        this.cnt = 0;
        this.gptProxy = new GptProxy(this);
	}

	async onInitDone()
	{
		super.onInitDone();

        this.fileIp = document.getElementById('fileInput');
        this.questionTf.setFocus(true);

        let id = localStorage.getItem('id');
        if(id === null){
            id = ''
        }
        this.idTf.setText(id);
        window.userId = id;

        this.promptData = await JsonUtil.load(this.promptFilePath);
	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)

        this.gptProxy.connect(SERVER_IP, SERVER_PORT_IMAGETOLAY);
	}

    sendQuery(query)
    {
        const protocol =  
        {
            userId:window.userId,
            type:ConstValue.REQUEST_IMAGETOLAY_QUERY,
            systemMessage : this.promptData[IMAGETOLAY_SYSTEM_MESSAGE],
            userMessage :this.promptData[IMAGETOLAY_USERMESSAGE],
            content : this.imageBytes.length > 0 ? CONTENT_IMAGE : CONTENT_QUESTION,
            imageByte : this.imageBytes.length == 0 ? null :this.imageBytes,
            question: query
        };

        this.gptProxy.send(protocol);

        var imgStl = `
            width:30px;
            height:30px;
            margin-right:10px;`
        var alignStl = `
            display: flex; 
            align-items:center;`

        var msg_que_ = this.formatString(`
            <b style="margin-top:20px; display:flex;"><h2 style="color : #fff;${alignStl}">
            <img src="Assets/img/ic_login.png"
            style="${imgStl}"/>
            ${this.que_replace(protocol.userId)}:</h2></b>\n<b><h2 style="color : #fff; word-wrap:break-word; padding-right:20px; white-space:pre-wrap;">${this.que_replace(protocol.question)}</h2></b>
            `);

        var msg_answer = this.formatString(`
            <b style="display:flex; margin-top:16px">
            <h2 style="color : #fff; ${alignStl}"><img src="Assets/img/ic_download_01.png"
            style="${imgStl}"/>SpiderVision:</h2></b>
            `);
        
        this.contentView.$ele.append(msg_que_);
        this.contentView.$ele.append(msg_answer);
        this.onDraw_IngPause("요청중...")
        this.questionTf.element.style.height = "73px"
        this.questionTf.setText("")
        this.cnt = this.cnt + 1; // 고유번호를 가지게끔 초기화를 마지막카운트 + 1 로 설정
        this.str = "";
        this.questionTf.enable(false);
        this.submitBtn.enable(false)
        this.imageBytes = [];
        this.contentView.scrollToBottom();    
    }
    //데이터받는함수
    onReceived(jsonObj)
    {
        const protocolType = jsonObj.type;
        switch(protocolType)
        {
            case ConstValue.RESPOND_IMAGETOLAY_QUERY:
                {
                    this.str += jsonObj.token;
                    this.onResultChange(this.str)
                    
                    if(!jsonObj.isResponding) {
                        this.submitBtn.enable(true);
                        this.questionTf.enable(true);
                        this.questionTf.setFocus(true);
                        
                        const resultObj = this.getJson(this.str);
            
                        const parentWidth = this.getContainer().getWidth();
                        const parentHeight = this.getContainer().getHeight();
            
                        const dialog = new ADialog();
                        dialog.setData(resultObj);
                        dialog.open('Source/ConverterView.lay',null,0,0, parentWidth, parentHeight);
                    }
                    break;
                }
        }
    }


    getJson(text) {
        // 정규 표현식을 사용하여 JSON 부분 추출
        const jsonMatch = text.match(/```json\n([\s\S]*?)\n```/);

        if (jsonMatch) {
            const jsonString = jsonMatch[1];
            try {
                return JSON.parse(jsonString);
            } catch (error) {
                console.error("유효한 JSON이 아닙니다.", error);
                return null;
            }
        } else {
            console.log("JSON을 찾을 수 없습니다.");
            return null;
        }
    }


    // 질문내용에 html tag가 존재할때 html로 화면에 보여주는걸 텍스트로 변경
    que_replace(text) {
        var arr = text.split("\n");
        var result = "";
        arr.forEach((data) => {
            var tmp = data.trim();
            result += tmp.replace(/<!--/g, '&lt;')
                         .replace(/-->/g, '&gt;')
                         .replace(/</g, '&lt;')
                         .replace(/>/g, '&gt;')
                         .replace(/{/g, '&#123;')
                         .replace(/}/g, '&#125;');
        result += "\n"
        })
        return result;
    }


    onResultChange(markdownText) {
        // 줄 단위로 분할
        var lines = markdownText.split('\n');
        var currentTag = '';
        var htmlResult = "";

        // 각 줄에 대해 처리
        for (var i = 0; i < lines.length; i++) {
            var line = lines[i].trim();

            // '#' 문자로 시작하는 줄 - 제목 처리
            if (line.startsWith('#')) {
                var level = 0;
                while (line.charAt(level) === '#') {
                    level++;
                }
                var tag = 'h' + level;
                var content = line.substring(level).trim();
                var id = 'section-' + i; // 각 섹션에 고유한 ID 부여

                // HTML 태그로 변환하여 결과에 추가
                htmlResult += '<' + tag + ' id="' + id + '">' + this.onConversion(content) + '</' + tag + '>\n';
                currentTag = tag;
            }
            // '=' 문자로 시작하는 줄 - 제목 처리
            else if (line.startsWith('=') && currentTag === 'h1') {
                var content = lines[i-1].trim(); // 바로 전 줄이 h1 제목일 것으로 가정
                var id = 'section-' + i;

                htmlResult += '<h1 id="' + id + '">' + this.onConversion(content) + '</h1>\n';
                currentTag = 'h1';
            }
            // '-' 문자로 시작하는 줄 - 제목 처리
            else if (line.startsWith('-') && currentTag === 'h2') {
                var content = lines[i-1].trim(); // 바로 전 줄이 h2 제목일 것으로 가정
                var id = 'section-' + i;

                htmlResult += '<h2 id="' + id + '">' + this.onConversion(content) + '</h2>\n';
                currentTag = 'h2';
            }
            // 코드 블록 처리 (``` 또는 ~~~)
            else if (line.startsWith('```') || line.startsWith('~~~')) {
                var language = line.substring(3).trim(); // 언어 이름 추출
                htmlResult += '<pre style="background:#2c2c2c; display:inline-block; padding:20px;"><code>';

                // 코드 블록 내용 추가
                i++; // 다음 줄부터 코드 블록 내용임
                while (i < lines.length && !lines[i].startsWith('```') && !lines[i].startsWith('~~~')) {
                    lines[i] = lines[i].replace(/<!--/g, '&lt;').replace(/-->/g, '&gt;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
                    htmlResult += lines[i] + '\n';
                    i++;
                }
                htmlResult += '</code></pre>\n';
            }
            // 일반 텍스트 - <p> 태그로 처리
            else {
                htmlResult += '<p>' + this.onConversion(line) + '</p>\n';
                currentTag = '';
            }
            this.contentView.$ele.find('#ingPause').remove(); // "답변작성중..." 문자열 제거
            this.contentView.$ele.find(`#test${this.cnt}`).remove(); // 문자열 제거
            this.cnt++;
            this.contentView.$ele.append(`<div id="test${this.cnt}">${this.onTest(htmlResult)}</div>`); // 화면 표시
            this.contentView.scrollToBottom(); // 스크롤 바텀으로 위치이동
        }
        return htmlResult;
    }
    onConversion(txt) {
        return txt.replace(/</g, '&lt;').replace(/>/g, '&gt;')
    }

    onTest(markdownText_) {
        var markdownText = markdownText_;
        // ***??*** 처리
        markdownText = markdownText.replace(/\*\*\*(.*?)\*\*\*/g, '<i>$1</i>')
                                   .replace(/\*\*(.*?)\*\*/g, '<b>$1</b>')
                                   .replace(/\#\#\#\# (.*?)\n/g, '<h3>$1.</h3>\n')
                                   .replace(/\#\#\# (.*?)\n/g, '<h3>$1.</h3>\n')
                                   .replace(/\#\# (.*?)\n/g, '<h2>$1</h2>\n')
                                   .replace(/# (.*?)\n/g, '<h1>$1</h1>\n')
                                   .replace(/-\s(.*?)\n/g, '<li>$1</li>')
                                   .replace(/\*\*(.*?)$/, '<b>$1</b>')
                                   .replace(/\*\*/g, '')
                                   .replace(/\`(.*?)\`/g, '<b>$1</b>');
        return markdownText;
    }

    onConnected(success)
    {
        if(success === false){
            this.onDraw_IngPause("서버와 연결이 끊겼습니다.")
            return;
        }
    }

    onClosed()
    {
        console.log("onclosed")
    }

   	onQuestionTfKeydown(comp, info, e)
	{   
        setTimeout(() => {
            var scrollHeight = this.questionTf.element.scrollHeight;
            
            if(this.questionTf.getText() == "") 
                this.questionTf.element.style.height = "73px"   
            else 
                this.questionTf.element.style.height = `${scrollHeight}px`;
        },10) 
        
        if(e.which !== 13 || e.shiftKey)
            return
            
        const txt = this.getQuestion(e);
        const userId = window.userId;

        if(userId.length === 0){
            this.onDraw_IngPause("ID를 입력해주세요");
            this.contentView.scrollToBottom();
            return;
        }
        if((txt == "" || txt == null) && this.imageBytes.length == 0){
            this.onDraw_IngPause("질문을 입력해주세요.");
            this.contentView.scrollToBottom();
            return;
        }
        this.sendQuery(txt);
	}

    getQuestion(e){
        e.preventDefault(); // 질문 전송 시 줄바꿈현상 제거 
        const question = this.questionTf.getText();
        return question;
    }


    formatString(template, replacements) {
    return template.replace(/{([^}]+)}/g, (match, key) => { 
        return typeof replacements[key] !== 'undefined'
            ? replacements[key]
            : match;
        });
    }

    imageToByte(arrayBuffer) {
        let binary = '';
        const uint8Array = new Uint8Array(arrayBuffer)
        const len = uint8Array.byteLength;
        for (let i = 0; i < len; i++) {
            binary += String.fromCharCode(uint8Array[i]);
        }
        return window.btoa(binary);
    }

	onQuestionTfBlur(comp, info, e)
	{
        const id = this.idTf.getText();
		localStorage.setItem("id", id)
	}

    appendImage(file) {
        const [url, imageByte] = ImageUtil.fileToByte(file);
        this.imageBytes.push(imageByte);
        AViewUtil.addImageToContentView(this.contentView, url,imageByte);
    }

	onAButton2Click(comp, info, e)
	{
        this.fileIp.click();
        this.fileIp.addEventListener('change', (e) => {
            const file = e.target.files[0];
            if(file) {
                this.appendImage(file)
            }
        },{once : true})
    }

	async onQuestionTfPaste(comp, info, e)
	{
        const clipboardData = e.clipboardData;

        if(!ClipboardUtil.containsImage(clipboardData)){
            return;
        }

        const file = ClipboardUtil.getImageFile(clipboardData);
        if(file !== null){
            this.appendImage(file);
        }

        const [url, imageByte] = await ClipboardUtil.getImageData(clipboardData)
        this.imageBytes.push(imageByte);
        await AViewUtil.addImageToContentView(this.contentView, url);                
	}

	onAButton3Click(comp, info, e)
	{
		//TODO:edit here
        setTimeout(() => {
            var scrollHeight = this.questionTf.element.scrollHeight;
            
            if(this.questionTf.getText() == "") 
                this.questionTf.element.style.height = "73px"   
            else 
                this.questionTf.element.style.height = `${scrollHeight}px`;
        },10) 

        const txt = this.questionTf.getText();
        const userId = window.userId;

        if(userId.length === 0){
            this.onDraw_IngPause("ID를 입력해주세요")
            this.contentView.scrollToBottom();
            return;
        }
        if((txt == "" || txt == null) && this.imageBytes.length == 0){
            this.onDraw_IngPause("질문을 입력해주세요.")
            this.contentView.scrollToBottom();
            return;
        }
        this.questionTf.setFocus(true);
        this.sendQuery(txt);
	}

    onDraw_IngPause(txt) {
        this.contentView.$ele.append(`<div id="ingPause"><p><h2>${txt}</h2></p></div>`)
    }

	onIdTfChange(comp, info, e)
	{
        window.userId = this.idTf.getText();
	}

	async onEditPromptBtnClick(comp, info, e)
	{
        const thisObj = this;

        const dialog = new ADialog();
        dialog.setResultCallback(function(result, data){
            thisObj.handleResult(result, data);
        })

        const srcPromptData = await JsonUtil.load(this.promptFilePath);

        const data = {
            srcPromptData : srcPromptData,
            systemMessage : this.promptData[IMAGETOLAY_SYSTEM_MESSAGE],
            userMessage :this.promptData[IMAGETOLAY_USERMESSAGE]
        }

        const container = this.getContainer();
        const parentWidth = container.getWidth();
        const parentHeight = container.getHeight();

        dialog.setData(data);
        dialog.open('Source/PromptEditView.lay',null,10,10, parentWidth - 20, parentHeight -20);
	}

    async handleResult(result, data)
    {
        switch(result)
        {
            // 데이터만 수정
            case 1:
            {
                this.promptData[IMAGETOLAY_SYSTEM_MESSAGE] = data.systemMessage;
                this.promptData[IMAGETOLAY_USERMESSAGE] = data.userMessage;
                break;
            }
            // 데이터 & 파일 수정
            case 2:
            {
                this.promptData[IMAGETOLAY_SYSTEM_MESSAGE] = data.systemMessage;
                this.promptData[IMAGETOLAY_USERMESSAGE] = data.userMessage;

                await JsonUtil.save(this.promptFilePath,this.promptData);
                break;
            }
        }
    }
}