afc.import('Assets/ConstValue.js')


MainView = class MainView extends AView
{
	constructor()
	{
		super()

		//TODO:edit here
	}

	init(context, evtListener)
	{
		super.init(context, evtListener)
	}

	onInitDone()
	{
		super.onInitDone()
        this.mainTabView.selectTabById("SpiderGPTView")
	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)
	}
}

