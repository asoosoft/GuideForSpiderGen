
MainView = class MainView extends AView
{
	constructor()
	{
		super()

		//TODO:edit here
	}

	init(context, evtListener)
	{
		super.init(context, evtListener)
		//TODO:edit here
	}

	onInitDone()
	{
		super.onInitDone()

        this.qmRest = new RestQueryManager('REST');
		this.qmRest.setNetworkIo(new UbHttpIO(this.qmRest));
		this.qmRest.setTimeout(Define.TIMEOUT_SEC);

        this.qmReal = new RealQueryManager('REAL', this);
        this.nio = new WebsocketIO(this.qmReal, true);
        this.qmReal.setNetworkIo(this.nio);
	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)
	}

	onConnectBtnClick(comp, info, e)
	{
		this.qmRest.startManager(Define.SERVER_ADDR_REST);
        this.qmReal.startManager(Define.SERVER_ADDR_WEBSOCKET);
	}

    onConnected(success)
    {
        if(success)
        {
            this.requestMarketData();
        }
    }

    // 종목 데이터 요청
    requestMarketData()
    {
        this.dataGrid.setRealMap('cd');

        const containerId = this.getContainerId();
        this.qmRest.sendProcessByName('rest_market',containerId , null, queryData=>{
            queryData.getBlockData('InBlock1')[0].is_details = true;
        }, queryData=>{
            const outBlock = queryData.getBlockData('OutBlock1');

             const marketNamesArr = Object.values(outBlock)
             .filter(item => item.market.includes('KRW'))
             .map(item=>item.market);

             this.requestTickData(marketNamesArr, containerId);
        });
    }

    // 종목의 tick data 요청
    requestTickData(marketArr , containerId)
    {
        // dataGrid 는 tick data 를 요청하기전에 한번 전체데이터를 요청해서 설정해야 함.
        this.qmRest.sendProcessByName('rest_ticker', containerId, null, queryData=>{
            const block = queryData.getBlockData('InBlock1')[0];
            block.markets = marketArr;
        }, queryData=>
        {
            const outBlock = queryData.getBlockData('OutBlock1');
            outBlock.forEach(item=>{
                 item.cd = item.market
            });

            this.qmReal.registerReal('ticker', 'cd', marketArr, [this.dataGrid], 0);
        });
    }
}

