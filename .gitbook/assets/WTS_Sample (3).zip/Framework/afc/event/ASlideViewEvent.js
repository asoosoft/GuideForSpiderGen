
/**
 * @author asoocool
 */

class ASlideViewEvent extends AEvent
{
	constructor(acomp)
	{
		super(acomp);
	}
}
window.ASlideViewEvent = ASlideViewEvent;




//---------------------------------------------------------------------------------------------------
//	Component Event Functions





//---------------------------------------------------------------------------------------------------
