
MainView = class MainView extends AView
{
	constructor()
	{
		super()

		//TODO:edit here
	}

	init(context, evtListener)
	{
		super.init(context, evtListener)
		//TODO:edit here
	}

	onInitDone()
	{
		super.onInitDone()

        this.qmRest = new RestQueryManager('REST');
		this.qmRest.setNetworkIo(new UbHttpIO(this.qmRest));
		this.qmRest.startManager(Define.SERVER_ADDR_REST);
		this.qmRest.setTimeout(Define.TIMEOUT_SEC);
        this.nio = new WebsocketIO(this, true);
	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)
	}

	onConnectBtnClick(comp, info, e)
	{
        this.nio.startIO(Define.SERVER_ADDR_WEBSOCKET);        
	}

    onConnected(success)
    {
        if(success)
        {
            this.nio.setHeartbeat(null);

            const asyncFunc = async()=> { await this.requestMarketDataAsync() };
            asyncFunc();
        }
    }
    
    async requestMarketDataAsync()
    {
        const containerId = this.getContainerId();
        this.qmRest.sendProcessByName('rest_market',containerId , null, queryData=>{
            queryData.getBlockData('InBlock1')[0].is_details = true;
        });
    }
}

