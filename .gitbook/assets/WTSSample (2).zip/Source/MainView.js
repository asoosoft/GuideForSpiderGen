
MainView = class MainView extends AView
{
	constructor()
	{
		super()

		//TODO:edit here
	}

	init(context, evtListener)
	{
		super.init(context, evtListener)
		//TODO:edit here
	}

	onInitDone()
	{
		super.onInitDone()

        this.qmRest = new RestQueryManager('REST');
		this.qmRest.setNetworkIo(new UbHttpIO(this.qmRest));
		this.qmRest.setTimeout(Define.TIMEOUT_SEC);

        this.qmReal = new RealQueryManager('REAL', this);
        this.nio = new WebsocketIO(this.qmReal, true);
        this.qmReal.setNetworkIo(this.nio);

        this.marketCode = null;
	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)
	}

	onConnectBtnClick(comp, info, e)
	{
		this.qmRest.startManager(Define.SERVER_ADDR_REST);
        this.qmReal.startManager(Define.SERVER_ADDR_WEBSOCKET);
	}

    onConnected(success)
    {
        if(success)
        {
            this.requestMarketData();
        }
    }

    // 종목 데이터 요청
    requestMarketData()
    {
        this.dataGrid.setRealMap('cd');

        const containerId = this.getContainerId();
        this.qmRest.sendProcessByName('rest_market',containerId , null, queryData=>{
            queryData.getBlockData('InBlock1')[0].is_details = true;
        }, queryData=>{
            const outBlock = queryData.getBlockData('OutBlock1');

             const marketNamesArr = Object.values(outBlock)
             .filter(item => item.market.includes('KRW'))
             .map(item=>item.market);

             this.requestTickData(marketNamesArr, containerId);
        });
    }

    // 종목의 tick data 요청
    requestTickData(marketArr , containerId)
    {
        // dataGrid 는 tick data 를 요청하기전에 한번 전체데이터를 요청해서 설정해야 함.
        this.qmRest.sendProcessByName('rest_ticker', containerId, null, queryData=>{
            const block = queryData.getBlockData('InBlock1')[0];
            block.markets = marketArr;
        }, queryData=>
        {
            const outBlock = queryData.getBlockData('OutBlock1');
            outBlock.forEach(item=>{
                 item.cd = item.market
            });

            this.qmReal.registerReal('ticker', 'cd', marketArr, [this.dataGrid]);
        });
    }

    onDataGridSelect(comp, info, e)
	{   
        const selData = comp.getSelectedData();
        const marketCode = selData[0].text;

        (async()=>{
            
            // 기존 업데이트 대상 취소처리
            if(this.marketCode)
            {
                this.qmReal.unregisterReal('ticker', [this.marketCode], [this.candleChart]);
            }

            await this.updateChart(marketCode);
            this.marketCode = marketCode;
        })();         
	}

    async updateChart(marketCode)
    {
        this.candleChart.resetData();

        const thisMarketCode = marketCode;

        this.qmRest.sendProcessByName('rest_minutes', this.getContainerId(), null, queryData=>
        {
            const inBlock = queryData.getBlockData('InBlock1')[0];
            inBlock.market = thisMarketCode;
            inBlock.count = 200;
        }, queryData =>{
            const outBlock = queryData.getBlockData('OutBlock1');
            if(!outBlock.length)
            {
                this.candleChart.nextIqryData = null;
                return;
            }

            for(let block of outBlock)
            {
                block.dateStr = block.candle_date_time_kst.replace(/[^0-9]/g, '').substring(0,8);
            }
            
            this.candleChart.nextIqryDate = outBlock[outBlock.length-1].candle_date_time_utc;

            // 새로운 실시간 업데이트 처리
            this.qmReal.registerReal('ticker', 'cd', [thisMarketCode], [this.candleChart], 0, queryData => {
                        let data = queryData.getBlockData('OutBlock1')[0];
                        data.DummyField = new Date(data.tms).format('yyyyMMdd');
                    });
        });
    }
}




















