
MainView = class MainView extends AView
{
	constructor()
	{
		super()

		//TODO:edit here
	}

	init(context, evtListener)
	{
		super.init(context, evtListener)
		//TODO:edit here
	}

	onInitDone()
	{
		super.onInitDone()

		this.upBitProxy = new UpbitProxy();
	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)
	}

	onConnectBtnClick(comp, info, e)
	{
        this.upBitProxy.connect(this);
	}

    onConnected(success)
    {
        if(success)
        {
            this.requestMarketDataAsync();
        }
    }
    
    async requestMarketDataAsync()
    {
        const marketDataArr = await this.upBitProxy.sendAsync('market/all?is_details=true');

        let marketNames = '';
        for(let marketData of marketDataArr)
        {
            marketNames += marketData.market + '\n';
        }

        this.resultTextArea.setText(marketNames);
    }

}

