
/**
 * @author asoocool
 */

class ASplitViewEvent extends AEvent
{
	constructor(acomp)
	{
		super(acomp);
	}
}
window.ASplitViewEvent = ASplitViewEvent;




//---------------------------------------------------------------------------------------------------
//	Component Event Functions





//---------------------------------------------------------------------------------------------------
