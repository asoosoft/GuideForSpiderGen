UpbitProxy = class UpbitProxy 
{
    constructor()
    {
        this.symbolDataArr = [];
        this.socket = null;
        this.handler = null;
    }

    connect(handler)
    {
        this.socket = new WebsocketIO(this, true)
        this.socket.startIO(Define.SERVER_ADDR_WEBSOCKET)
        this.handler = handler;
    }

    onConnected(success)
    {
        this.handler.onConnected(success);
    }

    async sendAsync(url)
    {
        try {
            const response = await fetch(`${Define.SERVER_ADDR_REST}${url}`);
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            const data = await response.json();            
            console.log(data);
            return data;
        } catch (error) {            
            throw error;
        }    
    }
}