var Define = {
    SERVER_ADDR_REST : 'https://api.upbit.com/v1/',
    SERVER_ADDR_WEBSOCKET : 'api.upbit.com/websocket/v1',
}    